module.exports = require('./../lib/redux/reducers/index');
