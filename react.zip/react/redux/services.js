module.exports = require('./../lib/redux/services/index');
