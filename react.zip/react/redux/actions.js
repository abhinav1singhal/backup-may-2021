module.exports = require('./../lib/redux/actions/index');
