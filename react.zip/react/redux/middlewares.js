module.exports = require('./../lib/redux/middlewares/index');
