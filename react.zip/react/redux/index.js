module.exports = require('./../lib/redux/index');
