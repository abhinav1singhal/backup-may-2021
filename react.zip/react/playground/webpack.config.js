/* eslint-disable no-var */

var path = require('path');
var merge = require('merge');
var webpack = require('webpack');
var ExtractTextPlugin = require('extract-text-webpack-plugin');
var CompressionPlugin = require('compression-webpack-plugin');

var defaultConfig = {
  resolve: {
    modules: [ 'node_modules', 'app' ],
    extensions: ['*', '.js'],
  },
};

module.exports.development = merge({
  cache: true,
  stats: {
    colors: true,
    reasons: true
  },
  devtool: '#inline-source-map',
  entry: './app/main',
  output: {
    path: path.join(__dirname, 'dist/assets/'),
    filename: 'main.js',
    sourcePrefix: '  '
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: ['babel-loader']
      },
      {
        test: /\.css$/,
        include: /FixedDataTable2/,
        use: ExtractTextPlugin.extract({
          fallback: 'style-loader',
          use: [
            {
              loader: 'css-loader',
              options: {
                sourceMap: true,
                importLoaders: 1,
                localIdentName: '[name]__[local]___[hash:base64:5]'
              }
            }
          ]
        })
      },
      {
        test: /\.css$/,
        exclude: /FixedDataTable2/,
        use: ExtractTextPlugin.extract({
          fallback: 'style-loader',
          use: [
            {
              loader: 'css-loader',
              options: {
                sourceMap: true,
                modules: true,
                importLoaders: 1,
                localIdentName: '[name]__[local]___[hash:base64:5]'
              }
            },
            'postcss-loader'
          ]
        })
      },
      {
        test: /\.(png|jpeg|jpg|gif)$/,
        loader: 'url-loader?limit=10000'
      },
      {
        test: /\.(otf|eot|svg|ttf|woff|woff2)$/,
        loader: 'file-loader'
      }
    ]
  },
  plugins: [
    new ExtractTextPlugin('main.css'),
    new webpack.DefinePlugin({
      __DEVTOOLS__: false
    }),
    new webpack.LoaderOptionsPlugin({
      debug: true
    })
  ]
}, defaultConfig);

module.exports.hotDevelopment = merge({
  cache: true,
  devtool: 'eval',
  stats: {
    colors: true,
    reasons: true
  },
  entry: [
    'webpack-hot-middleware/client',
    './app/main' // Your appʼs entry point
  ],
  output: {
    path: path.join(__dirname, 'dist'),
    filename: 'main.js',
    publicPath: '/assets/',
    sourcePrefix: '  '
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: ['babel-loader']
      },
      {
        test: /\.css$/,
        include: /FixedDataTable2/,
        use: [
          'style-loader',
          {
            loader: 'css-loader',
            options: {
              sourceMap: true,
              localIdentName: '[name]__[local]___[hash:base64:5]',
              importLoaders: 1
            },
          }
        ]
      },
      {
        test: /\.css$/,
        exclude: /FixedDataTable2/,
        use: [
          'style-loader',
          {
            loader: 'css-loader',
            options: {
              sourceMap: true,
              modules: true,
              importLoaders: 1,
              localIdentName: '[name]__[local]___[hash:base64:5]'
            }
          },
          'postcss-loader'
        ]
      },
      {
        test: /\.(png|jpeg|jpg|gif)$/,
        loader: 'url-loader?limit=100000'
      },
      {
        test: /\.(otf|eot|svg|ttf|woff|woff2)$/,
        loader: 'url-loader?limit=100000'
      }
    ]
  },
  plugins: [
    new ExtractTextPlugin('main.css'),
    new webpack.HotModuleReplacementPlugin(),
    new webpack.NoEmitOnErrorsPlugin(),
    new webpack.DefinePlugin({
      __DEVTOOLS__: true
    }),
    new webpack.LoaderOptionsPlugin({
      debug: true
    })
  ]
}, defaultConfig);

module.exports.production = merge({
  debug: false,
  entry: './app/main', // Your appʼs entry point
  output: {
    path: path.join(__dirname, 'dist/assets/'),
    filename: 'main.js',
    sourcePrefix: '  '
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: ['babel-loader']
      },
      {
        test: /\.css$/,
        include: /FixedDataTable2/,
        use: ExtractTextPlugin.extract({
          fallback: 'style-loader',
          use: [
            {
              loader: 'css-loader',
              options: {
                minimize: true,
                sourceMap: true,
                importLoaders: 1,
                localIdentName: '[hash:base64:7]'
              }
            }
          ]
        })
      },
      {
        test: /\.css$/,
        exclude: /FixedDataTable2/,
        use: ExtractTextPlugin.extract({
          fallback: 'style-loader',
          use: [
            {
              loader: 'css-loader',
              options: {
                minimize: true,
                sourceMap: true,
                modules: true,
                importLoaders: 1,
                localIdentName: '[hash:base64:7]'
              }
            },
            'postcss-loader'
          ]
        })
      },
      {
        test: /\.(png|jpeg|jpg|gif)$/,
        loader: 'url-loader?limit=10000'
      },
      {
        test: /\.(otf|eot|svg|ttf|woff|woff2)$/,
        loader: 'file-loader'
      }
    ]
  },
  plugins: [
    new ExtractTextPlugin('main.css'),
    new webpack.DefinePlugin({
      'process.env': { NODE_ENV: JSON.stringify('production') },
      __DEVTOOLS__: false
    }),
    new webpack.optimize.UglifyJsPlugin({
      compress: {
        warnings: false
      }
    }),
    new CompressionPlugin({
      asset: '{file}.gz',
      algorithm: 'gzip',
      regExp: /\.js$|\.css/,
      minRatio: 1
    })
  ]
}, defaultConfig);
