import http from 'http';
import express from 'express';
import gutil from 'gulp-util';
import morgan from 'morgan';
import url from 'url';
import {
  PORT,
  distPath
} from '../config';

export default function() {
  return () => {
    const server = express();

    // log all requests to the console
    server.use(morgan('dev'));
    server.use(express.static(distPath));

    // Serve index.html for all routes to leave routing up to frontend
    server.all('/*', function serve(req, res) {
      res.sendFile('index.html', {root: distPath});
    });

    // Start webserver if not already running
    const s = http.createServer(server);
    s.on('error', function onErrorHandler(err) {
      if (err.code === 'EADDRINUSE') {
        gutil.log(`Development server is already started at port ${PORT}`);
      } else {
        throw err;
      }
    });

    s.listen(PORT);
  };
}
