import lintDeps from 'moodys-lint-deps';
import { packagePath } from '../config';

export default function() {
  lintDeps(packagePath);
}
