import del from 'del';
import { distPath } from '../config';

export default function() {
  return del([distPath], { force: true });
}
