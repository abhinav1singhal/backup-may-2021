import browserSync from 'browser-sync';
import webpack from 'webpack';

export default function(watch, webpackConfig) {
  return function(cb) {
    const bundler = webpack(webpackConfig);
    let started = false;

    function bundle(err) {
      if (err) {
        throw new Error('Webpack build error');
      }
      if (!started) {
        started = true;
        return cb();
      }
      if (watch && browserSync.active) {
        browserSync.reload({once: true});
      }
    }

    if (watch) {
      bundler.watch(100, bundle);
    } else {
      bundler.run(bundle);
    }
  };
}
