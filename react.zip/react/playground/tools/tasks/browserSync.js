import browserSync from 'browser-sync';
import { PORT } from '../config';

export default function() {
  browserSync({
    proxy: `localhost:${PORT}`
  });
}
