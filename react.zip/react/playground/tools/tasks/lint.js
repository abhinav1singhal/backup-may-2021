import gulp from 'gulp';
import eslint from 'gulp-eslint';
import { appPath } from '../config';

export default function() {
  return gulp.src([
    appPath + '/**/*.js',
    appPath + '/**/*.jsx'
  ])
    .pipe(eslint())
    .pipe(eslint.format())
    .pipe(eslint.failAfterError());
}
