import gutil from 'gulp-util';
import express from 'express';
import morgan from 'morgan';
import webpack from 'webpack';
import url from 'url';
import proxy from 'http-proxy-middleware';
import {
  PORT,
  distPath
} from '../config';

export default function(webpackConfig) {
  return () => {

    const app = express();
    const compiler = webpack(webpackConfig);

    // log all requests to the console
    app.use(morgan('dev'));

    app.use(proxy('/api', {
      target: 'http://localhost:9091/fileuploader-service/',
      ws: true
    }));

    app.use(require('webpack-dev-middleware')(compiler, {
      noInfo: true,
      publicPath: webpackConfig.output.publicPath
    }));

    app.use(require('webpack-hot-middleware')(compiler));

    app.get('*', (req, res) => {
      res.sendFile('index.html', { root: distPath });
    });

    app.listen(PORT, 'localhost', (err) => {
      if (err) {
        if (err.code === 'EADDRINUSE') {
          gutil.log(`Development server is already started at port ${PORT}`);
        } else {
          throw err;
        }
      }
      gutil.log(`Listening at http://localhost:${PORT}`);
    });

  };
}
