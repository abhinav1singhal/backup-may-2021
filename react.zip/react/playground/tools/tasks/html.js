import gulp from 'gulp';
import size from 'gulp-size';
import { appPath, distPath } from '../config';

export default function() {
  return gulp.src(appPath + '/index.html')
    .pipe(gulp.dest(distPath))
    .pipe(size({
      title: 'html'
    }));
}
