import path from 'path';
import gutil from 'gulp-util';

const appPath = path.resolve(__dirname, '../app');
const distPath = path.resolve(__dirname, '../dist');
const packagePath = path.resolve(__dirname, '../package.json');
const webpackConfigPath = path.resolve(__dirname, '../webpack.config.js');
const PORT = gutil.env.port || 3333;

export {
  appPath,
  distPath,
  packagePath,
  webpackConfigPath,
  PORT
};
