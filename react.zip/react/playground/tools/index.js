import gulp from 'gulp';
import gutil from 'gulp-util';
import runSequence from 'run-sequence';
import { appPath, packagePath, webpackConfigPath, PORT } from './config';

/**
 * Tasks
 */

import cleanTask from './tasks/clean';
import lintTask from './tasks/lint';
import lintDepsTask from './tasks/lint-deps';
import htmlTask from './tasks/html';
import webpackTask from './tasks/webpack';
import browserSyncTask from './tasks/browserSync';
import serverTask from './tasks/server';
import hotServerTask from './tasks/serverHot';
import open from 'open';

// set variable via $ gulp --type production
const environment = gutil.env.type || 'development';
const webpackConfig = require(webpackConfigPath)[environment];

gulp.task('lint', lintTask);
gulp.task('lint-deps', lintDepsTask);

// remove dist folder
gulp.task('clean', cleanTask);

// copy html from app to dist
gulp.task('html', htmlTask);

gulp.task('webpack', webpackTask(false, webpackConfig));
gulp.task('webpack-watch', webpackTask(true, webpackConfig));
gulp.task('browserSync', browserSyncTask);
gulp.task('server', serverTask());
gulp.task('serverHot', hotServerTask(require(webpackConfigPath)['hotDevelopment'])); // eslint-disable-line dot-notation

gulp.task('watch', () => {
  gulp.watch(appPath + '/index.html', ['html']);
  gulp.watch([
    appPath + '/**/*.js',
    appPath + '/**/*.jsx'
  ], ['lint']);
  gulp.watch(packagePath, [ 'lint-deps' ]);
});

gulp.task('build', (cb) => {
  runSequence('clean', 'lint-deps', 'lint', ['html', 'webpack'], cb);
});

gulp.task('build:watch', (cb) => {
  runSequence('clean', 'lint-deps', 'lint', ['html', 'webpack-watch'], cb);
});

gulp.task('open', () => {
  open('http://localhost:' + PORT);
});

gulp.task('sync', (cb) => {
  runSequence('build:watch', 'server', 'browserSync', 'watch', cb);
});

gulp.task('hot', (cb) => {
  runSequence('clean', 'lint-deps', ['html', 'serverHot'], 'open', cb);
});

// by default build project and then watch files in order to trigger livereload
gulp.task('default', [ 'hot' ]);
