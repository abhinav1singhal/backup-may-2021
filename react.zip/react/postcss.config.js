module.exports = {
  ident: 'remove this and it fails',
  plugins: {
    'postcss-import': {},
    'postcss-nested': {},
    'postcss-simple-vars': {
      variables: function requireVariables() {
        return require('./src/variables.js');
      }
    },
    'postcss-simple-extend': {},
    'postcss-discard-comments': {},
    'postcss-discard-empty': {},
    'postcss-media-minmax': {},
    'autoprefixer': {
      browsers: [
        'last 2 versions'
      ]
    }
  }
};
