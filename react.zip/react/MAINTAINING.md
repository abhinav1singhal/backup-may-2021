# Maintaining React-Moodys

This document is for people working on React-Moodys. It describes common
tasks such as triaging or merging pull requests.

If you are interested in contributing to React-Moodys, you should check out
the [Contributing Guide](./CONTRIBUTING.md).

## Merging a pull request

Please, make sure:

- At least one collaborator (other than you) approves the PR
  - Commenting "LGTM" (Looks good to me) or something of similar sorts is
    sufficient.
  - If it's a simple docs change or a typo fix, feel free to skip this step.
- Commits follow the convention prescribed in the [Contributing
  Guide](./CONTRIBUTING.md).
  - This is very important, because the release process uses this to generate
    the [changelog](./CHANGELOG.md).
  - Commits are squashed. Each change is a single commit.
    - e.g. if the PR contains two changes such as `[fixed] Some Bug` and then
      `[fixed] Some other unrelated bug` it should be two separate changes.
    - e.g. if the first commit is `[fixed] Some bug` and the second commit is
      `[fixed] failing tests for previous commit`, you should squash them into a
      single commit
  - It's alright to ask the author of the pull request to fix any of the above.

## Releases

Releases should include documentation and
finally the actual npm module publish. We have all of this automated by running
`./tools/release` from the root of the repository. __PLEASE DO NOT RUN `npm
publish` BY ITSELF__.

Example usages of the release script:

```bash
$ ./tools/release patch
$ ./tools/release minor
$ ./tools/release major
$ ./tools/release minor --preid beta
```

Note that the above commands will bump the [semver](http://semver.org) version
programmatically so you don't need to. Please be mindful to ensure that semver
guidelines are followed. If it is discovered that we have pushed a release in
violation of semver, than a patch release reverting the offending change should
be pushed as soon as possible to correct the error. The offending change can
then be re-applied and released with the proper version bump.

### Release Candidates

In an effort to reduce the frequency with which we introduce breaking changes we
should do our best to first push deprecation warnings in a Minor release. Also,
Pull Requests with breaking changes should be submitted against the `vX-rc`
branch, where X is the next Major version. Which we will in turn release as an
`alpha` release of the next Major version. When we are ready to release the next
Major version bump we will merge the `vX-rc` branch into the `master` branch and
cut a `beta` release.  Once bugs have been addressed with the `beta` release
then we will release the Major version bump.
