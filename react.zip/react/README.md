# react-moodys

Moodys components built with [React][react]

## Docs

See the documentation with live editable examples.

## Local Setup

- Install the dependencies with `npm install`
- Run tests:
  - `npm run test` - single run
  - `npm run test:coverage` - single run with coverage report
  - `npm run test:watch` - watch mode, run on every file change
  - `npm run test:ci` - run with reports for CI
- Build with `npm run build`

## Changelog

See [Changelog][changelog] for details.

## Contributions

Yes please! See the [contributing guidelines][contributing] for details.

[bootstrap]: http://getbootstrap.com
[react]: http://facebook.github.io/react/

## Exclude files

```bash
node_modules
.test-report
npm-debug.log
```
