import moment from 'moment';
import { isArray, negate } from 'lodash';

export function isEmpty(value) {
  return value === null || value === undefined || value.length === 0 || value === false;
}

export function isValidNumber(value) {
  return !isNaN(Number(value));
}

export function isEmptyObject(value) {
  return Object.keys(value).every((key) => isEmpty(value[key]));
}

export const notEmptyObject = negate(isEmptyObject);

export const VALIDATORS = {
  REQUIRED: (value) => !isEmpty(value),
  NUMBER: (value) => isValidNumber(value),
  MAX: ({ max }) => (value) => value <= max,
  MIN: ({ min }) => (value) => value >= min,
  MAXLENGTH: ({ maxLength }) => (value) => value.length <= maxLength,
  MINLENGTH: ({ minLength }) => (value) => value.length >= minLength,
  INTEGER: (value) => /^(0|-?[1-9]\d*)$/.test(String(value)),
  FROM_BEFORE_TO: ({ from, to }) => !from || !to || moment(from).isSameOrBefore(to),
  ONE_ITEM_REQUIRED: (value) => isArray(value) && value.filter(notEmptyObject).length > 0,
  EMAIL: (value) => /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i.test(value),
  NAME_VALIDATOR: (value) => !value || /^[a-zA-Z0-9_\-\.]+$/.test(value) && value.length <= 60 && !value.includes('..')
};

export const VALIDATOR_MESSAGES = {
  REQUIRED: () => 'Please fill in all required fields.',
  NUMBER: (fieldKey) => `${fieldKey} must be a number.`,
  MAX: (fieldKey, error) => `${fieldKey} must be less than or equal to ${error.max}.`,
  MIN: (fieldKey, error) => `${fieldKey} must be greater than or equal to ${error.min}.`,
  MAXLENGTH: (fieldKey, error) => `${fieldKey} length must be less than or equal to ${error.maxLength}.`,
  MINLENGTH: (fieldKey, error) => `${fieldKey} length must be greater than or equal to ${error.minLength}.`,
  INTEGER: (fieldKey) => `${fieldKey} must be integer.`,
  FROM_BEFORE_TO: (fieldKey) => `${fieldKey} From shouldn’t be greater than ${fieldKey} To`,
  ONE_ITEM_REQUIRED: (fieldKey) => `Please add at least one ${fieldKey}.`,
  EMAIL: () => 'Email is invalid',
  UNEXPECTED: () => 'An unexpected error occurred.'
};
