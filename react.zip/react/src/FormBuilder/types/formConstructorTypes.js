import { PropTypes } from 'react';
import { values } from 'lodash';
import FormControl from '../components/FormControl';

// ToDo: extract this to utils
export const FORM_CONTROL_TYPES = {
  INPUT: 'INPUT', // ToDo: remove this type
  TEXT: 'TEXT',
  NUMBER: 'NUMBER',
  TEXTAREA: 'TEXTAREA',
  SELECT: 'SELECT',
  CHECKBOX: 'CHECKBOX',
  MULTISELECT: 'MULTISELECT',
  TEXTAREA_LIMITED: 'TEXTAREA_LIMITED',
  CHECKBOX_GROUP: 'CHECKBOX_GROUP',
  RADIO_GROUP: 'RADIO_GROUP',
  DATE_RANGE: 'DATE_RANGE',
  TEXT_FIELD: 'TEXT_FIELD',
  FILE: 'FILE',
  FIELD_LIST: 'FIELD_LIST',
  DATE_PICKER: 'DATE_PICKER',
  SELECT_RANGE: 'SELECT_RANGE',
  TREEVIEW_SELECT: 'TREEVIEW_SELECT',
  TREEVIEW_MULTISELECT: 'TREEVIEW_MULTISELECT'
};

export const formControlType = PropTypes.shape({
  key: PropTypes.string.isRequired,
  type: PropTypes.oneOfType([
    PropTypes.oneOf(values(FORM_CONTROL_TYPES)),
    (props, name, componentName) => {
      if (!props[name] || !(props[name].prototype instanceof FormControl)) {
        return new Error(`Invalid prop ${name} supplied to ${componentName}.`);
      }
      return null;
    }
  ]).isRequired,
  label: PropTypes.string,
  required: PropTypes.bool,
  disabled: PropTypes.bool
});

export const formControlListType = PropTypes.arrayOf(formControlType);
