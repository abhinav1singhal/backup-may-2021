import { PropTypes } from 'react';

export const pageType = PropTypes.shape({
  number: PropTypes.number,
  size: PropTypes.number,
  totalPages: PropTypes.number,
  totalElements: PropTypes.number
});
