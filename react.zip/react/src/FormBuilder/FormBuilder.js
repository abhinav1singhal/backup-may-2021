import React, { PropTypes } from 'react';
import classNames from 'classnames';
import { isString, pickBy, isPlainObject, noop } from 'lodash';

const theme = {};

import { formControlListType } from './types';

/**
 * ToDo:
 *  - display errors only after submit ?
 *  - display errors after change + blur ???
 * */

class FormBuilder extends React.Component {
  static propTypes = {
    controls: formControlListType.isRequired,
    data: PropTypes.object.isRequired,
    options: PropTypes.object.isRequired,
    onChange: PropTypes.func.isRequired,
    onOpen: PropTypes.func.isRequired,
    onClose: PropTypes.func.isRequired,
    validate: PropTypes.func.isRequired,
    fieldsErrors: PropTypes.object.isRequired,
    submitted: PropTypes.bool,
    disabled: PropTypes.oneOfType([
      PropTypes.bool,
      PropTypes.object
    ]),
    errorWrapperType: PropTypes.string,
    isFieldLevelError: PropTypes.func.isRequired,
    validatorMessages: PropTypes.object.isRequired,
    errorIconShown: PropTypes.bool,
    setRef: PropTypes.func.isRequired,
    disabledForm: PropTypes.bool,
    controlTypes: PropTypes.object.isRequired,
    customFieldLabel: PropTypes.func,
    controlWrapper: PropTypes.func,
    theme: PropTypes.shape({
      root: PropTypes.string,
      controlGroup: PropTypes.string,
      controlWrapper: PropTypes.string,
      controlLabel: PropTypes.string
    }).isRequired
  };

  // TODO: why name doesn't work
  static componentName = 'FormConstructor';

  render() {
    const {
      controls, data, options, onChange, onOpen, onClose, submitted,
      disabled, theme: customTheme, validate, fieldsErrors,
      isFieldLevelError, validatorMessages, errorIconShown, setRef,
      disabledForm, customFieldLabel
    } = this.props;

    return (
      <div className={classNames(theme.root, customTheme.root)}>
        {controls.map((item) => {
          let type;
          let Control;
          if (isString(item.type)) {
            type = item.type.toUpperCase();
            Control = this.props.controlTypes[type]; // ToDo: add warning message if control does not exists
          } else {
            type = item.type.name;
            Control = item.type;
          }
          if (!Control) {
            return null;
          }
          const itemTheme = item.theme || {};

          const disabledField = isPlainObject(disabled) ? (disabledForm || disabled[item.key] || item.disabled) : (disabled || item.disabled);

          const controlProps = {
            type,
            name: item.key,
            value: data[item.key],
            onChange: (value) => onChange(item.key, value),
            onOpen: () => onOpen(item.key),
            onClose: () => onClose(item.key),
            validate,
            errors: pickBy(fieldsErrors, (value, key) => key.startsWith(item.key)),
            options: options[item.key] || options,
            validators: item.validators,
            label: item.label,
            bsSize: item.bsSize,
            disabled: disabledField,
            required: item.required,
            multi: item.multi,
            valueKey: item.valueKey,
            labelKey: item.labelKey,
            placeholder: item.placeholder,
            submitted,
            errorWrapperType: this.props.errorWrapperType,
            isFieldLevelError,
            validatorMessages,
            errorIconShown,
            formatter: item.formatter,
            accept: item.accept, // TODO: maybe spread item to avoid passing unnecessary props, or pass props by 'type'
            clearable: item.clearable,
            itemType: item.itemType,
            addText: item.addText,
            canRemoveLast: item.canRemoveLast,
            customLabel: customFieldLabel,
            theme: {
              group: classNames(theme.controlGroup, customTheme.controlGroup, itemTheme.controlGroup),
              wrapper: classNames(theme.controlWrapper, customTheme.controlWrapper, itemTheme.controlWrapper),
              label: classNames(theme.controlLabel, customTheme.controlLabel, itemTheme.controlLabel),
              errorMessages: classNames(theme.controlErrorMessages, customTheme.controlErrorMessages),
              addWrapper: classNames(theme.addWrapper, customTheme.addWrapper),
              required: classNames(customTheme.required),
              requiredWrapper: customTheme.requiredWrapper
            },
            ref: (control) => setRef(control, item.key),
            key: `FormBuilder-${item.type}-${item.key}`
          };

          if (this.props.controlWrapper) {
            return this.props.controlWrapper(controlProps, Control);
          }

          return <Control {...controlProps} />;
        })}
      </div>
    );
  }
}

FormBuilder.defaultProps = {
  data: {},
  options: {},
  theme: {},
  onChange: () => {},
  validate: () => {},
  onOpen: noop,
  onClose: noop,
  controls: []
};

export default FormBuilder;
