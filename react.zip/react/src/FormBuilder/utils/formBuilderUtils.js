import { isString, isPlainObject, isArray, isFunction, isEqual, omit, union, isNil, isBoolean } from 'lodash';
import { VALIDATORS, isEmpty, isEmptyObject } from '../validators';
import { FORM_CONTROL_TYPES } from '../types/formConstructorTypes';

export function shouldUpdateValidators(props, previousProps) {
  return (
    previousProps.type !== props.type || previousProps.required !== props.required ||
    !isEqual(previousProps.validators, props.validators)
  );
}

export function shouldUpdateFormControl(props, state, prevProps, prevState) {
  const omitted = ['theme', 'validate', 'onChange', 'validators', 'setRef', 'errors'];
  return (
    !isEqual(omit(prevProps, omitted), omit(props, omitted)) ||
    !isEqual(prevProps.theme, props.theme) || !isEqual(prevState, state) ||
    !isEqual(prevProps.errors, props.errors)
  );
}

export function prepareValidators({type, validators = []}) {
  const result = [];

  function addValidator(name, item = {}) {
    const key = name.toUpperCase();
    if (isFunction(VALIDATORS[key])) {
      result.push({
        ...item,
        key,
        validate: isEqual(item, {}) ? VALIDATORS[key] : VALIDATORS[key](item)
      });
    }
  }

  addValidator(type);

  validators.forEach((item) => {
    if (isString(item)) {
      addValidator(item);
    } else if (isPlainObject(item) && isString(item.key)) {
      addValidator(item.key, item);
    }
  });

  return result;
}

export function validate(validators, value, required) {
  if (required && isEmpty(value)) {
    return [{ key: 'REQUIRED' }];
  }
  if (isNil(value) || value === '') {
    return [];
  }

  const errors = [];
  validators.forEach((validator) => {
    if (!validator.validate(value)) {
      errors.push(omit(validator, 'validate'));
    }
  });

  return errors;
}

export function isValidField(errors) {
  return isEmpty(errors);
}

export function prepareErrorMessage(validatorMessages, error, fieldLabel) {
  const messageGetter = validatorMessages[error.key];

  return isFunction(messageGetter) ?
    messageGetter(fieldLabel, error) :
    validatorMessages.UNEXPECTED();
}

export function isValidForm(fieldsErrors, errors) {
  if (!isEmpty(errors)) {
    return false;
  }

  return Object.keys(fieldsErrors).every((fieldKey) => isEmpty(fieldsErrors[fieldKey]));
}

export const ERROR_WRAPPER_TYPES = {
  POPOVER: 'popoverWrapper',
  LIST: 'listWrapper'
};

export function isDataEqual(data, savedData) {
  const keys = union(Object.keys(data), Object.keys(savedData));

  return keys.every((key) => isEmpty(data[key]) && isEmpty(savedData[key]) || isEqual(data[key], savedData[key]));
}

export function findFirstNotEmpty(data) {
  return data.findIndex((item) => item && !isEmptyObject(item));
}

export function isTreeSelect(type) {
  return type === FORM_CONTROL_TYPES.TREEVIEW_MULTISELECT || type === FORM_CONTROL_TYPES.TREEVIEW_SELECT;
}

export function isSelect(type) {
  return type === FORM_CONTROL_TYPES.SELECT || type === FORM_CONTROL_TYPES.MULTISELECT;
}

export function getControlsList(config) {
  if (isArray(config)) {
    return config;
  }
  if (isPlainObject(config)) {
    return Object.values(config).reduce((acc, cur) => acc.concat(getControlsList(cur)), []);
  }
  return [];
}

export function getDisabledMap(config, options, optionlessSelectsDisabled = true) {
  const res = {};
  getControlsList(config).forEach((item) => {
    if (optionlessSelectsDisabled && (isTreeSelect(item.type) || isSelect(item.type))) {
      res[item.key] = item.disabled || isEmpty(options[item.key]);
    } else if (isBoolean(item.disabled)) {
      res[item.key] = item.disabled;
    }
  });
  return res;
}
