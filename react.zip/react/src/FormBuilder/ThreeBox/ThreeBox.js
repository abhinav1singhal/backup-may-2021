import React, { PropTypes } from 'react';
import classNames from 'classnames';
import { noop } from 'lodash';
import Icon from '../../Icon';

import theme from './ThreeBox.css';

class ThreeBox extends React.Component {
  static propTypes = {
    checked: PropTypes.bool,
    intermediate: PropTypes.bool,
    label: PropTypes.node,

    disabled: PropTypes.bool,
    onChange: PropTypes.func.isRequired,

    className: PropTypes.string,
    theme: PropTypes.shape({
      root: PropTypes.string,
      label: PropTypes.string,
      box: PropTypes.string,
      input: PropTypes.string,
      disabled: PropTypes.string
    }).isRequired
  };

  onChange = () => {
    const { intermediate, checked } = this.props;
    const newValue = intermediate || !checked;
    this.props.onChange(newValue);
  }

  setInputRef = (input) => {
    this.input = input;
  }

  focus() {
    this.input.focus();
  }

  render() {
    const { theme: customTheme, className, label, intermediate, checked, disabled } = this.props;

    const rootClassName = classNames(theme.root, customTheme.root, className, {
      [theme.disabled]: disabled,
      [customTheme.disabled]: disabled
    });
    const labelClassName = classNames(theme.label, customTheme.label);
    const inputClassName = classNames(theme.input, customTheme.input);

    const iconProps = {
      className: classNames(theme.box, customTheme.box),
      type: checked ? 'checkbox-checked' : 'checkbox'
    };
    if (intermediate) {
      iconProps.type = 'checkbox-intermediate';
    }
    const inputProps = {
      ref: this.setInputRef,
      type: 'checkbox',
      className: inputClassName,
      disabled,
      onChange: this.onChange
    };

    return (
      <div className={rootClassName}>
        <Icon {...iconProps} />
        <input {...inputProps} />
        <div className={labelClassName}>{label}</div>
      </div>
    );
  }
}

ThreeBox.defaultProps = {
  theme: {},
  onChange: noop
};

export default ThreeBox;
