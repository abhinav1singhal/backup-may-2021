import React, { PropTypes } from 'react';
import classNames from 'classnames';
import { remove, includes } from 'lodash';
import { Checkbox } from '../../../CheckboxRadio';

import FormControl from '../FormControl';

class CheckboxGroup extends FormControl {
  static propTypes = {
    ...FormControl.propTypes,
    value: PropTypes.array.isRequired,
    options: PropTypes.arrayOf(PropTypes.object).isRequired
  };

  constructor(props) {
    super(props);
  }

  onChange(option, checked) {
    const value = this.props.value; // ToDo: prevent props mutation
    if (!checked) {
      value.push(option);
    } else {
      remove(value, option);
    }

    super.onChange(value);
  }

  renderOptions() {
    const {options, value, name, disabled} = this.props;

    return options.map((option) => {
      const checked = includes(value, option);
      const CheckboxProps = {
        name,
        checked,
        label: option.name,
        disabled,
        onChange: () => this.onChange(option, checked),
        key: `CheckboxGroup-${name}-${option.id}`
      };

      return <Checkbox  {...CheckboxProps} />;
    });
  }

  render() {
    const { theme } = this.props;
    const className = classNames({ 'has-error': this.shouldDisplayError() }, theme.group);
    const labelClassName = classNames('control-label', theme.label);

    return (
      <div className={className}>
        <label className={labelClassName}>{this.prepareLabel()}</label>
        {this.renderOptions()}
      </div>
    );
  }
}

CheckboxGroup.defaultProps = {
  ...FormControl.defaultProps,
  value: []
};

export default CheckboxGroup;
