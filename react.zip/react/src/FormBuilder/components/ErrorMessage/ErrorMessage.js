import React, { PropTypes } from 'react';
import Alert from '../../../BootstrapComponents/Alert';
import { uniq, isEqual } from 'lodash';

import { prepareErrorMessage } from '../../utils/formBuilderUtils';

class ErrorMessage extends React.Component {
  static propTypes = {
    fieldsErrors: PropTypes.object.isRequired,
    controls: PropTypes.array.isRequired,
    customErrors: PropTypes.arrayOf(PropTypes.object).isRequired,
    validatorMessages: PropTypes.object.isRequired,
    shown: PropTypes.bool.isRequired,
    isTopLevelError: PropTypes.func.isRequired
  };

  shouldComponentUpdate(props) {
    return (props.shown || this.props.shown) && !isEqual(props, this.props);
  }

  prepareErrors() {
    const { fieldsErrors, controls, customErrors, isTopLevelError, validatorMessages } = this.props;

    const errorMessages = Object.keys(fieldsErrors).map((errorKey) => {
      const fieldKey = errorKey.split('.')[0];
      const errors = fieldsErrors[errorKey];
      const fieldLabel = controls.find(({ key }) => key === fieldKey).label;
      return errors.filter(isTopLevelError).map((error) => prepareErrorMessage(validatorMessages, error, fieldLabel));
    }).reduce((prev, cur) => prev.concat(cur), [])
      .concat(customErrors.map((error) => prepareErrorMessage(validatorMessages, error)));
    return uniq(errorMessages);
  }

  render() {
    if (!this.props.shown) {
      return null;
    }
    const errorMessages = this.prepareErrors();

    if (errorMessages.length) {
      return (
        <Alert bsStyle="danger">
          {errorMessages.map((message, i) => {
            return <div key={`error-message-${i}`}>{message}</div>;
          })}
        </Alert>
      );
    }
    return null;
  }
}

ErrorMessage.defaultProps = {
  customErrors: [],
  validatorMessages: {},
  shown: false
};

export default ErrorMessage;
