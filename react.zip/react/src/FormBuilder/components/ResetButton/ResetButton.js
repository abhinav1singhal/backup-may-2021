import React, { PropTypes } from 'react';
import Button from '../../../Button';
import classNames from 'classnames';

class ResetButton extends React.Component {
  static propTypes = {
    text: PropTypes.string.isRequired,
    reset: PropTypes.func.isRequired,
    className: PropTypes.string
  };

  render() {
    const { text, reset, ...restProps } = this.props;
    const className = classNames('btn btn-default', this.props.className);

    return (
      <Button {...restProps} className={className} onClick={reset}>
        {text}
      </Button>
    );
  }
}

ResetButton.defaultProps = {
  text: 'Reset'
};

export default ResetButton;
