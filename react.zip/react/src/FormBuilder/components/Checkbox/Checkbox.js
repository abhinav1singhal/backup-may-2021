import React, { PropTypes } from 'react';
import classNames from 'classnames';
import { Checkbox as CheckboxComponent } from '../../../CheckboxRadio';

import FormControl from '../FormControl';

class Checkbox extends FormControl {
  static propTypes = {
    ...FormControl.propTypes,
    value: PropTypes.bool
  };

  constructor(props) {
    super(props);
  }

  onChange() {
    super.onChange(!this.props.value);
  }

  focus() {
    this.control.refs.input.focus();
  }

  render() {
    const { theme } = this.props;
    const className = classNames({ 'has-error': this.shouldDisplayError() });

    const CheckboxProps = {
      checked: this.props.value,
      label: this.prepareLabel(),
      onChange: this.onChange.bind(this),
      disabled: this.props.disabled,
      className,
      theme: {
        labelContainer: theme.group,
        label: theme.label
      },
      ref: this.ref
    };

    return <CheckboxComponent {...CheckboxProps} />;
  }
}
// labelClassName: PropTypes.string,
// className: PropTypes.string,
// name: PropTypes.string,
// theme: PropTypes.shape({
//   root: PropTypes.string,
//   group: PropTypes.string,
//   labelContainer: PropTypes.string,
// })

export default Checkbox;
