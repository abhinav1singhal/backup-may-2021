import React, { PropTypes } from 'react';
import TreeSelectComponent from '../../TreeSelect';

import FormControl from '../FormControl';

class TreeSelect extends FormControl {
  static propTypes = {
    ...FormControl.propTypes,
    value: PropTypes.arrayOf(PropTypes.object).isRequired,
    options: PropTypes.arrayOf(PropTypes.object).isRequired
  };

  render() {
    const { theme } = this.props;
    const TreeSelectProps = {
      value: this.props.value,
      label: this.prepareLabel(),
      placeholder: this.props.placeholder,
      onChange: this.onChange.bind(this),
      onOpen: this.props.onOpen,
      onClose: this.props.onClose,
      options: this.props.options,
      labelKey: this.props.labelKey,
      valueKey: this.props.valueKey,
      disabled: this.props.disabled,
      clearable: this.props.clearable,
      bsStyle: this.shouldDisplayError() ? 'error' : null,
      parentClassName: theme.group,
      wrapperClassName: theme.wrapper,
      labelClassName: theme.label,
      ref: this.ref
    };
    return <TreeSelectComponent {...TreeSelectProps} />;
  }
}

TreeSelect.defaultProps = {
  ...FormControl.defaultProps,
  value: [],
  labelKey: 'name',
  placeholder: '',
  clearable: true
};

export default TreeSelect;
