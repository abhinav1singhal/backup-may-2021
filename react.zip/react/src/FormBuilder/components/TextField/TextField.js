import React, { PropTypes } from 'react';
import classNames from 'classnames';

import FormControl from '../FormControl';

import theme from './TextField.css';

class TextField extends FormControl {
  static propTypes = {
    ...FormControl.propTypes,
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
  };

  render() {
    const { theme: customTheme, value } = this.props;
    const className = classNames('form-group', { 'has-error': this.shouldDisplayError() }, customTheme.group);
    const labelClassName = classNames('control-label', customTheme.label);
    const label = this.prepareLabel();

    return (
      <div className={className}>
        {label && <label className={labelClassName}>{label}</label>}
        <div className={classNames(theme.wrapper, customTheme.wrapper)}>{value}</div>
      </div>
    );
  }
}

export default TextField;
