export default from './NumberInput';
