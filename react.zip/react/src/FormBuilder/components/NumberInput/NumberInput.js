import React, { PropTypes } from 'react';
import Input from '../../../Input';

import FormControl from '../FormControl';

class Number extends FormControl {
  static propTypes = {
    ...FormControl.propTypes,
    value: PropTypes.oneOfType([
      PropTypes.string,
      PropTypes.number
    ])
  };

  onChange(event) {
    super.onChange(event.target.value);
  }

  focus() {
    this.control.refs.input.focus();
  }

  render() {
    const { theme } = this.props;
    const InputProps = {
      type: 'text',
      value: this.props.value,
      onChange: this.onChange.bind(this),
      onFocus: this.onFocus,
      onBlur: this.onBlur,
      label: this.prepareLabel(),
      disabled: this.props.disabled,
      bsStyle: this.shouldDisplayError() ? 'error' : null,
      groupClassName: theme.group,
      wrapperClassName: theme.wrapper,
      labelClassName: theme.label,
      ref: this.ref
    };

    return this.wrapControl(<Input {...InputProps} />);
  }
}

export default Number;
