import React, { PropTypes } from 'react';
import classNames from 'classnames';
import omit from 'lodash/omit';

import Select from '../Select';
import { FORM_CONTROL_TYPES } from '../../types';
import FormControl from '../FormControl';

import theme from './SelectRange.css';

class SelectRange extends FormControl {

  static propTypes = {
    ...FormControl.propTypes,
    value: PropTypes.shape({
      from: PropTypes.object,
      to: PropTypes.object
    }).isRequired,
    spacerHidden: PropTypes.bool
  };

  onChange(key, value) {
    super.onChange({
      ...this.props.value,
      [key]: value
    });
  }

  focus() {
    this.refs.from.focus();
  }

  renderSelect(key) {
    const SelectProps = {
      ...omit(this.props, ['label', 'theme']),
      theme: {
        ...omit(this.props.theme, ['label', 'wrapper', 'group'])
      },
      validators: [],
      type: FORM_CONTROL_TYPES.SELECT,
      name: `${this.props.name}.${key}`,
      value: this.props.value[key],
      onChange: (value) => this.onChange(key, value),
      ...this.props[key],
      ref: key
    };

    return (
      <div className={theme.selectContainer}>
        <Select {...SelectProps} />
      </div>
    );
  }

  render() {
    const { theme: customTheme, spacerHidden } = this.props;
    const className = classNames('form-group', { 'has-error': this.shouldDisplayError() }, customTheme.group);

    return this.wrapControl(
      <div className={className}>
        <label className={classNames('control-label', theme.label, customTheme.label)}>
          {this.prepareLabel()}
        </label>
        <div className={classNames(theme.wrapper, customTheme.wrapper)}>
          {this.renderSelect('from')}
          <div className={classNames(theme.rangeSpacer, { [theme.hidden]: spacerHidden })}>
            −
          </div>
          {this.renderSelect('to')}
        </div>
      </div>
    );
  }
}

SelectRange.defaultProps = {
  ...FormControl.defaultProps,
  value: {},
  from: {},
  to: {}
};

export default SelectRange;
