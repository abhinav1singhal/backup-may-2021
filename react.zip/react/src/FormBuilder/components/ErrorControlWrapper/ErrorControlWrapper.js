import React, { PropTypes } from 'react';
import { isFunction } from 'lodash';
import classNames from 'classnames';
import OverlayTrigger from '../../../OverlayTrigger';
import Popover from '../../../BootstrapComponents/Popover';

import ErrorMessageList from '../ErrorMessageList';
import { ERROR_WRAPPER_TYPES } from '../../utils/formBuilderUtils';

import theme from './ErrorControlWrapper.css';

class ErrorControlWrapper extends React.Component {
  static propTypes = {
    type: PropTypes.string, // TODO: improve this type
    errorMessages: PropTypes.arrayOf(PropTypes.string).isRequired,
    className: PropTypes.string,
    focused: PropTypes.bool,
    submitted: PropTypes.bool,
    children: PropTypes.node
  };

  [ERROR_WRAPPER_TYPES.POPOVER]() {
    const { errorMessages } = this.props;
    const className = classNames(theme.popoverError, this.props.className);
    const popover = (
      <Popover id="error-popover">
        <ErrorMessageList className={className} errorMessages={errorMessages} />
      </Popover>
    );
    const overlayTriggerProps = {
      trigger: this.shouldDisplayError() ? 'hover' : null,
      rootClose: true,
      placement: 'bottom',
      overlay: popover
    };

    return (
      <OverlayTrigger {...overlayTriggerProps}>
        {this.props.children}
      </OverlayTrigger>
    );
  }

  [ERROR_WRAPPER_TYPES.LIST]() {
    if (!this.shouldDisplayError() || !this.props.focused) {
      return <div>{this.props.children}</div>;
    }
    const { errorMessages } = this.props;
    const className = classNames(theme.listError, this.props.className);

    return (
      <div>
        {this.props.children}
        <ErrorMessageList className={className} errorMessages={errorMessages} />
      </div>
    );
  }

  isValidType() {
    const { type } = this.props;
    return type && isFunction(this[type]);
  }

  shouldDisplayError() {
    const { errorMessages, submitted } = this.props;
    return errorMessages.length > 0 && submitted;
  }

  render() {
    if (!this.isValidType()) {
      return this.props.children;
    }

    return this[this.props.type]();
  }
}

export default ErrorControlWrapper;
