import React, { PropTypes } from 'react';
import TextArea from '../../../TextArea';

class TextareaLimitedFormControl extends React.Component {
  static propTypes = {
    value: PropTypes.any,
    label: PropTypes.string,
    disabled: PropTypes.bool,
    onChange: PropTypes.func.isRequired,
    required: PropTypes.bool
  };

  render() {
    const TextAreaProps = {
      value: this.props.value,
      onChange: this.props.onChange,
      label: this.props.label,
      disabled: this.props.disabled
      // theme: PropTypes.object.isRequired,
      // scrollbarsTheme: PropTypes.object.isRequired,
      // placeholder: PropTypes.string,
      // height: PropTypes.number,
      // limit: PropTypes.number
    };

    return <TextArea {...TextAreaProps} />;
  }
}

export default TextareaLimitedFormControl;
