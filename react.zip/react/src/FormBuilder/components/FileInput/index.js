export default from './FileInput';
