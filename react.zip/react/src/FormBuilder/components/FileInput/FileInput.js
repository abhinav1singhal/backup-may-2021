import React, { PropTypes } from 'react';
import Input from '../../../Input';

import FormControl from '../FormControl';

import theme from './FileInput.css';

class FileInput extends FormControl {
  static propTypes = {
    ...FormControl.propTypes,
    value: PropTypes.object,
    accept: PropTypes.string
  };

  constructor(props) {
    super(props);
    this.touched = false;
    this.changeFile = this.changeFile.bind(this);
  }

  componentDidMount() {
    this.refs.fileInput.default = this.props.value;
  }

  changeFile(e) {
    e.preventDefault();
    e.stopPropagation();
    if (!this.touched) {
      super.onChange(undefined);
      this.touched = true;
    }
    this.refs.fileInput.click();
  }

  onChange(e) {
    e.preventDefault();
    e.stopPropagation();
    const file = this.refs.fileInput.files[0];
    super.onChange(file);
  }

  render() {
    const { theme: customTheme, value, accept } = this.props;
    const InputProps = {
      type: 'text',
      bsStyle: this.shouldDisplayError() ? 'error' : null,
      label: this.prepareLabel(),
      groupClassName: customTheme.group,
      wrapperClassName: customTheme.wrapper,
      labelClassName: customTheme.label,
      className: theme.textInput,
      value: value ? value.name : '',
      disabled: true,
      onClick: this.changeFile
    };
    const inputProps = {
      id: this.props.name,
      ref: 'fileInput',
      type: 'file',
      className: theme.fileInput,
      onChange: this.onChange,
      accept
    };

    return (
      <div className={theme.root}>
        <Input {...InputProps} />
        <input {...inputProps} />
      </div>
    );
  }
}

export default FileInput;
