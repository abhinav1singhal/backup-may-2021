import React, { PropTypes } from 'react';
import classNames from 'classnames';

import theme from './ErrorMessageList.css';

class ErrorMessageList extends React.Component {
  static propTypes = {
    className: PropTypes.string,
    errorMessages: PropTypes.arrayOf(PropTypes.string).isRequired
  };

  render() {
    const { errorMessages } = this.props;
    const className = classNames(theme.root, this.props.className);
    return (
      <div className={className}>
        {errorMessages.map((message, index) =>
          <div key={`error-message-${index}`}>{message}</div>)}
      </div>
    );
  }
}

export default ErrorMessageList;
