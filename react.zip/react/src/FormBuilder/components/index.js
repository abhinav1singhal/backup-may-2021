import { FORM_CONTROL_TYPES } from '../types';
import TextareaLimitedFormControl from './TextareaLimitedFormControl';

import TextInput from './TextInput';
import Checkbox from './Checkbox';
import Textarea from './Textarea';
import NumberInput from './NumberInput';
import Select from './Select';
import MultiSelect from './MultiSelect';
import CheckboxGroup from './CheckboxGroup';
import RadioGroup from './RadioGroup';
import DateRange from './DateRange';
import TextField from './TextField';
import FileInput from './FileInput';
import FieldList from './FieldList';
import DatePicker from './DatePicker';
import SelectRange from './SelectRange';
import TreeSelect from './TreeSelect';
import TreeMultiSelect from './TreeMultiSelect';

export const CONTROLS = {
  [FORM_CONTROL_TYPES.TEXT]: TextInput,
  [FORM_CONTROL_TYPES.NUMBER]: NumberInput,
  [FORM_CONTROL_TYPES.TEXTAREA]: Textarea,
  [FORM_CONTROL_TYPES.SELECT]: Select,
  [FORM_CONTROL_TYPES.CHECKBOX]: Checkbox,
  [FORM_CONTROL_TYPES.MULTISELECT]: MultiSelect,
  [FORM_CONTROL_TYPES.TEXTAREA_LIMITED]: TextareaLimitedFormControl,
  [FORM_CONTROL_TYPES.CHECKBOX_GROUP]: CheckboxGroup,
  [FORM_CONTROL_TYPES.RADIO_GROUP]: RadioGroup,
  [FORM_CONTROL_TYPES.DATE_RANGE]: DateRange,
  [FORM_CONTROL_TYPES.TEXT_FIELD]: TextField,
  [FORM_CONTROL_TYPES.FILE]: FileInput,
  [FORM_CONTROL_TYPES.FIELD_LIST]: FieldList,
  [FORM_CONTROL_TYPES.DATE_PICKER]: DatePicker,
  [FORM_CONTROL_TYPES.SELECT_RANGE]: SelectRange,
  [FORM_CONTROL_TYPES.TREEVIEW_SELECT]: TreeSelect,
  [FORM_CONTROL_TYPES.TREEVIEW_MULTISELECT]: TreeMultiSelect
};

export {
  FORM_CONTROL_TYPES,
  TextInput,
  Checkbox,
  Textarea,
  NumberInput,
  Select,
  MultiSelect,
  CheckboxGroup,
  RadioGroup,
  DateRange,
  TextField,
  FileInput,
  FieldList,
  DatePicker,
  SelectRange,
  TreeSelect,
  TreeMultiSelect
};

export SubmitButton from './SubmitButton';
export ResetButton from './ResetButton';
export ErrorMessage from './ErrorMessage';
export FormComponent from './FormComponent';
export FormControl from './FormControl';
