import React, { PropTypes } from 'react';
import MultiSelectComponent from '../../../MultiSelect';

import FormControl from '../FormControl';

class MultiSelect extends FormControl {
  static propTypes = {
    ...FormControl.propTypes,
    value: PropTypes.array,
    onOpen: PropTypes.func,
    onClose: PropTypes.func,
    options: PropTypes.arrayOf(PropTypes.object).isRequired
  };

  onChange(value) {
    super.onChange(value);
  }

  render() {
    const { theme } = this.props;
    const MultiSelectProps = {
      value: this.props.value,
      label: this.prepareLabel(),
      onChange: this.onChange.bind(this),
      onOpen: this.props.onOpen,
      onClose: this.props.onClose,
      options: this.props.options,
      labelKey: 'name',
      valueKey: 'id',
      disabled: this.props.disabled,
      bsSize: this.props.bsSize,
      bsStyle: this.shouldDisplayError() ? 'error' : null,
      wrapperClassName: theme.wrapper,
      labelClassName: theme.label,
      parentClassName: theme.group
    };

    return <MultiSelectComponent {...MultiSelectProps} />;
  }
}
// shownAm: PropTypes.number,
// showSelectAll: PropTypes.bool,
// searchable: PropTypes.bool,
// theme: PropTypes.object.isRequired

export default MultiSelect;
