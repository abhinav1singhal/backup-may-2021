import React, { PropTypes } from 'react';
import classNames from 'classnames';
import OverlayTrigger from '../../../OverlayTrigger';
import Popover from '../../../BootstrapComponents/Popover';

import ErrorMessageList from '../ErrorMessageList';
import Icon from '../../../Icon';

import theme from './ErrorIcon.css';

class ErrorIcon extends React.Component {
  static propTypes = {
    errorMessages: PropTypes.arrayOf(PropTypes.string).isRequired,
    shown: PropTypes.bool,
    theme: PropTypes.shape({
      messages: PropTypes.string,
      icon: PropTypes.string
    })
  };

  render() {
    const { shown, theme: customTheme, errorMessages } = this.props;
    if (!shown || errorMessages.length === 0) {
      return null;
    }

    const popover = (
      <Popover id="error-icon-popover">
        <ErrorMessageList className={customTheme.messages} errorMessages={errorMessages} />
      </Popover>
    );
    const overlayTriggerProps = {
      trigger: 'hover',
      rootClose: true,
      placement: 'top',
      overlay: popover
    };
    const iconClassName = classNames(theme.icon, customTheme.icon);

    return (
      <OverlayTrigger {...overlayTriggerProps}>
        <Icon type="error" className={iconClassName} />
      </OverlayTrigger>
    );
  }
}

ErrorIcon.defaultProps = {
  theme: {}
};

export default ErrorIcon;
