export default from './ErrorIcon';
