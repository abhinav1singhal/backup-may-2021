import React, { PropTypes } from 'react';
import Button from '../../../Button';
import classNames from 'classnames';

class SubmitButton extends React.Component {
  static propTypes = {
    text: PropTypes.string.isRequired,
    onSubmit: PropTypes.func.isRequired,
    className: PropTypes.string
  };

  render() {
    const { text, onSubmit, ...restProps } = this.props;
    const className = classNames('btn btn-primary', this.props.className);

    return (
      <Button { ...restProps} className={className} onClick={onSubmit}>
        {text}
      </Button>
    );
  }
}

SubmitButton.defaultProps = {
  text: 'Submit'
};

export default SubmitButton;
