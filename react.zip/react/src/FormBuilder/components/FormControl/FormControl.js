import React, { PropTypes } from 'react';
import { isEqual } from 'lodash';
import {
  prepareValidators, shouldUpdateValidators, shouldUpdateFormControl,
  validate, isValidField, prepareErrorMessage
} from '../../utils/formBuilderUtils';
import ErrorControlWrapper from '../ErrorControlWrapper';
import ErrorIcon from '../ErrorIcon';

class FormControl extends React.Component {
  static propTypes = {
    name: PropTypes.string.isRequired,
    type: PropTypes.string.isRequired,
    value: PropTypes.any, // ToDo: improve this type
    required: PropTypes.bool,
    label: PropTypes.string,
    validators: PropTypes.array, // ToDo: improve this type
    onChange: PropTypes.func.isRequired,
    submitted: PropTypes.bool,
    errors: PropTypes.object.isRequired,
    errorWrapperType: PropTypes.string, // TODO: improve this type
    isFieldLevelError: PropTypes.func.isRequired,
    validatorMessages: PropTypes.object.isRequired,
    errorIconShown: PropTypes.bool,
    formatter: PropTypes.func.isRequired,
    customLabel: PropTypes.func,
    theme: PropTypes.shape({
      required: PropTypes.string,
      group: PropTypes.string,
      wrapper: PropTypes.string,
      label: PropTypes.string,
      errorMessages: PropTypes.string
    }).isRequired
  };

  constructor(props) {
    super(props);

    this.validators = prepareValidators(props);
    this.value = props.value;
    this.state = { focused: false };

    this.onFocus = this.onFocus.bind(this);
    this.onBlur = this.onBlur.bind(this);
    this.onChange = this.onChange.bind(this);
    this.ref = (control) => { this.control = control; };
  }

  componentWillMount() {
    this.validate(this.props);
  }

  componentWillReceiveProps(props) {
    if (shouldUpdateValidators(props, this.props)) {
      this.validators = prepareValidators(props);
      this.validate(props);
    } else if (!isEqual(this.value, props.value)) {
      this.value = props.value;
      this.validate(props);
    }
  }

  shouldComponentUpdate(props, state) {
    return shouldUpdateFormControl(props, state, this.props, this.state);
  }

  onChange(value) {
    this.value = this.props.formatter(value);
    this.props.onChange(this.value);
    this.validate({ ...this.props, value: this.value });
  }

  onFocus() {
    this.setState({ focused: true }); // eslint-disable-line react/no-set-state
  }

  onBlur() {
    this.setState({ focused: false }); // eslint-disable-line react/no-set-state
  }

  validate(props) {
    const errors = validate(this.validators, props.value, props.required);
    props.validate(props.name, errors);
    return errors;
  }

  prepareRequiredLabel() {
    const {required, label, theme: customTheme} = this.props;
    if (!required || !label) {
      return label;
    }

    return (
      <span className={customTheme.requiredWrapper}>
        {label} <span className={customTheme.required}>*</span>
      </span>
    );
  }

  prepareErrorIcon() {
    const { theme: customTheme } = this.props;
    const errorIconProps = {
      errorMessages: this.prepareErrorMessages(),
      shown: this.shouldDisplayError() && this.props.errorIconShown,
      theme: {
        messages: customTheme.errorMessages,
        icon: customTheme.icon
      }
    };
    return <ErrorIcon {...errorIconProps} />;
  }

  prepareErrorMessages() {
    const { isFieldLevelError, validatorMessages, label, name } = this.props;
    const errors = (this.props.errors[name] || []).filter(isFieldLevelError);
    return errors.map((error) => prepareErrorMessage(validatorMessages, error, label));
  }

  prepareLabel() {
    if (this.props.customLabel) {
      return this.props.customLabel(this.props);
    }
    if (!this.props.label) {
      return undefined;
    }

    return (
      <span>
        {this.prepareErrorIcon()}
        {this.prepareRequiredLabel()}
      </span>
    );
  }

  shouldDisplayError() {
    const { name } = this.props;
    return this.props.submitted && !isValidField(this.props.errors[name]);
  }

  wrapControl(control) {
    const { theme: customTheme } = this.props;
    const errorControlWrapperProps = {
      type: this.props.errorWrapperType,
      className: customTheme.errorMessages,
      focused: this.state.focused,
      submitted: this.props.submitted,
      errorMessages: this.prepareErrorMessages()
    };

    return (
      <ErrorControlWrapper {...errorControlWrapperProps}>
        {control}
      </ErrorControlWrapper>
    );
  }
}

FormControl.defaultProps = {
  theme: {},
  errors: {},
  formatter: (value) => value
};

export default FormControl;
