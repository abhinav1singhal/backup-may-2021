import React, { PropTypes } from 'react';
import classNames from 'classnames';
import omit from 'lodash/omit';

import DatePicker from '../DatePicker';
import { FORM_CONTROL_TYPES } from '../../types';
import FormControl from '../FormControl';

import theme from './DateRange.css';

class DateRange extends FormControl {

  static propTypes = {
    ...FormControl.propTypes,
    value: PropTypes.shape({
      from: PropTypes.string,
      to: PropTypes.string
    }).isRequired,
    spacerHidden: PropTypes.bool
  };

  onChange(key, value) {
    super.onChange({
      ...this.props.value,
      [key]: value
    });
  }

  // focus() {
  //   this.refs.from.focus(); // TODO: improve in react-techstack
  // }

  renderDatePicker(key) {
    const date = this.props.value[key];
    const { name } = this.props;

    // ToDo: fix this labels
    const datePickerProps = {
      ...omit(this.props, ['label', 'theme']),
      theme: {
        ...omit(this.props.theme, ['label', 'wrapper'])
      },
      validators: [],
      type: FORM_CONTROL_TYPES.DATE_PICKER,
      name: `${name}.${key}`,
      value: date,
      onChange: (value) => this.onChange(key, value),
      ...this.props[key],
      ref: key
    };

    return (
      <div className={theme.datePickerContainer}>
        <DatePicker {...datePickerProps} />
      </div>
    );
  }

  render() {
    const { theme: customTheme, spacerHidden } = this.props;
    const className = classNames('form-group', { 'has-error': this.shouldDisplayError() }, customTheme.group);

    return this.wrapControl(
      <div className={className}>
        <label className={classNames('control-label', theme.label, customTheme.label)}>
          {this.prepareLabel()}
        </label>
        <div className={classNames(theme.wrapper, customTheme.wrapper)}>
          {this.renderDatePicker('from')}
          <div className={classNames(theme.datepickerSpacer, { [theme.hidden]: spacerHidden })}>
            −
          </div>
          {this.renderDatePicker('to')}
        </div>
      </div>
    );
  }
}

DateRange.defaultProps = {
  ...FormControl.defaultProps,
  value: {},
  from: {},
  to: {}
};

export default DateRange;
