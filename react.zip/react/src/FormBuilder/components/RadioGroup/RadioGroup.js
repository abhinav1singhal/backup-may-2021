import React, { PropTypes } from 'react';
import { isEqual } from 'lodash';
import classNames from 'classnames';
import { Radio } from '../../../CheckboxRadio';

import FormControl from '../FormControl';

class RadioGroup extends FormControl {
  static propTypes = {
    ...FormControl.propTypes,
    options: PropTypes.arrayOf(PropTypes.object).isRequired,
    value: PropTypes.object
  };

  onChange(value) {
    super.onChange(value);
  }

  renderOptions() {
    const {options, value, name, disabled} = this.props;

    return options.map((option) => {
      const RadioProps = {
        name,
        checked: isEqual(value, option),
        label: option.name,
        disabled,
        onChange: () => this.onChange(option),
        key: `RadioGroup-${name}-${option.id}`
      };

      return <Radio  {...RadioProps} />;
    });
  }

  render() {
    const { theme } = this.props;
    const className = classNames({ 'has-error': this.shouldDisplayError() }, theme.group);
    const labelClassName = classNames('control-label', theme.label);

    return (
      <div className={className}>
        <label className={labelClassName}>{this.prepareLabel()}</label>
        {this.renderOptions()}
      </div>
    );
  }
}

export default RadioGroup;
