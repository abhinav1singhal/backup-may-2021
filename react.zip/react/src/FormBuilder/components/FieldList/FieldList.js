import React, { PropTypes } from 'react';
import { omit } from 'lodash';
import classNames from 'classnames';
import Button from '../../../Button';

import Icon from '../../../Icon';

import FormControl from '../FormControl';
import FieldItem from './components/FieldItem';

import theme from './FieldList.css';

class FieldList extends FormControl {
  static propTypes = {
    ...FormControl.propTypes,
    value: PropTypes.array.isRequired
  };

  constructor(props) {
    super(props);

    this.push = this.push.bind(this);
    this.changeItem = this.changeItem.bind(this);
    this.onRemove = this.onRemove.bind(this);
  }

  onRemove(index) {
    const { value } = this.props;
    super.onChange([
      ...value.slice(0, index),
      ...value.slice(index + 1)
    ]);
  }

  changeItem(index, item) {
    const value = this.props.value.slice();
    value[index] = item;
    super.onChange(value);
  }

  push() {
    const { value } = this.props;
    super.onChange(value.concat(this.props.itemType.defaultValue));
  }

  renderAddButton() {
    const { theme: customTheme, disabled } = this.props;
    if (disabled) {
      return null;
    }
    const btnProps = {
      onClick: this.push,
      bsStyle: 'link',
      className: theme.addButton,
      disabled
    };
    const className = classNames(theme.icon, customTheme.icon);

    return (
      <div className={customTheme.addWrapper}>
        <Button {...btnProps}>
          <Icon type="plus" className={className} />
          {this.props.addText}
        </Button>
      </div>
    );
  }

  render() {
    const { value, theme: customTheme, name } = this.props;
    const itemProps = {
      ...omit(this.props, 'value', 'label', 'disabled', 'canRemoveLast', 'name')
    };
    const className = classNames({ 'has-error': this.shouldDisplayError() }, customTheme.group);
    const labelClassName = classNames('control-label', customTheme.label);
    const componentMapper = (item, index) => {
      const props = {
        ...itemProps,
        index,
        name: `${name}.${index}`,
        value: item,
        key: `item-${index}`,
        onChange: this.changeItem,
        onRemove: this.onRemove,
        removable: this.props.canRemoveLast || value.length > 1,
        Control: this.props.itemType,
        theme: customTheme
      };
      return <FieldItem {...props} />;
    };

    return (
      <div className={className}>
        <label className={labelClassName}>{this.prepareLabel()}</label>
        <div className={customTheme.wrapper}>
          {value.map(componentMapper)}
          {this.renderAddButton()}
        </div>
      </div>
    );
  }
}

FieldList.defaultProps = {
  ...FormControl.defaultProps,
  value: [],
  addText: 'Add Item',
  canRemoveLast: true
};

export default FieldList;
