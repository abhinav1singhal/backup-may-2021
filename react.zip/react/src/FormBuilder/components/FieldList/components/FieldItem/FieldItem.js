import React, { PropTypes } from 'react';
import { omit } from 'lodash';
import classNames from 'classnames';
import Icon from '../../../../../Icon';

import theme from './FieldItem.css';

class FieldItem extends React.Component {
  static propTypes = {
    onRemove: PropTypes.func.isRequired,
    onChange: PropTypes.func.isRequired,
    index: PropTypes.number.isRequired,
    removable: PropTypes.bool,
    theme: PropTypes.object
  };

  constructor(props) {
    super(props);

    this.onRemove = this.onRemove.bind(this);
    this.onChange = this.onChange.bind(this);
  }

  onRemove() {
    this.props.onRemove(this.props.index);
  }

  onChange(value) {
    this.props.onChange(this.props.index, value);
  }

  render() {
    const controlProps = {
      ...omit(this.props, 'Control', 'onChange', 'onRemove', 'index', 'removable'),
      onChange: this.onChange
    };
    const { removable, theme: customTheme } = this.props;
    const className = classNames(theme.icon, customTheme.icon);

    return (
      <div className={theme.root}>
        <this.props.Control {...controlProps} />
        {removable && <Icon type="exit" className={className} onClick={this.onRemove} />}
      </div>
    );
  }
}

FieldItem.defaultProps = {
  removable: true
};

export default FieldItem;
