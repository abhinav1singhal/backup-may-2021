import React, { PropTypes } from 'react';
import Input from '../../../Input';

import FormControl from '../FormControl';

class Textarea extends FormControl {
  static propTypes = {
    ...FormControl.propTypes,
    value: PropTypes.string
  };

  onChange(event) {
    super.onChange(event.target.value);
  }

  render() {
    const { theme } = this.props;
    const InputProps = {
      type: 'textarea',
      value: this.props.value,
      onChange: this.onChange.bind(this),
      label: this.prepareLabel(),
      disabled: this.props.disabled,
      bsStyle: this.shouldDisplayError() ? 'error' : null,
      groupClassName: theme.group,
      wrapperClassName: theme.wrapper,
      labelClassName: theme.label
    };

    return <Input {...InputProps} />;
  }
}

export default Textarea;
