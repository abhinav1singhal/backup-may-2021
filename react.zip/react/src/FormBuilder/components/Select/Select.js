import React, { PropTypes } from 'react';
import SelectComponent from '../../../Select';

import FormControl from '../FormControl';

class Select extends FormControl {
  static propTypes = {
    ...FormControl.propTypes,
    value: PropTypes.oneOfType([
      PropTypes.object,
      PropTypes.arrayOf(PropTypes.object)
    ]),
    onOpen: PropTypes.func,
    onClose: PropTypes.func,
    multi: PropTypes.bool,
    options: PropTypes.arrayOf(PropTypes.object).isRequired
  };

  onChange(value) {
    if (this.props.multi && !value) {
      super.onChange([]);
    } else {
      super.onChange(value);
    }
  }

  focus() {
    this.control.refs.BaseSelect.focus();
  }

  render() {
    const { theme } = this.props;
    const SelectProps = {
      value: this.props.value,
      label: this.prepareLabel(),
      placeholder: this.props.placeholder,
      onChange: this.onChange.bind(this),
      onOpen: this.props.onOpen,
      onClose: this.props.onClose,
      options: this.props.options,
      labelKey: this.props.labelKey,
      valueKey: this.props.valueKey,
      multi: this.props.multi,
      disabled: this.props.disabled,
      clearable: this.props.clearable,
      bsSize: this.props.bsSize,
      bsStyle: this.shouldDisplayError() ? 'error' : null,
      parentClassName: theme.group,
      wrapperClassName: theme.wrapper,
      labelClassName: theme.label,
      ref: this.ref
    };

    return <SelectComponent {...SelectProps} />;
  }
}

Select.defaultProps = {
  ...FormControl.defaultProps,
  labelKey: 'name',
  valueKey: 'name',
  placeholder: '',
  clearable: true
};
// multi: "	boolean	false", // ToDo: should be static property (not from configuration)
// bsStyle: "	one of:'success''warning''error'",
// backspaceRemoves: "	boolean	true",
// wrapperClassName: "	string",
// clearable: "	boolean	true",
// inputProps: "	object	{}",
// labelClassName: "	string",
// noResultsText: "	string	'No results found'",
// onOptionLabelClick: "	function	undefined",
// optionComponent: "	function	OptionComponent",
// filter: "	function",
// optionRenderer: "	function",
// placeholder: "	string	'Select...'",
// searchable: "	boolean	true",
// searchPromptText: "	string	'Type to search'",
// searchingText: "	string	'Searching...'",
// singleValueComponent: "	function	SingleValue",
// name: "	string	undefined",
// tabIndex: "	number",
// valueComponent: "	function	Value",
// onFocus: "	function",
// onBlur: "	function",
// onInputChange: "	function	undefined",
// onOpen: "	function",
// onClose: "	function",
// onFocusOption: "	function",
// className: "		undefined"

export default Select;
