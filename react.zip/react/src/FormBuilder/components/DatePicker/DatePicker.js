import React, { PropTypes } from 'react';
import classNames from 'classnames';
import moment from 'moment';
import DatePickerComponent from '../../../DatePicker';

import FormControl from '../FormControl';

import theme from './DatePicker.css';

class DatePicker extends FormControl {

  static propTypes = {
    ...FormControl.propTypes,
    value: PropTypes.string
  };

  onChange(value) {
    const valueStr = value ? value.format('YYYY-MM-DD') : value;
    super.onChange(valueStr);
  }

  focus() {
    this.refs.input.focus();
  }

  prepareLabel() {
    const { label, theme: customTheme } = this.props;
    if (!label) {
      return undefined;
    }

    return (
      <label className={classNames('control-label', theme.label, customTheme.label)}>
        {super.prepareLabel()}
      </label>
    );
  }

  render() {
    const { theme: customTheme } = this.props;
    const className = classNames('form-group', { 'has-error': this.shouldDisplayError() }, customTheme.group);
    const { disabled } = this.props;
    const date = this.props.value;

    const datePickerProps = {
      disabled,
      selected: date ? moment(date) : null,
      dateFormat: 'MM/DD/YYYY',
      onChange: (value) => this.onChange(value),
      ref: 'input'
    };

    return this.wrapControl(
      <div className={className}>
        {this.prepareLabel()}
        <div className={classNames(theme.wrapper, customTheme.wrapper)}>
          <div className={theme.datePickerContainer}>
            <DatePickerComponent {...datePickerProps} />
          </div>
        </div>
      </div>
    );
  }
}

export default DatePicker;
