import React, { PropTypes } from 'react';
import Input from '../../../Input';

import FormControl from '../FormControl';

class TextInput extends FormControl {
  static propTypes = {
    ...FormControl.propTypes,
    value: PropTypes.string
  };

  onChange(event) {
    super.onChange(event.target.value);
  }

  focus() {
    this.control.refs.input.focus();
  }

  render() {
    const {value, disabled, theme} = this.props;

    const InputProps = {
      type: 'text',
      value, // ToDo: consider switching to state
      onChange: this.onChange.bind(this),
      label: this.prepareLabel(),
      disabled,
      onFocus: this.onFocus,
      onBlur: this.onBlur,
      bsStyle: this.shouldDisplayError() ? 'error' : null,
      groupClassName: theme.group,
      wrapperClassName: theme.wrapper,
      labelClassName: theme.label,
      ref: this.ref
    };

    return this.wrapControl(<Input {...InputProps} />);
  }
}

// help: 	"node		",
// addonBefore: 	"node		",
// addonAfter: 	"node		",
// buttonBefore: 	"node		",
// buttonAfter: 	"node		",
// hasFeedback: 	"boolean	false	",
// feedbackIcon: 	"node		",
// id: 	"string, | ,number		",

// placeholder
// bsSize: 	"one of:'small''medium''large'		",

export default TextInput;
