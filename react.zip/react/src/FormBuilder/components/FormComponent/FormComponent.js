import React, { PropTypes } from 'react';
import { isEqual, isFunction, noop, some, omit } from 'lodash';

import { VALIDATOR_MESSAGES } from '../../../FormBuilder';
import { isValidField, isValidForm, isDataEqual, getDisabledMap } from '../../utils/formBuilderUtils';
import { balanceTrees } from '../../../utils/treeSelectUtils';

import { CONTROLS } from '../';

class FormComponent extends React.Component {
  static propTypes = {
    data: PropTypes.object.isRequired,
    config: PropTypes.oneOfType([
      PropTypes.object.isRequired,
      PropTypes.arrayOf(PropTypes.object).isRequired
    ]),
    options: PropTypes.object.isRequired,

    onSubmit: PropTypes.func.isRequired,
    onChange: PropTypes.func.isRequired,
    onValidate: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props);

    this.state = {
      ...this.prepareStateFromProps(props),
      submitted: false
    };

    this.controlTypes = { ...CONTROLS };
    this.validatorMessages = VALIDATOR_MESSAGES;
    this.errorIconShown = false;
    this.controlRefs = {};
    this.isTopLevelError = () => true;
    this.isFieldLevelError = () => false;

    this.validateField = this.validateField.bind(this);
    this.onChange = this.onChange.bind(this);
  }

  componentWillReceiveProps(props) {
    if (this.props.data !== props.data || !isEqual(this.props.options, props.options)) {
      this.setState({
        ...this.state,
        ...this.prepareStateFromProps(props),
        submitted: false
      });
    }
  }

  shouldComponentUpdate(props, state) {
    const omitted = ['onSubmit', 'onValidate', 'onChange'];
    return !isEqual(omit(this.props, omitted), omit(props, omitted)) || !isEqual(this.state, state);
  }

  onSubmit = (event) => {
    if (event && isFunction(event.preventDefault)) {
      event.preventDefault();
    }

    if (!this.isDisabledForm()) {
      this.scrollTop();
      if (isValidForm(this.state.fieldsErrors, this.state.errors)) {
        this.submitData(this.state.data);
      } else {
        this.focusFirstInvalid();
      }

      this.setState({
        submitted: true
      });
    }
  }

  onChange(key, value) {
    this.setState((state) => this.recalculateState({
      ...state,
      data: {
        ...state.data,
        [key]: value
      }
    }), () => this.props.onChange(this.state.data));
  }

  prepareStateFromProps(props) {
    const { options, data } = balanceTrees({ data: props.data, options: props.options }, props.options, props.config);
    const disabled = getDisabledMap(props.config, options);

    return {
      data,
      options,
      errors: [],
      fieldsErrors: {},
      disabled
    };
  }

  recalculateState(state) {
    const { options, data } = balanceTrees(state, this.props.options, this.props.config);
    const disabled = getDisabledMap(this.props.config, options);

    return {
      data,
      options,
      disabled
    };
  }

  scrollTop() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }

  submitData(data) {
    this.props.onSubmit(data);
  }

  focusFirstInvalid() {
    const { fieldsErrors } = this.state;
    return some(this.controls, ({ key }) => {
      if (!isValidField(fieldsErrors[key]) && isFunction(this.controlRefs[key].focus)) {
        this.controlRefs[key].focus();
        return true;
      }
      return false;
    });
  }

  validateField(key, value) {
    this.setState((state) => ({
      fieldsErrors: {
        ...state.fieldsErrors,
        [key]: value
      }
    }), () => this.props.onValidate(isValidForm(this.state.fieldsErrors, this.state.errors)));
  }

  reset = () => {
    this.setState({ data: this.props.data, submitted: false });
  }

  setRef = (control, key) => {
    this.controlRefs[key] = control;
  }

  setFormBuilderRef(instance, name) {
    this[name] = instance;
  }

  hasUnsavedChanges() {
    return !isDataEqual(this.props.data, this.state.data);
  }

  isDisabledForm() {
    return false;
  }

  updateConfig(configKey, key, updates) {
    this.config[configKey] = this.config[configKey].map((item) => {
      if (item.key === key) {
        return {
          ...item,
          ...updates
        };
      }
      return item;
    });
  }

  prepareFormConstructorProps(name) {
    return {
      data: this.state.data,
      disabled: this.state.disabled,
      disabledForm: this.isDisabledForm(),
      fieldsErrors: this.state.fieldsErrors,
      options: this.state.options,
      submitted: this.state.submitted,
      onChange: this.onChange,
      validate: this.validateField,
      isFieldLevelError: this.isFieldLevelError,
      validatorMessages: this.validatorMessages,
      errorIconShown: this.errorIconShown,
      setRef: this.setRef,
      controlTypes: this.controlTypes,
      ref: (instance) => this.setFormBuilderRef(instance, name) // ToDo: improve this
    };
  }

  prepareErrorMessageProps() {
    return {
      validatorMessages: this.validatorMessages,
      isTopLevelError: this.isTopLevelError,
      fieldsErrors: this.state.fieldsErrors,
      customErrors: this.state.errors,
      shown: this.state.submitted
    };
  }
}

FormComponent.defaultProps = {
  data: {},
  options: {},
  onSubmit: noop,
  onChange: noop,
  onValidate: noop
};

export default FormComponent;
