import React, { PropTypes } from 'react';
import ReactDOM from 'react-dom';
import classNames from 'classnames';
import Select from '../../../Select';
import Icon from '../../../Icon';
import { isFunction, isEqual } from 'lodash';

import theme from './GroupSelect.css';

function isExpandIcon(el) {
  return el && isFunction(el.getAttribute) && (el.getAttribute('type') === 'plus' || el.getAttribute('type') === 'minus' || isExpandIcon(el.parentNode));
}

function shouldClose(el, option) {
  return el && option && !!el.innerHTML;
}

class GroupSelect extends React.Component {
  static propTypes = {
    options: PropTypes.arrayOf(PropTypes.object).isRequired,
    value: PropTypes.object,
    label: PropTypes.node,
    onChange: PropTypes.func.isRequired,
    onOpen: PropTypes.func,
    onClose: PropTypes.func,

    valueKey: PropTypes.string.isRequired,
    labelKey: PropTypes.string.isRequired,
    clearable: PropTypes.bool,
    disabled: PropTypes.bool,
    placeholder: PropTypes.string,
    bsStyle: PropTypes.string,

    emptyValue: PropTypes.any,
    expandedByDefault: PropTypes.bool,
    levelOffset: PropTypes.number.isRequired,

    parentClassName: PropTypes.string,
    wrapperClassName: PropTypes.string,
    labelClassName: PropTypes.string,
    theme: PropTypes.object.isRequired
  };

  constructor(props) {
    super(props);

    this.state = {
      value: props.value,
      ...this.prepareOptions(props)
    };
  }

  componentWillReceiveProps(props) {
    if (this.props.value !== props.value) {
      this.setState({ value: props.value });
    }
    if (!isEqual(this.props.options, props.options)) {
      this.setState(this.prepareOptions(props));
    } else if (this.props.options !== props.options) {
      this.setState({ options: this.listOptions(this.state.expanded, props )});
    }
  }

  onChange = (option, event = {}) => {
    const { labelKey, valueKey, emptyValue } = this.props;
    if (!shouldClose(event.target, option, labelKey) && event.preventMenuClose && option) {
      event.preventMenuClose();
    }
    const shouldExpand = isExpandIcon(event.target);
    const threeBox = option ? ReactDOM.findDOMNode(this[`threebox-${option.treeId}`]) : null;

    if (shouldExpand) {
      this.toggleExpand(option);
    } else if (!option || !option[valueKey]) {
      this.props.onChange(emptyValue);
    } else if (threeBox && threeBox.contains(event.target) || shouldClose(event.target, option, labelKey) || !event.target) {
      this.onToggleValue(option);
    }
  }

  onToggleValue(option) {
    this.props.onChange(this.getNewValue(option));
  }

  getNewValue(option) {
    if (this.isDisabledOption(option)) {
      return this.props.value;
    }
    return option;
  }

  getSelectProps() {
    return {
      value: this.state.value,
      label: this.props.label,
      options: this.state.options,
      onChange: this.onChange,
      onOpen: this.props.onOpen,
      onClose: this.props.onClose,

      valueKey: this.props.valueKey,
      labelKey: this.props.labelKey,
      clearable: this.props.clearable,
      disabled: this.props.disabled,
      placeholder: this.props.placeholder,
      bsStyle: this.props.bsStyle,

      optionRenderer: this.optionRenderer,
      valueRenderer: this.valueRenderer,
      filter: this.filter,

      parentClassName: this.props.parentClassName,
      wrapperClassName: this.props.wrapperClassName,
      labelClassName: this.props.labelClassName,
      customTheme: {
        option: {
          root: theme.optionRoot
        }
      }
    };
  }

  toggleExpand(option) {
    const { expanded } = this.state;
    const optionKey = option[this.props.valueKey];

    const newExpanded =  {
      ...expanded,
      [optionKey]: !expanded[optionKey]
    };

    this.setState({
      expanded: newExpanded,
      options: this.listOptions(newExpanded, this.props)
    });
  }

  listOptions(expanded, props) {
    const res = [];
    const { valueKey } = props;

    function dfs(option) {
      res.push(option);

      if (expanded[option[valueKey]]) {
        option.children.forEach(dfs);
      }
    }

    props.options.forEach(dfs);
    return res;
  }

  prepareOptions(props) {
    const expanded = {};
    const { valueKey } = props;
    function dfs(option) {
      expanded[option[valueKey]] = true;
      option.children.forEach(dfs);
    }

    if (props.expandedByDefault) {
      props.options.forEach(dfs);
    }

    return { expanded, options: this.listOptions(expanded, props) };
  }

  filter = (options, value) => {
    // TODO: fix expand
    const searchKey = value.toLowerCase();
    const { valueKey, labelKey } = this.props;
    const { expanded } = this.state;
    const ok = {};
    const newExpanded = { ...expanded };

    function dfs(option) {

      const label = option[labelKey].toLowerCase();
      const optionKey = option[valueKey];
      const inChildren =  option.children.reduce((acc, child) => dfs(child) || acc, false);
      if (inChildren && !expanded[optionKey]) {
        newExpanded[optionKey] = true;
      }
      ok[optionKey] = inChildren || label.includes(searchKey);
      return ok[optionKey];
    }

    this.props.options.forEach((option) => {
      if (option.level === 0) {
        dfs(option);
      }
    });

    const filteredOptions = this.listOptions(newExpanded, this.props).filter((option) => ok[option[valueKey]]);
    this.setState({ expanded: newExpanded, options: filteredOptions });

    return filteredOptions;
  }

  isDisabledOption(option) {
    return option.expandable;
  }

  optionRenderer = (option) => {
    const { levelOffset, theme: customTheme } = this.props;
    const optionWrapperProps = {
      style: { marginLeft: levelOffset * option.level },
      className: classNames(theme.optionWrapper, customTheme.optionWrapper)
    };
    const optionProps = {
      className: classNames(
        theme.option,
        customTheme.option,
        { [theme.disabled]: this.isDisabledOption(option) }
      )
    };

    return (
      <div {...optionWrapperProps}>
        {this.renderIcon(option)}
        <div {...optionProps}>
          {this.renderOptionLabel(option)}
        </div>
      </div>
    );
  }

  valueRenderer = (value) => {
    const { labelKey } = this.props;
    return (
      <div className={theme.value}>
        {value.item[labelKey]}
      </div>
    );
  }

  renderIcon(option) {
    if (option.expandable) {
      const { valueKey, theme: customTheme } = this.props;
      const iconProps = {
        type: this.state.expanded[option[valueKey]] ? 'minus' : 'plus',
        className: classNames(theme.iconExpand, customTheme.iconExpand),
        size: '10px'
      };
      return <Icon {...iconProps} />;
    }
    return null;
  }

  renderOptionLabel(option) {
    const { labelKey, theme: customTheme } = this.props;
    const optionLabelProps = {
      className: classNames(theme.optionLabel, customTheme.optionLabel)
    };

    return (
      <div {...optionLabelProps}>
        {option[labelKey]}
      </div>
    );
  }

  render() {
    const selectProps = this.getSelectProps();
    return <Select {...selectProps} />;
  }
}

GroupSelect.defaultProps = {
  emptyValue: null,
  expandedByDefault: true,
  clearable: true,
  labelKey: 'label',
  valueKey: 'treeId',
  levelOffset: 20,
  theme: {}
};

export default GroupSelect;
