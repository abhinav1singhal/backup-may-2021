import React, { PropTypes } from 'react';
import classNames from 'classnames';
import Icon from '../../../../Icon';

import theme from './ValueItem.css';

class ValueItem extends React.Component {
  static propTypes = {
    option: PropTypes.object.isRequired,
    label: PropTypes.oneOfType([
      PropTypes.string,
      PropTypes.arrayOf(PropTypes.string)
    ]).isRequired,
    className: PropTypes.string,
    disabled: PropTypes.bool,
    onRemove: PropTypes.func.isRequired
  }

  onMouseDown = (e) => {
    e.stopPropagation();
  }

  onClick = () => {
    this.props.onRemove(this.props.option);
  }

  renderLabel() {
    const { label } = this.props;
    const res = [];
    label.forEach((item, i) => {
      if (i > 0) {
        res.push(<span className={theme.separator} key={`sep-${i}`}>/</span>);
      }
      res.push(<span className={theme.labelItem} key={`item-${i}`}>{item}</span>);
    });

    return res;
  }

  render() {
    const { className, label, disabled } = this.props;
    const iconProps = {
      size: '10px',
      type: 'exit',
      className: theme.icon,
      onClick: this.onClick,
      onMouseDown: this.onMouseDown
    };

    return (
      <div className={classNames(theme.root, { [theme.disabled]: disabled }, className)}>
        {this.renderLabel(label)}
        {!disabled && <div><Icon {...iconProps} /></div>}
      </div>
    );
  }
}

export default ValueItem;
