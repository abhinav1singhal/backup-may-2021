import GroupMultiSelect from '../GroupMultiSelect';

function addValue(option, value, checked) {
  const added = [option];

  let cur = option;
  while (cur.parent) {
    cur = cur.parent;
    if (!checked.has(cur)) {
      added.push(cur);
    } else {
      break;
    }
  }
  return value.concat(added);
}

function removeValue(option, value, checked) {
  const removed = new Set([option]);

  function dfs(cur) {
    if (checked.has(cur)) {
      removed.add(cur);
      cur.children.forEach(dfs);
    }
  }

  option.children.forEach(dfs);

  return value.filter((item) => !removed.has(item));
}

class TreeSelect extends GroupMultiSelect {
  isCheckboxLabel() {
    return true;
  }

  onToggleValue(option) {
    const { value } = this.props;
    const newValue = this.checked.has(option) ? removeValue(option, value, this.checked) : addValue(option, value, this.checked);
    this.props.onChange(newValue);
  }
}

export default TreeSelect;
