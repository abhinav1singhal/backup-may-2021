import GroupMultiSelect from '../GroupMultiSelect';

function addValue(option, value, checked) {
  const added = [];

  function dfs(cur) {
    if (cur.children.length === 0 && !checked.has(cur)) {
      added.push(cur);
    }
    cur.children.forEach(dfs);
  }

  dfs(option);
  return value.concat(added);
}

function removeValue(option, value, checked) {
  const removed = new Set();

  function dfs(cur) {
    if (checked.has(cur)) {
      removed.add(cur);
    }
    cur.children.forEach(dfs);
  }

  dfs(option);

  return value.filter((item) => !removed.has(item));
}

function buildOtherChecked(options, checked) {
  const res = {
    checked: new Set(),
    intermediate: new Set()
  };

  function dfs(option) {
    if (option.children.length > 0) {
      const childRes = option.children.reduce((acc, child) => {
        const cur = dfs(child);
        return { all: acc.all && cur.all, some: acc.some || cur.some };
      }, {all: true, some: false});
      if (childRes.all) {
        res.checked.add(option);
      } else if (childRes.some) {
        res.intermediate.add(option);
      }
      return childRes;
    }
    return { all: checked.has(option), some: checked.has(option) };
  }

  options.forEach(dfs);
  return res;
}

class ActiveGroupSelect extends GroupMultiSelect {
  constructor(props) {
    super(props);

    this.parentResult = buildOtherChecked(props.options, this.checked);
  }

  componentWillReceiveProps(props) {
    super.componentWillReceiveProps(props);

    this.parentResult = buildOtherChecked(props.options, this.checked);
  }

  isCheckboxLabel() {
    return true;
  }

  isCheckedOption(option) {
    return this.checked.has(option) || this.parentResult.checked.has(option);
  }

  isIntermediateOption(option) {
    return this.parentResult.intermediate.has(option);
  }

  onToggleValue(option) {
    const { value } = this.props;
    let newValue;
    if (this.checked.has(option) || this.parentResult.checked.has(option)) {
      newValue = removeValue(option, value, this.checked, this.parentResult.checked);
    } else {
      newValue = addValue(option, value, this.checked, this.parentResult.checked);
    }
    this.props.onChange(newValue);
  }
}

export default ActiveGroupSelect;
