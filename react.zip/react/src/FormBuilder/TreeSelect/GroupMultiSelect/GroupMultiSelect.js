import React, { PropTypes } from 'react';
import classNames from 'classnames';
import { isEmpty } from 'lodash';
import ThreeBox from '../../ThreeBox';

import GroupSelect from '../GroupSelect';
import ValueItem from '../components/ValueItem';

import theme from './GroupMultiSelect.css';


function removeOption(value, option) {
  return value.filter((item) => item !== option);
}

function addOption(value, option) {
  return value.concat(option);
}

function prepareTooltip(value) {
  if (value.length > 1) {
    return `${value.length} selected`;
  }
  return value[0].treeLabel.join(' / ');
}

class GroupMultiSelect extends GroupSelect {
  static propTypes = {
    ...GroupSelect.propTypes,
    value: PropTypes.arrayOf(PropTypes.object).isRequired
  };

  constructor(props) {
    super(props);

    this.state = {
      ...this.state,
      value: isEmpty(props.value) ?  null : {treeId: prepareTooltip(props.value), label: 'object'}
    };
    this.checked = new Set(props.value);
  }

  componentWillReceiveProps(props) {
    super.componentWillReceiveProps(props);

    if (this.props.value !== props.value)  {
      this.checked = new Set(props.value);
      this.setState(isEmpty(props.value) ? { value: null } : { value: { treeId: prepareTooltip(props.value), label: 'object' } });
    }
  }

  getNewValue(option) {
    if (this.isDisabledOption(option)) {
      return this.props.value;
    }

    const { value } = this.props;
    return this.checked.has(option) ? removeOption(value, option) : addOption(value, option);
  }

  getSelectProps() {
    const baseProps = super.getSelectProps();
    const { theme: customTheme } = this.props;

    return {
      ...baseProps,
      customTheme: {
        ...baseProps.customTheme,
        selectControl: classNames(theme.selectControl, customTheme.selectControl),
        clearIcon: classNames(theme.clearIcon, customTheme.clearIcon),
        searchInput: classNames(theme.searchInput, customTheme.searchInput)
      },
      valueWrapperClassName: classNames(theme.valueWrapper, customTheme.valueWrapper)
    };
  }

  isCheckboxLabel(option) {
    return !option.expandable;
  }

  isCheckedOption(option) {
    return this.checked.has(option);
  }

  isIntermediateOption() {
    return false;
  }

  renderOptionLabel(option) {
    if (this.isCheckboxLabel(option)) {
      const { labelKey, theme: customTheme } = this.props;
      const checkboxProps = {
        className: classNames(theme.checkbox, customTheme.checkbox),
        label: option[labelKey],
        checked: this.isCheckedOption(option),
        intermediate: this.isIntermediateOption(option),
        ref: (el) => { this[`threebox-${option.treeId}`] = el; }
      };

      return <ThreeBox {...checkboxProps} />;
    }
    return super.renderOptionLabel(option);
  }

  valueRenderer = () => {
    return this.props.value.map((option) => {
      const itemProps = {
        key: option.treeId,
        option,
        label: option.treeLabel,
        className: this.props.theme.valueItem,
        disabled: this.props.disabled,
        onRemove: this.onChange
      };
      return <ValueItem {...itemProps} />;
    });
  }
}

GroupMultiSelect.defaultProps = {
  ...GroupSelect.defaultProps,
  emptyValue: [],
  value: []
};

export default GroupMultiSelect;
