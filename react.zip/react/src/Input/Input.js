/* eslint-disable react/no-set-state */

import React, { PropTypes } from 'react';
import { uniqueId, get, isNumber } from 'lodash';
import classNames from 'classnames';
import FormGroup from '../BootstrapComponents/FormGroup';
import ClearIcon from '../sharedComponents/ClearIcon';
import Glyphicon from 'react-bootstrap/lib/Glyphicon';

import defaultTheme from './Input.css';

export default class Input extends React.Component {

  componentWillMount() {
    const id = this.props.id || uniqueId('inputId_');
    const { value: val } = this.props;
    const value = !val && !isNumber(val) ? null : val;
    this.setState({ id, value });
  }

  componentWillReceiveProps(nextProps) {
    const { value } = nextProps;
    if (this.props.value !== value && this.state.value !== value) {
      this.setState({ value });
    }
  }

  onClearValue = (e) => {
    const { onClear } = this.props;

    if (onClear) {
      onClear(e);
    }
    this.setState({ value: '' });
  }

  onChange = (e) => {
    const { onChange } = this.props;

    if (onChange) {
      onChange(e);
    }
    if (this.isText()) {
      this.setState({ value: e.target.value });
    }
  }

  getInputDOMNode() {
    return this.refs.input;
  }

  getValue() {
    if (this.props.type === 'static') {
      return this.props.value;
    } else if (this.props.type) {
      if (this.props.type === 'select' && this.props.multiple) {
        return this.getSelectedOptions();
      } else if (this.isText()) {
        return this.state.value;
      }
      return get(this.getInputDOMNode(), 'value');
    }
    throw new Error('Cannot use getValue without specifying input type.');
  }

  getChecked() {
    return this.getInputDOMNode().checked;
  }

  getSelectedOptions() {
    const values = [];

    Array.prototype.forEach.call(
      this.getInputDOMNode().getElementsByTagName('option'),
      (option) => {
        if (option.selected) {
          const value = option.getAttribute('value') || option.innerHtml;
          values.push(value);
        }
      });

    return values;
  }

  focus() {
    this.refs.input.focus();
  }

  isText() {
    return this.props.type === 'text';
  }

  isCheckboxOrRadio() {
    return this.props.type === 'checkbox' || this.props.type === 'radio';
  }

  isFile() {
    return this.props.type === 'file';
  }

  renderInputGroup(children) {
    const addonBefore = this.props.addonBefore ? (
      <span className={classNames('input-group-addon', this.props.theme.addonBefore)} key="addonBefore">
        {this.props.addonBefore}
      </span>
    ) : null;

    const addonAfter = this.props.addonAfter ? (
      <span className={classNames('input-group-addon', this.props.theme.addonAfter)} key="addonAfter">
        {this.props.addonAfter}
      </span>
    ) : null;

    const buttonBefore = this.props.buttonBefore ? (
      <span className={classNames('input-group-btn', this.props.theme.buttonBefore)}>
        {this.props.buttonBefore}
      </span>
    ) : null;

    const buttonAfter = this.props.buttonAfter ? (
      <span className={classNames('input-group-btn', this.props.theme.buttonAfter)}>
        {this.props.buttonAfter}
      </span>
    ) : null;

    let inputGroupClassName;
    switch (this.props.bsSize) {
      case 'small': inputGroupClassName = classNames('input-group-sm', this.props.theme.inputGroup); break;
      case 'large': inputGroupClassName = classNames('input-group-lg', this.props.theme.inputGroup); break;
      case 'default': inputGroupClassName = classNames('input-group-def', this.props.theme.inputGroup); break;
      default:
    }

    return addonBefore || addonAfter || buttonBefore || buttonAfter ? (
      <div className={classNames(inputGroupClassName, 'input-group')} key="input-group">
        {addonBefore}
        {buttonBefore}
        {children}
        {addonAfter}
        {buttonAfter}
      </div>
    ) : children;
  }

  renderClearIcon() {
    if (!this.getValue()) {
      return null;
    }

    const clearClassName = classNames(this.props.theme.clearIcon, defaultTheme.clearIcon);
    return (
      <ClearIcon
        className={clearClassName}
        title={this.props.clearText}
        onClick={this.onClearValue} />
    );
  }

  renderIcon() {
    if (this.props.hasFeedback) {
      if (this.props.feedbackIcon) {
        return React.cloneElement(this.props.feedbackIcon, { formControlFeedback: true });
      }

      switch (this.props.bsStyle) {
        case 'success': return <Glyphicon formControlFeedback glyph="ok" key="icon" />;
        case 'warning': return <Glyphicon formControlFeedback glyph="warning-sign" key="icon" />;
        case 'error': return <Glyphicon formControlFeedback glyph="remove" key="icon" />;
        default: return <span className="form-control-feedback" key="icon" />;
      }
    } else if (this.props.clearable && !this.props.disabled && this.isText()) {
      return this.renderClearIcon();
    } else {
      return null;
    }
  }

  renderHelp() {
    return this.props.help ? (
      <span className={classNames('help-block', this.props.theme.helpBlock)} key="help">
        {this.props.help}
      </span>
    ) : null;
  }

  renderCheckboxAndRadioWrapper(children) {
    const classes = {
      'checkbox': this.props.type === 'checkbox',
      'radio': this.props.type === 'radio'
    };

    return (
      <div className={classNames(classes, this.props.theme.checkboxRadioWrapper)} key="checkboxRadioWrapper">
        {children}
      </div>
    );
  }

  renderWrapper(children) {
    return (this.props.wrapperClassName || this.props.theme.wrapper || this.props.clearable) ? (
      <div
        className={classNames(this.props.wrapperClassName, this.props.theme.wrapper, defaultTheme.wrapper)}
        key="wrapper">
        {children}
      </div>
    ) : children;
  }

  renderLabel(children) {
    const classes = {
      'control-label': !this.isCheckboxOrRadio()
    };
    classes[this.props.labelClassName] = this.props.labelClassName;

    return this.props.label ? (
      <label htmlFor={this.state.id} className={classNames(classes, this.props.theme.label)} key="label">
        {children}
        {this.props.label}
      </label>
    ) : children;
  }

  renderInput() {
    if (!this.props.type) {
      return this.props.children;
    }
    const props = {
      ...this.props,
      ref: 'input',
      key: 'input',
      id: this.state.id
    };

    switch (this.props.type) {
      case 'select':
        return (
          <select {...props} className={classNames(this.props.className, 'form-control', this.props.theme.root)} >
            {this.props.children}
          </select>
        );
      case 'textarea':
        return <textarea {...props} className={classNames(this.props.className, 'form-control', this.props.theme.root)} />;
      case 'static':
        return (
          <p {...props} className={classNames(this.props.className, 'form-control-static', this.props.theme.root)} >
            {this.props.value}
          </p>
        );
      default:
        const className = this.isCheckboxOrRadio() || this.isFile() ? '' : 'form-control';
        const value = this.getValue();

        const clearable = this.props.clearable ? 'clearable' : '';

        return (
          <input
            {...props}
            value={value}
            className={classNames(this.props.className, className, clearable, this.props.theme.root)}
            onChange={this.onChange}
          />
        );
    }
  }

  renderFormGroup(children) {
    return <FormGroup {...this.props}>{children}</FormGroup>;
  }

  renderChildren() {
    return !this.isCheckboxOrRadio() ? [
      this.renderLabel(),
      this.renderWrapper([
        this.renderInputGroup(
          this.renderInput()
        ),
        this.renderIcon(),
        this.renderHelp()
      ])
    ] : this.renderWrapper([
      this.renderCheckboxAndRadioWrapper(
        this.renderLabel(
          this.renderInput()
        )
      ),
      this.renderHelp()
    ]);
  }

  render() {
    const children = this.renderChildren();
    return this.renderFormGroup(children);
  }
}

Input.propTypes = {
  type: PropTypes.string,
  label: PropTypes.node,
  help: PropTypes.node,
  addonBefore: PropTypes.node,
  addonAfter: PropTypes.node,
  buttonBefore: PropTypes.node,
  buttonAfter: PropTypes.node,
  bsSize: PropTypes.oneOf(['small', 'medium', 'large', 'default']),
  bsStyle: PropTypes.oneOf(['success', 'warning', 'error']),
  hasFeedback: PropTypes.bool,
  feedbackIcon: PropTypes.node,
  id: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number
  ]),
  groupClassName: PropTypes.string,
  wrapperClassName: PropTypes.string,
  labelClassName: PropTypes.string,
  multiple: PropTypes.bool,
  disabled: PropTypes.bool,
  /**
    Should it be possible to reset value
  */
  clearable: PropTypes.bool,
  value: PropTypes.any,
  onChange: PropTypes.func,
  /**
    Handler on clear icon click
  */
  onClear: PropTypes.func,
  /**
    Clear icon tittle text
  */
  clearText: PropTypes.string,
  className: PropTypes.string,
  children: PropTypes.any,

  theme: PropTypes.shape({
    root: PropTypes.string,
    addonBefore: PropTypes.string,
    addonAfter: PropTypes.string,
    buttonBefore: PropTypes.string,
    buttonAfter: PropTypes.string,
    inputGroup: PropTypes.string,
    helpBlock: PropTypes.string,
    checkboxRadioWrapper: PropTypes.string,
    wrapper: PropTypes.string,
    label: PropTypes.string,
    clearIcon: PropTypes.string
  })
};

Input.defaultProps = {
  disabled: false,
  hasFeedback: false,
  multiple: false,
  clearable: false,
  theme: {}
};
