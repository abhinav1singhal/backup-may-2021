export default from './Input';
