/* global describe, it */

import React from 'react';
import TestUtils from 'react-addons-test-utils';
import expect from 'expect';

import Input from '../Input';

describe('src.Input.__tests__.InputSpec', () => {

  describe('Input', () => {

    it('Input.getValue() should return current value', () => {

      const inputProps = {
        type: 'text',
        value: 'test',
        onChange: () => {},
        placeholder: 'Search by Analytic Object Name'
      };

      const component = TestUtils.renderIntoDocument(
        React.createElement(
          Input, {...inputProps}
        )
      );

      expect(component.getValue()).toBe(inputProps.value);

    });

  });
});
