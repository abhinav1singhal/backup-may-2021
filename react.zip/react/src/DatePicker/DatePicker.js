import React, { PropTypes } from 'react';
import { default as ExternalDatePicker } from 'react-datepicker';
import CSSModules from 'react-css-modules';
import Glyphicon from '../BootstrapComponents/Glyphicon';

import { pick, keys, noop } from 'lodash';
import styles from './DatePicker.css';

let DatePicker = class extends React.Component {

  static propTypes = {
    /**
     * Custom class name for input
     */
    className: PropTypes.string,
    /**
     * initial field value
     */
    selected: PropTypes.shape({
      _isAMomentObject: PropTypes.bool.isRequired
    }),
    /**
     * onChange handler: function (newDate) {}
     */
    onChange: PropTypes.func.isRequired,
    /**
     * Custom date format
     */
    dateFormat: PropTypes.string,
    /**
     * Placeholder text
     */
    placeholderText: PropTypes.string,
    /**
     * Specific date range
     */
    minDate: PropTypes.object,
    /**
     * Specific date range
     */
    maxDate: PropTypes.object,
    /**
     * Custom week start day
     */
    weekStart: PropTypes.string,
    /**
     * Exclude dates
     */
    excludeDates: PropTypes.arrayOf(
      PropTypes.shape({
        _isAMomentObject: PropTypes.bool.isRequired
      })
    ),
    /**
     * Include dates
     */
    includeDates: PropTypes.arrayOf(
      PropTypes.shape({
        _isAMomentObject: PropTypes.bool.isRequired
      })
    ),
    /**
     * Control label
     */
    label: PropTypes.string,
    /**
     * Disable datepicker
     */
    disabled: PropTypes.bool,
    /**
     * onBlur handler: function (date) {}
     */
    onBlur: PropTypes.func,
    /**
     * Configure Popover Placement
     */
    popoverAttachment: PropTypes.string,
    /**
     * Configure Popover Placement
     */
    popoverTargetAttachment: PropTypes.string,
    /**
     * Configure Popover Placement
     */
    popoverTargetOffset: PropTypes.string,
    /**
     * TabIndex
     */
    tabIndex: PropTypes.number,
    /**
     * Hide year dropdown
     */
    showYearDropdown: PropTypes.bool
  };

  getClasses = () => {
    let inputGroupClassName = 'input-group';
    switch (this.props.bsSize) {
      case 'small':
        inputGroupClassName += ' input-group-sm';
        break;
      case 'large':
        inputGroupClassName += ' input-group-lg';
        break;
      default:
    }
    return inputGroupClassName;
  };

  focus() {
    this.refs.picker.refs.input.focus();
  }

  renderLabel() {
    return (
      <label className="control-label">
        <span>{ this.props.label }</span>
      </label>
    );
  }

  render() {
    const props = pick(this.props, ...keys(DatePicker.propTypes));

    return (
      <div styleName="root"
        data-test="DatePicker__root">
        <div className="form-group">
          { this.props.label ? this.renderLabel() : null }
          <div className={this.getClasses()}>
            <span className="input-group-addon">
              <Glyphicon glyph="calendar" />
            </span>
            <ExternalDatePicker
              {...props}
              isClearable={false}
              ref="picker"
              className="form-control" />
          </div>

        </div>
      </div>
    );
  }

};

DatePicker = CSSModules(styles)(DatePicker);

DatePicker.defaultProps = {
  onBlur: noop,
  selected: undefined,
  showYearDropdown: true
};

export default DatePicker;
