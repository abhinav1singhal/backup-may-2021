/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { markup } from '../../utils/testUtils';
import expect from 'expect';

import DatePicker from '../DatePicker';

describe('src.DatePicker.__tests__.DatePickerSpec', () => {

  describe('DatePicker', () => {
    const baseProps = {
      onChange: () => {},
      selected: undefined
    };

    it('should render DatePicker', () => {

      const component = (<DatePicker {...baseProps}/>);

      const expectedMarkup = markup(`
        <div data-test="DatePicker__root" class="DatePicker__root">
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon">
                <span data-test="Glyphicon" class="glyphicon glyphicon-calendar"></span>
              </span>
              <div class="datepicker__input-container">
                <input type="text" class="datepicker__input form-control"/>
              </div>
            </div>
          </div>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should render small DatePicker', () => {

      const component = (<DatePicker bsSize="small" {...baseProps}/>);

      const expectedMarkup = markup(`
        <div data-test="DatePicker__root" class="DatePicker__root">
          <div class="form-group">
            <div class="input-group input-group-sm">
              <span class="input-group-addon">
                <span data-test="Glyphicon" class="glyphicon glyphicon-calendar"></span>
              </span>
              <div class="datepicker__input-container">
                <input type="text" class="datepicker__input form-control"/>
              </div>
            </div>
          </div>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should render large DatePicker', () => {

      const component = (<DatePicker bsSize="large" {...baseProps}/>);

      const expectedMarkup = markup(`
        <div data-test="DatePicker__root" class="DatePicker__root">
          <div class="form-group">
            <div class="input-group input-group-lg">
              <span class="input-group-addon">
                <span data-test="Glyphicon" class="glyphicon glyphicon-calendar"></span>
              </span>
              <div class="datepicker__input-container">
                <input type="text" class="datepicker__input form-control"/>
              </div>
            </div>
          </div>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

  });
});
