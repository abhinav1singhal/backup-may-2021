import React, { PropTypes } from 'react';
import CSSModules from 'react-css-modules';

const image = require('./images/techstack_logo.png');

class techstackLogo extends React.Component {

  static propTypes = {
    brandHref: PropTypes.string
  };

  render() {
    return (
      <a href={this.props.brandHref}
         styleName="logo"
         data-test="techstackLogo">
        <img styleName="image" src={image} />
      </a>
    );
  }
}

export default CSSModules(require('./techstackLogo.css'))(techstackLogo);
