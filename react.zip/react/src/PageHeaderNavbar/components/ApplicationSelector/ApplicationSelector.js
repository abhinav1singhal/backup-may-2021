import React, { PropTypes } from 'react';
import CSSModules from 'react-css-modules';

class ApplicationSelector extends React.Component {

  static propTypes = {
    applicationName: PropTypes.string
  };

  render() {
    return (
      <div styleName="root" data-test="ApplicationSelector__root">
        { this.props.applicationName }
      </div>
    );
  }
}

export default CSSModules(require('./ApplicationSelector.css'))(ApplicationSelector);
