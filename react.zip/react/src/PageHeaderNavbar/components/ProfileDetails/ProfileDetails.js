import React, { PropTypes } from 'react';
import classNames from 'classnames';

import defaultTheme from './ProfileDetails.css';

class ProfileDetails extends React.Component {

  static propTypes = {
    /**
     * Defines the current user name
     */
    userName: PropTypes.string.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string,
      textContainer: PropTypes.string
    })
  };

  render() {
    const { theme } = this.props;

    return (
      <div className={classNames(defaultTheme.root, theme.root)} data-test="ProfileDetails__root">
        <div className={classNames(defaultTheme.textContainer, theme.textContainer)} data-test="ProfileDetails__userName" title={this.props.userName}>
          {this.props.userName}
        </div>
      </div>
    );
  }
}

ProfileDetails.defaultProps = {
  theme: {}
};

export default ProfileDetails;
