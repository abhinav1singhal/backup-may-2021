/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import expect from 'expect';

import PageHeaderNavbar from '../PageHeaderNavbar';

describe('src.PageHeaderNavbar.__tests__.PageHeaderNavbarSpec', () => {

  describe('PageHeaderNavbar', () => {

    it('should render user details, techstack logo and appplication selector', () => {
      const component = (<PageHeaderNavbar {...{
        userName: 'Taran Adarsh',
        applicationName: 'DCE'
      }} />);

      const renderedComponent = renderToStaticMarkup(component);

      [
        'data-test="PageHeaderNavbar__root"',
        'data-test="techstackLogo"',
        'data-test="ProfileDetails__root"',
        'data-test="ProfileDetails__userName"',
        'data-test="ApplicationSelector__root"'
      ].forEach((text) => {
        expect(renderedComponent).toInclude(text);
      });

    });

  });

});
