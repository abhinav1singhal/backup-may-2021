import React, { PropTypes } from 'react';
import classNames from 'classnames';
import ProfileDetails from './components/ProfileDetails/ProfileDetails';
import techstackLogo from './components/techstackLogo/techstackLogo';
import ApplicationSelector from './components/ApplicationSelector/ApplicationSelector';

import defaultTheme from './PageHeaderNavbar.css';

class PageHeaderNavbar extends React.Component {

  static propTypes = {
    /**
     * Current user
     */
    userName: PropTypes.string,

    /**
     * Application name
     */
    applicationName: PropTypes.string,

    /**
     * Logo link
     */
    brandHref: PropTypes.string,

    /**
     * Children
     */
    children: PropTypes.any,

    theme: PropTypes.shape({
      root: PropTypes.string,
      logoContainer: PropTypes.string,
      applicationSelectorContainer: PropTypes.string,
      centerContainer: PropTypes.string,
      userContainer: PropTypes.string
    }),

    profileDetailsTheme: PropTypes.object
  };

  renderUser() {
    return (
      <ProfileDetails userName={this.props.userName} theme={this.props.profileDetailsTheme} />
    );
  }

  render() {
    const { theme } = this.props;
    return (
        <div className={classNames(defaultTheme.root, theme.root)} data-test="PageHeaderNavbar__root">
          <div className={classNames(defaultTheme.logoContainer, theme.logoContainer)}>
            <techstackLogo brandHref={this.props.brandHref} />
          </div>
          <div className={classNames(defaultTheme.applicationSelectorContainer, theme.applicationSelectorContainer)}>
            <ApplicationSelector applicationName={this.props.applicationName} />
          </div>
          <div className={classNames(defaultTheme.centerContainer, theme.centerContainer)}>
            {this.props.children}
          </div>
          <div className={classNames(defaultTheme.userContainer, theme.userContainer)}>
            { this.props.userName ? this.renderUser() : null }
          </div>
        </div>
    );
  }
}

PageHeaderNavbar.defaultProps = {
  theme: {}
};

export default PageHeaderNavbar;
