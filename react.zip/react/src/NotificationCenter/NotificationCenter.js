import React from 'react';
import Constants from './utils/constants';
import NotificationContainer from './NotificationContainer';

import { keys, filter, map } from 'lodash';

export default class NotificationCenter extends React.Component {

  static propTypes = {
    /**
     * Array of notifications
     * @type {array&lt;object&gt;}
     */
    notifications: React.PropTypes.arrayOf(
      React.PropTypes.shape({
        level: React.PropTypes.string.isRequired,
        title: React.PropTypes.string.isRequired,
        message: React.PropTypes.string.isRequired
      })
    ).isRequired,
    /**
     * Function which will be called after hide of notification
     */
    onHide: React.PropTypes.func
  };

  static notificationDefaults(level = 'info') {
    const autoDismiss =
      level === Constants.levels.error || level === Constants.levels.warning ? 0 : 5;

    return {
      position: 'tr',
      dismissible: true,
      autoDismiss
    };
  }

  render() {
    let containers = null;

    if (this.props.notifications.length) {

      const notifications = map(this.props.notifications, (notification) => {
        return {
          ...NotificationCenter.notificationDefaults(notification.level),
          ...notification
        };
      });

      containers = keys(Constants.positions).map((position) => {
        const output = filter(notifications, (notification) => {
          return notification.position === position;
        });

        if (output.length) {
          return (
            <NotificationContainer {...{
              key: position,
              position,
              notifications: output,
              onRemove: (uid) => {
                if (this.props.onHide) {
                  this.props.onHide(uid);
                }
              },
              allowHTML: true
            }} />
          );
        }
        return null;
      });
    }

    return (
      <div data-test="NotificationCenter__root">
        {containers}
      </div>
    );
  }

}
