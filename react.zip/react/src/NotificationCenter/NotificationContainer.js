import React, { PropTypes } from 'react';
import NotificationItem from './NotificationItem';
import Constants from './utils/constants';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import CSSModules from 'react-css-modules';

const BOTTOM_POSITIONS = [Constants.positions.bl, Constants.positions.br, Constants.positions.bc];

class NotificationContainer extends React.Component {
  static propTypes = {
    key: PropTypes.string,
    position: PropTypes.string.isRequired,
    notifications: PropTypes.arrayOf(
      PropTypes.shape({
        level: PropTypes.string.isRequired,
        title: PropTypes.string.isRequired,
        message: PropTypes.string.isRequired
      })
    ).isRequired,
    onRemove: PropTypes.func,
    allowHTML: PropTypes.bool,
    styles: PropTypes.object
  };

  render() {

    let { notifications } = this.props;

    if (BOTTOM_POSITIONS.indexOf(this.props.position) > -1) {
      notifications = notifications.reverse();
    }

    const notifictionItems = notifications.map((notification) => {
      return (<NotificationItem
        key={notification.uid}
        notification={notification}
        onRemove={this.props.onRemove}
        allowHTML={this.props.allowHTML}
      />);
    });

    return (
      <div styleName={`notifications-container notifications-${this.props.position}`}
           data-test={`NotificationContainer__nofitications-container-${this.props.position}`}>
        <ReactCSSTransitionGroup transitionName={{
          enter: this.props.styles['notification-transition-enter'],
          appear: this.props.styles['notification-transition-appear'],
          leave: this.props.styles['notification-transition-leave'],
          leaveActive: this.props.styles['notification-transition-leave-active']
        }} transitionAppear transitionAppearTimeout={500}
           transitionEnter transitionEnterTimeout={500}
           transitionLeave transitionLeaveTimeout={300}>
          {notifictionItems}
        </ReactCSSTransitionGroup>
      </div>
    );
  }
}

export default CSSModules(require('./styles/NotificationContainer.css'), { allowMultiple: true })(NotificationContainer);
