/* global describe, it, beforeEach, afterEach, sinon, clock */
/* eslint-disable no-new, new-cap */

import Helpers from '../utils/helpers';
import expect from 'expect';
import lolex from 'lolex';

let clock;

describe('src.NotificationCenter.__tests__.helpersSpec', () => {

  beforeEach(() => {
    clock = lolex.install(window);
  });

  afterEach(() => {
    clock.uninstall();
  });

  it('should call callback in specified time', () => {
    const spy = sinon.spy();
    const milliseconds = 1000;

    new Helpers.timer(() => {
      spy();
    }, milliseconds);

    clock.tick(milliseconds);
    sinon.assert.calledOnce(spy);
  });

  it('should call callback after pause in specified time', () => {
    const spy = sinon.spy();
    const milliseconds = 1000;
    const timer = new Helpers.timer(() => {
      spy();
    }, milliseconds);

    timer.pause();
    clock.tick(milliseconds);

    expect(spy.callCount).toEqual(0);

    timer.resume();
    clock.tick(milliseconds);

    sinon.assert.calledOnce(spy);
  });

  it('shouldn\'t call callback after timer clear', () => {
    const spy = sinon.spy();
    const milliseconds = 1000;
    const timer = new Helpers.timer(() => {
      spy();
    }, milliseconds);

    timer.clear();
    clock.tick(milliseconds);

    expect(spy.callCount).toEqual(0);
  });

});
