/* global describe, it, beforeEach, afterEach, sinon */

import Notification from '../Notification';
import expect from 'expect';

describe('src.NotificationCenter.__tests__.NotificationSpec', () => {

  const title = 'title';
  const message = 'message';

  it('should create correct error notification', () => {
    const level = 'error';
    const expected = { level, title, message };

    const notification = Notification.error('title', 'message');
    expect(notification).toEqual({ ...expected, uid: notification.uid });
  });

  it('should create correct success notification', () => {
    const level = 'success';
    const expected = { level, title, message };

    const notification = Notification.success('title', 'message');
    expect(notification).toEqual({ ...expected, uid: notification.uid });
  });

  it('should create correct warning notification', () => {
    const level = 'warning';
    const expected = { level, title, message };

    const notification = Notification.warning('title', 'message');
    expect(notification).toEqual({ ...expected, uid: notification.uid });
  });

  it('should create correct info notification', () => {
    const level = 'info';
    const expected = { level, title, message };

    const notification = Notification.info('title', 'message');
    expect(notification).toEqual({ ...expected, uid: notification.uid });
  });

  it('should provide options object properties', () => {
    const level = 'info';
    const dismissible = false;
    const autoDismiss = 10;
    const options = { dismissible, autoDismiss };

    const expected = {
      level,
      title,
      message,
      dismissible,
      autoDismiss
    };

    const notification = Notification.info('title', 'message', options);
    expect(notification).toEqual({ ...expected, uid: notification.uid });
  });

});
