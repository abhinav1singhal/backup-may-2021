/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import NotificationCenter from '../NotificationCenter';
import NotificationContainer from '../NotificationContainer';
import Notification from '../Notification';
import TestUtils from 'react-addons-test-utils';
import expect from 'expect';
import { forEach, map, merge } from 'lodash';
import constants from '../utils/constants';

describe('src.NotificationCenter.__tests__.NotificationContainerSpec', () => {
  const shallowRenderer = TestUtils.createRenderer();

  it('should show notifications in original order', () => {
    const notifications = map([
      Notification.error('1', '1', { uid: '1' }),
      Notification.error('2', '2', { uid: '2' }),
      Notification.error('3', '3', { uid: '3' })
    ], (notification) => {
      return merge(
        { },
        notification,
        NotificationCenter.notificationDefaults(constants.levels.errors)
      );
    });

    shallowRenderer.render(
      <NotificationContainer
        key={constants.positions.tr}
        position={constants.positions.tr}
        notifications={notifications} />
    );

    const component = shallowRenderer.getRenderOutput();
    const transitionGroups = component.props.children;
    const notificationItems = transitionGroups.props.children;

    let checkingUid = 1;

    forEach(notificationItems, (notificationItem) => {
      const notification = notificationItem.props.notification;

      expect(notification.uid).toEqual(String(checkingUid));
      checkingUid += 1;
    });
  });

  it('should show notifications in reversed order', () => {
    const notifications = map([
      Notification.error('1', '1', { uid: '1', position: constants.positions.bl }),
      Notification.error('2', '2', { uid: '2', position: constants.positions.bl }),
      Notification.error('3', '3', { uid: '3', position: constants.positions.bl })
    ], (notification) => {
      return merge(
        { },
        notification,
        NotificationCenter.notificationDefaults(constants.levels.errors)
      );
    });

    shallowRenderer.render(
      <NotificationContainer
        key={constants.positions.bl}
        position={constants.positions.bl}
        notifications={notifications} />
    );

    const component = shallowRenderer.getRenderOutput();
    const transitionGroups = component.props.children;
    const notificationItems = transitionGroups.props.children;

    let checkingUid = 3;

    forEach(notificationItems, (notificationItem) => {
      const notification = notificationItem.props.notification;

      expect(notification.uid).toEqual(String(checkingUid));
      checkingUid -= 1;
    });
  });

});
