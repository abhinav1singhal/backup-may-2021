/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { findDOMNode } from 'react-dom';
import { noop } from 'lodash';
import TestUtils from 'react-addons-test-utils';
import NotificationItem from '../NotificationItem';
import expect from 'expect';

describe('src.NotificationCenter.__tests__.NotificationItemSpec', () => {

  it('onRemove() should be after click on notification', () => {
    const spy = expect.createSpy();
    const instance = React.createElement(
      NotificationItem, {
        notification: {
          level: 'success',
          title: 'title',
          message: 'message',
          dismissible: true,
          autoDismiss: 5,
          action: noop
        },
        allowHTML: true,
        onRemove: spy
      }
    );
    const node = findDOMNode(TestUtils.renderIntoDocument(instance));

    TestUtils.Simulate.click(node);

    expect(spy).toHaveBeenCalled();
  });

});
