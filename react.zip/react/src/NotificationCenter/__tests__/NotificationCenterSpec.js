/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import NotificationCenter from '../NotificationCenter';
import Notification from '../Notification';
import TestUtils from 'react-addons-test-utils';
import ReactChildren from 'react/lib/ReactChildren';
import expect from 'expect';

describe('src.NotificationCenter.__tests__.NotificationCenterSpec', () => {
  const shallowRenderer = TestUtils.createRenderer();

  it('should provide default values', () => {
    const spy = expect.createSpy();
    const notification = Notification.error('Error title', 'Error message');
    const overridedNotification = {
      ...notification,
      ...NotificationCenter.notificationDefaults(notification.level)
    };

    shallowRenderer.render(<NotificationCenter notifications={[ notification ]} />);
    const component = shallowRenderer.getRenderOutput();

    ReactChildren.forEach(component.props.children, (group) => {
      if (group && group.props.notifications.length) {
        expect(overridedNotification).toEqual(group.props.notifications[0]);
        spy();
      }
    });

    expect(spy.calls.length).toEqual(1);
  });

  it('shouldn\'t override provided values', () => {
    const spy = expect.createSpy();
    const notification = {
      level: 'error',
      title: 'Error title',
      message: 'Error message',
      position: 'tl',
      dismissible: false,
      autoDismiss: 5
    };

    shallowRenderer.render(<NotificationCenter notifications={[ notification ]} />);
    const component = shallowRenderer.getRenderOutput();

    ReactChildren.forEach(component.props.children, (group) => {
      if (group && group.props.notifications.length) {
        expect(notification).toEqual(group.props.notifications[0]);
        spy();
      }
    });

    expect(spy.calls.length).toEqual(1);
  });

});
