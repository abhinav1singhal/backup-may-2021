import { merge } from 'lodash';
import shortid from 'shortid';

export default class Notification {

  static base(title, message, options = {}) {
    return merge({
      uid: shortid.generate(),
      title,
      message
    }, options);
  }

  static error(title, message, options) {
    return merge({ }, { level: 'error' }, Notification.base(title, message, options));
  }

  static success(title, message, options) {
    return merge({ }, { level: 'success' }, Notification.base(title, message, options));
  }

  static warning(title, message, options) {
    return merge({ }, { level: 'warning' }, Notification.base(title, message, options));
  }

  static info(title, message, options) {
    return merge({ }, { level: 'info' }, Notification.base(title, message, options));
  }

}
