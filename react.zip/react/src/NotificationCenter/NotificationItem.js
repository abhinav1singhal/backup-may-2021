/* eslint-disable react/no-danger */

import React, { PropTypes } from 'react';
import Helpers from './utils/helpers';
import CSSModules from 'react-css-modules';

class NotificationItem extends React.Component {

  static propTypes = {
    notification: PropTypes.object,
    onRemove: PropTypes.func,
    allowHTML: PropTypes.bool
  };

  componentDidMount() {
    const { notification } = this.props;
    const { element } = this.refs;

    this._height = element.offsetHeight;

    if (notification.autoDismiss) {
      this._notificationTimer = new Helpers.timer(() => { // eslint-disable-line
        this._hideNotification();
      }, notification.autoDismiss * 1000);

      element.addEventListener('mouseenter', () => {
        this._notificationTimer.pause();
      });

      element.addEventListener('mouseleave', () => {
        this._notificationTimer.resume();
      });
    }
  }

  onDismiss = () => {
    if (!this.props.notification.dismissible) {
      return;
    }
    this._hideNotification();
  };

  _notificationTimer = null;

  _height = 0;

  _allowHTML(str) {
    if (this.props.allowHTML) {
      return { __html: str };
    }
    return str;
  }

  _defaultAction(e) {
    e.preventDefault();
    const notification = this.props.notification;
    this._hideNotification();
    notification.action.callback();
  }

  _hideNotification = () => {
    if (this._notificationTimer) {
      this._notificationTimer.clear();
    }
    this.props.onRemove(this.props.notification.uid);
  };

  render() {
    const { notification } = this.props;

    let dismiss = null;
    let actionButton = null;
    let title = null;
    let message = null;

    if (notification.title) {
      title = <h4 styleName={`notification-title notification-title-${this.props.notification.level}`}>{notification.title}</h4>;
    }

    if (notification.message) {
      if (this.props.allowHTML) {
        message = (
          <div styleName="notification-message"
             data-test="NotificationItem__notification-message"
             dangerouslySetInnerHTML={this._allowHTML(notification.message)}></div>
        );
      } else {
        message = (
          <div styleName="notification-message"
            data-test="NotificationItem__notification-message">
            {notification.message}
          </div>
        );
      }
    }

    if (notification.dismissible) {
      dismiss = (
        <span
          styleName={`notification-dismiss notification-dismiss-${this.props.notification.level}`}
          data-test="NotificationItem__notification-dismiss"
          >&times;</span>
      );
    }

    if (notification.action) {
      actionButton = (
        <div>
          <button styleName={`notification-action-button notification-action-button-${this.props.notification.level}`}
            data-test="NotificationItem__notification-action-button"
            onClick={this._defaultAction}>
            {notification.action.label}
          </button>
        </div>
      );
    }

    return (
      <div ref="element"
           styleName={`notification notification-${this.props.notification.level}`}
           data-test={`NotificationItem__notification-${this.props.notification.level}`}
           onClick={this.onDismiss}>
        {title}
        {message}
        {dismiss}
        {actionButton}
      </div>
    );
  }

}

export default CSSModules(require('./styles/NotificationItem.css'), { allowMultiple: true })(NotificationItem);
