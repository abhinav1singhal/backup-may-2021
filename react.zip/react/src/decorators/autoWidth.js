/* eslint-disable react/no-set-state, react/prefer-es6-class, no-return-assign */

import React, { PropTypes } from 'react';
import { throttle } from 'lodash';

export default (Component) => {

  return React.createClass({

    propTypes: {
      width: PropTypes.any.isRequired
    },

    getInitialState() {
      this.onResize = throttle(() => {
        if (this.refs.root) {
          const width = this.refs.root.offsetWidth;
          if (this.state.width !== width) {
            this.setState({width});
          }
        }
      }, 30);

      return {};
    },

    componentDidMount() {
      if (this.props.width === 'auto') {
        this.onResize();
        window.addEventListener('resize', this.onResize);
      }
    },

    componentDidUpdate() {
      if (this.props.width === 'auto') {
        this.onResize();
      }
    },

    componentWillUnmount() {
      window.removeEventListener('resize', this.onResize);
    },

    getWrappedInstance() {
      return this.wrappedInstance;
    },

    render() {
      if (this.props.width === 'auto') {
        return (
          <div ref="root" style={{ display: 'block', overflowX: 'hidden', width: '100%' }}>
            { this.state.width ? <Component {...this.props} width={this.state.width}
                                    ref={(component) => this.wrappedInstance = component} /> : null }
          </div>
        );
      }
      return <Component {...this.props} ref={(component) => this.wrappedInstance = component} />;
    }

  });

};
