/* global describe, it, beforeEach, afterEach, sinon */
import React from 'react';
import { findDOMNode, unmountComponentAtNode } from 'react-dom';
import TestUtils from 'react-addons-test-utils';
import expect, { spyOn } from 'expect';
import autoWidth from '../autoWidth';

const DumbComponent = autoWidth((props) => {
  return <div style={{ width: props.width }}>Component</div>;
});

describe('src.decorators.__tests__.autoWidthSpec', () => {

  describe('autoWidth', () => {

    const dummyProps = {
      data: [{ id: 1 }],
      columns: [{ key: 'id', label: 'id' }],
      width: 'auto',
      height: 100
    };

    it('shouldn\'t change width value if numeric value was specified', () => {
      const width = 100;

      const node = findDOMNode(
        TestUtils.renderIntoDocument(<DumbComponent width={width} />)
      );

      expect(node.style.width).toEqual(`${width}px`);
    });

    it('should call add resize event and call onResize if width == auto', () => {
      const spy = spyOn(window, 'addEventListener').andCallThrough();

      TestUtils.renderIntoDocument(
        React.createElement(
          DumbComponent, { ...dummyProps }
        )
      );

      expect(window.addEventListener.calls[0].arguments[0]).toEqual('resize');
      spy.restore();
    });

    it('should remove resize event when component is unmounted', () => {
      const spy = spyOn(window, 'removeEventListener').andCallThrough();

      const component = TestUtils.renderIntoDocument(
        React.createElement(
          DumbComponent, { ...dummyProps }
        )
      );

      const node = findDOMNode(component);
      unmountComponentAtNode(node.parentNode);

      expect(window.removeEventListener.calls[0].arguments[0]).toEqual('resize');
      spy.restore();
    });

  });

});
