/* eslint-disable react/no-set-state */

import React, { PropTypes, cloneElement } from 'react';
import ValidComponentChildren from 'react-bootstrap/lib/utils/ValidComponentChildren';
import { noop, isNumber } from 'lodash';
import classNames from 'classnames';

class Accordion extends React.Component {

  static propTypes = {
    defaultEventKey: PropTypes.number,
    onSelect: PropTypes.func.isRequired,
    theme: PropTypes.object.isRequired,
    className: PropTypes.string,
    children: PropTypes.any
  };

  constructor(props) {
    super(props);
    const activeKey = isNumber(props.defaultEventKey) || props.defaultEventKey ? props.defaultEventKey : null;
    this.state = {
      activeKey
    };
  }

  handleSelect(e, key) {
    e.preventDefault();
    this.props.onSelect(key);
    this.setState({
      activeKey: this.state.activeKey === key ? null : key
    });
  }

  renderItem(child, index) {
    const props = {
      ...child.props,
      ref: child.ref,
      key: child.key ? child.key : index,
      open: child.props.eventKey === this.state.activeKey,
      onSelect: (e) => { this.handleSelect(e, child.props.eventKey); }
    };

    return cloneElement(child, props);
  }

  render() {
    const { theme } = this.props;

    const classes = classNames({
      [theme.root]: true,
      [this.props.className]: !!this.props.className
    });

    return (
      <div className={classes}>
        { ValidComponentChildren.map(this.props.children, this.renderItem.bind(this) )}
      </div>
    );
  }

}

Accordion.defaultProps = {
  theme: require('./Accordion.css'),
  onSelect: noop
};

export default Accordion;
