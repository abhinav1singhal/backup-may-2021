import React, { PropTypes } from 'react';
import { Collapse } from 'react-bootstrap';
import classNames from 'classnames';
import { noop } from 'lodash';

class AccordionItem extends React.Component {

  static propTypes = {
    /**
     * Section name
     */
    title: PropTypes.string.isRequired,
    /**
     * Select handler
     */
    onSelect: PropTypes.func.isRequired,
    /**
     * Defines opened or closed state
     */
    open: PropTypes.bool.isRequired,
    /**
     * Unique identifier of section
     */
    eventKey: PropTypes.number.isRequired,
    /**
     * Callback fired after Collapse component expanded
     */
    onEntered: PropTypes.func,
    /**
     * Callback fired after Collapse component collapsed
     */
    onExited: PropTypes.func,
    /**
     * Animation duration
     */
    timeout: PropTypes.number,
    /**
     * Puts in Accordion header a custom component
     */
    headerComponent: PropTypes.any,
    theme: PropTypes.object.isRequired,
    className: PropTypes.string,
    children: PropTypes.any
  };

  renderContent() {
    return (
      <Collapse
        in={this.props.open}
        timeout={this.props.timeout}
        onEntered={this.props.onEntered}
        onExited={this.props.onExited}
      >
        <div>{this.props.children}</div>
      </Collapse>
    );
  }

  renderArrow() {
    return (
      <div className={this.props.theme.arrowContainer}>
        <span className={this.props.theme.arrow} />
      </div>
    );
  }

  render() {
    const { theme } = this.props;
    const classes = classNames({
      [theme.item]: !this.props.open,
      [theme.openedItem]: this.props.open,
      [this.props.className]: !!this.props.className
    });
    const headerContent = this.props.headerComponent || this.props.title;
    return (
      <div className={classes}>
        <div className={theme.header} onClick={this.props.onSelect}>
          <div className={theme.headerTitle} title={this.props.title}>
            { headerContent }
          </div>
          { this.props.children ? this.renderArrow() : null }
        </div>
        { this.props.children ? this.renderContent() : null }
      </div>
    );
  }

}

AccordionItem.defaultProps = {
  theme: require('./AccordionItem.css'),
  open: false,
  timeout: 200,
  onSelect: noop,
  onEntered: noop,
  onExited: noop
};

export default AccordionItem;
