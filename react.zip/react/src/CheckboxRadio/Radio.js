import checkComponentFactory from './checkComponentFactory';
import theme from './Radio.css';

export default checkComponentFactory('Radio', 'radio', theme);
