import checkComponentFactory from './checkComponentFactory';
import theme from './Checkbox.css';

export default checkComponentFactory('Checkbox', 'checkbox', theme);
