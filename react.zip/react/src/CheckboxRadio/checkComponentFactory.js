/* eslint-disable react/prefer-es6-class */

import React, { PropTypes } from 'react';
import { noop } from 'lodash';
import classNames from 'classnames';

export default (displayName, type, defaultTheme) => {

  return React.createClass({

    displayName,

    propTypes: {
      checked: PropTypes.bool,
      label: PropTypes.node,
      labelClassName: PropTypes.string,
      className: PropTypes.string,
      readOnly: PropTypes.bool,
      disabled: PropTypes.bool,
      name: PropTypes.string,
      value: PropTypes.any,
      onChange: PropTypes.func,
      theme: PropTypes.shape({
        root: PropTypes.string,
        group: PropTypes.string,
        labelContainer: PropTypes.string,
        label: PropTypes.string
      }),
      position: PropTypes.string
    },

    getDefaultProps() {
      return {
        checked: false,
        readOnly: false,
        onChange: noop,
        theme: {}
      };
    },

    getValue() {
      return this.refs.input.value;
    },

    isChecked() {
      return this.refs.input.checked;
    },

    render() {
      const { disabled, readOnly, label, theme, position, ...props } = this.props;
      const isInputDisabled = disabled || readOnly;
      const classes = classNames(
        defaultTheme.root,
        theme.root,
        {
          [defaultTheme.checked]: this.props.checked && !isInputDisabled,
          [defaultTheme.disabled]: isInputDisabled && !this.props.checked,
          [defaultTheme.disabledChecked]: isInputDisabled && this.props.checked,
          [this.props.className]: !!this.props.className
        }
      );
      const inputProps = {
        ...props,
        disabled: isInputDisabled,
        type,
        ref: 'input'
      };

      const leftLabel = position === 'left';
      const groupClass = classNames(theme.group, 'form-group');
      const typeClass = classNames(type, {leftLabel});
      const labelContainerClass = classNames(theme.labelContainer, this.props.labelClassName);
      const labelClass = classNames(theme.label, `${type}-label`);

      return (
        <div className={classes}>
          <div className={groupClass}>
            <div className={typeClass}>
              <label className={labelContainerClass}>
                <input {...inputProps} />
                { label ? <span className={labelClass}>{ label }</span> : null }
              </label>
            </div>
          </div>
        </div>
      );
    }

  });

};
