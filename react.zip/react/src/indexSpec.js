/* global assert beforeEach afterEach describe it */
/* eslint-disable no-console */

require('babel-polyfill');
import expect from 'expect';

beforeEach(() => {
  expect.spyOn(console, 'warn');
  expect.spyOn(console, 'error');
});

afterEach(() => {

  const errors = [];

  if (console.error.calls.length) {
    console.error.calls.forEach((item) => {
      errors.push(item.arguments[0]);
    });
  }

  if (console.warn.calls.length) {
    console.warn.calls.forEach((item) => {
      errors.push(item.arguments[0]);
    });
  }

  expect.restoreSpies();

  errors.forEach((err) => {
    console.error(err);
  });

  expect(errors.length).toEqual(0, `There should not be any console.warn or console.error, but found ${errors.length}:\n\n ${errors.join('\n\n')}`);

});

describe('src.indexSpec', () => {

  describe('Process environment for tests', () => {
    it('Should be development for React console warnings', () => {
      expect(process.env.NODE_ENV).toEqual('development');
    });
  });

});


// Ensure all files in src folder are loaded for proper code coverage analysis
function requireAll(r) { r.keys().forEach(r); }
requireAll(require.context('../src', true, /\.js$/));
