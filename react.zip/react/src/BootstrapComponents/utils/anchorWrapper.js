import React from 'react';

export default (component) => {
  return (props) => {
    return React.createElement(component, {
      'data-test': component.displayName,
      ...props
    });
  };
};
