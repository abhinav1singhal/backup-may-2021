require('./_bootstrap.css');
import anchorWrapper from './utils/anchorWrapper';
export default anchorWrapper(require('react-bootstrap/lib/Pager'));
