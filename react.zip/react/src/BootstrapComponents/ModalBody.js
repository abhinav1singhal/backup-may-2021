require('./_bootstrap.css');
export default from 'react-bootstrap/lib/ModalBody';
