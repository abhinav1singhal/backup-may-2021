import React, { PropTypes } from 'react';
import BaseSelect from '../Select/components/BaseSelect';
import Value from '../Select/components/Value';
import SingleValue from '../Select/components/SingleValue';
import OptionComponent from '../Select/components/Option';

import { getValues, getFirstFocusableOption, getOptions, getValueForState } from '../Select/utils/selectUtils';

import { pick, keys } from 'lodash';

class Autocomplete extends React.Component {

  static propTypes = {
    /**
      * onChange handler: function (newValue) {}
    */
    onChange: PropTypes.func.isRequired,
    /**
      * onRequestData handler: function(value) {}
    */
    onRequestData: PropTypes.func.isRequired,
    /**
      * array of options
      * @type {array&lt;object&gt;}
    */
    options: PropTypes.array.isRequired,
    /**
      Ms delay before sending data request
    */
    delay: PropTypes.number,
    /**
      Multi-value input
     */
    multi: React.PropTypes.bool,
    /**
      Whether backspace removes an item if there is no text input
     */
    backspaceRemoves: React.PropTypes.bool,
    /**
     * Bootstrap compatible validation styles
     */
    bsStyle: React.PropTypes.oneOf([
      'success',
      'warning',
      'error'
    ]),
    /**
      className for the wrapper element
     */
    wrapperClassName: PropTypes.string,
    /**
      Should it be possible to reset value
     */
    clearable: PropTypes.bool,
    /**
      Whether the Select is disabled or not
     */
    disabled: PropTypes.bool,
    /**
      Custom attributes for the Input (in the Select-control) e.g: {'data-foo': 'bar'}
    */
    inputProps: PropTypes.object,
    /**
     * Label for input
     */
    label: PropTypes.string,
    /**
     * Class name for input's label
     */
    labelClassName: PropTypes.string,
    /**
      Path of the label value in option objects
     */
    labelKey: PropTypes.string,
    /**
      Placeholder displayed when there are no matching search results
     */
    noResultsText: PropTypes.string,
    /**
      onClick handler for value labels: function (value, event) {}
     */
    onOptionLabelClick: PropTypes.func,
    /**
      Option component to render in dropdown
     */
    optionComponent: PropTypes.func,
    /**
      optionRenderer: function (option) {}
     */
    optionRenderer: PropTypes.func,
    /**
      field placeholder, displayed when there's no value
     */
    placeholder: PropTypes.string,
    /**
      label to prompt for search input
     */
    searchPromptText: PropTypes.string,
    /**
      searching text
     */
    searchingText: PropTypes.string,
    /**
      single value component when multiple is set to false
     */
    singleValueComponent: PropTypes.func,
    /**
      initial field value
     */
    value: PropTypes.any,
    /**
     input name
    */
    name: PropTypes.string,
    /**
      Tab index
     */
    tabIndex: PropTypes.number,
    /**
      value component to render in multiple mode
    */
    valueComponent: PropTypes.func,
    /**
      path of the label value in option objects
     */
    valueKey: PropTypes.string,
    /**
      valueRenderer: function (option) {}
    */
    valueRenderer: PropTypes.func,

    /**
      onFocus handler: function (event) {}
     */
    onFocus: PropTypes.func,
    /**
      onBlur handler: function (event) {}
     */
    onBlur: PropTypes.func,
    /**
      onOpen handler
     */
    onOpen: PropTypes.func,
    /**
      onClose handler
     */
    onClose: PropTypes.func,
    /**
      onFocusOption handler
     */
    onFocusOption: PropTypes.func,
    /**
     * Custom filter function
     */
    filter: PropTypes.func,
    /**
     * Set style for the selected Value elements
     */
    valueStyle: PropTypes.object,
    /**
     className for the top parent element
     */
    parentClassName: PropTypes.string,
    /**
     * Set theme for the Select component
     */
    customTheme: PropTypes.shape({
      root: PropTypes.string,
      input: PropTypes.string,
      searchInput: PropTypes.string,
      clearIcon: PropTypes.string,
      arrowIcon: PropTypes.shape({
        wrapper: PropTypes.string,
        icon: PropTypes.string
      }),
      selectControl: PropTypes.string,
      optionMenuWrapper: PropTypes.string,

      option: PropTypes.object,
      optionMenu: PropTypes.object
    })
  };

  constructor(props) {
    super(props);
    this.state = {
      isOpen: false,
      isFocused: false,
      inputValue: '',
      focusedOption: undefined,
      isLoading: false,
      value: props.value,
      options: props.options
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState({  // eslint-disable-line
      value: nextProps.value,
      options: nextProps.options,
      focusedOption: undefined,
      isLoading: false
    });
  }

  onFilterValues(options, value) {
    if (this.props.filter) {
      return this.props.filter(options, value);
    }
    return options.filter((option) => {
      return option[this.props.valueKey].toLowerCase().indexOf(value.toLowerCase()) > -1;
    });
  }

  onInputChange = (value) => {
    if (!value) {
      this.onBlur();
    } else {
      this.setState({
        inputValue: value,
        options: [],
        isFocused: true,
        isLoading: true,
        isOpen: true
      });
      clearTimeout(this.timer);
      this.timer = setTimeout(() => {
        this.props.onRequestData(value);
      }, this.props.delay);
    }
  };

  onFocus = () => {
    this.setState({
      isFocused: true
    });
    if (this.props.onFocus) {
      this.props.onFocus();
    }
  };

  onBlur = () => {
    const value = '';
    this.setState({
      inputValue: value,
      options: [],
      isLoading: false,
      isOpen: false,
      isFocused: false
    });

    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.props.onRequestData(value);
    }, this.props.delay);

    if (this.props.onBlur) {
      this.props.onBlur();
    }
  };

  onChange = (value) => {
    this.setState({
      value,
      options: [],
      inputValue: '',
      isOpen: false,
      isFocused: true
    });
    if (this.props.onChange) {
      this.props.onChange(value);
    }
  };

  onClose = () => {
    this.setState({
      isOpen: false
    });
    if (this.props.onClose) {
      this.props.onClose();
    }
  };

  onOpen = () => {
    this.setState({
      isOpen: true
    });
    if (this.props.onOpen) {
      this.props.onOpen();
    }
  };

  onFocusOption = (option, open = false) => {
    if (open) {
      this.setState({
        isOpen: true,
        inputValue: '',
        focusedOption: option
      });
    } else {
      this.setState({
        focusedOption: option
      });
    }
    if (this.props.onFocusOption) {
      this.props.onFocusOption(option);
    }
  };

  render() {

    const values = getValues(this.state.value, this.props.multi);
    const valueForState = getValueForState(values, this.props.valueKey, this.props.multi);
    const options = getOptions(this.state.options, this.state.value,
                               this.props.valueKey, this.props.multi);

    const focusedOption = this.state.focusedOption ?
      this.state.focusedOption : getFirstFocusableOption(options);

    const props = pick(this.props, ...keys(Autocomplete.propTypes));

    return (
      <BaseSelect
        {...props}
        {...this.state}
        searchable
        options={options}
        focusedOption={focusedOption}
        values={values}
        value={valueForState}
        onChange={this.onChange}
        onInputChange={this.onInputChange}
        onFocus={this.onFocus}
        onFocusOption={this.onFocusOption}
        onBlur={this.onBlur}
        onClose={this.onClose}
        onOpen={this.onOpen}
        customTheme={this.props.customTheme} />
    );
  }

}

Autocomplete.defaultProps = {
  multi: false,
  backspaceRemoves: true,
  labelKey: 'label',
  valueKey: 'value',
  clearable: true,
  disabled: false,
  inputProps: {},
  name: undefined,
  noResultsText: 'No results found',
  onChange: undefined,
  onInputChange: undefined,
  onOptionLabelClick: undefined,
  optionComponent: OptionComponent,
  options: undefined,
  placeholder: 'Select...',
  searchingText: 'Searching...',
  searchPromptText: 'Type to search',
  singleValueComponent: SingleValue,
  value: undefined,
  valueComponent: Value,
  delay: 150,
  customTheme: {}
};

export default Autocomplete;
