export default from './FileSelector';
