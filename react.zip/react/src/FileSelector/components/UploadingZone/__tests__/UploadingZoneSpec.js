/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { markup } from '../../../../utils/testUtils';
import expect from 'expect';

import UploadingZone from '../UploadingZone';

describe('src.FileSelector.components.UploadingZone.__tests__.UploadingZoneSpec', () => {

  describe('UploadingZone', () => {

    it('should render UploadingZone', () => {

      const component = <UploadingZone />;

      const expectedMarkup = markup(`
        <div data-test="UploadingZone__root" class="UploadingZone__root">
          <div class="UploadingZone__text">
            Uploading files...
            <span class="UploadingZone__icon"></span>
          </div>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

  });

});
