import React from 'react';
import CSSModules from 'react-css-modules';

import styles from './UploadingZone.css';

class UploadingZone extends React.Component {

  render() {
    return (
      <div styleName="root" data-test="UploadingZone__root">
        <div styleName="text">
          Uploading files...
          <span styleName="icon"></span>
        </div>
      </div>
    );
  }

}

export default CSSModules(styles)(UploadingZone);
