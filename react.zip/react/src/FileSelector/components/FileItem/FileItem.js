import React from 'react';
import classNames from 'classnames';
import CSSModules from 'react-css-modules';
import styles from './FileItem.css';

export function getFileSize(file: Object): string {
  let size = parseInt(file.size, 10);
  size = size / 1024;
  return parseFloat(size.toFixed(1)).toString();
}

class FileItem extends React.Component {

  static propTypes = {
    file: React.PropTypes.shape({
      name: React.PropTypes.string.isRequired,
      type: React.PropTypes.string,
      size: React.PropTypes.number.isRequired
    }).isRequired,
    onRemove: React.PropTypes.func.isRequired
  };

  getNameAndExtension() {
    return [ this.props.file.name, this.props.file.name.split('.').pop() ];
  }

  render() {

    const [ name, extention ] = this.getNameAndExtension();
    const size = getFileSize(this.props.file);

    const fileIconClass = classNames({
      'file-icon': extention.length <= 3,
      'file-icon-small': extention.length > 3
    });

    return (
      <div styleName="root" data-test="FileItem__root">
        <div styleName={fileIconClass} data-type={ extention }></div>
        <div styleName="description">
          <div styleName="description-text">{ name }</div>
          <div styleName="description-text-small">{ size } Kb</div>
        </div>
        <div styleName="remove-button"
             data-test="FileItem__remove-button"
             onClick={this.props.onRemove}>x</div>
      </div>
    );
  }

}

export default CSSModules(styles)(FileItem);
