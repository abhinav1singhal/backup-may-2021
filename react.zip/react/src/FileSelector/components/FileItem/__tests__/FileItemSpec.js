/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { markup } from '../../../../utils/testUtils';
import TestUtils from 'react-addons-test-utils';
import expect, { createSpy } from 'expect';

import FileItem, { getFileSize } from '../FileItem';

describe('src.FileSelector.components.FileItem.__tests__.FileItemSpec', () => {

  describe('FileItem', () => {

    it('should render FileItem markup', () => {

      const file = {
        name: '123.doc',
        size: 31201
      };

      const component = <FileItem file={file} onRemove={() => {}} />;

      const expectedMarkup = markup(`
        <div data-test="FileItem__root" class="FileItem__root">
          <div data-type="doc" class="FileItem__file-icon"></div>
          <div class="FileItem__description">
              <div class="FileItem__description-text">123.doc</div>
              <div class="FileItem__description-text-small FileItem__description-text">
                30.5 Kb
              </div>
          </div>
          <div data-test="FileItem__remove-button" class="FileItem__remove-button">x</div>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should render FileItem markup with long extention name', () => {

      const file = {
        name: '123.jpeg',
        size: 2048
      };

      const component = <FileItem file={file} onRemove={() => {}} />;

      const expectedMarkup = markup(`
        <div data-test="FileItem__root" class="FileItem__root">
          <div data-type="jpeg" class="FileItem__file-icon-small FileItem__file-icon"></div>
          <div class="FileItem__description">
              <div class="FileItem__description-text">123.jpeg</div>
              <div class="FileItem__description-text-small FileItem__description-text">
                2 Kb
              </div>
          </div>
          <div data-test="FileItem__remove-button" class="FileItem__remove-button">x</div>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should convert size to kilobites', () => {

      const onRemoveSpy = createSpy();

      const file = {
        name: '123.doc',
        size: 31201
      };

      const component = <FileItem file={file} onRemove={onRemoveSpy} />;

      const fileItem = TestUtils.renderIntoDocument(component);
      const removeButton = TestUtils.findRenderedDOMComponentWithClass(fileItem, 'FileItem__remove-button');

      TestUtils.Simulate.click(removeButton);

      expect(onRemoveSpy).toHaveBeenCalled();

    });

  });

  describe('getFileSize', () => {

    it('getFileSize should return file size in kilobites', () => {

      expect(getFileSize({
        name: '123.doc',
        size: 1024
      })).toEqual('1');

      expect(getFileSize({
        name: '123.doc',
        size: 0
      })).toEqual('0');

      expect(getFileSize({
        name: '123.doc',
        size: 20000
      })).toEqual('19.5');

    });

  });

});
