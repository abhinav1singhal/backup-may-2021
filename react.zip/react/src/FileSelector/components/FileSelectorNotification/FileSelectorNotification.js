import React from 'react';
import CSSModules from 'react-css-modules';
import { noop } from 'lodash';
import styles from './FileSelectorNotification.css';


class FileSelectorNotification extends React.Component {

  static propTypes = {
    type: React.PropTypes.oneOf([ 'error', 'warning' ]).isRequired,
    text: React.PropTypes.string.isRequired,
    onClick: React.PropTypes.func
  };

  render() {
    return (
      <div styleName={`${this.props.type}-notification`}
           data-test={`FileSelectorNotification__${this.props.type}-notification`}
           title={this.props.text}
           onClick={this.props.onClick}>
           { this.props.text }
       </div>
    );
  }

}

FileSelectorNotification.defaultProps = {
  onClick: noop
};

export default CSSModules(styles)(FileSelectorNotification);
