/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { markup } from '../../../../utils/testUtils';
import TestUtils from 'react-addons-test-utils';
import expect, { createSpy } from 'expect';

import FileSelectorNotification from '../FileSelectorNotification';

describe('src.FileSelector.components.FileSelectorNotification.__tests__.FileSelectorNotificationSpec', () => {

  describe('FileSelectorNotification', () => {

    it('should render corresponding type of the notification', () => {

      const warningComponent = (
        <FileSelectorNotification type="warning"
                                    text="This is warning notification" />
      );

      const errorComponent = (
              <FileSelectorNotification type="error"
                                          text="This is error notification" />
      );

      expect(renderToStaticMarkup(warningComponent)).toEqual(markup(`
        <div data-test="FileSelectorNotification__warning-notification" title="This is warning notification" class="FileSelectorNotification__warning-notification FileSelectorNotification__notification">
          This is warning notification
        </div>
      `));

      expect(renderToStaticMarkup(errorComponent)).toEqual(markup(`
        <div data-test="FileSelectorNotification__error-notification" title="This is error notification" class="FileSelectorNotification__error-notification FileSelectorNotification__notification">
          This is error notification
        </div>
      `));

    });

    it('should call onClick callback', () => {

      const spy = createSpy();

      const component = (
        <FileSelectorNotification type="warning" text="notification text"
                    onClick={spy} />
      );

      const renderedComponent = TestUtils.renderIntoDocument(component);

      TestUtils.Simulate.click(TestUtils.findRenderedDOMComponentWithClass(renderedComponent, 'FileSelectorNotification__notification'));

      expect(spy).toHaveBeenCalled();

    });

  });

});
