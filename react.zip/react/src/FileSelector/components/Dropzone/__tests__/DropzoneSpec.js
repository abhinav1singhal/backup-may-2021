/* global describe, it, beforeEach, afterEach */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { markup } from '../../../../utils/testUtils';
import TestUtils from 'react-addons-test-utils';
import expect from 'expect';
import { createSpy, spyOn } from 'expect';

import Dropzone from '../Dropzone';

describe('src.FileSelector.components.Dropzone.__tests__.DropzoneSpec', () => {

  describe('Dropzone', () => {

    it('should render Dropzone', () => {

      const component = (
        <Dropzone className="dropzone-component"
                  maxFiles={1}
                  accept={''}
                  disableClick={false} />
      );

      const expectedMarkup = markup(`
        <div class="dropzone-component" data-test="Dropzone__root">
          <input type="file" style="display:none;" accept=""/>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should add multiple and accept attributes to input', () => {

      const component = (
        <Dropzone className="opened-dropzone-component"
                  maxFiles={2}
                  accept="image/*"
                  disableClick={false}>
            <div className="some-inner-content">inner content</div>
        </Dropzone>
      );

      const expectedMarkup = markup(`
        <div class="opened-dropzone-component" data-test="Dropzone__root">
          <div class="some-inner-content">inner content</div>
          <input type="file" style="display:none;" multiple="" accept="image/*"/>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should call onDragEnter and onDragLeave callbacks', () => {

      const onDragEnterSpy = createSpy();
      const onDragLeaveSpy = createSpy();

      const component = (
        <Dropzone className="dropzone"
                  onDragEnter={onDragEnterSpy}
                  onDragLeave={onDragLeaveSpy} />
      );

      const node = TestUtils.findRenderedDOMComponentWithClass(
                    TestUtils.renderIntoDocument(component),
                    'dropzone'
                  );

      TestUtils.Simulate.dragEnter(node);
      TestUtils.Simulate.dragLeave(node);
      TestUtils.Simulate.dragOver(node);

      expect(onDragEnterSpy).toHaveBeenCalled();
      expect(onDragLeaveSpy).toHaveBeenCalled();

    });

    describe('onDrop, onDropAccepted, onDropRejected', () => {

      const xlsFile = {
        name: 'template.xlsx',
        size: 4348,
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      };

      const pngFile = {
        name: '123.png',
        size: 139730,
        type: 'image/png'
      };

      const folder = {
        name: 'exampleFolder',
        size: 1000,
        type: ''
      };

      it('should call onDrop callback with all dropped files', () => {

        const onDrop = createSpy();
        const onDropAccepted = createSpy();
        const onDropRejected = createSpy();
        const files = [
          xlsFile,
          pngFile,
          folder // should be not considered
        ];

        const component = (
          <Dropzone className="dropzone"
                    maxFiles={3}
                    onDrop={onDrop}
                    onDropAccepted={onDropAccepted}
                    onDropRejected={onDropRejected} />
        );

        const node = TestUtils.findRenderedDOMComponentWithClass(
                      TestUtils.renderIntoDocument(component),
                      'dropzone'
                    );

        TestUtils.Simulate.drop(node, {
          dataTransfer: {
            files
          }
        });

        // should be called once with correct arguments

        expect(onDrop).toHaveBeenCalled();
        expect(onDrop.calls[0].arguments[0]).toEqual([ xlsFile, pngFile ]);
        expect(onDrop.calls[0].arguments[1].dataTransfer).toEqual({ files });

        // onDropAccepted should be called

        expect(onDropAccepted).toHaveBeenCalled();
        expect(onDropAccepted.calls[0].arguments[0]).toEqual([ xlsFile, pngFile ]);
        expect(onDropAccepted.calls[0].arguments[1].dataTransfer).toEqual({ files });

        // onDropRejected should not be called
        expect(onDropRejected).toNotHaveBeenCalled();

      });

      it('should not call onDropAccepted if any validation is failed', () => {

        const suites = [
          {
            params: {
              maxFiles: 1
            },
            expect: {
              rejected: [ pngFile ],
              reason: 'TOO_MANY_FILES',
              accepted: [ xlsFile ]
            }
          },
          {
            params: {
              accept: 'image/*',
              maxFiles: 5
            },
            expect: {
              rejected: [ xlsFile ],
              reason: 'RESTRICTED_FILE_FORMAT',
              accepted: [ pngFile ]
            }
          },
          {
            params: {
              maxFiles: 5,
              maxSize: 1000
            },
            expect: {
              rejected: [ xlsFile, pngFile ],
              reason: 'TOO_BIG_FILES',
              accepted: []
            }
          }
        ];

        suites.forEach((suite) => {

          const onDrop = createSpy();
          const onDropAccepted = createSpy();
          const onDropRejected = createSpy();
          const files = [
            xlsFile,
            pngFile
          ];

          const component = (
            <Dropzone className="dropzone"
                      onDropAccepted={onDropAccepted}
                      onDropRejected={onDropRejected}
                      onDrop={onDrop}
                      {...suite.params} />
          );

          const node = TestUtils.findRenderedDOMComponentWithClass(
                        TestUtils.renderIntoDocument(component),
                        'dropzone'
                      );

          TestUtils.Simulate.drop(node, {
            dataTransfer: {
              files
            }
          });

          expect(onDrop.calls.length).toEqual(1);
          expect(onDrop.calls[0].arguments[0]).toEqual(files);

          expect(onDropAccepted).toNotHaveBeenCalled();
          expect(onDropRejected).toHaveBeenCalled();
          expect(onDropRejected.calls[0].arguments[0]).toEqual(suite.expect.rejected);
          expect(onDropRejected.calls[0].arguments[1]).toEqual(suite.expect.reason);
          expect(onDropRejected.calls[0].arguments[2]).toEqual(suite.expect.accepted);
          expect(onDropRejected.calls[0].arguments[3].dataTransfer).toEqual({ files });

        });

      });

    });

    it('should open file selector on click on dropzone', () => {

      const component = TestUtils.renderIntoDocument((
        <Dropzone className="dropzone" />
      ));

      const spy = spyOn(component, 'open').andCallThrough();

      const node = TestUtils.findRenderedDOMComponentWithClass(
                    component,
                    'dropzone'
                  );

      TestUtils.Simulate.click(node);

      expect(component.open).toHaveBeenCalled();

      spy.restore();

    });

    it('should not call open function if disableClick is passed', () => {

      const component = TestUtils.renderIntoDocument((
        <Dropzone className="dropzone" disableClick />
      ));

      const spy = spyOn(component, 'open').andCallThrough();

      const node = TestUtils.findRenderedDOMComponentWithClass(
                    component,
                    'dropzone'
                  );

      TestUtils.Simulate.click(node);

      expect(component.open).toNotHaveBeenCalled();

      spy.restore();

    });

  });

});
