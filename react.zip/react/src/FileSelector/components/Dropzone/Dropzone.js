import React from 'react';
import accept from 'attr-accept';
import { noop, flow } from 'lodash';
import DropzoneValidationErrors from './DropzoneValidationErrors';

class Dropzone extends React.Component {

  static propTypes = {
    onDrop: React.PropTypes.func,
    onDropAccepted: React.PropTypes.func,
    onDropRejected: React.PropTypes.func,
    onDragEnter: React.PropTypes.func,
    onDragLeave: React.PropTypes.func,

    className: React.PropTypes.string,

    disableClick: React.PropTypes.bool,
    maxFiles: React.PropTypes.number,
    maxSize: React.PropTypes.number,
    accept: React.PropTypes.string,
    children: React.PropTypes.any
  };

  constructor(props, context) {
    super(props, context);
    this.onClick = this.onClick.bind(this);
    this.onDragEnter = this.onDragEnter.bind(this);
    this.onDragLeave = this.onDragLeave.bind(this);
    this.onDragOver = this.onDragOver.bind(this);
    this.onDrop = this.onDrop.bind(this);
  }

  componentDidMount() {
    this.enterCounter = 0;
  }

  onDragEnter(e) {
    e.preventDefault();

    // Count the dropzone and any children that are entered.
    ++this.enterCounter;

    this.props.onDragEnter(e);
  }

  onDragOver(e) {
    e.preventDefault();
  }

  onDragLeave(e) {
    e.preventDefault();

    // Only deactivate once the dropzone and all children was left.
    if (--this.enterCounter > 0) {
      return;
    }

    this.props.onDragLeave(e);
  }

  onDrop(e) {

    e.preventDefault();

    // Reset the counter along with the drag on a drop.
    this.enterCounter = 0;

    const droppedFiles = e.dataTransfer ? e.dataTransfer.files : e.target.files;
    const files = [];

    for (let i = 0; i < droppedFiles.length; i++) {
      const file = droppedFiles[i];
      if (file.type) {
        files.push(file);
      }
    }

    this.props.onDrop(files, e);

    const [ accepted, rejected, rejectReason ] = this.splitToAcceptedRejected(files);

    if (rejected.length === 0) {
      this.props.onDropAccepted(accepted, e);
    } else {
      this.props.onDropRejected(rejected, rejectReason, accepted, e);
    }

  }

  onClick() {
    if (!this.props.disableClick) {
      this.open();
    }
  }

  filterByType = (input) => {

    const [ acceptedFiles, rejectedFiles, reason ] = input;

    const accepted = [];
    const rejected = [];

    acceptedFiles.forEach((file) => {
      if (accept(file, this.props.accept)) {
        accepted.push(file);
      } else {
        rejected.push(file);
      }
    });

    return [ accepted, [ ...rejectedFiles, ...rejected ], reason || (rejected.length ? DropzoneValidationErrors.RESTRICTED_FILE_FORMAT : null) ];

  };

  filterBySize = (input) => {

    const [ acceptedFiles, rejectedFiles, reason ] = input;

    const accepted = [];
    const rejected = [];

    acceptedFiles.forEach((file) => {
      if (this.props.maxSize > 0 && file.size > this.props.maxSize) {
        rejected.push(file);
      } else {
        accepted.push(file);
      }
    });

    return [ accepted, [ ...rejectedFiles, ...rejected ], reason || (rejected.length ? DropzoneValidationErrors.TOO_BIG_FILES : null)];
  };

  filterByIndex = (input) => {

    const [ acceptedFiles, rejectedFiles, reason ] = input;

    let accepted = acceptedFiles;
    let rejected = [];

    if (this.props.maxFiles > 0 && acceptedFiles.length > this.props.maxFiles) {
      accepted = acceptedFiles.slice(0, this.props.maxFiles);
      rejected = acceptedFiles.slice(this.props.maxFiles);
    }

    return [ accepted, [ ...rejectedFiles, ...rejected ], reason || (rejected.length ? DropzoneValidationErrors.TOO_MANY_FILES : null) ];
  };

  splitToAcceptedRejected(files) {
    const [ accepted, rejected, reason ] = flow(
      this.filterByIndex,
      this.filterByType,
      this.filterBySize
    )([ [ ...files ], [], null ]);

    return [ accepted, rejected, reason ];
  }

  open() {
    const fileInput = this.refs.fileInput;
    fileInput.value = null;
    fileInput.click();
  }

  render() {
    return (
      <div
        className={this.props.className}
        data-test="Dropzone__root"
        onClick={this.onClick}
        onDragEnter={this.onDragEnter}
        onDragOver={this.onDragOver}
        onDragLeave={this.onDragLeave}
        onDrop={this.onDrop}
      >
        {this.props.children}
        <input
          type="file"
          ref="fileInput"
          style={{ display: 'none' }}
          multiple={this.props.maxFiles !== 1}
          accept={this.props.accept}
          onChange={this.onDrop}
        />
      </div>
    );
  }
}

Dropzone.defaultProps = {
  disableClick: false,
  maxFiles: 0,
  maxSize: 0,
  onDrop: noop,
  onDropAccepted: noop,
  onDropRejected: noop,
  onDragEnter: noop,
  onDragLeave: noop
};

export default Dropzone;
