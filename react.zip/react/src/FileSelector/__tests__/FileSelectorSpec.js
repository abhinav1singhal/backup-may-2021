/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { markup } from '../../utils/testUtils';
import TestUtils from 'react-addons-test-utils';
import expect, { spyOn, createSpy } from 'expect';

import FileSelector from '../FileSelector';

describe('src.FileSelector.__tests__.FileSelectorSpec', () => {

  describe('FileSelector', () => {

    const excelFile = {
      name: 'template.xlsx',
      size: 4348,
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    };

    const pngFile = {
      name: '123.png',
      size: 139730,
      type: 'image/png'
    };

    const files = [
      excelFile,
      pngFile
    ];

    it('should render empty Dropzone by default', () => {

      const component = <FileSelector maxFiles={1} files={[]} onChange={() => {}} />;

      const expectedMarkup = markup(`
        <div data-test="FileSelector__root" class="FileSelector__root">
          <div class="FileSelector__drop-zone" data-test="Dropzone__root">
            <div data-test="FileSelector__text-area" class="FileSelector__text-area">
              <div>Drag &amp; Drop File</div>
              <div class="FileSelector__text-area-small-text">1 file maximum</div>
            </div>
            <input type="file" style="display:none;"/>
          </div>
          <div class="FileSelector__buttons-panel">
            <button data-test="FileSelector__choose-button" class="FileSelector__button btn btn-default" type="button">Select a file</button>
          </div>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should render UploadingZone if isUploading is true', () => {

      const component = (
        <FileSelector maxFiles={1}
                          isUploading files={[]} onChange={() => {}} />
      );

      expect(renderToStaticMarkup(component)).toContain('data-test="UploadingZone__root"');

    });

    it('should render files if files are passed', () => {

      const component = <FileSelector files={files} onChange={() => {}} />;
      const staticMarkup = renderToStaticMarkup(component);

      expect(staticMarkup).toInclude(markup('<div class="FileSelector__file-items-container">'));
      expect(staticMarkup).toInclude(markup('data-test="FileItem__root"'));

    });

    it('should render plural placeholders when maxFiles is more than 1', () => {

      const component = <FileSelector maxFiles={3} files={[]} onChange={() => {}} />;

      const staticMarkup = renderToStaticMarkup(component);

      expect(staticMarkup).toInclude(markup(`
        Select files
      `));
      expect(staticMarkup).toInclude(markup(`
        Drag &amp; Drop Files
      `));

    });

    it('should show maximum files info if maxFiles are passed', () => {

      const component = (
        <FileSelector maxFiles={3} files={[]}
                      onChange={() => {}} />
      );

      const staticMarkup = renderToStaticMarkup(component);


      expect(staticMarkup).toInclude(markup(`
        <div data-test="FileSelector__text-area" class="FileSelector__text-area">
          <div>Drag &amp; Drop Files</div>
          <div class="FileSelector__text-area-small-text">3 files maximum</div>
        </div>
      `));

    });

    it('should add accept title to max files information', () => {

      const component = (
        <FileSelector maxFiles={3}
                      accept="images/*"
                      acceptTitle="only image files"
                      files={[]} onChange={() => {}} />
      );

      const staticMarkup =  renderToStaticMarkup(component);

      expect(staticMarkup).toInclude(markup(`
        <div data-test="FileSelector__text-area" class="FileSelector__text-area">
          <div>Drag &amp; Drop Files</div>
          <div class="FileSelector__text-area-small-text">3 files maximum, only image files</div>
        </div>
      `));

    });

    it('should render title about max file size', () => {

      const component = (
        <FileSelector maxFiles={3}
                      maxSize={10000}
                      files={[]} onChange={() => {}} />
      );

      const staticMarkup =  renderToStaticMarkup(component);

      expect(staticMarkup).toInclude(markup(`
        <div data-test="FileSelector__text-area" class="FileSelector__text-area">
          <div>Drag &amp; Drop Files</div>
          <div class="FileSelector__text-area-small-text">3 files maximum, max. size is 9.8Kb</div>
        </div>
      `));

    });


    it('should show error if isError is passed', () => {

      const component = (
        <FileSelector maxFiles={3}
                      isError
                      files={[]} onChange={() => {}} />
      );

      const staticMarkup =  renderToStaticMarkup(component);

      expect(staticMarkup).toInclude('data-test="FileSelectorNotification__error-notification"');
      expect(staticMarkup).toInclude('Oops.. Something went wront. No files were uploaded.');

    });

    it('should show error with custom message if isError is passed', () => {

      const component = (
        <FileSelector maxFiles={3}
                      isError={{
                        message: 'Contact system administrator'
                      }}
                      files={[]} onChange={() => {}} />
      );

      const staticMarkup =  renderToStaticMarkup(component);

      expect(staticMarkup).toInclude('data-test="FileSelectorNotification__error-notification"');
      expect(staticMarkup).toInclude('Contact system administrator');

    });

    it('should render validation error if isValid is false', () => {

      const component = (
        <FileSelector maxFiles={3}
                      isValid={false}
                      files={[]} onChange={() => {}} />
      );

      const staticMarkup =  renderToStaticMarkup(component);

      expect(staticMarkup).toInclude('data-test="FileSelectorNotification__warning-notification"');
      expect(staticMarkup).toInclude('These files cannot be selected');

    });

    it('should show upload button if onUpload callback is passed and at least one file is selected', () => {

      const component = renderToStaticMarkup((
        <FileSelector files={files}
                      onChange={() => {}}
                      onUpload={() => {}} />
                  ));
      const componentWithoutFiles = renderToStaticMarkup((
        <FileSelector files={[]}
                      onChange={() => {}}
                      onUpload={() => {}} />
                  ));

      expect(component).toContain('data-test="FileSelector__choose-button"');
      expect(component).toContain('data-test="FileSelector__upload-button"');

      expect(componentWithoutFiles).toContain('data-test="FileSelector__choose-button"');
      expect(componentWithoutFiles).toExclude('data-test="FileSelector__upload-button"');

    });

    it('should change state onDrop, onDragEnter and onDragLeave', () => {

      const onChangeSpy = createSpy();

      const component = TestUtils.renderIntoDocument((
        <FileSelector files={files}
                        onChange={onChangeSpy}
                        onUpload={() => {}} />
      ));

      const setStateSpy = spyOn(component, 'setState').andCallThrough();

      const node = TestUtils.findRenderedDOMComponentWithClass(
                    component,
                    'FileSelector__drop-zone'
                  );


      TestUtils.Simulate.dragEnter(node);
      TestUtils.Simulate.drop(node, {
        dataTransfer: {
          files
        }
      });
      TestUtils.Simulate.dragLeave(node);

      expect(component.setState.calls.length).toEqual(3);
      expect(component.setState.calls[0].arguments).toEqual([{ isDragActive: true }]);
      expect(component.setState.calls[1].arguments).toEqual([{ isDragActive: false }]);
      expect(component.setState.calls[2].arguments).toEqual([{ isDragActive: false }]);

      expect(onChangeSpy).toHaveBeenCalledWith(files);

      setStateSpy.restore();
      onChangeSpy.restore();

    });

    it('should call onChange on remove file click', () => {

      const onChangeSpy = createSpy();

      const component = TestUtils.renderIntoDocument((
        <FileSelector files={files}
                        onChange={onChangeSpy}
                        onUpload={() => {}} />
      ));

      const removeFileButtons = TestUtils.scryRenderedDOMComponentsWithClass(
                  component,
                  'FileItem__remove-button'
                );

      TestUtils.Simulate.click(removeFileButtons[0]);

      expect(onChangeSpy).toHaveBeenCalledWith([
        files[1]
      ]);

      onChangeSpy.restore();

    });

    it('should call onUpload callback after clicking on Upload button', () => {

      const onUploadSpy = createSpy();

      const component = TestUtils.renderIntoDocument((
        <FileSelector files={files}
                        onChange={() => {}}
                        onUpload={onUploadSpy} />
      ));

      const buttons = TestUtils.scryRenderedDOMComponentsWithClass(
        component,
        'FileSelector__button'
      );

      TestUtils.Simulate.click(buttons[1]);

      expect(onUploadSpy).toHaveBeenCalledWith(files);

      onUploadSpy.restore();

    });

    it('should call onOpenClick after clicking on Choose button', () => {

      const component = TestUtils.renderIntoDocument((
        <FileSelector files={files}
                        onChange={() => {}}
                        onUpload={() => {}} />
      ));

      const spy = spyOn(component.refs.dropzone, 'open');

      const buttons = TestUtils.scryRenderedDOMComponentsWithClass(
        component,
        'FileSelector__button'
      );

      TestUtils.Simulate.click(buttons[0]);

      expect(spy).toHaveBeenCalled();

      spy.restore();

    });

    it('should render concete validation message after onDropRejected', () => {

      const suites = [
        {
          params: {
            maxFiles: 1
          },
          expect: 'You selected 2 file(s) whereas it is allowed to upload 1 file(s) maximum.'
        },
        {
          params: {
            maxFiles: 4,
            accept: 'image/*'
          },
          expect: 'The following file types are not allowed: xlsx'
        },
        {
          params: {
            maxFiles: 5,
            maxSize: 3000
          },
          expect: 'Uploading files bigger than 2.9Kb is not allowed.'
        }
      ];

      suites.forEach((suite) => {

        const component = TestUtils.renderIntoDocument((
          <FileSelector files={files}
                        onChange={() => {}} {...suite.params} />
        ));

        const node = TestUtils.findRenderedDOMComponentWithClass(
                component,
                'FileSelector__drop-zone'
              );

        TestUtils.Simulate.dragEnter(node);
        TestUtils.Simulate.drop(node, {
          dataTransfer: {
            files
          }
        });
        TestUtils.Simulate.dragLeave(node);

        expect(component.state.validationMessage).toEqual(suite.expect);

      });

    });

    it('click on validation message should reset validationMessage state and call onReset callback', () => {

      const onResetSpy = createSpy();
      const component = TestUtils.renderIntoDocument((
        <FileSelector files={files}
                      isValid={false}
                      onChange={() => {}}
                      onReset={onResetSpy} />
      ));

      const setStateSpy = spyOn(component, 'setState').andCallThrough();

      const validationMessage = TestUtils.findRenderedDOMComponentWithClass(
              component,
              'FileSelectorNotification__notification'
            );

      TestUtils.Simulate.click(validationMessage);

      expect(onResetSpy).toHaveBeenCalled();
      expect(setStateSpy).toHaveBeenCalledWith({ validationMessage: 'These files cannot be selected' });

    });

  });

});
