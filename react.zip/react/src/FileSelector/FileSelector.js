import React from 'react';
import classNames from 'classnames';
import CSSModules from 'react-css-modules';
import { noop, uniq } from 'lodash';

import FileItem from './components/FileItem';
import { getFileSize } from './components/FileItem/FileItem';
import Dropzone, { DropzoneValidationErrors } from './components/Dropzone';
import UploadingZone from './components/UploadingZone';
import FileSelectorNotification from './components/FileSelectorNotification';
import Button from '../BootstrapComponents/Button';

import styles from './FileSelector.css';

const DEFAULT_VALIDATION_MESSAGE = 'These files cannot be selected';
const DEFAULT_ERROR_MESSAGE = 'Oops.. Something went wront. No files were uploaded.';

let FileSelector = class extends React.Component {

  static propTypes = {
    /**
     * Selected files
     * @type {array&lt;object&gt;}
     */
    files: React.PropTypes.array.isRequired,
    /**
     * Max selected files constrained
     */
    maxFiles: React.PropTypes.number,
    /**
     * Max weight of the file
     */
    maxSize: React.PropTypes.number,
    /**
     * Callback for files change event
     */
    onChange: React.PropTypes.func.isRequired,
    /**
     * Callback on invalid drop
     */
    onReject: React.PropTypes.func,
    /**
     * Callback reset the state
     */
    onReset: React.PropTypes.func,
    /**
     * Uploading status
     */
    isUploading: React.PropTypes.bool,
    /**
     * Validation status
     */
    isValid: React.PropTypes.bool,
    /**
     * Error status
     */
    isError: React.PropTypes.oneOfType([
      React.PropTypes.bool,
      React.PropTypes.shape({
        message: React.PropTypes.string
      })
    ]),
    /**
     * Input accept attribute for HTML5 input[type="file"]
     */
    accept: React.PropTypes.string,
    /**
     * Information title about accept types of files
     */
    acceptTitle: React.PropTypes.string,
    /**
     * Callback on upload button click, if onUpload is not defined, then upload button is hidden
     */
    onUpload: React.PropTypes.func
  };

  constructor(props) {
    super(props);
    this.state = {
      isDragActive: false
    };
  }

  onDragEnter = () => {
    this.setState({ isDragActive: true });
  };

  onDragLeave = () => {
    this.setState({ isDragActive: false });
  };

  onDrop = () => {
    this.setState({ isDragActive: false });
  };

  onOpenClick = () => {
    this.refs.dropzone.open();
  };

  onUploadClick = () => {
    if (this.props.onUpload && this.props.files.length) {
      this.props.onUpload(this.props.files);
    }
  };

  getMaxSizeInKb() {
    return getFileSize({ size: this.props.maxSize });
  }

  isMultiple() {
    return this.props.maxFiles !== 1;
  }

  onDropAccepted = (files) => {
    this.props.onChange(files);
  };

  onDropRejected = (rejectedFiles, rejectReason, acceptedFiles) => {

    let message = DEFAULT_VALIDATION_MESSAGE;

    switch (rejectReason) { // eslint-disable-line default-case
      case DropzoneValidationErrors.TOO_MANY_FILES:
        message = `You selected ${rejectedFiles.length + acceptedFiles.length} file(s) whereas it is allowed to upload ${this.props.maxFiles} file(s) maximum.`;
        break;
      case DropzoneValidationErrors.RESTRICTED_FILE_FORMAT:
        const formats = uniq(rejectedFiles.map((file) => file.name.split('.').pop() ));
        message = `The following file types are not allowed: ${ formats.join(', ') }`;
        break;
      case DropzoneValidationErrors.TOO_BIG_FILES:
        message = `Uploading files bigger than ${this.getMaxSizeInKb()}Kb is not allowed.`;
        break;
    }

    this.setState({ validationMessage: message });
    this.props.onReject(rejectedFiles, acceptedFiles);
  };

  onFileRemove = (index) => {
    return () => {
      const files = [ ...this.props.files ];
      files.splice(index, 1);
      this.props.onChange(files);
    };
  };

  onReset = () => {
    this.setState({ validationMessage: DEFAULT_VALIDATION_MESSAGE });
    this.props.onReset();
  };

  constuctAdditionalText() {
    const titles = [];

    if (this.props.maxFiles > 1) {
      titles.push(`${this.props.maxFiles} files maximum`);
    } else if (this.props.maxFiles === 1) {
      titles.push('1 file maximum');
    }
    if (this.props.acceptTitle) {
      titles.push(this.props.acceptTitle);
    }
    if (this.props.maxSize) {
      titles.push(`max. size is ${this.getMaxSizeInKb()}Kb`);
    }

    return titles.join(', ');
  }

  renderInfo() {

    let text = 'Drag & Drop File';
    const additionalText = this.constuctAdditionalText();

    if (this.isMultiple()) {
      text = 'Drag & Drop Files';
    }

    return (
      <div styleName="text-area" data-test="FileSelector__text-area">
        <div>{ text }</div>
        { additionalText ? <div styleName="text-area-small-text">{ additionalText }</div> : null }
      </div>
    );
  }

  renderFiles() {
    let items = this.props.files.map((file, index) => {
      return <FileItem file={file} key={index} onRemove={this.onFileRemove(index)} />;
    });
    if (this.props.maxFiles) {
      items = items.slice(0, this.props.maxFiles);
    }
    return <div styleName="file-items-container">{ items }</div>;
  }

  renderButtonsPanel() {

    const hasFiles = this.props.files.length > 0;
    const withUpload = typeof this.props.onUpload === 'function';

    return (
      <div styleName="buttons-panel">
        { this.renderChooseButton() }
        { hasFiles && withUpload ? this.renderUploadButton() : null }
      </div>
    );
  }

  renderChooseButton() {
    let text = 'Select a file';

    if (this.isMultiple()) {
      text = 'Select files';
    }

    return (
      <Button
        bsStyle="default"
        styleName="button"
        data-test="FileSelector__choose-button"
        disabled={this.props.isUploading}
        onClick={this.onOpenClick}
      >
        { text }
      </Button>
    );
  }

  renderUploadButton() {
    return (
      <Button
        bsStyle="primary"
        styleName="button"
        data-test="FileSelector__upload-button"
        disabled={this.props.isUploading}
        onClick={this.onUploadClick}>
        Upload
      </Button>
    );
  }

  render() {

    let mainZone;
    let bottomZone;

    if (this.props.isUploading) {
      mainZone = <UploadingZone />;
    } else {

      const classes = classNames({
        'drop-zone': !this.state.isDragActive && this.props.isValid && !this.props.isError,
        'active-drop-zone': this.state.isDragActive && this.props.isValid && !this.props.isError,
        'invalid-drop-zone': !this.props.isValid && !this.props.isError,
        'error-drop-zone': this.props.isError
      });

      mainZone = (
        <Dropzone ref="dropzone"
          accept={this.props.accept}
          maxFiles={this.props.maxFiles}
          maxSize={this.props.maxSize}
          disableClick
          onDrop={this.onDrop}
          onDragEnter={this.onDragEnter}
          onDragLeave={this.onDragLeave}
          onDropAccepted={this.onDropAccepted}
          onDropRejected={this.onDropRejected}
          styleName={classes}>
          { this.props.files.length ? this.renderFiles() : this.renderInfo() }
        </Dropzone>
      );
    }

    if (this.props.isError) {
      bottomZone = <FileSelectorNotification type="error" text={this.props.isError.message || DEFAULT_ERROR_MESSAGE} onClick={this.onReset} />;
    } else if (!this.props.isValid) {
      bottomZone = <FileSelectorNotification type="warning" text={this.state.validationMessage || DEFAULT_VALIDATION_MESSAGE} onClick={this.onReset} />;
    } else {
      bottomZone = this.renderButtonsPanel();
    }

    return (
      <div styleName="root" data-test="FileSelector__root">
        { mainZone }
        { bottomZone }
      </div>
    );
  }

};

FileSelector = CSSModules(styles)(FileSelector);

FileSelector.defaultProps = {
  maxFiles: 0,
  maxSize: 0,
  isUploading: false,
  isValid: true,
  onReject: noop,
  onReset: noop,
  isError: false
};

export default FileSelector;
