import React, { PropTypes } from 'react';
import Helmet from 'react-helmet';

export default class DocumentTitle extends React.Component {

  static propTypes = {

    /**
     * Defines current document title
     */
    title: PropTypes.string,

    /**
     * Defines current document title template.
     * For example '%s - techstack', where %s is a current title
     */
    titleTemplate: PropTypes.string,

    /**
     * Component's children
     */
    children: PropTypes.any
  };

  render() {
    return (
      <div>
          <Helmet title={this.props.title} titleTemplate={this.props.titleTemplate} />
          { this.props.children }
      </div>
    );
  }

}
