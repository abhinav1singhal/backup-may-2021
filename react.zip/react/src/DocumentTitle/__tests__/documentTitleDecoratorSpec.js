/* global describe, it, beforeEach, afterEach, expect */

import React from 'react';
import { render, unmountComponentAtNode } from 'react-dom';
import documentTitleDecorator, { getDisplayName } from '../documentTitleDecorator';
import expect from 'expect';

class SampleComponent extends React.Component {

  render() {
    return (
      <div>Some content</div>
    );
  }

}

describe('src.DocumentTitle.__tests__.documentTitleDecoratorSpec', () => {
  let headElement;
  const container = document.createElement('div');

  beforeEach(() => {
    headElement = headElement || document.head || document.querySelector('head');
  });

  afterEach(() => {
    unmountComponentAtNode(container);
  });

  it('should wrap passed component in DocumentTitleComponent', () => {

    const DecoratedComponent = documentTitleDecorator({ title: 'someTitle'})(SampleComponent);

    render(
      <DecoratedComponent />,
      container
    );

    expect(document.title).toEqual('someTitle');
  });

  it('should have static WrappedComponent field', () => {
    const DecoratedComponent = documentTitleDecorator({ title: 'someTitle'})(SampleComponent);
    expect(DecoratedComponent.WrappedComponent).toNotBe(undefined);
    expect(DecoratedComponent.WrappedComponent).toEqual(SampleComponent);
  });

  it('should have displayName', () => {
    const DecoratedComponent = documentTitleDecorator({
      title: 'someTitle'
    })(SampleComponent);
    expect(DecoratedComponent.displayName).toNotBe(undefined);
    expect(DecoratedComponent.displayName.indexOf('DocumentTitle')).toEqual(0);
  });

  it('getDisplayName() should provide default values', () => {
    expect(getDisplayName({ })).toEqual('Component');
    expect(getDisplayName({ name: 'Test' })).toEqual('Test');
  });

});
