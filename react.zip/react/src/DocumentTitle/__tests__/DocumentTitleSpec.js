/* global describe, it, beforeEach, afterEach */

import React from 'react';
import { render, unmountComponentAtNode } from 'react-dom';
import DocumentTitle from '../DocumentTitle';
import expect from 'expect';

describe('src.DocumentTitle.__tests__.DocumentTitleSpec', () => {
  let headElement;
  const container = document.createElement('div');

  beforeEach(() => {
    headElement = headElement || document.head || document.querySelector('head');
  });

  afterEach(() => {
    unmountComponentAtNode(container);
  });

  it('should update page title', () => {
    render(
      <DocumentTitle title="someTitle">
        <div>Some content</div>
      </DocumentTitle>,
      container
    );
    expect(document.title).toEqual('someTitle');
  });

  it('will set title based on deepest nested component', () => {
    render(
      <DocumentTitle title="firstTitle">
        <DocumentTitle title="secondTitle">
          <DocumentTitle title="thirdTitle">
            <div>Some content</div>
          </DocumentTitle>
        </DocumentTitle>
      </DocumentTitle>,
      container
    );
    expect(document.title).toEqual('thirdTitle');
  });

  it('will use a titleTemplate based on deepest nested component', () => {
    render(
      <DocumentTitle
          title={'Test'}
          titleTemplate={'This is a %s of the titleTemplate feature'}
      >
          <DocumentTitle
              title={'Second Test'}
              titleTemplate={'A %s using nested titleTemplate attributes'}
          />
      </DocumentTitle>,
      container
    );
    expect(document.title).toEqual('A Second Test using nested titleTemplate attributes');
  });
});
