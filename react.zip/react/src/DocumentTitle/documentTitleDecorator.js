import React from 'react';
import DocumentTitle from './DocumentTitle';

export function getDisplayName(Component) {
  return Component.displayName || Component.name || 'Component';
}

export default (config) => {

  return (WrappedComponent) => {

    const DocumentTitleDecorator = (props) => {
      return (
        <DocumentTitle {...config}>
          <WrappedComponent {...props} />
        </DocumentTitle>
      );
    };

    DocumentTitleDecorator.displayName = `DocumentTitle(${getDisplayName(WrappedComponent)})`;
    DocumentTitleDecorator.WrappedComponent = WrappedComponent;

    return DocumentTitleDecorator;

  };

};
