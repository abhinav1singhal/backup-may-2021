export documentTitleDecorator from './documentTitleDecorator';
export default from './DocumentTitle';
