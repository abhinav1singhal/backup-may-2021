/* eslint-disable react/no-set-state */

import React, { PropTypes } from 'react';
import { noop, isNaN } from 'lodash';
import classNames from  'classnames';

class Counter extends React.Component {
  static propTypes = {
    theme: PropTypes.object.isRequired,
    value: PropTypes.number,
    minValue: PropTypes.number,
    maxValue: PropTypes.number,
    onChange: PropTypes.func
  };

  constructor(props) {
    super(props);

    this.state = {
      value: props.value || props.minValue || props.maxValue || 0,
      valid: true
    };
    this.minValue = props.minValue;
    this.maxValue = props.maxValue;
    this.increment = this.increment.bind(this);
    this.decrement = this.decrement.bind(this);
    this.onChange = this.onChange.bind(this);
  }

  componentWillUpdate(nextProps, nextState) {
    if (nextState.valid) {
      this.props.onChange(nextState.value);
    }
  }

  onChange(event) {
    const {value} = event.target;
    this.tryUpdate(value);
  }

  tryUpdate(value) {
    if (isNaN(value)) {
      return;
    }
    const numberValue = Number(value);
    this.setState({
      value,
      valid: !isNaN(numberValue) && this.inRange(numberValue)
    });
  }

  inRange(value) {
    return !(this.minValue !== null && this.minValue > value)
      && !(this.maxValue !== null && this.maxValue < value);
  }

  increment() {
    this.tryUpdate(Number(this.state.value) + 1);
  }

  decrement() {
    this.tryUpdate(Number(this.state.value) - 1);
  }

  render() {
    const {theme} = this.props;
    const classes = classNames(
      theme.root,
      { [theme.error]: !this.state.valid }
    );
    return (
      <div>
        <input
          className={classes}
          value={this.state.value}
          onChange={this.onChange}
        />
        <div className={theme.up} onClick={this.increment}></div>
        <div className={theme.down} onClick={this.decrement}></div>
      </div>
    );
  }
}

Counter.defaultProps = {
  theme: require('./Counter.css'),
  onChange: noop,
  minValue: null,
  maxValue: null
};

export default Counter;
