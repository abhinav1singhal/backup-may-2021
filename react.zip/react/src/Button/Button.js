import React, { PropTypes } from 'react';
import BootstrapButton from '../BootstrapComponents/Button';
import classNames from  'classnames';

const customStyles = ['white'];
const PREFIX = 'btn';

class Button extends React.Component {

  static propTypes = {
    bsStyle: PropTypes.string,
    className: PropTypes.string
  };

  render() {
    const { bsStyle, ...props } = this.props;
    if (customStyles.indexOf(bsStyle) !== -1) {
      props.className = classNames(props.className, `${PREFIX}-${bsStyle}`);
    } else {
      props.bsStyle = bsStyle;
    }

    return <BootstrapButton {...props} />;
  }
}

export default Button;
