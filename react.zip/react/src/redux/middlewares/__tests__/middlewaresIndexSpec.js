/* global describe, it, beforeEach, afterEach, sinon */

import expect from 'expect';

import { createThunk } from '../index';

describe('src.redux.middlewares.__tests__.middlewaresIndexSpec', () => {

  describe('middlewaresIndex', () => {

    it('createThunk should return thunk middleware', () => {
      expect(createThunk()).toBeA('function');
    });

  });

});
