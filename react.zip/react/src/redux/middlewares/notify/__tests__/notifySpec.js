/* global describe, it, beforeEach, afterEach, sinon */

const TEST_ACTION = 'TEST_ACTION';
const TEST_FUNCTION_ACTION = 'TEST_FUNCTION_ACTION';

const TEST_ACTION_NOTIFICATION = {
  level: 'success',
  title: 'Complete',
  message: 'Test action'
};

const TEST_FUNCTION_ACTION_NOTIFICATION = (action) => {
  return {
    level: 'success',
    title: 'Complete',
    message: `Test function ${action.id}`
  };
};

const config = {
  [TEST_ACTION]: TEST_ACTION_NOTIFICATION,
  [TEST_FUNCTION_ACTION]: TEST_FUNCTION_ACTION_NOTIFICATION
};

import createNotifier from '../notify';
import { SHOW_NOTIFICATION } from '../../../actions/notificationActions';
import expect from 'expect';

describe('src.redux.middlewares.notify.__tests__.notifySpec', () => {

  describe('Notify Middleware', () => {

    it('should be a function', () => {
      expect(createNotifier).toBeA('function');
    });

    it('should pass action to next function if action is not written in config', () => {
      const notifyMiddleware = createNotifier(config);
      const dispatch = sinon.spy();
      const action = {
        type: 'SOME_TYPE'
      };

      notifyMiddleware()(dispatch)(action);

      sinon.assert.calledOnce(dispatch);
      sinon.assert.calledWith(dispatch, action);
    });

    describe('simple notification', () => {
      it('should create notify action and pass notifiable action to next function', () => {
        const notifyMiddleware = createNotifier(config, () => {
          return 0;
        });
        const dispatch = sinon.spy();
        const action = {
          type: TEST_ACTION
        };

        notifyMiddleware()(dispatch)(action);

        sinon.assert.calledTwice(dispatch);
        sinon.assert.calledWith(dispatch, action);
        sinon.assert.calledWith(dispatch, {
          type: SHOW_NOTIFICATION,
          notification: {
            uid: 0, ...TEST_ACTION_NOTIFICATION
          }
        });
      });
    });

    describe('notification which belongs on action', () => {
      it('should create notify action and pass notifiable action to next function', () => {
        const notifyMiddleware = createNotifier(config, () => {
          return 0;
        });
        const dispatch = sinon.spy();
        const action = {
          id: 1000,
          type: TEST_FUNCTION_ACTION
        };

        notifyMiddleware()(dispatch)(action);

        sinon.assert.calledTwice(dispatch);
        sinon.assert.calledWith(dispatch, action);
        sinon.assert.calledWith(dispatch, {
          type: SHOW_NOTIFICATION,
          notification: {
            uid: 0, ...TEST_FUNCTION_ACTION_NOTIFICATION(action)
          }
        });
      });
    });
  });

});
