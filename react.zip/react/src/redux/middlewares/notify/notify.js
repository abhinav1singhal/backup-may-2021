
import { SHOW_NOTIFICATION } from '../../actions/notificationActions';
import shortid from 'shortid';

const defaultUidCreator = () => {
  return shortid.generate();
};

/**
 * @param  {Object} Config object with keys mapped on notifiable actions
 * @param  {function} Function, which returns unique uid
 */
export default function notifyMiddlware(config, getUid = defaultUidCreator) {

  return () => (next) => (action) => {
    const { type } = action;

    if (config[type]) {
      next(action);

      const notification = typeof config[type] === 'function' ?
        config[type](action) : config[type];

      if (!!notification) {
        next({
          type: SHOW_NOTIFICATION,
          notification: { ...notification, uid: getUid() }
        });
      }
    } else {
      next(action);
    }
  };

}
