import createCaptureStore from './createCaptureStore';
import { noop } from 'lodash';
import platform from 'platform';

const transformer = (state) => state;

export default function captureMiddleware({
  application, sessionId,
  sender = noop,
  enabled = true,
  sendInterval = 500
}) {

  if (typeof sender !== 'function') {
    throw new Error('Sender must be a function');
  }

  const session = {
    browser: {
      name: platform.name,
      version: platform.version,
      layout: platform.layout
    },
    os: {
      family: platform.os.family,
      architecture: platform.os.architecture,
      version: platform.os.version
    },
    ua: platform.ua,
    description: platform.description
  };

  const captureStore = createCaptureStore(sender, sendInterval);

  return ({ getState }) => (next) => (action) => {

    if (enabled) {
      const prevState = transformer(getState());
      const nextState = transformer(getState());

      captureStore({
        sessionId: typeof sessionId === 'function' ? sessionId() : sessionId,
        application,
        session,
        prevState,
        action,
        nextState,
        time: new Date().getTime()
      });
    }

    return next(action);

  };

}
