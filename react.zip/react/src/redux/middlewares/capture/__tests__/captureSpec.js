/* global describe, it, beforeEach, afterEach, sinon */

import createCapture from '../capture';
import expect from 'expect';
import { noop } from 'lodash';
import lolex from 'lolex';

let clock;

describe('src.redux.middlewares.capture.__tests__.captureSpec', () => {

  describe('Capture Middleware', () => {

    beforeEach(() => {
      clock = lolex.install(window);
    });

    afterEach(() => {
      clock.uninstall();
    });

    it('should be a function', () => {
      expect(createCapture).toBeA('function');
    });

    it('should call sender function in senderInterval', () => {
      const sender  = sinon.spy();
      const milliseconds = 1000;

      const capture = createCapture({
        application: 'test-application',
        sessionId: () => new Date().getTime(),
        sender,
        sendInterval: milliseconds
      });

      const dispatch = sinon.spy();
      const action = {
        type: 'SOME_TYPE'
      };

      capture({
        getState: noop
      })(dispatch)(action);

      clock.tick(milliseconds);
      sinon.assert.calledOnce(dispatch);
      sinon.assert.calledWith(dispatch, action);
      sinon.assert.calledOnce(sender);
    });

    it('should throw error if sender is not a function', () => {
      expect(() => {
        createCapture({
          application: 'test-application',
          sessionId: () => new Date().getTime(),
          sender: { }
        });
      }).toThrow(Error);
    });

  });

});
