import { filter, last } from 'lodash';

const actionsPool = [];
let timer = null;
let prevented = false;
let lastUpdatedTime = -1;
let fails = 0;

function promisify(item) {
  if (item && typeof item.then === 'function' && typeof item.catch === 'function') {
    return item;
  }
  return new Promise((resolve, reject) => {
    if (item === false) {
      reject();
    } else {
      resolve();
    }
  });
}

function stop() {
  clearInterval(timer);
  timer = null;
}

const tick = (sender) => {
  return () => {
    const now = new Date();
    const lastItem = last(actionsPool);
    if (lastItem && lastItem.time > lastUpdatedTime) {
      const toBeSent = filter(actionsPool, (item) => item.time >= lastUpdatedTime);
      lastUpdatedTime = now;
      promisify(sender(toBeSent))
        .catch(() => {
          fails = fails + 1;
          if (fails >= 3) {
            stop();
            prevented = true;
            console.warn('Capture middleware has been stopped after 3 send attempts.'); // eslint-disable-line no-console
          }
        });
    }
  };
};

function start(sender, sendInterval) {
  timer = setInterval(tick(sender), sendInterval);
}

export default function createCaptureStore(sender, sendInterval) {
  return (data) => {
    actionsPool.push(data);
    if (timer === null && !prevented) {
      start(sender, sendInterval);
    }
  };
}
