/* global describe, it, beforeEach, afterEach, sinon */

import createDelay from '../delay';
import expect from 'expect';
import lolex from 'lolex';

let clock;

describe('src.redux.middlewares.delay.__tests__.delaySpec', () => {

  describe('Delay Middleware', () => {

    beforeEach(() => {
      clock = lolex.install(window);
    });

    afterEach(() => {
      clock.uninstall();
    });

    it('should be a function', () => {
      expect(createDelay).toBeA('function');
    });

    it('should pass action to next function if meta.delay is not defined in action', () => {
      const delay = createDelay();
      const dispatch = sinon.spy();
      const action = {
        type: 'SOME_TYPE'
      };

      delay()(dispatch)(action);

      sinon.assert.calledOnce(dispatch);
      sinon.assert.calledWith(dispatch, action);
    });

    it('should pass action to next function in meta.delay milliseconds', () => {
      const delay = createDelay();
      const dispatch = sinon.spy();
      const milliseconds = 1000;

      const action = {
        type: 'SOME_TYPE',
        meta: {
          delay: milliseconds
        }
      };

      delay()(dispatch)(action);
      expect(dispatch.callCount).toEqual(0);

      clock.tick(milliseconds);
      sinon.assert.calledOnce(dispatch);
      sinon.assert.calledWith(dispatch, action);
    });

  });

});
