import thunk from 'redux-thunk';

export createLogger from 'redux-logger';
export createPromise from './promise/promise';
export createCapture from './capture/capture';
export createNotifier from './notify/notify';
export createDelay from './delay/delay';

export function createThunk() {
  return thunk;
}
