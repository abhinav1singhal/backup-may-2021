/* global describe, it, beforeEach, afterEach, sinon */

import createPromise from '../promise';
import { createAsyncAction } from '../../../utils/actionsUtils';
import expect from 'expect';

describe('src.redux.middlewares.promise.__tests__.promiseSpec', () => {

  describe('Promise Middleware', () => {

    it('should be a function', () => {
      expect(createPromise).toBeA('function');
    });

    it('should pass action to next function if promise is not defined in action', () => {

      const promiseMiddleware = createPromise();
      const dispatch = sinon.spy();
      const action = {
        type: 'SOME_TYPE'
      };

      promiseMiddleware()(dispatch)(action);

      sinon.assert.calledOnce(dispatch);
      sinon.assert.calledWith(dispatch, action);

    });

    it('should pass action to next function if promise is not a function', () => {

      const promiseMiddleware = createPromise();
      const dispatch = sinon.spy();
      const action = {
        type: 'SOME_TYPE',
        promise: { foo: 'bar' }
      };

      promiseMiddleware()(dispatch)(action);

      sinon.assert.calledOnce(dispatch);
      sinon.assert.calledWith(dispatch, action);

    });

    describe('simple type', () => {

      it('should call promise and pass action to next function without promise object: SUCCESS', (done) => {

        const promiseMiddleware = createPromise();
        const dispatch = sinon.spy();
        const action = {
          type: 'SOME_TYPE',
          promise: () => {
            return new Promise((resolve) => {
              resolve();
            });
          }
        };

        promiseMiddleware()(dispatch)(action)
          .then(() => {
            sinon.assert.calledOnce(dispatch);
            sinon.assert.calledWith(dispatch, {
              type: 'SOME_TYPE'
            });
            done();
          });

      });

      it('should call promise and pass action to next function without promise object: FAILURE', (done) => {

        const promiseMiddleware = createPromise();
        const dispatch = sinon.spy();
        const action = {
          type: 'SOME_TYPE',
          promise: () => {
            return new Promise((resolve, reject) => {
              reject();
            });
          }
        };

        promiseMiddleware()(dispatch)(action)
          .then(() => {
            sinon.assert.calledOnce(dispatch);
            sinon.assert.calledWith(dispatch, {
              type: 'SOME_TYPE'
            });
            done();
          });

      });

    });

    describe('async type', () => {

      it('should call promise and pass action to next function without promise object: SUCCESS', (done) => {

        const promiseMiddleware = createPromise();
        const dispatch = sinon.spy();
        const type = createAsyncAction('SOME_TYPE');
        const action = {
          id: 'additional data',
          type,
          promise: () => {
            return new Promise((resolve) => {
              resolve('data from promise');
            });
          }
        };

        promiseMiddleware()(dispatch)(action)
          .then(() => {
            sinon.assert.callCount(dispatch, 2);
            expect(...dispatch.getCall(0).args).toEqual({
              id: 'additional data',
              type: type.REQUEST
            });
            expect(...dispatch.getCall(1).args).toEqual({
              id: 'additional data',
              type: type.SUCCESS,
              payload: 'data from promise'
            });
            done();
          });

      });

      it('should call promise and pass action to next function without promise object: FAILURE', (done) => {

        const promiseMiddleware = createPromise();
        const dispatch = sinon.spy();
        const type = createAsyncAction('SOME_TYPE');
        const action = {
          id: 'additional data',
          type,
          promise: () => {
            return new Promise((resolve, reject) => {
              reject('data from promise');
            });
          }
        };

        promiseMiddleware()(dispatch)(action)
          .then(() => {
            sinon.assert.callCount(dispatch, 2);
            expect(...dispatch.getCall(0).args).toEqual({
              id: 'additional data',
              type: type.REQUEST
            });
            expect(...dispatch.getCall(1).args).toEqual({
              id: 'additional data',
              type: type.FAILURE,
              payload: 'data from promise'
            });
            done();
          });

      });

    });

  });

});
