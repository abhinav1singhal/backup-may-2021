/* eslint-disable no-redeclare */

function isSimpleActionType(type) {
  return typeof type === 'string';
}

function isAsyncActionType(type) {
  return typeof type === 'object' &&
    hasOwnProperty.call(type, 'REQUEST') &&
    hasOwnProperty.call(type, 'SUCCESS') &&
    hasOwnProperty.call(type, 'FAILURE') &&
    hasOwnProperty.call(type, 'CANCEL') &&
    hasOwnProperty.call(type, 'RESET');
}

export default function promiseMiddleware(...args) {

  return () => (next) => (action) => {

    const { promise, type, ...rest } = action;

    if (!promise || typeof promise !== 'function') {
      return next(action);
    }

    let REQUEST_ACTION;
    let SUCCESS_ACTION;
    let CANCEL_ACTION;
    let FAILURE_ACTION;
    let RESET_ACTION;

    if (isSimpleActionType(type)) {
      REQUEST_ACTION = type;
    } else if (isAsyncActionType(type)) {
      REQUEST_ACTION = type.REQUEST;
      SUCCESS_ACTION = type.SUCCESS;
      FAILURE_ACTION = type.FAILURE;
      CANCEL_ACTION = type.CANCEL;
      RESET_ACTION = type.RESET;
    } else {
      return next(action);
    }

    next({ ...rest, type: REQUEST_ACTION });

    return promise(...args).then(
      (result) => {
        if (SUCCESS_ACTION) {
          next({ ...rest, type: SUCCESS_ACTION, payload: result });
        } else if (RESET_ACTION) {
          next({ ...rest, type: RESET_ACTION });
        }
      },
      (error) => {
        if (error instanceof Error) {
          throw error;
        } else {
          if (FAILURE_ACTION) {
            next({ ...rest, type: FAILURE_ACTION, payload: error });
          } else if (CANCEL_ACTION) {
            next({ ...rest, type: CANCEL_ACTION, payload: error });
          }
        }
      }
    );

  };

}
