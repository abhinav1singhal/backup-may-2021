import { ActionsNamespaceFactory } from '../utils/actionsUtils';

const actionsNamespace = ActionsNamespaceFactory('DICTIONARIES');

export const LOAD_DICTIONARIES = actionsNamespace.createAsyncAction('LOAD_DICTIONARIES');
export const LOAD_DICTIONARIES_MAP = actionsNamespace.createAsyncAction('LOAD_DICTIONARIES_MAP');

export function loadDictionaries(config) {
  return {
    type: LOAD_DICTIONARIES,
    promise: ({dictionariesService}) => dictionariesService.loadDictionaries(config)
  };
}

export function loadDictionariesMap(list) {
  return {
    type: LOAD_DICTIONARIES_MAP,
    promise: ({dictionariesService}) => dictionariesService.loadDictionariesMap(list)
  };
}
