export const SHOW_NOTIFICATION = 'SHOW_NOTIFICATION';
export const HIDE_NOTIFICATION = 'HIDE_NOTIFICATION';

export function showNotification(notification) {
  return {
    notification,
    type: SHOW_NOTIFICATION
  };
}

export function hideNotification(uid: number) {
  return {
    uid,
    type: HIDE_NOTIFICATION
  };
}
