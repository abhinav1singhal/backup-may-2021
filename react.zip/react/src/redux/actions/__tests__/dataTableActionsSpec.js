/* global describe, it, beforeEach, afterEach */

import expect from 'expect';
import {
  addTable,
  updateTable,
  removeTable,
  sortTable,
  filterTable
} from '../dataTableActions';

describe('src.redux.actions.__tests__.dataTableActionsSpec', () => {

  describe('dataTableActions', () => {

    it('addTable action shoud return default settings if settings param is not passed', () => {

      const id = 10001;

      expect(addTable(id)).toEqual({
        id,
        settings: {
          sortKey: null,
          sortDirection: null,
          filterText: ''
        },
        type: 'dataTable(ADD_TABLE)'
      });

    });

    it('addTable action should have dataTable(ADD_TABLE) type', () => {

      const id = 301;
      const settings = {
        sortKey: 'name',
        sortDirection: 'DESC',
        filterText: 'new..'
      };

      expect(addTable(id, settings)).toEqual({
        id,
        settings,
        type: 'dataTable(ADD_TABLE)'
      });

    });

    it('updateTable action should have dataTable(UPDATE_TABLE) type', () => {

      const id = 201;
      const settings = { width: 100, columns: [ { width: 10, key: 'test', label: 'Test' } ]};

      expect(updateTable(id, settings)).toEqual({
        id,
        settings,
        type: 'dataTable(UPDATE_TABLE)'
      });

    });

    it('removeTable action should have dataTable(REMOVE_TABLE) type', () => {

      const id = 101;

      expect(removeTable(id)).toEqual({
        id,
        type: 'dataTable(REMOVE_TABLE)'
      });

    });

    it('sortTable action should have dataTable(SORT_TABLE) type', () => {

      const id = 998;
      const sortDirection = 'ASC';
      const sortKey = 'name';

      expect(sortTable(id, sortKey, sortDirection)).toEqual({
        id,
        sortKey,
        sortDirection,
        type: 'dataTable(SORT_TABLE)'
      });

    });

    it('filterTable action should have dataTable(FILTER_TABLE) type', () => {

      const id = 999;
      const filterText = 'new york';

      expect(filterTable(id, filterText)).toEqual({
        id,
        filterText,
        type: 'dataTable(FILTER_TABLE)'
      });

    });

  });

});
