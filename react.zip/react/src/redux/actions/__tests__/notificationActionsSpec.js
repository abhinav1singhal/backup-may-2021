/* global describe, it, beforeEach, afterEach */

import expect from 'expect';
import { showNotification, hideNotification } from '../notificationActions';

describe('src.redux.actions.__tests__.notificationActionsSpec', () => {

  describe('notificationActions', () => {

    describe('showNotification', () => {

      it('should have SHOW_NOTIFICATION type', () => {
        expect(showNotification({ uid: 123 })).toEqual({
          notification: {
            uid: 123
          },
          type: 'SHOW_NOTIFICATION'
        });
      });

    });

    describe('hideNotification', () => {

      it('should have HIDE_NOTIFICATION type', () => {
        expect(hideNotification(123)).toEqual({
          uid: 123,
          type: 'HIDE_NOTIFICATION'
        });
      });

    });

  });

});
