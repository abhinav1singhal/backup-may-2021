/* global describe, it, beforeEach, afterEach */

import expect from 'expect';
import {
  addTable, removeTable,
  cellsChanged, rowsAdded, columnsAdded,
  rowsRemoved, columnsRemoved
} from '../handsontableActions';

describe('src.redux.actions.__tests__.handsontableActionsSpec', () => {

  describe('handsontableActions', () => {

    it('addTable action should have handsontable(ADD_TABLE) type', () => {

      const id = 'firstTable';
      const data = [ [ 1, 2, 3 ], [ 4, 5, 6] ];

      expect(addTable(id, data)).toEqual({
        id,
        data,
        type: 'handsontable(ADD_TABLE)'
      });

    });

    it('removeTable action should have handsontable(REMOVE_TABLE) type', () => {

      const id = 'firstTable';

      expect(removeTable(id)).toEqual({
        id,
        type: 'handsontable(REMOVE_TABLE)'
      });

    });

    it('cellsChanged action should have handsontable(CELLS_CHANGED) type', () => {

      const id = 'tableId';
      const changes = [ { prev: 1, state: 2, index: [1, 2] } ];

      expect(cellsChanged(id, changes)).toEqual({
        id,
        changes,
        type: 'handsontable(CELLS_CHANGED)'
      });

    });

    it('rowsAdded action should have handsontable(ROWS_ADDED) type', () => {

      const id = 'tableId';
      const startIndex = 2;
      const amount = 10;

      expect(rowsAdded(id, startIndex, amount)).toEqual({
        id,
        startIndex,
        amount,
        type: 'handsontable(ROWS_ADDED)'
      });

    });

    it('columnsAdded action should have handsontable(COLUMNS_ADDED) type', () => {

      const id = 'tableId';
      const startIndex = 2;
      const amount = 10;

      expect(columnsAdded(id, startIndex, amount)).toEqual({
        id,
        startIndex,
        amount,
        type: 'handsontable(COLUMNS_ADDED)'
      });

    });

    it('columnsRemoved action should have handsontable(COLUMNS_REMOVED) type', () => {

      const id = 'tableId';
      const startIndex = 2;
      const amount = 10;

      expect(columnsRemoved(id, startIndex, amount)).toEqual({
        id,
        startIndex,
        amount,
        type: 'handsontable(COLUMNS_REMOVED)'
      });

    });

    it('rowsRemoved action should have handsontable(ROWS_REMOVED) type', () => {

      const id = 'tableId';
      const startIndex = 2;
      const amount = 10;

      expect(rowsRemoved(id, startIndex, amount)).toEqual({
        id,
        startIndex,
        amount,
        type: 'handsontable(ROWS_REMOVED)'
      });

    });

  });

});
