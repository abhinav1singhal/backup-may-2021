export const ADD_TABLE = 'handsontable(ADD_TABLE)';
export const REMOVE_TABLE = 'handsontable(REMOVE_TABLE)';
export const CELLS_CHANGED = 'handsontable(CELLS_CHANGED)';
export const ROWS_ADDED = 'handsontable(ROWS_ADDED)';
export const COLUMNS_ADDED = 'handsontable(COLUMNS_ADDED)';
export const ROWS_REMOVED = 'handsontable(ROWS_REMOVED)';
export const COLUMNS_REMOVED = 'handsontable(COLUMNS_REMOVED)';

export function addTable(id: number, data: Array<Array<any>>) {
  return {
    id,
    type: ADD_TABLE,
    data
  };
}

export function removeTable(id: number) {
  return {
    id,
    type: REMOVE_TABLE
  };
}

export function cellsChanged(id: number, changes: Array<any>) {
  return {
    id,
    type: CELLS_CHANGED,
    changes
  };
}

export function rowsAdded(id: number, startIndex: number, amount: number) {
  return {
    id,
    type: ROWS_ADDED,
    startIndex,
    amount
  };
}

export function columnsAdded(id: number, startIndex: number, amount: number) {
  return {
    id,
    type: COLUMNS_ADDED,
    startIndex,
    amount
  };
}

export function rowsRemoved(id: number, startIndex: number, amount: number) {
  return {
    id,
    type: ROWS_REMOVED,
    startIndex,
    amount
  };
}

export function columnsRemoved(id: number, startIndex: number, amount: number) {
  return {
    id,
    type: COLUMNS_REMOVED,
    startIndex,
    amount
  };
}
