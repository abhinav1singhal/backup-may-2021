export const ADD_TABLE = 'dataTable(ADD_TABLE)';
export const REMOVE_TABLE = 'dataTable(REMOVE_TABLE)';
export const SORT_TABLE = 'dataTable(SORT_TABLE)';
export const FILTER_TABLE = 'dataTable(FILTER_TABLE)';
export const UPDATE_TABLE = 'dataTable(UPDATE_TABLE)';

export function addTable(
  id: number,
  settings = {
    sortKey: null,
    sortDirection: null,
    filterText: ''
  }) {
  return {
    id,
    settings,
    type: ADD_TABLE
  };
}

export function updateTable(id: number, settings: Object) {
  return {
    id,
    settings,
    type: UPDATE_TABLE
  };
}

export function removeTable(id: number) {
  return {
    id,
    type: REMOVE_TABLE
  };
}

export function sortTable(id: number, sortKey: string, sortDirection: string) {
  return {
    id,
    sortKey,
    sortDirection,
    type: SORT_TABLE
  };
}

export function filterTable(id: number, filterText: string) {
  return {
    id,
    filterText,
    type: FILTER_TABLE
  };
}
