export handleActions from 'redux-actions/lib/handleActions';
export connectConsoleUtils from './utils/connectConsoleUtils';
export makeSwappable from './utils/makeSwappable';
export * as dictionariesUtils from './utils/dictionariesUtils';
export dictionariesService from './services/dictionariesService';

// NOTE: asyncConstant should be considered as @Deprecated
export ActionsNamespace, {
  ActionsNamespaceFactory, createAction, createAsyncAction, createAsyncAction as asyncConstant
} from './utils/actionsUtils';
