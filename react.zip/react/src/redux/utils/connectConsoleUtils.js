/* eslint-disable */

(function(console){

    if (!console.save) {
      console.save = function(data, filename){

          if(!data) {
              console.error('Console.save: No data')
              return;
          }

          if(!filename) filename = 'console.json'

          if(typeof data === "object"){
              data = JSON.stringify(data, undefined, 4)
          }

          var blob = new Blob([data], {type: 'text/json'}),
              e    = document.createEvent('MouseEvents'),
              a    = document.createElement('a')

          a.download = filename
          a.href = window.URL.createObjectURL(blob)
          a.dataset.downloadurl =  ['text/json', a.download, a.href].join(':')
          e.initMouseEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null)
          a.dispatchEvent(e)
      }
    }

})(console)

/* eslint-enable */

export default (store) => {

  global.getState = () => {
    return store.getState();
  };

  global.applyState = (state) => {
    return store.dispatch({ type: 'swap(APPLY_STATE)', state: JSON.parse(JSON.stringify(state)) });
  };

  global.saveStateToFile = (filename) => {
    console.save(store.getState(), filename); // eslint-disable-line no-console
  };

};
