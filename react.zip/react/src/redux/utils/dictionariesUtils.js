import { reduce, mapValues, filter, find, isPlainObject, isUndefined } from 'lodash';

import { isNotEmptyString } from '../../utils/stringUtils';
import { isNotEmptyArray } from '../../utils/arrayUtils';

// ToDo: consider to extract such ENUMs to separate files ???
export const DICTIONARIES_QUERY_ID = {
  LOB: 'lookup-lob'
};

export const DICTIONARIES_DATA_ENTITY_ID = {
  LOB: 'lob'
};

export function prepareDictionaryRequestItemConfig(itemConfig) {
  const config = {};

  if (isNotEmptyArray(itemConfig.additionalFields)) {
    config.additionalFields = filter(itemConfig.additionalFields, isNotEmptyString);
  }

  if (isNotEmptyString(itemConfig.idField)) {
    config.idField = itemConfig.idField;
  }

  if (isNotEmptyString(itemConfig.nameField)) {
    config.nameField = itemConfig.nameField;
  }

  if (isPlainObject(itemConfig.queryParams)) {
    config.queryParams = itemConfig.queryParams;
  }

  return config;
}

export function prepareDictionariesRequestList(listConfig) {
  // ToDo: check if dictionaries isArray
  return reduce(listConfig, (result, item) => {
    if (typeof(item) === 'string') {
      result.push({
        queryId: item,
        ...prepareDictionaryRequestItemConfig(item)
      });
    } else {
      if (isNotEmptyString(item.queryId)) {
        result.push({
          queryId: item.queryId,
          ...prepareDictionaryRequestItemConfig(item)
        });
      } else if (isNotEmptyString(item.dataEntityId)) {
        result.push({
          dataEntityId: item.dataEntityId,
          ...prepareDictionaryRequestItemConfig(item)
        });
      }
    }

    return result;
  }, []);
}

export function prepareDictionariesConfigListFromMap(mapConfig) {
  if (!isPlainObject(mapConfig)) {
    return [];
  }

  return reduce(mapConfig, (result, item) => {
    if (isPlainObject(item)) {
      result.push(item);
    }

    return result;
  }, []);
}

export function prepareDictionariesConfigListFromItemsList(itemsList) {
  if (!isNotEmptyArray(itemsList)) {
    return [];
  }

  return reduce(itemsList, (result, item) => {
    if (isPlainObject(item) && isNotEmptyString(item.key) && isPlainObject(item.dictionary)) {
      result.push(item.dictionary);
    }

    return result;
  }, []);
}

export function prepareDictionariesConfigMapFromItemsList(itemsList) {
  if (!isNotEmptyArray(itemsList)) {
    return {};
  }

  return reduce(itemsList, (result, {key, dictionary}) => {
    result[key] = dictionary;
    return result;
  }, {});
}

function findItemInDictionariesConfigList(listConfig, {queryId, dataEntityId}) {
  let needle;
  if (isNotEmptyString(queryId)) {
    needle = {queryId};
  } else if (isNotEmptyString(dataEntityId)) {
    needle = {dataEntityId};
  }

  return isUndefined(needle) ? undefined : find(listConfig, needle);
}

export function mergeDictionariesConfigList(listConfig, mergeListConfig) {
  return reduce(mergeListConfig, (result, item) => {
    if (isUndefined(findItemInDictionariesConfigList(result, item))) {
      result.push(item);
    }

    return result;
  }, listConfig);
}


export function prepareDictionariesMap(mapConfig, dictionaries) {
  return mapValues(mapConfig, (item) => {
    let result = [];

    if (isNotEmptyArray(item.list)) {
      result = item.list;
    }

    if (dictionaries[item.queryId]) {
      result = dictionaries[item.queryId];
    }

    if (dictionaries[item.dataEntityId]) {
      result = dictionaries[item.dataEntityId];
    }

    return result;
  });
}

export function prepareDictionariesMapForItemsList(itemsList, dictionaries) {
  if (!isNotEmptyArray(itemsList)) {
    return {};
  }

  return reduce(itemsList, (result, {key, dictionary}) => {
    if (isPlainObject(dictionary)) {
      result[key] = [];

      // ToDo: improve this
      if (isNotEmptyArray(dictionary.list)) {
        result[key] = dictionary.list;
      }

      if (dictionaries[dictionary.queryId]) {
        result[key] = dictionaries[dictionary.queryId];
      }

      if (dictionaries[dictionary.dataEntityId]) {
        result[key] = dictionaries[dictionary.dataEntityId];
      }
    }

    return result;
  }, {});
}
