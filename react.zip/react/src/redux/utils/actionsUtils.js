import { isString, isArray } from 'lodash/lang';

const GLOBAL_NAMESPACE = {};
const namespaceSymbol = Symbol('namespace');
const NAMESPACE_PREFIX = 'Actions namespace';
const ACTION_PREFIX = 'Action';

export function validateKey(name, key) {
  if (!isString(key) || key.trim() === '') {
    throw new Error(`${name} key should be of type string and can not be empty. Invalid ${name.toLowerCase()} key: '${key}'. `);
  }
}

function validateNamespaceKey(key) {
  validateKey(NAMESPACE_PREFIX, key);
  if (GLOBAL_NAMESPACE.hasOwnProperty(key)) {
    throw new Error(`${NAMESPACE_PREFIX} with key ${key} already exist in application.`);
  }
}

function validateActionKey(namespace, storage, key) {
  validateKey(ACTION_PREFIX, key);
  if (storage.hasOwnProperty(key)) {
    throw new Error(`${ACTION_PREFIX} with key ${key} already exist in ${namespace} namespace.`);
  }
}

function prepareAsyncActionType(key) {
  return {
    REQUEST: `${key}_REQUEST`,
    SUCCESS: `${key}_SUCCESS`,
    FAILURE: `${key}_FAILURE`,
    RESET: `${key}_RESET`,
    CANCEL: `${key}_CANCEL`
  };
}

export default class ActionsNamespace {
  constructor(namespace, params = {}) {
    validateNamespaceKey(namespace);
    this[namespaceSymbol] = namespace;
    GLOBAL_NAMESPACE[namespace] = this;

    if (isArray(params.actions)) {
      params.actions.forEach((key) => {
        this.addAction(key);
      });
    }

    if (isArray(params.asyncActions)) {
      params.asyncActions.forEach((key) => {
        this.addAsyncAction(key);
      });
    }
  }

  prepareActionKey(key) {
    validateActionKey(this[namespaceSymbol], this, key);

    return `${this[namespaceSymbol]}.${key}`;
  }

  addAction(key) {
    this[key] = this.prepareActionKey(key);

    return this;
  }

  addAsyncAction(key) {
    this[key] = prepareAsyncActionType(this.prepareActionKey(key));

    return this;
  }

  createAction(key) {
    this.addAction(key);

    return this[key];
  }

  createAsyncAction(key) {
    this.addAsyncAction(key);

    return this[key];
  }
}

export function ActionsNamespaceFactory(key) {
  return GLOBAL_NAMESPACE.hasOwnProperty(key) ? GLOBAL_NAMESPACE[key] : new ActionsNamespace(key);
}

export function createAction(key) {
  validateKey(ACTION_PREFIX, key);

  return key;
}

export function createAsyncAction(key) {
  validateKey(ACTION_PREFIX, key);

  return prepareAsyncActionType(key);
}
