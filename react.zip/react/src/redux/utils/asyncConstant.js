/* eslint-disable no-console */

import { createAsyncAction } from './actionsUtils';

// ToDo: remove this file after refactoring
export default function asyncConstant(constant) {
  console.info('The `asyncConstant` method was Deprecated, use `createAsyncAction` method from `./actionsUtils` instead');
  return createAsyncAction(constant);
}
