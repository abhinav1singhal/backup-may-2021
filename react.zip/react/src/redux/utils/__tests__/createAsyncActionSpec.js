/* global describe, it, beforeEach, afterEach, expect */
/* eslint-disable lodash/import */

import { createAsyncAction, validateKey } from '../actionsUtils';
import _ from 'lodash';
import expect from 'expect';

describe('src.redux.utils.__tests__.createAsyncActionSpec', () => {

  describe('createAsyncAction', () => {

    it('should create Object with 5 keys: REQUEST, SUCCESS, FAILURE, RESET, CANCEL', () => {
      const type = createAsyncAction('SOME_TYPE');
      expect(_.isObject(type)).toBe(true);
      expect(_.has(type, 'REQUEST')).toBe(true);
      expect(_.has(type, 'SUCCESS')).toBe(true);
      expect(_.has(type, 'FAILURE')).toBe(true);
      expect(_.has(type, 'RESET')).toBe(true);
      expect(_.has(type, 'CANCEL')).toBe(true);
      expect(_.keys(type).length).toEqual(5);
    });

    it('should append postfixes to passed constant', () => {
      const type = createAsyncAction('SOME_TYPE');

      expect(type.REQUEST).toEqual('SOME_TYPE_REQUEST');
      expect(type.SUCCESS).toEqual('SOME_TYPE_SUCCESS');
      expect(type.FAILURE).toEqual('SOME_TYPE_FAILURE');
      expect(type.RESET).toEqual('SOME_TYPE_RESET');
      expect(type.CANCEL).toEqual('SOME_TYPE_CANCEL');
    });

    it('Validation should throw if passed constant is not a string', () => {
      const PREFIX = 'Action';

      expect(() => validateKey(PREFIX)).toThrow();
      expect(() => validateKey(PREFIX, null)).toThrow();
      expect(() => validateKey(PREFIX, {})).toThrow();
      expect(() => validateKey(PREFIX, [])).toThrow();
      expect(() => validateKey(PREFIX, 2390)).toThrow();
      expect(() => validateKey(PREFIX, 'MyKey')).toNotThrow();

    });

  });

});
