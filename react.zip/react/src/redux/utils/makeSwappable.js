export default function makeSwappable(reducer) {
  return (state, action) => {
    switch (action.type) {
      case 'swap(APPLY_STATE)':
        return reducer(action.state, action);
      default:
        return reducer(state, action);
    }
  };
}
