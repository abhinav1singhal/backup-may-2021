import {
  SHOW_NOTIFICATION,
  HIDE_NOTIFICATION
} from '../actions/notificationActions';
import { filter } from 'lodash';
import handleActions from 'redux-actions/lib/handleActions';

const getInitialState = () => {
  return [];
};

export default handleActions({
  [SHOW_NOTIFICATION](state, action) {
    if (action.notification) {
      return [...state, action.notification];
    }
    return state;
  },

  [HIDE_NOTIFICATION](state, action) {
    if (action.uid) {
      return filter(state, (notification) => {
        return notification.uid !== action.uid;
      });
    }
    return state;
  }
}, getInitialState());
