import {
  ADD_TABLE,
  UPDATE_TABLE,
  REMOVE_TABLE,
  SORT_TABLE,
  FILTER_TABLE
} from '../actions/dataTableActions';
import handleActions from 'redux-actions/lib/handleActions';
import { keys, has, flowRight } from 'lodash';
import ImmutableStore from 'immutable-store';

export const getInitialState = () => {
  return ImmutableStore({
    settings: {},
    ids: () => {
      return {
        value: [],

        deps: {
          settings: ['settings']
        },

        get: (value, deps) => {
          return keys(deps.settings);
        }
      };
    }
  });
};

export default handleActions({

  [ADD_TABLE](state, action) {
    if (
      has(action, 'id') &&
      has(action, 'settings')
    ) {
      return state.settings.set(action.id, { id: action.id, ...action.settings });
    }

    return state;
  },

  [UPDATE_TABLE](state, action) {
    if (
      has(action, 'id') &&
      has(action, 'settings') &&
      has(state, `settings[${action.id}]`)
    ) {
      return state.settings.set(action.id, { id: action.id, ...action.settings });
    }

    return state;
  },

  [REMOVE_TABLE](state, action) {
    if (has(action, 'id')) {
      return state.settings.unset(action.id);
    }

    return state;
  },

  [SORT_TABLE](state, action) {
    if (
      has(action, 'id') &&
      has(action, 'sortKey') &&
      has(action, 'sortDirection') &&
      has(state, `settings[${action.id}]`)
    ) {
      return flowRight(
        (st) => st.settings[action.id].set('sortKey', action.sortKey),
        (st) => st.settings[action.id].set('sortDirection', action.sortDirection)
      )(state);
    }

    return state;
  },

  [FILTER_TABLE](state, action) {
    if (
      has(action, 'id') &&
      has(action, 'filterText') &&
      has(state, `settings[${action.id}]`)
    ) {
      return state.settings[action.id].set('filterText', action.filterText);
    }

    return state;
  }

}, getInitialState());
