/* global describe, it, beforeEach, afterEach, sinon */

import expect from 'expect';
import {
  ADD_TABLE,
  UPDATE_TABLE,
  REMOVE_TABLE,
  SORT_TABLE,
  FILTER_TABLE,
  addTable
} from '../../actions/dataTableActions';
import ImmutableStore from 'immutable-store';
import { sortTypes } from '../../../DataTable/DataTable';
import dataTableReducer, { getInitialState } from '../dataTableReducer';

describe('src.redux.reducers.__tests__.dataTableReducerSpec', () => {

  describe('DataTable Reducer', () => {

    const initialState = getInitialState();

    it('should be a function', () => {
      expect(dataTableReducer).toBeA('function');
    });

    it('should return the initial state', () => {
      expect(
        dataTableReducer(undefined, {
          settings: {},
          ids: []
        })
      ).toEqual(initialState);
    });

    describe('ADD_TABLE', () => {

      const getState = (prevState, action) => {
        return dataTableReducer(prevState, {
          id: action.id,
          settings: action.settings,
          type: ADD_TABLE
        });
      };

      it('should handle ADD_TABLE and provide default values for settings', () => {

        const payload = {
          id: 1,
          settings: {
            sortKey: null,
            sortDirection: null,
            filterText: ''
          }
        };

        const state = getState(initialState, payload);

        expect(state.ids).toEqual([ '1' ]);
        expect(state.settings.toJS()).toEqual({
          1: {
            id: 1,
            sortKey: null,
            sortDirection: null,
            filterText: ''
          }
        });
      });

      it('should not change state if action is invalid', () => {
        const payloads = [
          {}, { id: 1 }
        ];

        payloads.forEach((payload) => {
          const state = dataTableReducer(initialState, {
            type: ADD_TABLE,
            ...payload
          });
          expect(state.toJS()).toEqual(initialState.toJS());
        });

      });

    });

    describe('UPDATE_TABLE', () => {

      it('should handle UPDATE_TABLE and update settings', () => {
        const getState = (prevState, action) => {
          return dataTableReducer(prevState, {
            id: action.id,
            settings: action.settings,
            type: UPDATE_TABLE
          });
        };

        const prevState = ImmutableStore({
          settings: {
            1: {
              sortKey: null,
              sortDirection: null,
              filterText: ''
            }
          }
        });

        const payload = {
          id: 1,
          settings: {
            sortKey: 'test',
            sortDirection: 'ASK',
            filterText: ''
          }
        };

        const state = getState(prevState, payload);

        expect(state.settings.toJS()).toEqual({
          1: {
            id: 1,
            sortKey: 'test',
            sortDirection: 'ASK',
            filterText: ''
          }
        });
      });

      it('should not change state if action is invalid', () => {
        const payloads = [
          {}, { id: 1 }
        ];

        payloads.forEach((payload) => {
          const state = dataTableReducer(initialState, {
            type: UPDATE_TABLE,
            ...payload
          });
          expect(state.toJS()).toEqual(initialState.toJS());
        });

      });

    });

    describe('REMOVE_TABLE', () => {

      it('should handle ', () => {
        const getState = (prevState, action) => {
          return dataTableReducer(prevState, {
            id: action.id,
            type: REMOVE_TABLE
          });
        };

        const prevState = ImmutableStore({
          settings: {
            1: {
              sortKey: null,
              sortDirection: null,
              filterText: ''
            }
          }
        });

        const state = getState(prevState, { id: 1 });

        expect(state.settings.toJS()).toEqual({});
      });

      it('should not change state if action is invalid', () => {
        const payloads = [
          {}
        ];

        payloads.forEach((payload) => {
          const state = dataTableReducer(initialState, {
            type: REMOVE_TABLE,
            ...payload
          });
          expect(state.toJS()).toEqual(initialState.toJS());
        });

      });

    });

    describe('SORT_TABLE', () => {

      it('should handle SORT_TABLE and merge settings', () => {
        const payload = {
          id: '1'
        };

        const stateWithTable = dataTableReducer(initialState,
          addTable(payload.id, payload.data)
        );

        expect(stateWithTable.ids).toEqual([ '1' ]);

        const getState = (prevState, action) => {
          return dataTableReducer(prevState, {
            id: action.id,
            sortKey: action.sortKey,
            sortDirection: action.sortDirection,
            type: SORT_TABLE
          });
        };

        const testingState = getState(stateWithTable, { id: '1', sortKey: 'id', sortDirection: sortTypes.ASC });
        expect(testingState.settings.toJS()).toEqual({ 1: { id: '1', sortKey: 'id', sortDirection: sortTypes.ASC, filterText: '' } });
      });

      it('should not change state if action is invalid', () => {
        const payloads = [
          {},
          { id: 1 },
          { id: 1, sortKey: 'title' },
          { id: 1, sortKey: 'title', sortDirection: 'DESC' }
        ];

        payloads.forEach((payload) => {
          const state = dataTableReducer(initialState, {
            type: SORT_TABLE,
            ...payload
          });
          expect(state.toJS()).toEqual(initialState.toJS());
        });

      });

    });

    describe('FILTER_TABLE', () => {

      it('should handle FILTER_TABLE and merge settings', () => {
        const payload = {
          id: '1'
        };

        const stateWithTable = dataTableReducer(initialState,
          addTable(payload.id)
        );

        expect(stateWithTable.ids).toEqual([ '1' ]);

        const getState = (prevState, action) => {
          return dataTableReducer(prevState, {
            id: action.id,
            filterText: action.filterText,
            type: FILTER_TABLE
          });
        };

        const testingState = getState(stateWithTable, { id: 1, filterText: '1' });

        expect(testingState.settings.toJS()).toEqual({ 1: { id: '1', filterText: '1', sortKey: null, sortDirection: null } });
      });

      it('should not change state if action is invalid', () => {
        const payloads = [
          {},
          { id: 1 },
          { id: 1, filterText: 'title' }
        ];

        payloads.forEach((payload) => {
          const state = dataTableReducer(initialState, {
            type: FILTER_TABLE,
            ...payload
          });
          expect(state.toJS()).toEqual(initialState.toJS());
        });

      });

    });

  });

});
