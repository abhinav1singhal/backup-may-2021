/* global describe, it, beforeEach, afterEach, sinon */

import expect from 'expect';
import requestsReducer, { getActionHandlersAndInitialState } from '../requestsReducer';
import { keys } from 'lodash';

import { createAsyncAction } from '../../utils/actionsUtils';
import AsyncStatus from '../../../utils/asyncStatus';

const ASYNC_ACTION_1 = createAsyncAction('ASYNC_ACTION_1');
const ASYNC_ACTION_2 = createAsyncAction('ASYNC_ACTION_2');

describe('src.redux.reducers.__tests__.requestsReducerSpec', () => {

  describe('Requests reducer', () => {

    it('should be a function', () => {
      expect(requestsReducer).toBeA('function');
    });

    it('should create reducer based on passed config', () => {

      const config = {
        field1: ASYNC_ACTION_1,
        field2: ASYNC_ACTION_2
      };

      const [ actionHandlers, initialState ] = getActionHandlersAndInitialState(config);

      expect(keys(actionHandlers)).toEqual([
        'ASYNC_ACTION_1_REQUEST', 'ASYNC_ACTION_1_SUCCESS', 'ASYNC_ACTION_1_FAILURE', 'ASYNC_ACTION_1_RESET', 'ASYNC_ACTION_1_CANCEL',
        'ASYNC_ACTION_2_REQUEST', 'ASYNC_ACTION_2_SUCCESS', 'ASYNC_ACTION_2_FAILURE', 'ASYNC_ACTION_2_RESET', 'ASYNC_ACTION_2_CANCEL'
      ]);

      expect(initialState).toEqual({
        field1: {
          status: AsyncStatus.NONE,
          meta: {},
          error: false
        },
        field2: {
          status: AsyncStatus.NONE,
          meta: {},
          error: false
        }
      });

      expect(requestsReducer(config)).toBeA('function');

    });

    it('should handle REQUEST, SUCCESS, FAILURE, RESET, CANCEL actions properly', () => {

      const reducer = requestsReducer({ field1: ASYNC_ACTION_1 });
      const prevState = {
        field1: {
          status: AsyncStatus.NONE,
          error: false
        }
      };

      const requestState = reducer(prevState, { type: ASYNC_ACTION_1.REQUEST });
      expect(requestState).toEqual({
        field1: {
          status: AsyncStatus.REQUEST,
          meta: {},
          error: false,
          statusCode: null,
          responseMessage: null
        }
      });

      const successState = reducer(requestState, { type: ASYNC_ACTION_1.SUCCESS });
      expect(successState).toEqual({
        field1: {
          status: AsyncStatus.SUCCESS,
          meta: {},
          error: false,
          statusCode: null,
          responseMessage: null
        }
      });

      const failureState = reducer(requestState, { type: ASYNC_ACTION_1.FAILURE });
      expect(failureState).toEqual({
        field1: {
          status: AsyncStatus.FAILURE,
          meta: {},
          error: true,
          statusCode: null,
          responseMessage: null
        }
      });
      const error = new Error('test error');
      const failureStateWithError = reducer(requestState, { type: ASYNC_ACTION_1.FAILURE, error });
      expect(failureStateWithError).toEqual({
        field1: {
          status: AsyncStatus.FAILURE,
          meta: {},
          error,
          statusCode: null,
          responseMessage: null
        }
      });

      const resetState = reducer(requestState, { type: ASYNC_ACTION_1.RESET });
      expect(resetState).toEqual({
        field1: {
          status: AsyncStatus.NONE,
          meta: {},
          error: false,
          statusCode: null,
          responseMessage: null
        }
      });

      const cancelState = reducer(requestState, { type: ASYNC_ACTION_1.CANCEL });
      expect(cancelState).toEqual({
        field1: {
          status: AsyncStatus.CANCEL,
          meta: {},
          error: false,
          statusCode: null,
          responseMessage: null
        }
      });

    });

  });

});
