/* global describe, it, beforeEach, afterEach, sinon */

import expect from 'expect';
import {
  SHOW_NOTIFICATION,
  HIDE_NOTIFICATION
} from '../../actions/notificationActions';
import notificationsReducer from '../notificationsReducer';

describe('src.redux.reducers.__tests__.notificationsReducerSpec', () => {

  describe('Notification reducer', () => {

    it('should be a function', () => {
      expect(notificationsReducer).toBeA('function');
    });

    describe('SHOW_NOTIFICATION', () => {

      it('should add notification with correct action', () => {
        const prevState = [ ];
        const notification = { uid: 1 };

        const nextState = notificationsReducer(prevState, { type: SHOW_NOTIFICATION, notification });

        expect(nextState.length).toEqual(1);
        expect(nextState[0]).toEqual(notification);
      });

      it('should not change the state if notification is missing', () => {
        const prevState = [ ];
        const state = notificationsReducer(prevState, { type: SHOW_NOTIFICATION });
        expect(state).toEqual(prevState);
      });

    });

    describe('HIDE_NOTIFICATION', () => {

      it('should remove notification with correct action', () => {
        const prevState = [{ uid: 1 }];
        const nextState = notificationsReducer(prevState, { type: HIDE_NOTIFICATION, uid: 1 });
        expect(nextState.length).toEqual(0);
      });

      it('should not change the state if uid is missing', () => {
        const prevState = [ ];
        const state = notificationsReducer(prevState, { type: HIDE_NOTIFICATION });
        expect(state).toEqual(prevState);
      });

    });

  });

});
