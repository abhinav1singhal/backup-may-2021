/* global describe, it, beforeEach, afterEach, sinon */

import expect from 'expect';
import {
  ADD_TABLE,
  REMOVE_TABLE,
  CELLS_CHANGED,
  ROWS_ADDED,
  COLUMNS_ADDED,
  ROWS_REMOVED,
  COLUMNS_REMOVED
} from '../../actions/handsontableActions';
import handsontableReducer from '../handsontableReducer';

describe('src.redux.reducers.__tests__.handsontableReducerSpec', () => {

  describe('Handsontable reducer', () => {

    it('should be a function', () => {
      expect(handsontableReducer).toBeA('function');
    });

    const createShouldChangeStateTest = (type, payloads) => {

      it(`${type} should not change the state if required actions params are missing`, () => {

        payloads.forEach((payload) => {
          const prevState = {
            [0]: {
              data: [[1, 2], [3, 4]]
            }
          };

          const nextState = handsontableReducer(prevState, {
            type,
            ...payload
          });

          expect(nextState).toEqual(prevState);
        });

      });

    };

    it('should handle ADD_TABLE', () => {
      const id = 1;
      const data = [[3, 4], [5, 6]];

      const prevState = {
        [0]: {
          data: [[1, 2], [3, 4]]
        }
      };

      const nextState = handsontableReducer(prevState, { id, type: ADD_TABLE, data });

      expect(nextState[0].data[1][0]).toEqual(3);
      expect(nextState[0].data[0][1]).toEqual(2);

      expect(nextState[id].data[0][0]).toEqual(3);
    });
    createShouldChangeStateTest(ADD_TABLE, [ {}, { id: 1 } ]);


    it('should handle REMOVE_TABLE', () => {
      const id = 1;

      const prevState = {
        [id]: {
          data: [[1, 2], [3, 4]]
        }
      };

      const nextState = handsontableReducer(prevState, { id, type: REMOVE_TABLE });

      expect(nextState).toEqual({ });
    });
    createShouldChangeStateTest(REMOVE_TABLE, [ {} ]);

    it('should handle CELLS_CHANGED', () => {
      const id = 1;
      const changes = [
        [1, 0, 3, 99],
        [0, 1, 2, 101]
      ];

      const prevState = {
        [id]: {
          data: [[1, 2], [3, 4]]
        }
      };

      const nextState = handsontableReducer(prevState, { id, type: CELLS_CHANGED, changes });

      expect(nextState[id].data[1][0]).toEqual(99);
      expect(nextState[id].data[0][1]).toEqual(101);
    });
    createShouldChangeStateTest(CELLS_CHANGED, [ {}, { id: 1 } ]);

    it('should handle ROWS_ADDED', () => {
      const id = 1;
      const startIndex = 1;
      const amount = 2;

      const prevState = {
        [id]: {
          data: [[1, 2], [3, 4]]
        }
      };

      const nextState = handsontableReducer(prevState, {
        id,
        type: ROWS_ADDED,
        startIndex,
        amount
      });

      expect(nextState[id].data.length).toEqual(4);
      expect(nextState[id].data).toEqual([
        [1, 2],
        ['', ''],
        ['', ''],
        [3, 4]
      ]);
    });
    createShouldChangeStateTest(ROWS_ADDED, [ {}, { id: 1 }, { id: 1, startIndex: 1 } ]);

    it('should handle COLUMNS_ADDED', () => {
      const id = 1;
      const startIndex = 1;
      const amount = 3;

      const prevState = {
        [id]: {
          data: [[1, 2], [3, 4]]
        }
      };

      const nextState = handsontableReducer(prevState, { id, type: COLUMNS_ADDED, startIndex, amount });

      expect(nextState[id].data.length).toEqual(2);
      expect(nextState[id].data).toEqual([
        [ 1, '', '', '', 2 ],
        [ 3, '', '', '', 4 ]
      ]);
    });
    createShouldChangeStateTest(COLUMNS_ADDED, [ {}, { id: 1 }, { id: 1, startIndex: 1 } ]);

    it('should handle ROWS_REMOVED', () => {
      const id = 1;
      const startIndex = 1;
      const amount = 2;

      const prevState = {
        [id]: {
          data: [[1, 2], [3, 4], [5, 6]]
        }
      };

      const nextState = handsontableReducer(prevState, { id, type: ROWS_REMOVED, startIndex, amount });

      expect(nextState[id].data.length).toEqual(1);
      expect(nextState[id].data[0]).toEqual([1, 2]);
    });
    createShouldChangeStateTest(ROWS_REMOVED, [ {}, { id: 1 }, { id: 1, startIndex: 1} ]);

    it('should handle COLUMNS_REMOVED', () => {
      const id = 1;
      const startIndex = 1;
      const amount = 1;

      const prevState = {
        [id]: {
          data: [[1, 2], [3, 4]]
        }
      };

      const nextState = handsontableReducer(prevState, { id, type: COLUMNS_REMOVED, startIndex, amount });

      expect(nextState[id].data.length).toEqual(2);
      expect(nextState[id].data[0]).toEqual([1]);
    });
    createShouldChangeStateTest(COLUMNS_REMOVED, [ {}, { id: 1 }, { id: 1, startIndex: 1} ]);

    it('shouldn\'t make any changes with another tables', () => {
      const id1 = 1;
      const id2 = 2;
      const changes = [
        [1, 0, 3, 99],
        [0, 1, 2, 101]
      ];

      const prevState = {
        [id1]: {
          data: [[1, 2], [3, 4]]
        },
        [id2]: {
          data: [[0, 0], [1, 1]]
        }
      };

      const nextState = handsontableReducer(prevState, { id: id1, type: CELLS_CHANGED, changes });

      expect(nextState[id1].data[1][0]).toEqual(99);
      expect(nextState[id1].data[0][1]).toEqual(101);

      expect(nextState[id2].data[1][0]).toEqual(1);
      expect(nextState[id2].data[0][1]).toEqual(0);
    });

  });

});
