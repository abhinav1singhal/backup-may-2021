import handleActions from 'redux-actions/lib/handleActions';

function getInitialState() {
  return {};
}

// ToDo: implement this
export default handleActions({

}, getInitialState());
