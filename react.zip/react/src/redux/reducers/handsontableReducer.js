import {
  ADD_TABLE,
  REMOVE_TABLE,
  CELLS_CHANGED,
  ROWS_ADDED,
  COLUMNS_ADDED,
  ROWS_REMOVED,
  COLUMNS_REMOVED
} from '../actions/handsontableActions';
import handleActions from 'redux-actions/lib/handleActions';
import { map, omit, has } from 'lodash';

export const getInitialState = () => {
  return {};
};

export default handleActions({

  [ADD_TABLE](state, action) {
    if (
      has(action, 'id') &&
      has(action, 'data')
    ) {
      return {
        ...state,
        [action.id]: {
          data: action.data
        }
      };
    }
    return state;
  },

  [REMOVE_TABLE](state, action) {
    if (
      has(action, 'id')
    ) {
      return omit(state, action.id);
    }
    return state;
  },

  [CELLS_CHANGED](state, action) {
    if (
      has(action, 'id') &&
      has(action, 'changes')
    ) {
      const table = state[action.id];
      const data = [...table.data];

      for (let i = 0; i !== action.changes.length; ++i) {
        const change = action.changes[i];
        data[change[0]][change[1]] = change[3];
      }
      return {
        ...state,
        [action.id]: {
          data
        }
      };
    }
    return state;
  },

  [ROWS_ADDED](state, action) {
    if (
      has(action, 'id') &&
      has(action, 'startIndex') &&
      has(action, 'amount')
    ) {
      const table = state[action.id];
      const data = [...table.data];
      const dim = data.length ? data[0].length : 0;

      for (let i = 0; i !== action.amount; ++i) {
        const newRow = map(new Array(dim), () => {
          return '';
        });
        data.splice(action.startIndex, 0, newRow);
      }

      return {
        ...state,
        [action.id]: {
          data
        }
      };
    }
    return state;
  },

  [COLUMNS_ADDED](state, action) {
    if (
      has(action, 'id') &&
      has(action, 'startIndex') &&
      has(action, 'amount')
    ) {

      const table = state[action.id];
      const data = [...table.data];

      for (let i = 0; i !== data.length; ++i) {
        for (let j = 0; j !== action.amount; ++j) {
          data[i].splice(action.startIndex, 0, '');
        }
      }

      return {
        ...state,
        [action.id]: {
          data
        }
      };
    }
    return state;
  },

  [ROWS_REMOVED](state, action) {
    if (
      has(action, 'id') &&
      has(action, 'startIndex') &&
      has(action, 'amount')
    ) {
      const table = state[action.id];
      const data = [...table.data];

      for (let i = 0; i !== action.amount; ++i) {
        data.splice(action.startIndex, 1);
      }

      return {
        ...state,
        [action.id]: {
          data
        }
      };
    }
    return state;
  },

  [COLUMNS_REMOVED](state, action) {
    if (
      has(action, 'id') &&
      has(action, 'startIndex') &&
      has(action, 'amount')
    ) {
      const table = state[action.id];
      const data = [...table.data];

      for (let i = 0; i !== data.length; ++i) {
        for (let j = 0; j !== action.amount; ++j) {
          data[i].splice(action.startIndex, 1);
        }
      }

      return {
        ...state,
        [action.id]: {
          data
        }
      };
    }
    return state;
  }

}, getInitialState());
