/* eslint-disable consistent-return */

import { PropTypes } from 'react';
import requirablePropType from '../../../utils/requirablePropType';

const requestStringPattern = /REQUEST$|SUCCESS$|FAILURE$|RESET$|CANCEL$/;

function requestStringCheck(props, propName, componentName) {
  if (!requestStringPattern.test(props[propName])) {
    return new Error(
      `Invalid request type: '${propName}' supplied to '${componentName}'. Validation failed.`
    );
  }
}

const requestPropType = requirablePropType(requestStringCheck);

const requestObjectType = PropTypes.shape({
  REQUEST: requestPropType.isRequired,
  SUCCESS: requestPropType.isRequired,
  FAILURE: requestPropType.isRequired,
  RESET: requestPropType.isRequired,
  CANCEL: requestPropType.isRequired
});

const requestsReducerType = PropTypes.objectOf(requestObjectType);

export default {
  requestObjectType,
  requestsReducerType
};
