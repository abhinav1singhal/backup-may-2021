import { handleActions } from 'redux-actions';
import AsyncStatus from '../../utils/asyncStatus';
import { keys, has, isNumber } from 'lodash';

function getStatusCode(payload = {}) {
  const statusCode = has(payload, '$statusCode') ? payload.$statusCode : payload.status;
  return isNumber(statusCode) ? statusCode : null;
}

function getResponseMessage(payload = {}) {
  return has(payload, '$responseMessage') ? payload.$responseMessage : null;
}

const createRequestReducers = (asyncAction, key) => {

  return {
    [asyncAction.REQUEST]: (state, action) => {
      return {
        ...state,
        [key]: {
          status: AsyncStatus.REQUEST,
          meta: action.meta || {},
          error: false,
          statusCode: getStatusCode(action.payload),
          responseMessage: getResponseMessage(action.payload)
        }
      };
    },
    [asyncAction.SUCCESS]: (state, action) => {
      return {
        ...state,
        [key]: {
          status: AsyncStatus.SUCCESS,
          meta: state[key].meta,
          error: false,
          statusCode: getStatusCode(action.payload),
          responseMessage: getResponseMessage(action.payload)
        }
      };
    },
    [asyncAction.FAILURE]: (state, action) => {
      return {
        ...state,
        [key]: {
          status: AsyncStatus.FAILURE,
          meta: state[key].meta,
          error: action.error ? action.error : true,
          statusCode: getStatusCode(action.payload),
          responseMessage: getResponseMessage(action.payload)
        }
      };
    },
    [asyncAction.RESET]: (state, action) => {
      return {
        ...state,
        [key]: {
          status: AsyncStatus.NONE,
          meta: {},
          error: false,
          statusCode: getStatusCode(action.payload),
          responseMessage: getResponseMessage(action.payload)
        }
      };
    },
    [asyncAction.CANCEL]: (state, action) => {
      return {
        ...state,
        [key]: {
          status: AsyncStatus.CANCEL,
          meta: state[key].meta,
          error: false,
          statusCode: getStatusCode(action.payload),
          responseMessage: getResponseMessage(action.payload)
        }
      };
    }
  };

};

export function getActionHandlersAndInitialState(config) {
  const reducerKeys = keys(config);

  const initialState = reducerKeys.reduce((prev, reducerName) => {
    return {
      ...prev,
      [reducerName]: {
        status: AsyncStatus.NONE,
        meta: {},
        error: false
      }
    };
  }, {});

  const actionHandlers = reducerKeys.reduce((prev, reducerName) => {
    const newActionHandlers = createRequestReducers(config[reducerName], reducerName);
    return {
      ...prev,
      ...newActionHandlers
    };
  }, {});

  return [ actionHandlers, initialState ];
}

export default (config) => {
  return handleActions(...getActionHandlersAndInitialState(config));
};
