import { mapValues, map, forEach, omit, isArray } from 'lodash';

import {
  prepareDictionariesRequestList, prepareDictionariesConfigListFromMap, prepareDictionariesMap,
  prepareDictionariesConfigListFromItemsList, prepareDictionariesConfigMapFromItemsList
} from '../utils/dictionariesUtils';

/**
 * ToDo:
 *  - cleanup service & utils
 *  - prepare JSDoc
 *  - implement error handling
 *  - do not perform request if dictionaries request list is empty
 */

export function loadDictionaries(client, listConfig, BASE_API_URL) {
  return client.post(`${BASE_API_URL}/dictionaries`, {
    dictionaries: prepareDictionariesRequestList(listConfig)
  }).then(({data}) => mapValues(data, (list) => map(list, (item) => { // ToDo: improve this (temp fix)
    const result = {
      id: item.id,
      name: item.name
    };

    forEach(omit(item, ['id', 'name', 'description']), (value, key) => {
      result[key] = (isArray(value) && value.length <= 1) ? value[0] : value;
    });

    return result;
  })));
}

export function loadDictionariesMap(client, mapConfig, BASE_API_URL) {
  return loadDictionaries(client, prepareDictionariesConfigListFromMap(mapConfig), BASE_API_URL)
    .then((dictionaries) => prepareDictionariesMap(mapConfig, dictionaries));
}

export function loadDictionariesByItemsConfigList(client, itemsConfigList, BASE_API_URL) {
  return loadDictionaries(client, prepareDictionariesConfigListFromItemsList(itemsConfigList), BASE_API_URL);
}

export function loadDictionariesMapByItemsConfigList(client, itemsConfigList, BASE_API_URL) {
  return loadDictionariesMap(client, prepareDictionariesConfigMapFromItemsList(itemsConfigList), BASE_API_URL);
}

export default (client) => {
  const Service = {
    loadDictionaries: (listConfig, BASE_API_URL) => loadDictionaries(client, listConfig, BASE_API_URL),
    loadDictionariesMap: (mapConfig, BASE_API_URL) => loadDictionariesMap(client, mapConfig, BASE_API_URL),
    loadDictionariesByItemsConfigList: (formConfig, BASE_API_URL) => loadDictionariesByItemsConfigList(client, formConfig, BASE_API_URL),
    loadDictionariesMapByItemsConfigList: (formConfig, BASE_API_URL) => loadDictionariesMapByItemsConfigList(client, formConfig, BASE_API_URL)
  };

  return Service;
};
