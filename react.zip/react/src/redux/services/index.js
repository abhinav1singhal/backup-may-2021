export dictionariesService, {
  loadDictionaries, loadDictionariesMap, loadDictionariesByItemsConfigList, loadDictionariesMapByItemsConfigList
} from './dictionariesService';
