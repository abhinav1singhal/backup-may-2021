/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { markup } from '../../utils/testUtils';
import expect from 'expect';

import LoadingContainer from '../LoadingContainer';

describe('src.LoadingContainer.__tests__.LoadingContainerSpec', () => {

  describe('LoadingContainer', () => {

    it('should render children if isLoading is false', () => {

      const component = (
        <LoadingContainer isLoading={false}>
          <div>This is container content</div>
        </LoadingContainer>
      );

      expect(renderToStaticMarkup(component)).toInclude(markup(`
        <div>This is container content</div>
      `));

    });

    it('should render container with spinner if isLoading is true', () => {

      const component = (
        <LoadingContainer isLoading>
          <div>This is container content</div>
        </LoadingContainer>
      );

      const renderedComponent = renderToStaticMarkup(component);

      [
        'data-test="LoadingContainer__root"',
        'data-test="LoadingContainer__loadingArea"',
        'data-test="LoadingContainer__contentArea"',
        'data-test="Spinner__root"'
      ].forEach((selector) => {
        expect(renderedComponent).toContain(selector);
      });

      expect(renderedComponent).toInclude(
        '<div style="display:none;" class="LoadingContainer__contentArea" data-test="LoadingContainer__contentArea"><div>This is container content</div></div>'
      );

    });

    it('should add paddingTop offset to loading container if offset is defined', () => {

      const component = (
        <LoadingContainer isLoading offset={200}>
          <div>This is container content</div>
        </LoadingContainer>
      );

      expect(renderToStaticMarkup(component)).toContain(
        '<div style="padding-top:200px;padding-bottom:200px;display:block;" class="LoadingContainer__loadingArea" data-test="LoadingContainer__loadingArea">'
      );

    });

    it('should render title if it is passed', () => {

      const component = (
        <LoadingContainer isLoading title="Wait until it is loading...">
          <div>This is container content</div>
        </LoadingContainer>
      );

      expect(renderToStaticMarkup(component)).toContain('<div class="LoadingContainer__title">Wait until it is loading...</div>');

    });

    it('should set spinner type', () => {

      const component = (
        <LoadingContainer isLoading spinner="primary">
          <div>This is container content</div>
        </LoadingContainer>
      );

      expect(renderToStaticMarkup(component)).toContain('<svg class="Spinner__root" data-test="Spinner__root" width="40" height="40" viewBox="0 0 40 40">');

    });

  });

});
