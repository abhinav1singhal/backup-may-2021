import React, { PropTypes } from 'react';
import Spinner, { SPINNER_TYPES } from '../Spinner';

class LoadingContainer extends React.Component {

  static propTypes = {
    /**
     * Optional title near the spinner
     */
    title: PropTypes.string,
    /**
     * Top offset
     */
    offset: PropTypes.number,
    /**
     * Spinner type
     */
    spinner: PropTypes.oneOf(SPINNER_TYPES),
    /**
     * Show/hide spinner
     */
    isLoading: PropTypes.bool,
    /**
     * CSS Theme
     */
    theme: PropTypes.shape({
      root: PropTypes.string.isRequired,
      contentArea: PropTypes.string.isRequired,
      loadingArea: PropTypes.string.isRequired,
      spinnerContainer: PropTypes.string.isRequired,
      title: PropTypes.string.isRequired
    }).isRequired,

    spinColor: PropTypes.string,
    circleColor: PropTypes.string,

    children: PropTypes.node
  };

  renderTitle() {
    const { title, theme } = this.props;
    if (title) {
      return (
        <div className={theme.title}>{ title }</div>
      );
    }
    return null;
  }

  render() {

    const { offset, spinner, isLoading, spinColor, circleColor, theme } = this.props;

    const loadingAreaStyles = {
      paddingTop: offset || 0,
      paddingBottom: offset || 0,
      display: isLoading ? 'block' : 'none'
    };

    const contentAreaStyles = {
      display: isLoading ? 'none' : 'block'
    };

    return (
      <div className={theme.root}
           data-test="LoadingContainer__root">
        <div style={loadingAreaStyles}
             className={theme.loadingArea}
             data-test="LoadingContainer__loadingArea">
          <div className={theme.spinnerContainer}>
            <Spinner type={spinner} color={spinColor} circleColor={circleColor} />
            { this.renderTitle() }
          </div>
        </div>
        <div style={contentAreaStyles}
             className={theme.contentArea}
             data-test="LoadingContainer__contentArea">
          { this.props.children }
        </div>
      </div>
    );
  }

}

LoadingContainer.defaultProps = {
  isLoading: false,
  spinner: 'default',
  theme: require('./LoadingContainer.css')
};

export default LoadingContainer;
