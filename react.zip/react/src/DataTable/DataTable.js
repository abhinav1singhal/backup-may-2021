import React, { PropTypes } from 'react';
import classNames from  'classnames';
import FixedDataTable2 from '../FixedDataTable2';
const { Table, Column, Cell } = FixedDataTable2;
import autoSizer from './autoSizer';

const DEFAULT_TYPE = 'root';

export const sortTypes = {
  ASC: 'ASC',
  DESC: 'DESC'
};

function heightPropTypeChecker(props, propName, componentName) {
  if (props.height === undefined && props.maxHeight === undefined) {
    return new Error(`Either height or maxHeight must be specified for ${componentName}`);
  }
  return null;
}

class DataTable extends React.Component {
  static propTypes = {
    columns: PropTypes.arrayOf(PropTypes.object).isRequired,
    data: PropTypes.arrayOf(PropTypes.object).isRequired,

    width: PropTypes.number.isRequired,
    height: heightPropTypeChecker,
    maxHeight: heightPropTypeChecker,
    rowHeight: PropTypes.number.isRequired,
    headerHeight: PropTypes.number.isRequired,
    type: PropTypes.oneOf([ 'lined', 'striped', 'bordered', DEFAULT_TYPE ]).isRequired,
    className: PropTypes.string,
    theme: PropTypes.object.isRequired
  };

  renderCell = ({ rowIndex, columnKey }) => {
    const { data } = this.props;
    return <Cell>{data[rowIndex][columnKey]}</Cell>;
  }

  render() {
    const { columns, width, height, maxHeight, data, rowHeight, headerHeight } = this.props;
    const tableProps = {
      width,
      height,
      maxHeight,
      rowsCount: data.length,
      rowHeight,
      headerHeight,
      className: classNames(
        this.props.className,
        this.props.theme[this.props.type]
      )
    };
    const columnWidth = Math.max(200, width /  columns.length);
    return (
      <Table {...tableProps}>
        {
          columns.filter(({hidden}) => !hidden).map((column) => {
            const columnProps = {
              key: column.id,
              columnKey: column.id,
              label: column.label,
              width: columnWidth,
              cell: this.renderCell,
              header: column.label
            };

            return (
              <Column {...columnProps} />
            );
          })
        }
      </Table>
    );
  }
}

DataTable.defaultProps = {
  headerHeight: 50,
  rowHeight: 50,
  theme: require('./DataTable.css'),
  type: DEFAULT_TYPE
};

export default autoSizer(DataTable);
