import React, { PropTypes } from 'react';
import Input from '../Input';
import classNames from  'classnames';

class IconInput extends React.Component {

  static propTypes = {
    theme: PropTypes.object.isRequired,
    icon: PropTypes.node.isRequired,
    leftSided: PropTypes.bool,
    className: PropTypes.string
  };

  render() {
    const { icon, theme, className, leftSided, ...restProps } = this.props;
    const classes = classNames(
      className,
      {
        [theme['has-left-icon']]: leftSided,
        [theme['form-control']]: leftSided
      }
    );

    return (
      <Input {...restProps}
        className={classes}
        type="text"
        hasFeedback
        feedbackIcon={icon}
      />
    );
  }
}

IconInput.defaultProps = {
  theme: require('./IconInput.css')
};

export default IconInput;
