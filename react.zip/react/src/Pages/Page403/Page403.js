import React from 'react';
import BasePage from '../BasePage';

const Page403 = (props) => {
  return <BasePage {...props} />;
};

Page403.defaultProps = {
  header: '403',
  title: 'Access denied',
  content: 'Sorry, but you have no permission to view this page.',
  dataTestPrefix: 'Page403'
};

export default Page403;
