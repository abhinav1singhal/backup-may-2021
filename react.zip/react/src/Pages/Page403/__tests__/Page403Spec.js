/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import expect from 'expect';

import Page403 from '../Page403';

describe('src.Pages.Page403.__tests__.Page403Spec', () => {

  describe('Page403', () => {

    it('should have all anchors and correct content', () => {
      const renderedComponent = renderToStaticMarkup(<Page403 />);

      [
        'data-test="Page403__root"',
        'data-test="Page403__header"',
        'data-test="Page403__title"',
        'data-test="Page403__content"'
      ].forEach((selector) => {
        expect(renderedComponent).toContain(selector);
      });

      [
        Page403.defaultProps.header,
        Page403.defaultProps.title,
        Page403.defaultProps.content
      ].forEach((text) => {
        expect(renderedComponent).toContain(text);
      });

    });

    it('should have ability to override header, title, content', () => {

      const header = 'Custom header';
      const title = 'Custom title';
      const content = 'Custom content';

      const renderedComponent = renderToStaticMarkup((
        <Page403 header={header}
                 title={title}
                 content={content} />
      ));

      [
        header, title, content
      ].forEach((text) => {
        expect(renderedComponent).toContain(text);
      });

    });

  });

});
