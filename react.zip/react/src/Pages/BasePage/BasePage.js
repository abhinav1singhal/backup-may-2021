import React, { PropTypes } from 'react';
import classNames from 'classnames';

import theme from './BasePage.css';

class BasePage extends React.Component {
  static propTypes = {
    header: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    content: PropTypes.string.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string,
      header: PropTypes.string,
      title: PropTypes.string,
      content: PropTypes.string
    }).isRequired,
    dataTestPrefix: PropTypes.string.isRequired
  };

  render() {
    const { header, title, content, theme: customTheme, dataTestPrefix } = this.props;

    return (
      <div className={classNames(theme.root, customTheme.root)} data-test={`${dataTestPrefix}__root`}>
        <div className={classNames(theme.header, customTheme.header)} data-test={`${dataTestPrefix}__header`}>
          { header }
        </div>
        <div className={classNames(theme.title, customTheme.title)} data-test={`${dataTestPrefix}__title`}>
          { title }
        </div>
        <div className={classNames(theme.content, customTheme.content)} data-test={`${dataTestPrefix}__content`}>
          { content }
        </div>
      </div>
    );
  }
}

BasePage.defaultProps = {
  theme: {},
  dataTestPrefix: 'BasePage'
};

export default BasePage;
