export default from './BasePage';
