/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import expect from 'expect';

import BasePage from '../BasePage';

describe('src.Pages.BasePage.__tests__.BasePageSpec', () => {

  describe('BasePage', () => {

    it('should have all anchors and correct content', () => {
      const header = 'Base header';
      const title = 'Base title';
      const content = 'Base content';

      const renderedComponent = renderToStaticMarkup((
        <BasePage header={header}
                  title={title}
                  content={content} />
      ));

      [
        'data-test="BasePage__root"',
        'data-test="BasePage__header"',
        'data-test="BasePage__title"',
        'data-test="BasePage__content"'
      ].forEach((selector) => {
        expect(renderedComponent).toContain(selector);
      });

      [
        header, title, content
      ].forEach((text) => {
        expect(renderedComponent).toContain(text);
      });

    });

  });

});
