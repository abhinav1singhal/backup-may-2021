/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import expect from 'expect';

import Page500 from '../Page500';

describe('src.Pages.Page500.__tests__.Page500Spec', () => {

  describe('Page500', () => {

    it('should have all anchors and correct content', () => {
      const renderedComponent = renderToStaticMarkup(<Page500 />);

      [
        'data-test="Page500__root"',
        'data-test="Page500__header"',
        'data-test="Page500__title"',
        'data-test="Page500__content"'
      ].forEach((selector) => {
        expect(renderedComponent).toContain(selector);
      });

      [
        Page500.defaultProps.header,
        Page500.defaultProps.title,
        Page500.defaultProps.content
      ].forEach((text) => {
        expect(renderedComponent).toContain(text);
      });

    });

    it('should have ability to override header, title, content', () => {

      const header = 'Custom header';
      const title = 'Custom title';
      const content = 'Custom content';

      const renderedComponent = renderToStaticMarkup((
        <Page500 header={header}
                 title={title}
                 content={content} />
      ));

      [
        header, title, content
      ].forEach((text) => {
        expect(renderedComponent).toContain(text);
      });

    });

  });

});
