import React from 'react';
import BasePage from '../BasePage';

const Page500 = (props) => {
  return <BasePage {...props} />;
};

Page500.defaultProps = {
  header: '500',
  title: 'There was a problem serving the requested page.',
  content: 'We have been notified of the problem and we are working on it.',
  dataTestPrefix: 'Page500'
};

export default Page500;
