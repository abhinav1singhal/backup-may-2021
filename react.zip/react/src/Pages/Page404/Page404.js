import React from 'react';
import BasePage from '../BasePage';

const Page404 = (props) => {
  return <BasePage {...props} />;
};

Page404.defaultProps = {
  header: '404',
  title: 'Page Not Found',
  content: 'Sorry, but the page you are looking for has note been found. Try checking the URL for error, then hit the refresh button on your browser or try found something else in our app.',
  dataTestPrefix: 'Page404'
};

export default Page404;
