/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import expect from 'expect';

import Page404 from '../Page404';

describe('src.Pages.Page404.__tests__.Page404Spec', () => {

  describe('Page404', () => {

    it('should have all anchors and correct content', () => {
      const renderedComponent = renderToStaticMarkup(<Page404 />);

      [
        'data-test="Page404__root"',
        'data-test="Page404__header"',
        'data-test="Page404__title"',
        'data-test="Page404__content"'
      ].forEach((selector) => {
        expect(renderedComponent).toContain(selector);
      });

      [
        Page404.defaultProps.header,
        Page404.defaultProps.title,
        Page404.defaultProps.content
      ].forEach((text) => {
        expect(renderedComponent).toContain(text);
      });

    });

    it('should have ability to override header, title, content', () => {

      const header = 'Custom header';
      const title = 'Custom title';
      const content = 'Custom content';

      const renderedComponent = renderToStaticMarkup((
        <Page404 header={header}
                 title={title}
                 content={content} />
      ));

      [
        header, title, content
      ].forEach((text) => {
        expect(renderedComponent).toContain(text);
      });

    });

  });

});
