export BasePage from './BasePage';
export Page403 from './Page403';
export Page404 from './Page404';
export Page500 from './Page500';
