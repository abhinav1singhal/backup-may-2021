/**
 * Copyright Schrodinger, LLC
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 *
 * @providesModule cssVar
 * @typechecks
 */

"use strict";

var CSS_VARS = {
  'scrollbar-face-active-color': 'rgba(151, 151, 151, 0.8)',
  'scrollbar-face-color': 'rgba(151, 151, 151, 0.8)',
  'scrollbar-face-margin': '7px',
  'scrollbar-face-radius': '0px',
  'scrollbar-size': '22px',
  'scrollbar-size-large': '30px',
  'scrollbar-track-color': 'rgba(255, 255, 255, 0.9)',
  'fbui-white': '#fff',
  'fbui-desktop-background-light': '#f6f7f8',
};

/**
 * @param {string} name
 */
function cssVar(name) {
  if (CSS_VARS.hasOwnProperty(name)) {
    return CSS_VARS[name];
  }

  throw new Error(
    'cssVar' + '("' + name + '"): Unexpected class transformation.'
  );
}

cssVar.CSS_VARS = CSS_VARS;

module.exports = cssVar;
