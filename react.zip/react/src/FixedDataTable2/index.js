require('../FixedDataTable2/css/style/fixedDataTableCell.css');
require('../FixedDataTable2/css/style/fixedDataTable.css');
require('../FixedDataTable2/css/style/fixedDataTableColumnReorder.css');
require('../FixedDataTable2/css/style/fixedDataTableColumnResizerLine.css');
require('../FixedDataTable2/css/style/fixedDataTableRow.css');
require('../FixedDataTable2/css/style/Scrollbar.css');

require('../FixedDataTable2/css/layout/fixedDataTableCellLayout.css');
require('../FixedDataTable2/css/layout/fixedDataTableCellGroupLayout.css');
require('../FixedDataTable2/css/layout/fixedDataTableColumnResizerLineLayout.css');
require('../FixedDataTable2/css/layout/fixedDataTableLayout.css');
require('../FixedDataTable2/css/layout/fixedDataTableRowLayout.css');
require('../FixedDataTable2/css/layout/ScrollbarLayout.css');

export default from './FixedDataTableRoot';
