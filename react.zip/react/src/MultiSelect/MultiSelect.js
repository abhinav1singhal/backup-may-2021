import React, { Component, PropTypes } from 'react';
import Select from '../Select';
import { Checkbox } from '../CheckboxRadio';
import { findIndex, remove, noop, isUndefined, isArray, isEqual, clone } from 'lodash';

class MultiSelect extends Component {
  static propTypes = {
    options: PropTypes.arrayOf(PropTypes.object).isRequired,
    value: PropTypes.array,
    valueKey: PropTypes.string,
    labelKey: PropTypes.string,
    shownAm: PropTypes.number,
    label: PropTypes.node,
    onChange: PropTypes.func.isRequired,
    onOpen: PropTypes.func,
    onClose: PropTypes.func,
    disabled: PropTypes.bool,
    showSelectAll: PropTypes.bool,
    searchable: PropTypes.bool,
    bsSize: PropTypes.string,
    bsStyle: PropTypes.string,
    labelClassName: PropTypes.string,
    wrapperClassName: PropTypes.string,
    parentClassName: PropTypes.string,
    theme: PropTypes.object.isRequired
  };

  constructor(props) {
    super(props);

    this.state = this.prepareState(props.value,
      isUndefined(props.showSelectAll) ? props.options.length > 2 : props.showSelectAll, props.options);
  }

  componentWillReceiveProps(props) {
    const newSate = this.prepareState(props.value, this.state.showSelectAll, props.options);
    if (!isEqual(this.props.options, props.options)) {
      newSate.showSelectAll = isUndefined(props.showSelectAll) ? props.options.length > 3 : props.showSelectAll;
    }

    if (!isEqual(this.state, newSate)) {
      this.setState(newSate); // eslint-disable-line react/no-set-state
    }
  }

  onChange(option, event = {}) {
    if (!option) return undefined;
    if (event.target && event.target.type === 'checkbox' || option.$selectAll) {
      event.preventMenuClose();
    }

    const { value: _value, valueKey, options} = this.props;
    const value = clone(_value);
    if (isArray(option)) {
      if (!value) return undefined;
      this.setState({allSelected: false}); // eslint-disable-line react/no-set-state
      remove(value, value[value.length - 1]);
      this.props.onChange(value);
      return undefined;
    }
    if (!option.$selectAll && findIndex(options, option) === -1) {
      return undefined;
    }

    if (this.isSelected(option)) {
      if (option.$selectAll) {
        options.forEach((el) => {
          remove(value, {[valueKey]: el[valueKey]});
        });
      } else {
        remove(value, {[valueKey]: option[valueKey]});
      }
      this.setState({allSelected: false}); // eslint-disable-line react/no-set-state
    } else {
      if (option.$selectAll) {
        options.filter((item) => {
          return findIndex(value, item) === -1;
        }).forEach((el) => {
          value.push(el);
        });
        this.setState({allSelected: true}); // eslint-disable-line react/no-set-state
      } else {
        value.push(option);
      }
    }

    this.props.onChange(value);
    return undefined;
  }

  generateOptionsWithSelectAll() {
    if (this.state.showSelectAll === false) return this.props.options;
    const {labelKey, options} = this.props;

    return [
      {
        $selectAll: true,
        [labelKey]: 'Select all'
      },
      ...options
    ];
  }

  prepareState(value, showSelectAll, options) {
    const result = {
      allSelected: false,
      selectValue: undefined,
      showSelectAll
    };

    if (isArray(value) && value.length > 0) {
      result.allSelected = value.length === options.length;

      let title = '';
      if (value.length > this.props.shownAm) {
        title = result.allSelected ? 'All selected' : `${value.length} selected`;
      } else {
        title = value.map((item) => item[this.props.labelKey]).join(', ');
      }

      result.selectValue = {
        [this.props.labelKey]: title,
        [this.props.valueKey]: title
      };
    }

    return result;
  }

  isSelected(option) {
    if (this.state.allSelected) return true;

    const {value, valueKey} = this.props;
    return findIndex(value, {[valueKey]: option[valueKey]}) !== -1;
  }

  renderOption(option) {
    if (!option.$selectAll) {
      const checkboxProps = {
        label: option[this.props.labelKey],
        checked: this.isSelected(option),
        onChange: noop
      };

      return <Checkbox {...checkboxProps} />;
    }
    const theme = this.props.theme;

    return (
      <div className={this.state.allSelected ? theme.selectAllActive : theme.selectAllInactive}>
        {this.state.allSelected ? 'Deselect all' : 'Select all' }
      </div>
    );
  }

  render() {
    const { labelKey, label, disabled, options, searchable, bsSize, bsStyle, labelClassName, wrapperClassName, parentClassName } = this.props;
    const selectProps = {
      disabled,
      searchable: isUndefined(searchable) ? options.length > 3 : searchable,
      options: this.generateOptionsWithSelectAll(),
      optionRenderer: this.renderOption.bind(this),
      value: this.state.selectValue,
      valueKey: labelKey,
      labelKey,
      onChange: this.onChange.bind(this),
      onOpen: this.props.onOpen,
      onClose: this.props.onClose,
      clearable: false,
      label,
      bsSize,
      bsStyle,
      labelClassName,
      wrapperClassName,
      parentClassName
    };

    return <Select {...selectProps} />;
  }
}

MultiSelect.defaultProps = {
  value: [],
  valueKey: 'value',
  labelKey: 'label',
  shownAm: 2,
  theme: require('./MultiSelect.css')
};

export default MultiSelect;
