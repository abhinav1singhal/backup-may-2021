import React from 'react';
import CSSModules from 'react-css-modules';
import styles from './DataTableOverflowCell.css';

let DataTableOverflowCell = (props) => {
  return (
    <div style={{ width: props.width }}
         title={props.title}
         styleName="root"
         data-test="DataTableOverflowCell__root">
      { props.children }
    </div>
  );
};

DataTableOverflowCell = CSSModules(styles)(DataTableOverflowCell);

DataTableOverflowCell.propTypes = {
  width: React.PropTypes.number.isRequired,
  title: React.PropTypes.string,
  children: React.PropTypes.node.isRequired
};

export default DataTableOverflowCell;
