/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import expect from 'expect';

import DataTableOverflowCell from '../DataTableOverflowCell';

describe('src.OldDataTable.components.DataTableOverflowCell.__tests__.DataTableOverflowCellSpec', () => {

  describe('DataTableOverflowCell', () => {

    it('should render DataTableOverflowCell', () => {

      const component = <DataTableOverflowCell width={100} title={'123 Tooltip'}>{ 123 }</DataTableOverflowCell>;

      const expectedMarkup = `
        <div style="width:100px;" title="123 Tooltip" data-test="DataTableOverflowCell__root" class="DataTableOverflowCell__root">123</div>
      `;

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup.trim());

    });

  });

});
