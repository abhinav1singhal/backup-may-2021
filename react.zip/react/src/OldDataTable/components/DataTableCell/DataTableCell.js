import React from 'react';
import CSSModules from 'react-css-modules';
import styles from './DataTableCell.css';

let DataTableCell = (props) => {
  return (
    <div styleName="root" data-test="DataTableCell__root">
      { props.children }
    </div>
  );
};

DataTableCell = CSSModules(styles)(DataTableCell);

DataTableCell.propTypes = {
  children: React.PropTypes.node.isRequired
};

export default DataTableCell;
