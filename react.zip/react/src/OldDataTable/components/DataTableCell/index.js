export default from './DataTableCell';
