import React, { PropTypes } from 'react';
import CSSModules from 'react-css-modules';
import FixedDataTable2 from '../FixedDataTable2';
const { Table, Column, Cell } = FixedDataTable2;
import classNames from  'classnames';
import DataTableCell from './components/DataTableCell';
import autoWidth from '../decorators/autoWidth';
import { isNumber, isString, floor } from 'lodash';
import styles from './DataTable.css';

export const sortTypes = {
  ASC: 'ASC',
  DESC: 'DESC'
};

const COLUMN_WIDTH_REGEXP = /^(\d+|\d*\.\d+)%?$/;
const DEFAULT_TYPE = 'root';

let DataTable = class extends React.Component {

  static propTypes = {
    /**
     * Defines table data. Must be array of objects
     */
    data: PropTypes.arrayOf(PropTypes.object).isRequired,
    /**
     * Defines width of table
     */
    width: PropTypes.number.isRequired,
    /**
     * Defines height of table
     */
    height: PropTypes.number.isRequired,
    /**
     * Defines column of table. Must be array of objects, where every object
     * contains displaying label and name of field in data
     */
    columns: PropTypes.arrayOf(PropTypes.object).isRequired,
    /**
     * Defines function for render every header cell content. Will receive following arguments:
     * (headerCellProps, headerCellContent)
     */
    headerCell: PropTypes.func,
    /**
     * Defines height of table header. By default value is 50 (px)
     * @defaultValue 50
     */
    headerHeight: PropTypes.number,
    /**
     * Defines height of each row in table. Can be override by rowHeightGetter.
     * By default value is 50 (px)
     * @defaultValue 50
     */
    rowHeight: PropTypes.number,
    /**
     * Defines function for specifying height of data and header row by row index
     */
    rowHeightGetter: PropTypes.func,
    /**
     * Defines function for specifying className of data row by row index. Will receive following arguments:
     * (rowIndex, rowData)
     */
    rowClassNameGetter: PropTypes.func,
    /**
     * Defines function for render every cell content. Will receive following arguments:
     * (cellData, cellDataKey, rowData, cellProps)
     */
    cell: PropTypes.func,
    /**
     * Defines key in which table is sorted
     */
    sortKey: PropTypes.string,
    /**
     * Defines direction of sorting in table (ASC/DESC)
     */
    sortDirection: PropTypes.oneOf(['ASC', 'DESC']),
    /**
     * Defines sort function, which will be called after user click on
     * column header
     */
    onSort: PropTypes.func,
    /**
     * Defines filter for rows filtering
     */
    filterText: PropTypes.string,
    /**
     * Custom filter function that overrides build-in. (data, filterText)
     */
    filterData: PropTypes.func,
    /**
     * Custom sort function that overrides build-in. (data, sortKey, sortDirection)
     */
    sortData: PropTypes.func,
    /**
     * Set DataTable className
     */
    className: PropTypes.string,
    /**
     * Set DataTable type (`root` by default)
     */
    type: PropTypes.oneOf([ 'lined', 'striped', 'bordered', DEFAULT_TYPE ]).isRequired,
    /**
     * CSS theme used for DataTable
     */
    theme: PropTypes.object.isRequired
  };

  constructor(props) {
    super(props);

    this._defaultColumnWidth = null;
  }

  sortRowsBy = (dataKey) => {
    return (e) => {
      e.preventDefault();

      let sortDirection = sortTypes.ASC;
      if (dataKey === this.props.sortKey) {
        if (this.props.sortDirection === sortTypes.ASC) {
          sortDirection = sortTypes.DESC;
        }
      }

      this.props.onSort(
        dataKey,
        sortDirection
      );
    };
  };

  _renderHeaderCell = (headerCellProps) => {
    let headerCellContent = headerCellProps.title;

    if (this.props.onSort) {
      headerCellContent = (
        <a href="#" onClick={this.sortRowsBy(headerCellProps.columnKey)}>
          {headerCellContent}
          {this._renderHeaderCellArrow(headerCellProps.columnKey)}
        </a>
      );
    }

    return (
      <Cell {...headerCellProps}>
        {this.props.headerCell ? this.props.headerCell(headerCellProps, headerCellContent) : headerCellContent}
      </Cell>
    );
  };

  _renderHeaderCellArrow = (columnKey) => {
    if (columnKey === this.props.sortKey) {
      let className = 'arrow';
      if (this.props.sortDirection === sortTypes.DESC) {
        className += ' arrow-inversed';
      }

      return (
        <span className={className}></span>
      );
    }
    return null;
  };

  _renderCell = (cellProps) => {
    const rowData = this.props.data[cellProps.rowIndex];
    const cellData = rowData[cellProps.columnKey];

    return (
      <Cell {...cellProps}>
        { this.props.cell ? this.props.cell(cellData, cellProps.columnKey, rowData, cellProps) :
          <DataTableCell>{ cellData }</DataTableCell> }
      </Cell>
    );
  };

  _getColumns = () => {
    let flexColumnsWidth = this.props.width;
    let flexColumnsCount = this.props.columns.length;

    const columns = this.props.columns.map((column) => {
      const columnWidth = this._prepareColumnWidth(column.width);

      if (columnWidth > 0) {
        flexColumnsCount--;
        flexColumnsWidth -= columnWidth;
      }

      return {...column, width: columnWidth};
    });

    if (flexColumnsWidth > 0 && flexColumnsCount > 0) {
      this._defaultColumnWidth = floor(flexColumnsWidth / flexColumnsCount);
    }

    return columns;
  };

  _prepareColumnWidth = (width) => {
    let columnWidth;

    if (isNumber(width)) {
      columnWidth = width;
    } else if (isString(width) && COLUMN_WIDTH_REGEXP.test(width)) {
      columnWidth = parseFloat(width);

      if (width.endsWith('%')) {
        columnWidth = floor((this.props.width / 100) * columnWidth);
      }
    }

    return columnWidth;
  };

  _rowClassNameGetter = (rowIndex) => {
    return this.props.rowClassNameGetter(rowIndex, this.props.data[rowIndex]);
  };

  render() {
    const tableProps = {
      rowsCount: this.props.data.length,
      width: this.props.width,
      height: this.props.height,
      rowHeight: this.props.rowHeight,
      rowHeightGetter: this.props.rowHeightGetter,
      rowClassNameGetter: this.props.rowClassNameGetter && this._rowClassNameGetter,
      headerHeight: this.props.headerHeight
    };

    const tableColumns = this._getColumns();
    const classes = classNames(
      this.props.className,
      this.props.theme[this.props.type]
    );

    const dataTableProps = {
      'data-test': 'DataTable__root',
      className: classes
    };

    if (this.props.type === DEFAULT_TYPE) {
      dataTableProps.styleName = DEFAULT_TYPE;
    }

    return (
      <div {...dataTableProps} >
        <Table {...tableProps}>
          {
            tableColumns.map((column) => {
              const columnProps = {
                columnKey: column.key,
                header: (headerCellProps) => {
                  headerCellProps.title = column.label;
                  return this._renderHeaderCell(headerCellProps);
                },
                cell: this._renderCell,
                key: column.key,
                width: column.width ? column.width : this._defaultColumnWidth
              };

              return (
                <Column {...columnProps} />
              );
            })
          }
        </Table>
      </div>
    );
  }

};

DataTable = CSSModules(styles)(DataTable);

DataTable = autoWidth(DataTable);

DataTable.defaultProps = {
  rowHeight: 50,
  headerHeight: 50,
  theme: require('./DataTable.css'),
  type: DEFAULT_TYPE
};

export default DataTable;
