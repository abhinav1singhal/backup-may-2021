import DataTable, { sortTypes } from './DataTable';

import mapProps from 'map-props';
import { flowRight, filter, orderBy } from 'lodash';

export const filterData = (data, filterText) => {
  return filter(data, (row) => {
    const val = filterText ? filterText.toLowerCase() : '';
    for (const el in row) {
      if (row.hasOwnProperty(el)) {
        const elem = row[el];
        if (elem && String(elem).toLowerCase().indexOf(val) !== -1) {
          return true;
        }
      }
    }
    return false;
  });
};

export const sortData = (data, sortKey, sortDirection) => {
  return orderBy(
    data,
    (item) => {
      const value = item[sortKey];
      if (typeof value === 'string') {
        return value.toLowerCase();
      }
      return value;
    },
    (sortDirection || '').toLowerCase()
  );
};

const DataTableContainer = mapProps({
  data: (props) => {
    const { data, sortKey, sortDirection, filterText } = props;
    return flowRight(
      (d) => {
        if (typeof props.filterData === 'function') {
          return props.filterData(d, filterText);
        }
        return filterData(d, filterText);
      },
      (d) => {
        if (typeof props.sortData === 'function') {
          return props.sortData(d, sortKey, sortDirection);
        }
        return sortData(d, sortKey, sortDirection);
      }
    )(data);
  }
})(DataTable);

DataTableContainer.sortTypes = sortTypes;

export default DataTableContainer;
