import React from 'react';
import InlineSVG from 'svg-inline-react';
import classNames from 'classnames';

export const types = [
  'accept', 'submit', 'cancel', 'collapse', 'collapseTop', 'expand', 'expandBottom',
  'minus', 'search', 'save', 'plus', 'tableicon', 'autoselect', 'manselect',
  'downloadxls', 'downloadfile', 'play', 'error', 'edit', 'arrow-left', 'arrow-right',
  'back', 'forward', 'erase-borders', 'undo', 'drawing-cell', 'select-content', 'select-active',
  'bin', 'save-section', 'calendar', 'historical-data', 'lock', 'view-less', 'view-more',
  'exchange', 'account-type-date', 'account-type-integer', 'account-type-monetary',
  'account-type-multiplier', 'account-type-percentage', 'account-type-string', 'zoom-in', 'zoom-out',
  'no-document', 'settings', 'double-arrows-left', 'double-arrows-right', 'acc-calendar', 'acc-monetary',
  'acc-mult', 'acc-percantage', 'acc-string', 'acc-unit', 'iap-suggestions', 'text', 'rotate-clockwise',
  'question', 'info', 'comments', 'view', 'merge', 'set-grid', 'merge-columns', 'merge-rows',
  'external-link', 'exit', 'warning',
  'checkbox', 'checkbox-checked', 'checkbox-intermediate'
];

const allSVGIcons = types.reduce((collection, type) => {
  collection[type] = require(`!!svg-inline-loader!./svg/${type}.svg`);
  return collection;
}, {});

class Icon extends React.Component {

  static propTypes = {
    /**
     * Base Component theme
     */
    theme: React.PropTypes.object,

    /**
     * An icon name.
     * @type {string&lt;icon_type&gt;}
     */
    type: React.PropTypes.oneOf(types),

    /**
     * Custom svg icon
     */
    svg: React.PropTypes.any,

    /**
     * Icon color
     */
    color: React.PropTypes.string,

    /**
     * An icon size
     */
    size: React.PropTypes.oneOfType([
      React.PropTypes.string,
      React.PropTypes.number
    ]),

    /**
     * An icon width
     */
    width: React.PropTypes.oneOfType([
      React.PropTypes.string,
      React.PropTypes.number
    ]),

    /**
     * An icon height
     */
    height: React.PropTypes.oneOfType([
      React.PropTypes.string,
      React.PropTypes.number
    ]),

    /**
     * Additional class name
     */
    className: React.PropTypes.string,

    /**
     * Adds 'form-control-feedback' class
     * @private
     */
    formControlFeedback: React.PropTypes.bool
  };

  render() {
    const classes = classNames(this.props.className, this.props.theme.icon, {
      ['form-control-feedback']: this.props.formControlFeedback
    });
    const styles = {
      fill: this.props.color,
      width: this.props.width || this.props.size,
      height: this.props.height || this.props.size
    };

    const svg = this.props.svg || allSVGIcons[this.props.type];

    return (
      <InlineSVG {...this.props}
                 style={styles}
                 className={classes}
                 src={svg}
           />
    );
  }

}

Icon.defaultProps = {
  size: '1em',
  theme: require('./Icon.css')
};

export default Icon;
