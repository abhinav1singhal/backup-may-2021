/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import TestUtils from 'react-addons-test-utils';
import { markup } from '../../../../utils/testUtils';
import expect from 'expect';

import Value from '../Value';

describe('src.Select.components.Value.__tests__.ValueSpec', () => {

  describe('Value', () => {

    it('should render Value', () => {

      const component = (<Value {...{
        option: {
          value: 'USA',
          label: 'United States'
        }
      }} />);

      const expectedMarkup = markup(`
        <div class="Value__valueWrapper">United States</div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should render Value which can be removed - multiselect', () => {

      const component = (<Value {...{
        option: {
          value: 'USA',
          label: 'United States'
        },
        onRemove: () => {},
        optionLabelClick: true
      }} />);

      const expectedMarkup = markup(`
        <div class="Value__item">
          <span class="Value__label">
            <a class="Value__labelLink">
              United States
            </a>
          </span>
          <span class="Value__icon">×</span>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should render disabled Value which can be removed - multiselect', () => {

      const component = (<Value {...{
        option: {
          value: 'USA',
          label: 'United States'
        },
        renderer: (option) => {
          return `${option.value} - ${option.label}`;
        },
        onRemove: () => {},
        disabled: true
      }} />);

      const expectedMarkup = markup(`
        <div class="Value__disabledItem Value__item">
          <span class="Value__disabledLabel Value__label">USA - United States</span>
          <span class="Value__disabledIcon Value__icon">×</span>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should call onRemove callback on click and touchEnd events on close icon', () => {

      const onRemoveHandler = expect.createSpy();

      const component = (<Value {...{
        option: {
          value: 'USA',
          label: 'United States'
        },
        onRemove: onRemoveHandler
      }} />);

      const value = TestUtils.renderIntoDocument(component);
      const valueIcon = TestUtils.findRenderedDOMComponentWithClass(value, 'Value__icon');

      TestUtils.Simulate.click(valueIcon);
      TestUtils.Simulate.mouseDown(valueIcon);
      TestUtils.Simulate.touchEnd(valueIcon);

      expect(onRemoveHandler.calls.length).toEqual(2);

    });

    it('should call onRemove callback if component is disabled', () => {

      const onRemoveHandler = expect.createSpy();

      const component = (<Value {...{
        option: {
          value: 'USA',
          label: 'United States'
        },
        onRemove: onRemoveHandler,
        disabled: true
      }} />);

      const value = TestUtils.renderIntoDocument(component);
      const valueIcon = TestUtils.findRenderedDOMComponentWithClass(value, 'Value__icon');

      TestUtils.Simulate.click(valueIcon);
      TestUtils.Simulate.mouseDown(valueIcon);
      TestUtils.Simulate.touchEnd(valueIcon);

      expect(onRemoveHandler.calls.length).toEqual(0);

    });

  });

});
