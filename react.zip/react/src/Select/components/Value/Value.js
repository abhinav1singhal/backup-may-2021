import React from 'react';
import classes from 'classnames';
import CSSModules from 'react-css-modules';

import styles from './Value.css';

class Value extends React.Component {

  static propTypes = {
    /**
     * disabled prop passed to ReactSelect
     */
    disabled: React.PropTypes.bool,
    /**
     * method to handle click on value label
     */
    onOptionLabelClick: React.PropTypes.func,
    /**
     * method to handle remove of that value
     */
    onRemove: React.PropTypes.func,
    /**
     * option passed to component
     */
    option: React.PropTypes.object.isRequired,
    /**
     * indicates if onOptionLabelClick should be handled
     */
    optionLabelClick: React.PropTypes.bool,
    /**
     * method to render option label passed to ReactSelect
     */
    renderer: React.PropTypes.func,
    /**
     * component height
     */
    height: React.PropTypes.number,

    /**
     className for the value element
     */
    valueClassName: React.PropTypes.string,

    /**
     className for the wrapper value element
     */
    valueWrapperClassName: React.PropTypes.string,
    /**
     Style for the wrapper value element
     */
    style: React.PropTypes.object
  };

  blockEvent = (event) => {
    event.stopPropagation();
  };

  handleOnRemove = (event) => {
    if (!this.props.disabled && this.props.onRemove) {
      this.props.onRemove(event);
    }
  };

  render() {
    let { label } = this.props.option;

    if (this.props.renderer) {
      label = this.props.renderer(this.props.option);
    }

    if (!this.props.onRemove && !this.props.optionLabelClick) {
      const { height } = this.props;
      const wrapperInlineStyle = height ? { lineHeight: `${height}px` } : {};
      const wrapperClasses = classes(this.props.option.className, this.props.valueWrapperClassName);

      return (
        <div
          styleName="valueWrapper"
          style={wrapperInlineStyle}
          className={wrapperClasses}
          title={this.props.option.title}>
          {label}
        </div>
      );
    }

    if (this.props.optionLabelClick) {
      label = (
        <a styleName="labelLink" className={ this.props.option.className}
          onMouseDown={this.blockEvent}
          onTouchEnd={this.props.onOptionLabelClick}
          onClick={this.props.onOptionLabelClick}
          title={this.props.option.title}>
          {label}
        </a>
      );
    }

    const itemClasses = classes({
      item: !this.props.disabled,
      disabledItem: this.props.disabled
    });

    const iconClasses = classes({
      icon: !this.props.disabled,
      disabledIcon: this.props.disabled
    });

    const labelClasses = classes({
      label: !this.props.disabled,
      disabledLabel: this.props.disabled
    });

    const valueClasses = classes(this.props.option.className, this.props.valueClassName);
    const style = {...this.props.option.style, ...this.props.style};

    return (
      <div
        styleName={itemClasses}
        className={valueClasses}
        style={style}
        title={this.props.option.title}>
          <span styleName={labelClasses}>{label}</span>
          <span styleName={iconClasses}
          onMouseDown={this.blockEvent}
          onClick={this.handleOnRemove}
          onTouchEnd={this.handleOnRemove}>&times;</span>
      </div>
    );
  }

}

export default CSSModules(styles)(Value);
