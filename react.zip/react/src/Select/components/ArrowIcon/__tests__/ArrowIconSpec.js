/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import TestUtils from 'react-addons-test-utils';
import expect from 'expect';

import ArrowIcon from '../ArrowIcon';

describe('src.Select.components.ArrowIcon.__tests__.ArrowIconSpec', () => {

  describe('ArrowIcon', () => {

    it('should render basic ArrowIcon', () => {

      const component = <ArrowIcon isOpen={false} isDisabled={false} onMouseDown={() => {}}/>;

      const expectedMarkup = `
        <span class="ArrowIcon__root"><span class="ArrowIcon__arrow"></span></span>
      `;

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup.trim());

    });

    it('should render opened ArrowIcon', () => {
      const component = <ArrowIcon isOpen isDisabled={false} onMouseDown={() => {}}/>;

      const expectedMarkup = `
        <span class="ArrowIcon__root"><span class="ArrowIcon__openedArrow ArrowIcon__arrow"></span></span>
      `;

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup.trim());
    });

    it('should render disabled ArrowIcon', () => {
      const component = <ArrowIcon isOpen={false} isDisabled onMouseDown={() => {}}/>;

      const expectedMarkup = `
        <span class="ArrowIcon__root"><span class="ArrowIcon__disabledArrow ArrowIcon__arrow"></span></span>
      `;

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup.trim());
    });

    it('should call onMouseDown callback on mouseDown event', () => {

      const onMouseDownHandler = expect.createSpy();

      const component = (
        <ArrowIcon isOpen={false} isDisabled={false} onMouseDown={onMouseDownHandler} />
      );
      const arrow = TestUtils.renderIntoDocument(component);
      const arrowRoot = TestUtils.findRenderedDOMComponentWithClass(arrow, 'ArrowIcon__root');

      TestUtils.Simulate.mouseDown(arrowRoot);

      expect(onMouseDownHandler).toHaveBeenCalled();

    });

  });

});
