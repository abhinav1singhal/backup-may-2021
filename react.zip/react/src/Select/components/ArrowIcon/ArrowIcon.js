import React, { PropTypes } from 'react';
import CSSModules from 'react-css-modules';
import classes from 'classnames';
import styles from './ArrowIcon.css';

class ArrowIcon extends React.Component {

  static propTypes = {
    isOpen: PropTypes.bool.isRequired,
    isDisabled: PropTypes.bool.isRequired,
    onMouseDown: PropTypes.func.isRequired,
    classNames: PropTypes.shape({
      wrapper: PropTypes.string,
      icon: PropTypes.string
    }),
    arrowStateStyles: PropTypes.shape({
      default: PropTypes.object,
      opened: PropTypes.object,
      disabled: PropTypes.object
    })
  };

  render() {
    const iconClasses = classes({
      'arrow': !this.props.isDisabled && !this.props.isOpen,
      'openedArrow': this.props.isOpen && !this.props.isDisabled,
      'disabledArrow': this.props.isDisabled && !this.props.isOpen
    });
    let customStyle;
    if (this.props.isOpen) {
      customStyle = this.props.arrowStateStyles.opened;
    } else if (this.props.isDisabled) {
      customStyle = this.props.arrowStateStyles.disabled;
    } else {
      customStyle = this.props.arrowStateStyles.default;
    }

    return (
      <span className={this.props.classNames.wrapper} styleName="root" onMouseDown={this.props.onMouseDown}>
        <span className={this.props.classNames.icon}
          styleName={iconClasses} onMouseDown={this.props.onMouseDown} style={customStyle} />
      </span>
    );
  }

}

ArrowIcon.defaultProps = {
  arrowStateStyles: {default: {}, opened: {}, disabled: {}},
  classNames: {}
};

export default CSSModules(styles)(ArrowIcon);
