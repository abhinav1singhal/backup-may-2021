/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import expect from 'expect';
import { markup } from '../../../../utils/testUtils';

import SingleValue from '../SingleValue';

describe('src.Select.components.SingleValue.__tests__.SingleValueSpec', () => {

  describe('SingleValue', () => {

    it('should render SingleValue with title', () => {

      const component = <SingleValue title="title" placeholder="placeholder" />;

      const expectedMarkup = markup(`
        <div title="title" class="SingleValue__valuePlaceholder SingleValue__placeholder">
          <span>placeholder</span>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should render SingleValue without title', () => {

      const component = <SingleValue placeholder="placeholder" />;

      const expectedMarkup = markup(`
        <div class="SingleValue__placeholder">
          <span>placeholder</span>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

  });

});
