import React, {PropTypes} from 'react';
import classNames from  'classnames';

class SingleValue extends React.Component {

  static propTypes = {
    placeholder: PropTypes.string,
    title: PropTypes.string,
    theme: PropTypes.object.isRequired,
    height: PropTypes.number,
    className: PropTypes.string
  };

  render() {
    const { theme, height, className } = this.props;
    const style = height ? { height, lineHeight: `${height}px` } : {};
    const themePlaceholder = this.props.title ? theme.valuePlaceholder : theme.placeholder;
    const classes = classNames(
      className,
      themePlaceholder
    );

    return (
      <div
        title={this.props.title}
				className={classes}
        style={style}>
        <span>{this.props.placeholder}</span>
      </div>
    );
  }

}

SingleValue.defaultProps = {
  theme: require('./SingleValue.css')
};

export default SingleValue;
