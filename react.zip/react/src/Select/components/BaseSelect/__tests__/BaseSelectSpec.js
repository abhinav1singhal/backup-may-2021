/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import expect from 'expect';
import TestUtils from 'react-addons-test-utils';
import { markup } from '../../../../utils/testUtils';

import BaseSelect from '../BaseSelect';
import Option from '../../Option';
import Value from '../../Value';
import SingleValue from '../../SingleValue';

describe('src.Select.components.BaseSelect.__tests__.BaseSelectSpec', () => {

  describe('BaseSelect', () => {

    const baseProps = {
      valueKey: 'value',
      labelKey: 'label',
      options: [
        { value: 'Russia', label: 'Russia' },
        { value: 'USA', label: 'USA' }
      ],
      values: [],
      inputProps: {},
      optionComponent: Option,
      valueComponent: Value,
      singleValueComponent: SingleValue,
      isOpen: true,
      onFocus: () => {},
      onFocusOption: () => {},
      onBlur: () => {},
      onChange: () => {},
      onInputChange: () => {},
      onOpen: () => {},
      onClose: () => {},
      dropdownWidth: 100
    };

    it('should render BaseSelect', () => {

      const component = (<BaseSelect {...baseProps}/>);

      const expectedMarkup = markup(`
        <div class="form-group">
          <div class="BaseSelect__root">
            <input type="hidden"/>
            <div class="BaseSelect__SelectControl BaseSelect__SelectControl--open BaseSelect__SelectControl--pointer">
              <div title="" class="SingleValue__placeholder">
                <span></span>
              </div>
              <div class="BaseSelect__input" tabindex="0"></div>
              <span class="ArrowIcon__root">
                <span class="ArrowIcon__openedArrow ArrowIcon__arrow"></span>
              </span>
            </div>
            <div style="width:100px;" class="BaseSelect__menuOuter">
              <div class="OptionsMenu__menu">
                <div class="Option__option">Russia</div>
                <div class="Option__option">USA</div>
              </div>
            </div>
          </div>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should render loading BaseSelect', () => {

      const component = (<BaseSelect {...{
        ...baseProps,
        options: [],
        isLoading: true
      }}/>);

      const expectedMarkup = markup(`
        <div class="form-group">
          <div class="BaseSelect__root">
            <input type="hidden"/>
            <div class="BaseSelect__SelectControl BaseSelect__SelectControl--open BaseSelect__SelectControl--pointer">
              <div title="" class="SingleValue__placeholder">
                <span></span>
              </div>
              <div class="BaseSelect__input" tabindex="0"></div>
              <span aria-hidden="true" class="LoadingIndicator__root">
                <span class="LoadingIndicator__icon"></span>
              </span>
              <span class="ArrowIcon__root">
                <span class="ArrowIcon__openedArrow ArrowIcon__arrow"></span>
              </span>
            </div>
            <div style="width:100px;" class="BaseSelect__menuOuter">
              <div class="OptionsMenu__menu">
                <div class="OptionsMenu__textLabel"></div>
              </div>
            </div>
          </div>
        </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should call callback after select option', () => {
      const spy = expect.createSpy();
      const component = TestUtils.renderIntoDocument(<BaseSelect {...{
        ...baseProps,
        onChange: spy
      }}/>);
      const options = TestUtils.scryRenderedDOMComponentsWithClass(
        component,
        'Option__option'
      );
      TestUtils.Simulate.mouseDown(options[0]);
      expect(spy).toHaveBeenCalled();
    });

    it('should call callback after open', () => {
      const spy = expect.createSpy();
      const component = TestUtils.renderIntoDocument(<BaseSelect {...{
        ...baseProps,
        isOpen: false,
        onOpen: spy
      }}/>);
      const arrow = TestUtils.findRenderedDOMComponentWithClass(
       component,
       'ArrowIcon__root'
      );
      TestUtils.Simulate.mouseDown(arrow);
      expect(spy).toHaveBeenCalled();
    });

    it('should call callback after close', () => {
      const spy = expect.createSpy();
      const component = TestUtils.renderIntoDocument(<BaseSelect {...{
        ...baseProps,
        onClose: spy
      }}/>);
      const arrow = TestUtils.findRenderedDOMComponentWithClass(
       component,
       'ArrowIcon__root'
      );
      TestUtils.Simulate.mouseDown(arrow);
      expect(spy).toHaveBeenCalled();
    });

    it('should call callback after onFocus', () => {
      const spy = expect.createSpy();
      const component = TestUtils.renderIntoDocument(<BaseSelect {...{
        ...baseProps,
        onFocus: spy
      }}/>);
      const input = TestUtils.findRenderedDOMComponentWithClass(
        component,
        'BaseSelect__input'
      );
      TestUtils.Simulate.focus(input);
      expect(spy).toHaveBeenCalled();
    });

    it('should call callback after onInputChange', () => {
      const spy = expect.createSpy();
      const component = TestUtils.renderIntoDocument(<BaseSelect {...{
        ...baseProps,
        searchable: true,
        onInputChange: spy
      }}/>);
      const input = TestUtils.scryRenderedDOMComponentsWithTag(
        component,
        'input'
      );
      TestUtils.Simulate.change(input[1]);
      expect(spy).toHaveBeenCalled();
    });

    it('should call callback after onFocusOption', () => {
      const spy = expect.createSpy();
      const component = TestUtils.renderIntoDocument(<BaseSelect {...{
        ...baseProps,
        onFocusOption: spy
      }}/>);
      const options = TestUtils.scryRenderedDOMComponentsWithClass(
        component,
        'Option__option'
      );
      TestUtils.Simulate.mouseEnter(options[0]);
      expect(spy).toHaveBeenCalled();
    });

    it('should call callback after onOptionLabelClick', () => {
      const spy = expect.createSpy();
      const component = TestUtils.renderIntoDocument(<BaseSelect {...{
        ...baseProps,
        multi: true,
        values: [{ value: 'Russia', label: 'Russia' }],
        onOptionLabelClick: spy
      }}/>);
      const label = TestUtils.findRenderedDOMComponentWithClass(
        component,
        'Value__labelLink'
      );
      TestUtils.Simulate.click(label);
      expect(spy).toHaveBeenCalled();
    });

  });

});
