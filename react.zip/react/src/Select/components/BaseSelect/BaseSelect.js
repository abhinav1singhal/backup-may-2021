/* eslint-disable react/prefer-es6-class, react/no-set-state, react/no-did-update-set-state */

import React, { PropTypes } from 'react';
import { findDOMNode } from 'react-dom';
import Input from 'react-input-autosize';
import classNames from 'classnames';
import Value from '../Value';
import OptionsMenu from '../OptionsMenu';
import LoadingIndicator from '../LoadingIndicator';
import ClearIcon from '../../../sharedComponents/ClearIcon';
import ArrowIcon from '../ArrowIcon';
import defaultTheme from './BaseSelect.css';

const BaseSelect = React.createClass({

  getInitialState() {
    return {
      menuOuterStyle: {
        top: 'auto',
        left: 'auto'
      },
      inputStyle: {
        maxWidth: 'initial'
      },
      collapsed: [],
      hidden: []
    };
  },

  displayName: 'BaseSelect',

  propTypes: {
    bsStyle: PropTypes.oneOf([
      'success',
      'warning',
      'error'
    ]),
    backspaceRemoves: PropTypes.bool,
    wrapperClassName: PropTypes.string,
    clearAllText: PropTypes.string,
    clearValueText: PropTypes.string,
    clearable: PropTypes.bool,
    disabled: PropTypes.bool,
    inputProps: PropTypes.object.isRequired,
    isLoading: PropTypes.bool,
    labelKey: PropTypes.string.isRequired,
    multi: PropTypes.bool,
    noResultsText: PropTypes.string,
    onOptionLabelClick: PropTypes.func,
    optionComponent: PropTypes.func.isRequired,
    optionRenderer: PropTypes.func,
    options: PropTypes.array,
    placeholder: PropTypes.string,
    searchable: PropTypes.bool,
    searchPromptText: PropTypes.string,
    searchingText: PropTypes.string,
    singleValueComponent: PropTypes.func.isRequired,
    label: PropTypes.node,
    labelClassName: PropTypes.string,
    value: PropTypes.any,
    values: PropTypes.array.isRequired,
    name: PropTypes.string,
    inputValue: PropTypes.string,
    tabIndex: PropTypes.number,
    valueComponent: PropTypes.func.isRequired,
    valueKey: PropTypes.string.isRequired,
    valueRenderer: PropTypes.func,
    valueClassName: PropTypes.string,
    valueStyle: PropTypes.object,
    valueWrapperClassName: PropTypes.string,
    isFocused: PropTypes.bool,
    isOpen: PropTypes.bool,
    focusedOption: PropTypes.any,
    onFocus: PropTypes.func.isRequired,
    onBlur: PropTypes.func.isRequired,
    onChange: PropTypes.func.isRequired,
    onInputChange: PropTypes.func,
    onOpen: PropTypes.func.isRequired,
    onClose: PropTypes.func.isRequired,
    onFocusOption: PropTypes.func.isRequired,
    expandable: PropTypes.bool,
    dropdownFixed: PropTypes.bool,
    dropdownWidth: PropTypes.oneOfType([
      PropTypes.string,
      PropTypes.number
    ]),
    theme: PropTypes.oneOf([
      'default',
      'noBorder'
    ]),
    maxHeight: PropTypes.number,
    optionsMenuStyle: PropTypes.object,
    optionsMenuClassName: PropTypes.string,
    optionsMenuTitle: PropTypes.string,
    arrowStateStyles: PropTypes.shape({
      default: PropTypes.object,
      opened: PropTypes.object,
      disabled: PropTypes.object
    }),
    menuOrientationAuto: PropTypes.bool,
    parentClassName: PropTypes.string,

    customTheme: PropTypes.shape({
      root: PropTypes.string,
      input: PropTypes.string,
      searchInput: PropTypes.string,
      clearIcon: PropTypes.string,
      arrowIcon: PropTypes.shape({
        wrapper: PropTypes.string,
        icon: PropTypes.string
      }),
      selectControl: PropTypes.string,
      label: PropTypes.string,
      optionMenuWrapper: PropTypes.string,

      option: PropTypes.object,
      optionMenu: PropTypes.object
    })
  },

  getDefaultProps: () => {
    return {
      disabled: false,
      isOpen: false,
      isFocused: false,
      isLoading: false,
      customTheme: {}
    };
  },

  componentDidMount() {
    this.setInputStyle();
    window.addEventListener('resize', this.setInputStyle);
  },

  componentDidUpdate() {
    if (!this.props.disabled && this._focusAfterUpdate) {
      clearTimeout(this._blurTimeout);
      clearTimeout(this._focusTimeout);
      this._focusTimeout = setTimeout(() => {
        if (!this.isMounted()) return;
        this.focus();
        this._focusAfterUpdate = false;
      }, 50);
    }
    if (this._focusedOptionReveal) {
      if (this.refs.menu.refs.focused && this.refs.menu) {
        const focusedDOM = findDOMNode(this.refs.menu.refs.focused);
        const menuDOM = findDOMNode(this.refs.menu);
        const focusedRect = focusedDOM.getBoundingClientRect();
        const menuRect = menuDOM.getBoundingClientRect();

        if (focusedRect.bottom > menuRect.bottom || focusedRect.top < menuRect.top) {
          menuDOM.scrollTop = (focusedDOM.offsetTop + focusedDOM.clientHeight - menuDOM.offsetHeight);
        }
      }
      this._focusedOptionReveal = false;
    }

    if (this.props.dropdownFixed && this.props.menuOrientationAuto) {
      if (this.props.isOpen && !this._menuPositionDefined) {
        const wrapper = findDOMNode(this.refs.wrapper);
        const menu = findDOMNode(this.refs.selectMenuContainer);
        const {top, left, right} = wrapper.getBoundingClientRect();
        const menuHeight = menu.offsetHeight;
        const dropdownWidth = this.props.dropdownWidth || wrapper.offsetWidth;
        const width = window.innerWidth;
        const leftPoint = (left + dropdownWidth) > width ? right - dropdownWidth : left;
        const menuBottomPoint = top + wrapper.offsetHeight + menuHeight;
        this._menuOrientationTop = this._menuOrientationTop || menuBottomPoint > window.innerHeight;
        if (this._menuOrientationTop) {
          this.setState({
            menuOuterStyle: {
              left: leftPoint,
              top: top - menuHeight,
              width: dropdownWidth
            }
          });
        } else {
          this.setState({
            menuOuterStyle: {
              left: leftPoint,
              top: top + wrapper.offsetHeight,
              width: dropdownWidth
            }
          });
        }
        this._menuPositionDefined = true;
      }
    }
  },

  componentWillUnmount() {
    clearTimeout(this._blurTimeout);
    clearTimeout(this._focusTimeout);
    window.removeEventListener('resize', this.setInputStyle);
  },

  onCollapse(collapsed, hidden) {
    this.setState({ collapsed, hidden });
  },

  getValueOptions(val) {
    return {
      label: val ? val[this.props.labelKey] : '',
      title: val ? val[this.props.valueKey] : '',
      item: val ? val : {}
    };
  },

  blur() {
    const input = this.refs.input;
    input.blur();
  },

  focus() {
    const input = this.refs.input;
    input.focus();
  },

  open() {
    this.props.onOpen();
    this._menuPositionDefined = this._menuOrientationTop = false;
  },

  close() {
    this.props.onClose();
  },

  clickedOutsideElement(element, event) {
    let eventTarget = (event.target) ? event.target : event.srcElement;
    while (eventTarget != null) { // eslint-disable-line
      if (eventTarget === element) return false;
      eventTarget = eventTarget.offsetParent;
    }
    return true;
  },

  setValue(value, focusAfterUpdate, event) {
    if (focusAfterUpdate || focusAfterUpdate === undefined) {
      this._focusAfterUpdate = true;
    }
    this.props.onChange(value, event);
  },

  selectValue(value, event) {
    if (!this.props.multi) {
      this.setValue(value, undefined, event);
    } else if (value) {
      this.addValue(value, event);
    }
    this.unfocusOption(value);
  },

  addValue(value) {
    this.setValue(this.props.values.concat(value), undefined, event);
  },

  popValue() {
    if (this.props.values) {
      this.setValue(this.props.values.slice(0, this.props.values.length - 1));
    }
  },

  removeValue(valueToRemove) {
    this.setValue(this.props.values.filter((value) => {
      return value !== valueToRemove;
    }));
  },

  clearValue(event) {
    // if the event was triggered by a mousedown and not the primary
    // button, ignore it.
    if (event && event.type === 'mousedown' && event.button !== 0) {
      return;
    }
    event.stopPropagation();
    event.preventDefault();
    this.setValue(null);
  },

  resetValue() {
    let value = null;
    if (this.props.value !== '') {
      value = this.props.multi ? this.props.values : this.props.values[0];
    }
    this.setValue(value);
  },

  handleMouseDown(event) {
    // if the event was triggered by a mousedown and not the primary
    // button, or if the component is disabled, ignore it.
    if (this.props.disabled || (event.type === 'mousedown' && event.button !== 0)) {
      return;
    }
    event.stopPropagation();
    event.preventDefault();

    // for the non-searchable select, close the dropdown when button is clicked
    if (this.props.isOpen && !this.props.searchable) {
      this.close();
      return;
    }

    this.open();

    if (!this.props.isFocused) {
      this.focus();
    }

    if (this.props.dropdownFixed) {
      const wrapper = findDOMNode(this);
      const {top, left} = wrapper.getBoundingClientRect();
      const wrapperHeight = wrapper.offsetHeight;
      const dropdownWidth = this.props.dropdownWidth || wrapper.offsetWidth;
      this.setState({menuOuterStyle: {
        left,
        top: top + wrapperHeight,
        width: dropdownWidth
      }});
    }
  },

  handleMouseDownOnMenu(event) {
    // if the event was triggered by a mousedown and not the primary
    // button, or if the component is disabled, ignore it.
    if (this.props.disabled || (event.type === 'mousedown' && event.button !== 0)) {
      return;
    }
    this._focusAfterUpdate = true;
    event.stopPropagation();
    event.preventDefault();
  },

  handleMouseDownOnArrow(event) {
    // if the event was triggered by a mousedown and not the primary
    // button, or if the component is disabled, ignore it.
    if (this.props.disabled || (event.type === 'mousedown' && event.button !== 0)) {
      return;
    }
    // If not focused, handleMouseDown will handle it
    if (!this.props.isOpen) {
      return;
    }
    event.stopPropagation();
    event.preventDefault();
    this.close();
  },

  handleInputFocus(event) {
    this.props.onFocus(event);
  },

  handleInputBlur(event) {
    this._blurTimeout = setTimeout(() => {
      if (this._focusAfterUpdate || !this.isMounted()) return;
      this.props.onBlur(event);
    }, 50);
  },

  handleKeyDown(event) {
    if (this.props.disabled) return;
    switch (event.keyCode) {
      case 8: // backspace
        if (!this.props.inputValue && this.props.backspaceRemoves) {
          event.preventDefault();
          this.popValue();
        }
        return;
      case 9: // tab
        if (event.shiftKey || !this.props.isOpen || !this.props.focusedOption) {
          return;
        }
        this.selectFocusedOption();
        break;
      case 13: // enter
        if (!this.props.isOpen) return;
        this.selectFocusedOption();
        break;
      case 27: // escape

        if (this.props.isOpen) {
          this.resetValue();
        } else if (this.props.clearable) {
          this.clearValue(event);
        }
        break;
      case 38: // up
        this.focusPreviousOption();
        break;
      case 40: // down
        this.focusNextOption();
        break;
      default: return;
    }
    event.preventDefault();
  },

  handleInputChange(event) {
    const inputValue = event.target.value;
    this._menuPositionDefined = false;
    this.props.onInputChange(inputValue);
  },

  selectFocusedOption() {
    if (this.props.focusedOption) {
      return this.selectValue(this.props.focusedOption);
    }
    return null;
  },

  focusOption(op) {
    this.props.onFocusOption(op);
  },

  focusNextOption() {
    this.focusAdjacentOption('next');
  },

  focusPreviousOption() {
    this.focusAdjacentOption('previous');
  },

  focusAdjacentOption(dir) {
    this._focusedOptionReveal = true;
    const ops = this.props.options.filter((op) => {
      return !op.disabled;
    });
    if (!this.props.isOpen) {
      this.props.onFocusOption(
        this.props.focusedOption || ops[dir === 'next' ? 0 : ops.length - 1],
        true
      );
      return;
    }
    if (!ops.length) {
      return;
    }
    let focusedIndex = -1;
    for (let i = 0; i < ops.length; i++) {
      if (this.props.focusedOption === ops[i]) {
        focusedIndex = i;
        break;
      }
    }
    let focusedOption = ops[0];
    if (dir === 'next' && focusedIndex > -1 && focusedIndex < ops.length - 1) {
      focusedOption = ops[focusedIndex + 1];
    } else if (dir === 'previous') {
      if (focusedIndex > 0) {
        focusedOption = ops[focusedIndex - 1];
      } else {
        focusedOption = ops[ops.length - 1];
      }
    }
    this.props.onFocusOption(focusedOption);
  },

  unfocusOption(op) {
    if (this.props.focusedOption === op) {
      this.props.onFocusOption(null);
    }
  },

  handleOptionLabelClick(value, event) {
    if (this.props.onOptionLabelClick) {
      this.props.onOptionLabelClick(value, event);
    }
  },

  setInputStyle() {
    this.setState({
      inputStyle: {
        maxWidth: this.refs.wrapper.offsetWidth - findDOMNode(this.refs.arrowIcon).offsetWidth - 10
      }
    });
  },

  renderMenu() {

    let focusedValue = this.props.focusedOption ? this.props.focusedOption[this.props.valueKey] : null;
    if (this.props.options.length > 0) {
      focusedValue = focusedValue === null ? this.props.options[0] : focusedValue;
    }

    let renderLabel = this.props.optionRenderer;
    if (!renderLabel) {
      renderLabel = (op) => op[this.props.labelKey];
    }

    const optionsMenuProps = {
      options: this.props.options,
      optionComponent: this.props.optionComponent,
      focusedValue,
      value: this.props.value,
      valueKey: this.props.valueKey,
      inputValue: this.props.inputValue,
      renderLabel,
      isLoading: this.props.isLoading,
      expandable: this.props.expandable,
      searchingText: this.props.searchingText,
      noResultsText: this.props.noResultsText,
      searchPromptText: this.props.searchPromptText,
      title: this.props.optionsMenuTitle,
      onMouseEnter: this.focusOption,
      onMouseLeave: this.unfocusOption,
      onMouseDown: this.selectValue,
      onMenuMouseDown: this.handleMouseDownOnMenu,
      onCollapse: this.onCollapse,
      hiddenOptions: this.state.hidden,
      collapsedOptions: this.state.collapsed,
      theme: this.props.customTheme.optionMenu,
      optionTheme: this.props.customTheme.option
    };

    const { dropdownWidth, dropdownFixed } = this.props;
    const { menuOuterStyle } = this.state;

    const className = dropdownFixed ? defaultTheme.menuOuterFixed : defaultTheme.menuOuter;
    let style = dropdownFixed ? menuOuterStyle : {width: dropdownWidth};
    style = Object.assign(style, this.props.optionsMenuStyle);

    return (

      <div ref="selectMenuContainer"
           style={style}
           className={classNames(className, this.props.optionsMenuClassName)}>
        <OptionsMenu ref="menu" {...optionsMenuProps} />
      </div>
    );
  },

  renderClearButton() {
    return (
      <ClearIcon
          title={this.props.multi ? this.props.clearAllText : this.props.clearValueText}
          className={this.props.customTheme.clearIcon}
          onClick={this.clearValue} />
    );
  },

  renderArrow() {
    return (
      <ArrowIcon
        classNames={this.props.customTheme.arrowIcon}
        onMouseDown={this.handleMouseDownOnArrow}
        isOpen={this.props.isOpen}
        isDisabled={this.props.disabled}
        arrowStateStyles={this.props.arrowStateStyles}
        ref="arrowIcon" />
    );
  },

  renderInput() {
    let input;

    const className = classNames(
      defaultTheme.input,
      this.props.customTheme.input,
      {
        [defaultTheme['SelectInput--multi']]: this.props.multi && this.props.value,
        [defaultTheme['SelectInput--multi--empty']]: this.props.multi && !this.props.value
      }
    );

    const style = this.props.maxHeight ? { height: this.props.maxHeight } : {};

    const inputProps = {
      ref: 'input',
      className: classNames(className, this.props.inputProps.className),
      tabIndex: this.props.tabIndex || 0,
      onFocus: this.handleInputFocus,
      onBlur: this.handleInputBlur,
      style
    };
    for (const key in this.props.inputProps) {
      if (this.props.inputProps.hasOwnProperty(key) && key !== 'className') {
        inputProps[key] = this.props.inputProps[key];
      }
    }

    if (!this.props.disabled) {
      if (this.props.searchable) {
        input = (
          <Input value={this.props.inputValue}
                onChange={this.handleInputChange}
                minWidth="5" {...inputProps}
                inputClassName={classNames(defaultTheme.searchInput, this.props.customTheme.searchInput)}
                inputStyle={this.state.inputStyle}
                style={style}
          />
        );
      } else {
        input = <div {...inputProps}></div>;
      }
    } else if (!this.props.multi || !this.props.values.length) {
      input = <div className={className} style={style}></div>;
    }

    return input;
  },

  renderValue() {
    const value = [];
    const valueClasses = classNames(this.props.valueClassName);
    const valueWrapperClasses = classNames(this.props.valueWrapperClassName);

    if (this.props.multi) {
      this.props.values.forEach((val) => {
        const onOptionLabelClick = this.handleOptionLabelClick.bind(this, val);
        const onRemove = this.removeValue.bind(this, val);
        const option = this.getValueOptions(val);
        const valueComponent = React.createElement(this.props.valueComponent, {
          key: val[this.props.valueKey],
          option,
          renderer: this.props.valueRenderer,
          optionLabelClick: !!this.props.onOptionLabelClick,
          onOptionLabelClick,
          onRemove,
          disabled: this.props.disabled,
          className: valueClasses,
          style: this.props.valueStyle,
          valueWrapperClassName: valueWrapperClasses
        });
        value.push(valueComponent);
      }, this);
    }

    if (!this.props.inputValue && (!this.props.multi || !value.length)) {
      const val = this.props.values[0] || null;
      if (this.props.valueRenderer && !!this.props.values.length) {
        const option = this.getValueOptions(val);
        value.push(<Value
            className={valueClasses}
            style={this.props.valueStyle}
            valueWrapperClassName={valueWrapperClasses}
            key={0}
            option={option}
            renderer={this.props.valueRenderer}
            disabled={this.props.disabled}
            height={this.props.maxHeight} />);
      } else {
        const singleValueComponent = React.createElement(this.props.singleValueComponent, {
          key: 'placeholder',
          title: val ? val[this.props.valueKey] : '',
          placeholder: val ? val[this.props.valueKey] : this.props.placeholder,
          height: this.props.maxHeight,
          className: valueClasses,
          style: this.props.valueStyle,
          valueWrapperClassName: valueWrapperClasses
        });
        value.push(singleValueComponent);
      }
    }

    return value;
  },

  renderLabel() {
    const labelClasses = classNames(
      this.props.customTheme.label,
      {
        'control-label': true,
        [this.props.labelClassName]: !!this.props.labelClassName
      }
    );
    return (
      <label className={labelClasses}>{ this.props.label }</label>
    );
  },

  render() {
    const loading = this.props.isLoading;
    const clearable = this.props.clearable && this.props.value && !this.props.disabled && !(loading);
    const isSuccess = this.props.bsStyle === 'success';
    const isWarning = this.props.bsStyle === 'warning';
    const isError = this.props.bsStyle === 'error';
    const isNoBorder = this.props.theme === 'noBorder';
    const isCursorPointer = !this.props.isFocused && !this.props.value;

    const wrapperClass = classNames(
      this.props.parentClassName,
      {
        'form-group': true,
        'has-success': isSuccess,
        'has-warning': isWarning,
        'has-error': isError
      });

    const selectControlClass = classNames(
      defaultTheme.SelectControl,
      this.props.customTheme.selectControl,
      this.props.valueWrapperClassName,
      {
        [defaultTheme['SelectControl--open']]: this.props.isOpen,
        [defaultTheme['SelectControl--focused']]: this.props.isFocused,
        [defaultTheme['SelectControl--searchable']]: this.props.searchable,
        [defaultTheme['SelectControl--disabled']]: this.props.disabled,
        [defaultTheme['SelectControl--pointer']]: isCursorPointer,
        [defaultTheme['SelectControl--noBorder']]: isNoBorder
      }
    );

    const selectControlInlineStyle = this.props.maxHeight ? { height: this.props.maxHeight} : {};

    return (
      <div className={wrapperClass}>
        { this.props.label ? this.renderLabel() : null }
        <div ref="wrapper" className={classNames(defaultTheme.root, this.props.customTheme.root, this.props.wrapperClassName)}>
          <input type="hidden" ref="value"
            name={this.props.name} value={this.props.value}
            disabled={this.props.disabled} />
          <div style={selectControlInlineStyle}
            ref="control"
            onKeyDown={this.handleKeyDown}
            onMouseDown={this.handleMouseDown}
            onTouchEnd={this.handleMouseDown}
            className={selectControlClass}>
              { this.renderValue() }
              { this.renderInput() }
              { loading ? <LoadingIndicator /> : null }
              { clearable ? this.renderClearButton() : null }
              { this.renderArrow() }
          </div>
          { this.props.isOpen ? this.renderMenu() : null }
        </div>
      </div>
    );
  }

});

export default BaseSelect;
