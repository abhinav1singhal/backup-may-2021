import React from 'react';
import CSSModules from 'react-css-modules';
import styles from './LoadingIndicator.css';

class LoadingIndicator extends React.Component {

  render() {
    return (
      <span styleName="root" aria-hidden="true">
        <span styleName="icon" />
      </span>
    );
  }

}

export default CSSModules(styles)(LoadingIndicator);
