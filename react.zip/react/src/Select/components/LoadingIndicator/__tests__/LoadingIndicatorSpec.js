/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import expect from 'expect';
import { markup } from '../../../../utils/testUtils';

import LoadingIndicator from '../LoadingIndicator';

describe('src.Select.components.LoadingIndicator.__tests__.LoadingIndicatorSpec', () => {

  describe('LoadingIndicator', () => {

    it('should render LoadingIndicator', () => {

      const component = <LoadingIndicator />;

      const expectedMarkup = markup(`
        <span aria-hidden="true" class="LoadingIndicator__root">
          <span class="LoadingIndicator__icon"></span>
        </span>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

  });

});
