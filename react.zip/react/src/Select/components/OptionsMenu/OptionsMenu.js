import React, { PropTypes } from 'react';
import { map, findIndex, takeWhile } from 'lodash';
import defaultTheme from './OptionsMenu.css';
import classNames from 'classnames';

class OptionsMenu extends React.Component {

  static propTypes = {
    options: PropTypes.array.isRequired,
    optionComponent: PropTypes.func.isRequired,
    renderLabel: PropTypes.func.isRequired,
    valueKey: PropTypes.string.isRequired,
    isLoading: PropTypes.bool.isRequired,
    expandable: PropTypes.bool,
    onMenuMouseDown: PropTypes.func.isRequired,
    onMouseEnter: PropTypes.func.isRequired,
    onMouseLeave: PropTypes.func.isRequired,
    onMouseDown: PropTypes.func.isRequired,
    focusedValue: PropTypes.any,
    value: PropTypes.string,
    inputValue: PropTypes.string,
    searchingText: PropTypes.string,
    noResultsText: PropTypes.string,
    searchPromptText: PropTypes.string,
    title: PropTypes.string,

    theme: PropTypes.shape({
      menu: PropTypes.string,
      menuTitle: PropTypes.string,
      textLabel: PropTypes.string
    }),
    optionTheme: PropTypes.object,
    hiddenOptions: PropTypes.array,
    collapsedOptions: PropTypes.array,
    onCollapse: PropTypes.func
  };

  onCollapse = (option, expand) => {
    const { collapsedOptions, hiddenOptions, valueKey } = this.props;
    const value = option[valueKey];
    let collapsed;
    let hidden;
    const relatedSections = this.getAllSubsections(value);

    if (expand) {
      collapsed = collapsedOptions.filter((item) => item !== value);
      hidden = hiddenOptions.filter((item) => !~relatedSections.indexOf(item));
    } else {
      collapsed = [...collapsedOptions, value];
      hidden = [...hiddenOptions, ...relatedSections];
    }
    this.props.onCollapse(collapsed, hidden);
  }

  getAllSubsections(key) {
    const index = findIndex(this.props.options, [this.props.valueKey, key]);
    const subsections = takeWhile(this.props.options.slice(index + 1), ['isSubsection', true]);
    return map(subsections, this.props.valueKey);
  }

  renderItems() {
    const { focusedValue, options, renderLabel, collapsedOptions, hiddenOptions, expandable } = this.props;

    return map(options, (item) => {
      const value = item[this.props.valueKey];
      const isSelected = this.props.value === value;
      const isFocused = focusedValue === value;
      const ref = isFocused ? 'focused' : null;

      const optionProps = {
        key: `option-${value}`,
        isSelected,
        isFocused,
        isDisabled: item.disabled || false,
        renderFunc: renderLabel,
        mouseEnter: () => {
          this.props.onMouseEnter(item);
        },
        mouseLeave: () => {
          this.props.onMouseLeave(item);
        },
        mouseDown: (event) => {
          this.props.onMouseDown(item, event);
        },
        option: item,
        className: classNames({ [defaultTheme.secondLevel]: item.isSubsection, [defaultTheme.expandable]: expandable }),
        theme: this.props.optionTheme,
        ref
      };

      if (expandable) {
        optionProps.collapsed = !!~collapsedOptions.indexOf(value);
        optionProps.hidden = !!~hiddenOptions.indexOf(value);
        optionProps.hasChilds = !!this.getAllSubsections(value).length;
        optionProps.onCollapse = this.onCollapse;
        optionProps.expandable = expandable;
      }

      return React.createElement(this.props.optionComponent, optionProps);
    });
  }

  renderInfo() {
    let noResultsText;
    if (this.props.isLoading) {
      noResultsText = this.props.searchingText;
    } else if (this.props.inputValue) {
      noResultsText = this.props.noResultsText;
    } else {
      noResultsText = this.props.searchPromptText;
    }

    return (
      <div className={classNames(defaultTheme.textLabel, this.props.theme.textLabel)}>
        {noResultsText}
      </div>
    );
  }

  renderTitle() {
    if (this.props.title) {
      return (<div className={classNames(defaultTheme.menuTitle, this.props.theme.menuTitle)}>{this.props.title}</div>);
    }
    return null;
  }

  render() {
    return (
      <div ref="optionMenu" className={classNames(defaultTheme.menu, this.props.theme.menu)} onMouseDown={(event) => this.props.onMenuMouseDown(event)}>
        { this.renderTitle() }
        { this.props.options.length ? this.renderItems() : this.renderInfo() }
      </div>
    );
  }
}

OptionsMenu.defaultProps = {
  theme: {}
};

export default OptionsMenu;
