/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import expect from 'expect';
import { markup } from '../../../../utils/testUtils';

import Option from '../../Option';
import OptionsMenu from '../OptionsMenu';

describe('src.Select.components.OptionsMenu.__tests__.OptionsMenuSpec', () => {

  describe('OptionsMenu', () => {

    it('should render OptionsMenu', () => {

      const component = (<OptionsMenu {...{
        options: [
          { value: 'Russia', label: 'Russia' },
          { value: 'USA', label: 'USA' }
        ],
        valueKey: 'value',
        optionComponent: Option,
        renderLabel: (option) => option.label,
        isLoading: false,
        onMouseEnter: () => {},
        onMouseDown: () => {},
        onMouseLeave: () => {},
        onMenuMouseDown: () => {}
      }}/>);

      const expectedMarkup = markup(`
          <div class="OptionsMenu__menu">
            <div class="Option__option">Russia</div>
            <div class="Option__option">USA</div>
          </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should render OptionsMenu with focused option', () => {

      const component = (<OptionsMenu {...{
        options: [
          { value: 'Russia', label: 'Russia' },
          { value: 'USA', label: 'USA' }
        ],
        valueKey: 'value',
        optionComponent: Option,
        renderLabel: (option) => option.label,
        isLoading: false,
        onMouseEnter: () => {},
        onMouseDown: () => {},
        onMouseLeave: () => {},
        onMenuMouseDown: () => {},
        focusedValue: 'Russia'
      }}/>);

      const expectedMarkup = markup(`
          <div class="OptionsMenu__menu">
            <div class="Option__option Option__focusedOption">Russia</div>
            <div class="Option__option">USA</div>
          </div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    describe('options are empty', () => {

      it('should show searchingText if isLoading is true', () => {

        const component = (<OptionsMenu {...{
          options: [],
          searchingText: 'Loading...',
          valueKey: 'value',
          optionComponent: Option,
          renderLabel: (option) => option.label,
          isLoading: true,
          onMouseEnter: () => {},
          onMouseDown: () => {},
          onMouseLeave: () => {},
          onMenuMouseDown: () => {}
        }}/>);

        const expectedMarkup = markup(`
            <div class="OptionsMenu__menu">
              <div class="OptionsMenu__textLabel">Loading...</div>
            </div>
        `);

        expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

      });

      it('should show noResultsText if isLoading is false and inputValue is not null', () => {

        const component = (<OptionsMenu {...{
          options: [],
          searchingText: 'Loading...',
          valueKey: 'value',
          noResultsText: 'Nothing has been found =(',
          inputValue: 'something',
          optionComponent: Option,
          renderLabel: (option) => option.label,
          isLoading: false,
          onMouseEnter: () => {},
          onMouseDown: () => {},
          onMouseLeave: () => {},
          onMenuMouseDown: () => {}
        }}/>);

        const expectedMarkup = markup(`
            <div class="OptionsMenu__menu">
              <div class="OptionsMenu__textLabel">Nothing has been found =(</div>
            </div>
        `);

        expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

      });

      it('should show searchPromptText if isLoading is false and inputValue is null', () => {

        const component = (<OptionsMenu {...{
          options: [],
          searchingText: 'Loading...',
          valueKey: 'value',
          searchPromptText: 'Type to search...',
          optionComponent: Option,
          renderLabel: (option) => option.label,
          isLoading: false,
          onMouseEnter: () => {},
          onMouseDown: () => {},
          onMouseLeave: () => {},
          onMenuMouseDown: () => {}
        }}/>);

        const expectedMarkup = markup(`
            <div class="OptionsMenu__menu">
              <div class="OptionsMenu__textLabel">Type to search...</div>
            </div>
        `);

        expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

      });

    });

  });

});
