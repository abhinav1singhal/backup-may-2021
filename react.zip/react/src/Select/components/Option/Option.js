import React from 'react';
import classNames from 'classnames';
import { noop } from 'lodash';
import Icon from '../../../Icon';
import defaultTheme from './Option.css';

class Option extends React.Component {

  static propTypes = {
    /*
      className (based on mouse position)
     */
    className: React.PropTypes.string,
    /*
      method to handle click on option element
     */
    mouseDown: React.PropTypes.func,
    /*
      method to handle mouseEnter on option
     */
    mouseEnter: React.PropTypes.func,
    /*
      method to handle mouseLeave on option
     */
    mouseLeave: React.PropTypes.func,
    /*
      object that is base for that option
     */
    option: React.PropTypes.object.isRequired,
    /*
      method passed to ReactSelect component to render label text
     */
    renderFunc: React.PropTypes.func.isRequired,
    isDisabled: React.PropTypes.bool.isRequired,
    isFocused: React.PropTypes.bool.isRequired,
    hasChilds: React.PropTypes.bool,
    expandable: React.PropTypes.bool,
    hidden: React.PropTypes.bool,
    collapsed: React.PropTypes.bool,
    onCollapse: React.PropTypes.func,

    theme: React.PropTypes.shape({
      root: React.PropTypes.string
    })
  };

  onCollapse = () => {
    const { option, collapsed } = this.props;
    this.props.onCollapse(option, collapsed);
  }

  blockEvent(event) {
    event.preventDefault();
    return false;
  }

  renderOptionElement(optionClasses, obj, renderedLabel) {
    return (
      <div className={optionClasses}
           style={obj.style}
           onMouseEnter={this.props.mouseEnter}
           onMouseLeave={this.props.mouseLeave}
           onMouseDown={this.props.mouseDown}
           title={obj.title}>
        { renderedLabel }
      </div>
    );
  }

  render() {
    const { collapsed, hasChilds, renderFunc, hidden, isFocused, isDisabled, expandable } = this.props;

    if (hidden) {
      return null;
    }

    const obj = this.props.option;
    const renderedLabel = renderFunc(obj);
    const optionClasses = classNames(
      defaultTheme.option,
      obj.className,
      this.props.theme.root,
      this.props.className,
      {
        [defaultTheme.disabledOption]: isDisabled && !isFocused,
        [defaultTheme.focusedOption]: isFocused && !isDisabled
      }
    );
    const collapseHandler = hasChilds ? this.onCollapse : noop;

    if (isDisabled) {
      return (
        <div className={optionClasses}
             onMouseDown={this.blockEvent}
             onClick={this.blockEvent}>
          {renderedLabel}
        </div>
      );
    }

    const optionElement = this.renderOptionElement(optionClasses, obj, renderedLabel);

    return expandable ? (
      <div className={defaultTheme.wrapper}>
        { !obj.isSubsection &&
        <div className={defaultTheme.collapse} onClick={collapseHandler}>
          { hasChilds &&
          <Icon type={collapsed ? 'zoom-in' : 'zoom-out'} size="10" />
          }
        </div>
        }
        { optionElement }
      </div>
    ) : optionElement;
  }

}

Option.defaultProps = {
  theme: {}
};

export default Option;
