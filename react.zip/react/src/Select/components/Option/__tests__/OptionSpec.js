/* global describe, it, beforeEach, afterEach, sinon */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { findDOMNode } from 'react-dom';
import TestUtils from 'react-addons-test-utils';
import expect from 'expect';
import { markup } from '../../../../utils/testUtils';

import Option from '../Option';

describe('src.Select.components.Option.__tests__.OptionSpec', () => {

  describe('Option', () => {

    it('should render Option', () => {

      const component = (<Option {...{
        renderFunc: (option) => option.label,
        option: {
          value: 'USA',
          label: 'United States'
        },
        isDisabled: false,
        isFocused: false
      }} />);

      const expectedMarkup = markup(`
        <div class="Option__option">United States</div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should render disabled Option', () => {

      const component = (<Option {...{
        renderFunc: (option) => option.label,
        option: {
          value: 'USA',
          label: 'United States'
        },
        isDisabled: true,
        isFocused: false
      }} />);

      const expectedMarkup = markup(`
        <div class="Option__option Option__disabledOption">United States</div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    it('should render focused Option', () => {

      const component = (<Option {...{
        renderFunc: (option) => option.label,
        option: {
          value: 'USA',
          label: 'United States'
        },
        isDisabled: false,
        isFocused: true
      }} />);

      const expectedMarkup = markup(`
        <div class="Option__option Option__focusedOption">United States</div>
      `);

      expect(renderToStaticMarkup(component)).toEqual(expectedMarkup);

    });

    describe('events', () => {

      it('should call callbacks on mouseDown, mouseEnter and mouseLeave', () => {

        const onMouseDownHandler = expect.createSpy();
        const onMouseEnterHandler = expect.createSpy();
        const onMouseLeaveHandler = expect.createSpy();

        const component = (<Option {...{
          renderFunc: (option) => option.label,
          option: {
            value: 'USA',
            label: 'United States'
          },
          isFocused: false,
          isDisabled: false,
          mouseDown: onMouseDownHandler,
          mouseEnter: onMouseEnterHandler,
          mouseLeave: onMouseLeaveHandler
        }} />);

        const option = findDOMNode(TestUtils.renderIntoDocument(component));

        TestUtils.Simulate.mouseDown(option);
        TestUtils.Simulate.mouseEnter(option);
        TestUtils.Simulate.mouseLeave(option);

        expect(onMouseDownHandler).toHaveBeenCalled();
        expect(onMouseLeaveHandler).toHaveBeenCalled();
        expect(onMouseEnterHandler).toHaveBeenCalled();

      });

      it('should not call callbacks on disabled option', () => {

        const onMouseDownHandler = expect.createSpy();
        const onMouseEnterHandler = expect.createSpy();
        const onMouseLeaveHandler = expect.createSpy();

        const component = (<Option {...{
          renderFunc: (option) => option.label,
          option: {
            value: 'USA',
            label: 'United States'
          },
          isFocused: false,
          isDisabled: true,
          mouseDown: onMouseDownHandler,
          mouseEnter: onMouseEnterHandler,
          mouseLeave: onMouseLeaveHandler
        }} />);

        const option = findDOMNode(TestUtils.renderIntoDocument(component));

        TestUtils.Simulate.mouseDown(option);
        TestUtils.Simulate.mouseEnter(option);
        TestUtils.Simulate.mouseLeave(option);

        expect(onMouseDownHandler.calls.length).toEqual(0);
        expect(onMouseLeaveHandler.calls.length).toEqual(0);
        expect(onMouseEnterHandler.calls.length).toEqual(0);

      });

    });

  });

});
