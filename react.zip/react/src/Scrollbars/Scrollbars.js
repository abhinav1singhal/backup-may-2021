/* eslint-disable react/no-set-state */

import React, { PropTypes } from 'react';
import { Scrollbars as ExportedScrollbars } from 'react-custom-scrollbars';
import { noop, throttle } from 'lodash';

class Scrollbars extends React.Component {

  static propTypes = {
    /**
     * The element your content will be rendered in
     */
    renderView: PropTypes.func,

    /**
     * Event handler. Will be called with the native scroll event
     * Signature: onScroll(event)
     */
    onScroll: PropTypes.func,

    /**
     * Event handler. Runs inside the animation frame. Passes values about the current scroll position
     * Signature: onScrollFrame(values)
     */
    onScrollFrame: PropTypes.func,

    /**
     * On start event handler.
     */
    onScrollStart: PropTypes.func,

    /**
     * On end event handler.
     */
    onScrollStop: PropTypes.func,

    /**
     * Min thumb height
     */
    thumbMinSize: PropTypes.number,

    /**
     * Fixed thumb height
     */
    thumbSize: PropTypes.number,

    /**
     * Container height
     */
    height: PropTypes.any.isRequired,
    /**
     * Container width
     */
    width: PropTypes.any.isRequired,

    /**
     * Disable horizontal scrollbar
     */
    disableHorizontal: PropTypes.bool.isRequired,

    /**
     * Disable horizontal scrollbar
     */
    disableVertical: PropTypes.bool.isRequired,

    /**
     * Should show shadows
     */
    shadows: PropTypes.bool,

    /**
     * Set className to scrollbar view wrapper container
     */
    viewWrapperClassName: PropTypes.string,

    /**
     * Set style to scrollbar view wrapper container
     */
    viewWrapperStyle: PropTypes.object,
    className: PropTypes.string,
    children: PropTypes.any,
    style: PropTypes.object,
    theme: PropTypes.object.isRequired,
    /**
     * Set style to Scrollbar horizontal thumb pointer
     */
    trackHorizontalStyle: PropTypes.object,
    /**
     * Set style to Scrollbar vertical thumb pointer
     */
    trackVerticalStyle: PropTypes.object,
    /**
     * Callback at the scrollTop method ends evaluating
     * Signature: scrollTopDidStop(scrollTopPosition)
     */
    scrollTopDidStop: PropTypes.func,
    /**
     * Callback at the scrollLeft method ends evaluating
     * Signature: scrollLeftDidStop(scrollLeftPosition)
     */
    scrollLeftDidStop: PropTypes.func,
    // TODO: check possibility to pass component on render
    /**
     * To replace vertical Scrollbars track component (overflow-y panel)
     */
    renderTrackVertical: PropTypes.func,
    /**
     * To replace horizontal Scrollbars track component (overflow-x panel)
     */
    renderTrackHorizontal: PropTypes.func,
    /**
     * Toggle to activate auto hide
     */
    autoHide: PropTypes.bool,
    /**
     * Auto hide delay in ms
     */
    autoHideTimeout: PropTypes.number,
    /**
     * Duration for hide animation in ms
     */
    autoHideDuration: PropTypes.number,
    /**
     * Toggle to activate auto-height
     */
    autoHeight: PropTypes.bool,
    /**
     * Minimal height in auto-height mode
     */
    autoHeightMin: PropTypes.number,
    /**
     * Maximal height in auto-height mode
     */
    autoHeightMax: PropTypes.number,
    /**
     * Event handler. Will be called with native Scrollbars update events.
     * Passes values about the scroll position and current content and window height/width
     * Signature: onUpdate(values)
     */
    onUpdate: PropTypes.func,
    /**
     * To customize vertical Scrollbars thumb
     */
    renderThumbVertical: PropTypes.func,
    /**
     * To customize horizontal Scrollbars thumb
     */
    renderThumbHorizontal: PropTypes.func
  };

  constructor(props) {
    super(props);
    this.state = {
      scrollTop: 0,
      scrollLeft: 0,
      scrollHeight: 0,
      clientHeight: 0,
      height: 0,
      scrollTopWatcher: {},
      scrollLeftWatcher: {}
    };
  }

  componentDidMount() {
    if (this.props.shadows || this.props.height === 'auto') {
      window.addEventListener('resize', this.handleWindowResize);
      if (this.props.height === 'auto') {
        throttle(() => {
          this.setState({ height: this.getParentHeight() });
        }, 30)();
      }
    }
  }

  componentWillReceiveProps() {
    if (this.props.height === 'auto') {
      throttle(() => {
        this.setState({ height: this.getParentHeight() });
      }, 30)();
    }
  }

  componentDidUpdate() {
    const { scrollTop, scrollTopWatcher, scrollLeft, scrollLeftWatcher } = this.state;

    if (scrollTopWatcher.watch && scrollTopWatcher.position === scrollTop) {
      scrollTopWatcher.watch = false;
      this.scrollTopDidStop();
    }

    if (scrollLeftWatcher.watch && scrollLeftWatcher.position === scrollLeft) {
      scrollLeftWatcher.watch = false;
      this.scrollLeftDidStop();
    }
  }

  componentWillUnmount() {
    if (this.props.shadows || this.props.height === 'auto') {
      window.removeEventListener('resize', this.handleWindowResize);
    }
  }

  getParentHeight() {
    if (this.refs.root) {
      const parentElement = this.refs.root.parentElement;
      if (parentElement) {
        return parentElement.offsetHeight;
      }
    }
    return 0;
  }

  getElement() {
    return this.refs.scrollbar;
  }

  getScrollTop() {
    return this.refs.scrollbar.getScrollTop();
  }

  getScrollLeft() {
    return this.refs.scrollbar.getScrollLeft();
  }

  handleUpdate = (values) => {
    this.props.onUpdate(values);
  };

  handleScroll = (event) => {
    this.props.onScroll(event);
  };

  handleScrollFrame = (values) => {
    const { scrollTop, scrollLeft, scrollHeight, clientHeight } = values;
    this.setState({ scrollTop, scrollLeft, scrollHeight, clientHeight });
    this.props.onScrollFrame(values);
  };

  handleWindowResize = throttle(() => {
    const { scrollbar } = this.refs;
    const { scrollTop, scrollLeft, scrollHeight, clientHeight } = scrollbar.getValues();
    this.setState({
      scrollTop,
      scrollLeft,
      scrollHeight,
      clientHeight,
      height: this.getParentHeight()
    });
  }, 50);

  scrollToTop() {
    this.refs.scrollbar.scrollToTop();
  }

  scrollTop(nPixels: number) {
    this.refs.scrollbar.scrollTop(nPixels);
    this.setState({scrollTopWatcher: {
      watch: true,
      position: nPixels
    }});
  }

  scrollTopDidStop() {
    const scrollTopPosition = this.getScrollTop();
    this.props.scrollTopDidStop(scrollTopPosition);
  }

  scrollToLeft() {
    this.refs.scrollbar.scrollToLeft();
  }

  scrollLeft(nPixels: number) {
    this.refs.scrollbar.scrollLeft(nPixels);
    this.setState({scrollLeftWatcher: {
      watch: true,
      position: nPixels
    }});
  }

  scrollLeftDidStop() {
    const scrollLeftPosition = this.getScrollLeft();
    this.props.scrollLeftDidStop(scrollLeftPosition);
  }

  renderTrackHorizontal = ({ style, ...props }) => {
    if (this.props.renderTrackHorizontal) {
      return this.props.renderTrackHorizontal({ style, ...props});
    }
    const trackStyle = {
      right: 2,
      bottom: 2,
      left: 2,
      borderRadius: 3,
      cursor: 'pointer',
      height: 7,
      display: this.props.disableHorizontal ? 'none' : 'block'
    };
    return (
      <div style={{...style, ...trackStyle}} {...props} />
    );
  }

  renderTrackVertical = ({ style, ...props }) => {
    if (this.props.renderTrackVertical) {
      return this.props.renderTrackVertical({ style, ...props});
    }
    const trackStyle = {
      right: 2,
      bottom: 2,
      top: 2,
      borderRadius: 3,
      cursor: 'pointer',
      width: 7,
      display: this.props.disableVertical ? 'none' : 'block'
    };
    return (
      <div style={{...style, ...trackStyle}} {...props} />
    );
  }

  renderThumbVertical = ({ style, ...props}) => {
    if (this.props.renderThumbVertical) {
      return this.props.renderThumbVertical({ style, ...props});
    }
    const thumbStyle = {
      borderRadius: 0,
      backgroundColor: 'rgb(145,150,155)',
      cursor: 'pointer'
    };
    const passedStyle = this.props.trackVerticalStyle;

    return (
      <div style={{...style, ...thumbStyle, ...passedStyle}} {...props} />
    );
  }

  renderThumbHorizontal = ({ style, ...props}) => {
    if (this.props.renderThumbHorizontal) {
      return this.props.renderThumbHorizontal({ style, ...props});
    }
    const thumbStyle = {
      borderRadius: 0,
      backgroundColor: 'rgb(145,150,155)',
      cursor: 'pointer'
    };
    const passedStyle = this.props.trackHorizontalStyle;

    return (
      <div style={{...style, ...thumbStyle, ...passedStyle}} {...props} />
    );
  }

  renderShadows() {
    if (this.props.shadows) {
      const { theme } = this.props;
      const { scrollTop, scrollHeight, clientHeight } = this.state;
      const shadowTopOpacity = 1 / 20 * Math.min(scrollTop, 20);
      const bottomScrollTop = scrollHeight - clientHeight;
      const shadowBottomOpacity = !clientHeight ?
        1 : 1 / 20 * (bottomScrollTop - Math.max(scrollTop, bottomScrollTop - 20));

      return (
        <div>
          { this.renderShadow(theme.topShadow, shadowTopOpacity) }
          { this.renderShadow(theme.bottomShadow, shadowBottomOpacity) }
        </div>
      );
    }
    return null;
  }

  renderShadow(theme, opacity) {
    return (
      <div className={theme} style={{ opacity }} />
    );
  }

  renderView({ style, ...props }) {
    if (this.props.renderView) {
      return this.props.renderView({ style, ...props });
    }
    const {viewWrapperStyle, viewWrapperClassName} = this.props;
    return (
      <div {...props} style={{ ...style, ...viewWrapperStyle }} className={viewWrapperClassName}/>
    );
  }

  render() {

    const { height, width, theme, ...restProps } = this.props;

    const style = {
      ...this.props.style,
      position: 'relative',
      overflow: 'hidden',
      height,
      width
    };

    return (
        <div style={style} className={theme.root} ref="root">
          <ExportedScrollbars {...restProps}
                              style={style}
                              ref="scrollbar"
                              onUpdate={this.handleUpdate}
                              onScroll={this.handleScroll}
                              onScrollFrame={this.handleScrollFrame}
                              renderTrackHorizontal={this.renderTrackHorizontal}
                              renderTrackVertical={this.renderTrackVertical}
                              renderThumbHorizontal={this.renderThumbHorizontal}
                              renderThumbVertical={this.renderThumbVertical}
                              renderView={this.renderView.bind(this)}
           />
          { this.renderShadows() }
        </div>
    );

  }

}

Scrollbars.defaultProps = {
  onUpdate: noop,
  onScroll: noop,
  onScrollFrame: noop,
  thumbMinSize: 20,
  width: '100%',
  height: '100%',
  shadows: false,
  disableHorizontal: false,
  disableVertical: false,
  scrollTopDidStop: noop,
  scrollLeftDidStop: noop,
  theme: require('./Scrollbars.css')
};

export default Scrollbars;
