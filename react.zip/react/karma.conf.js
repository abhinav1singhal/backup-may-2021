/* eslint-disable */

var webpack = require('webpack');
var argv = require('yargs').argv;
var isCI = argv.ci === true;
var isCoverage = argv.coverage === true;

var reporters = [ 'mocha', 'junit-moodys' ];

var rules = [
  {
    test: /\.js/,
    exclude: /node_modules/,
    loader: 'babel-loader'
  },
  {
    test: /\.css$/,
    loader: [
      'style-loader',
      '!css-loader',
      '?module&importLoaders=1&localIdentName=[name]__[local]'
    ].join('')
  },
  {
    test: /\.(png|jpg|otf|eot|svg|ttf|woff|woff2)$/,
    loader: 'null-loader'
  }
];
if (isCoverage) {
  reporters.push('coverage');
  rules.unshift({
      test: /\.js/,
      enforce: "pre",
      exclude: [ /node_modules/, /Spec\.js/, /(styleguide)+/ ],
      loader: 'moodys-coverage-loader'
    });
}

module.exports = function(config) {
  config.set({

    browsers: [ 'PhantomJS' ],

    frameworks: [ 'phantomjs-shim', 'mocha', 'sinon-chai' ],

    basePath: '',

    files: [
      './src/indexSpec.js'
    ],

    preprocessors: {
      './src/indexSpec.js': ['webpack', 'sourcemap']
    },

    reporters: reporters,

    webpack: {
      output: {
        pathinfo: true
      },
      devtool: 'eval',
      module: {
        rules: rules
      },
      plugins: [
        new webpack.DefinePlugin({
          'process.env': {
            'NODE_ENV': JSON.stringify('development')
          }
        })
      ],
      externals: {
        cheerio: 'window',
        'react/lib/ExecutionEnvironment': true,
        'react/lib/ReactContext': true
      }
    },

    mochaReporter: {
      output: 'autowatch'
    },

    junitReporter: {
      outputDir: '.test-report'
    },

    coverageReporter: {
      dir: '.test-report',
      reporters: isCI ? [
        { type: 'html', subdir: 'html' },
        { type: 'lcov', subdir: 'lcov' },
        { type: 'cobertura', subdir: '.', file: 'cobertura.txt' }
      ] : [
        { type: 'html', subdir: 'html' }
      ]
    },

    webpackServer: {
      noInfo: true
    },

    port: 9876,

    colors: true,

    autoWatch: true,

    captureTimeout: 60000,

    browserNoActivityTimeout: 45000,

    singleRun: true

  });
};
