# Contributing

We welcome community support with both pull requests and reporting bugs. Please
don't hesitate to jump in.

## Tests

All commits that fix bugs or add features need a test.

## Code Style

Please adhere to the current code styling. We have included an `.editorconfig`
at the repo's root to facilitate uniformity regardless of your editor. See the
[editor config site][editorconfig] for integration details.

We use [ESLint][eslint] for all JavaScript Linting. There should be no linting
errors and no new warnings for new work. You are welcome to configure your
editor to use ESLint or the `npm test` command will run unit tests and the
linter.

## Commit Subjects for Public API Changes

If your patch **changes the API or fixes a bug** please use one of the following
prefixes in your commit subject:

- `[fixed] ...`
- `[changed] ...`
- `[added] ...`
- `[removed] ...`

That ensures the subject line of your commit makes it into the auto-generated
changelog. Do not use these tags if your change doesn't fix a bug and doesn't
change the public API.

## Visual Changes

When making a visual change, if at all feasible please provide screenshots
and/or screencasts of the proposed change. This will help us to understand the
desired change easier.

## Docs

Please update the docs with any API changes, the code and docs should always be
in sync.

Component prop documentation is generated automatically from the React components
and their leading comments. Please make sure to provide comments for any `propTypes` you add
or change in a Component.

```js
propTypes: {
    /**
     * Sets the visibility of the Component
     */
    show: React.PropTypes.bool,

    /**
     * A callback fired when the visibility changes
     * @type {func}
     * @required
     */
    onHide: myCustomPropType
}
```

There are a few caveats to this format that differ from conventional JSDoc comments.

- Only specific doclets (the @ things) should be used, and only when the data cannot be parsed from the component itself
    - `@type`: Override the "type", use the same names as the default React PropTypes: string, func, bool, number, object. You can express enum and oneOfType types, Like `{("optionA"|"optionB")}`.
    - `@required`: to mark a prop as required (use the normal React isRequired if possible)
    - `@private`: Will hide the prop in the documentation
- All description text should be above the doclets.

## Notes for lodash functions usage in the code

You can use `lodash` but keep it to things where it actually needs it, i.e. don't use `lodash`'s `forEach` when `Array.prototype.forEach` is fine.

[eslint-plugin-lodash](https://github.com/eslint-plugins/eslint-plugin-lodash) will help in preventing to not include the full `lodash`.

## Collaborators

Please see the [Maintaining](./MAINTAINING.md) documentation.

[editorconfig]: http://editorconfig.org
[eslint]: http://eslint.org
[commit-message]: http://robots.thoughtbot.com/5-useful-tips-for-a-better-commit-message
