# Changelog

## v1.9.0 - 19 October 2018

New features:
- Added `Select` `expandable` for `optionsMenu`

## v1.8.12 - 12 October 2018

New features:
- Added `Select` second level for `optionsMenu` with `isSubsection` flag for menu item

## v1.8.11 - 11 October 2018

Fixes:
- `MultiSelect` Prevents closing on "Select\Deselect all"

## v1.8.10 - 29 June 2018
Updates:
- set submitted to false in `FormComponent` on data update

## v1.8.9 - 27 June 2018
Updates:
- Updated `FormComponent` with `recalculateState` and `prepareStateFromProps`

## v1.8.8 - 25 June 2018
Updates:
- Add treeSelectUtils

## v1.8.7 - 8 June 2018
Updates:
- export new `FormBuilder` utils

## v1.8.6 - 7 June 2018
Updates:
- update `FormBuilderConfigDTO` with new utils

## v1.8.5 - 4 June 2018

Updates:
- add queryParams to dictionaryUtils

## v1.8.4 - 30 March 2018

Fixes:
- `FormBulider` controlWrapper default prop as noop

## v1.8.3 - 23 May 2018

Updates:
- Add onOpen, onClose props to `TreeSelect`

## v1.8.2 - 18 May 2018

New features:
- `FormBulider` pass controlWrapper as prop
- `FormComponent` pass pass onChange as prop and call it as callback
- `FormComponent` return parameter isValidForm for onValidate handler
- `Icon` add warning icon

Fixes:
- `TextField` avoid render <label> if this.props.label was not passed

## v1.8.1 - 15 May 2018

New features:
- `FormBulider` onClose and onOpen added

## v1.8.0 - 2 May 2018

New features:
- `Axios` auto-cancel added

## v1.7.7 - 30 March 2018
Fixes:
- `TreeSelect` unexpected scroll on checkbox hover

## v1.7.6 - 30 March 2018

Updates:
- Updated `react-dom` version to `0.14.9`

## v1.7.5 - 28 March 2018

Bug fixes:
- Save action meta information only on request action
- Fixed exit icon.svg

## v1.7.4 - 27 March 2018

Bug fixes:
- Reverted: Wrapped `DataTable` in `AutoSizer` decorator (OldDataTable)

## v1.7.3 - 27 March 2018

New features:
- Wrapped `DataTable` in `AutoSizer` decorator (OldDataTable)
- Added action meta information to requests reduced

## v1.7.0 - 27 March 2018

New features:
- Wrapped `DataTable` in `AutoSizer` decorator

## v1.6.0 - 19 March 2018

Updates:
  - Added `utils/array` and `utils/string`, moved `DictionariesConfigDTO` to utils
  - Deprecated `dictionariesUtils` in `redux/utils`

## v1.5.7 - 16 March 2018

Bug fixes:
  - Fixed `Icons` for `FormBuilder`

## v1.5.6 - 13 March 2018

Updates:
  - Added `customFieldLabel` prop to `FormBuilder`

## v1.5.5 - 13 March 2018

New features:
- Added `limitText` prop for limitBox of `TextArea` component

## v1.5.4 - 9 March 2018

New features:
- Added `DictionaryConfigDTO` to utils

## v1.5.3 - 8 March 2018

Bug fixes:
- Fixed issue with TreeViewMultiSelect remove value icon color

## v1.5.2 - 7 March 2018

Bug fixes:
- Added missing checkbox icons

## v1.5.0 - 2 March 2018

New features:
- Added `DictionariesService` to redux

## v1.5.0 - 26 February 2018

New features:
- Added `FormBuilder` and child components

## v1.4.4 - 22 February 2018

Updates:
- Added submit tags on `TagsInput` blur
- `Input` width in `TagsInput` became adaptive

## v1.4.3 - 12 February 2018

Updates:
- Added up-down keys for `TagsInput` suggestions
- Added `Accordion` to support 0 defaultEventKey

Bug fixes:
- Fixed `NotificationCenter` to not showing empty notifications

## v1.4.2 - 7 February 2018

Updates:
- Fixed `react-datepicker` year selection styles

## v1.4.0 - 6 February 2018

Updates:
- Updated 'TagsInput'

## v1.3.4 - 28 January 2018

New features:
- Added `ArrowIcon` component

## v1.3.1 - 20 January 2018

New features:
- Added `buttonBefore` `buttonAfter` components support to `TagsInput`

## v1.3.0 - 19 January 2018

New features:
- Added `TagsInput` component

Bug fixes:
- Fixed `Input` set value 0

## v1.2.1 - 10 November 2017

Bug fixes:
- Fixed `Select` focus behaviour

## v1.2.0 - 31 October 2017

Bug fixes:
- Fixed `TextArea` pasting order

## v1.1.11 - 24 October 2017

Updates:
- Added `TextArea` support `limit` newline counting \r \n in pasting text
- Added `TextArea` minimal height calculating

## v1.1.10 - 12 October 2017

Updates:
- Fixed `TextArea` bug with `onChange` behavior

## v1.1.9 - 11 October 2017

Updates:
- Fixed `TextArea` bug with `onPaste` behavior
- Fixed IE bug with selection for `Input` and `Textarea`

## v1.1.8 - 9 October 2017

Updates:
- Added new sizes for `Select`
- Fixed props issue for `Select`
- Update `Tabs` styles

## v1.1.7 - 6 October 2017

Updates:
- Fixed `TextArea` bug with `onChange` behavior
- Update `TextArea` styles


## v1.1.6 - 13 September 2017

Updates:
- Updated `FixedDataTable2` to default scrollToRow to top row

## v1.1.5 - 12 September 2017

Updates:
- Updated `FixedDataTable2` Scrollbars

## v1.1.0 - 31 August 2017

Updates:
- Added `fixed-data-table-2` with new Scrollbars
- Updated `DataTable` to use `fixed-data-table-2`

## v1.0.3 - 2 August 2017

Updates:
- Updated `react-redux` to 4.4.6

## v1.0.2 - 1 August 2017

Bug fixes:
- Fixed `Textarea` mount height issue

## v1.0.1 - 27 July 2017

Bug fixes:
- Fixed `Input` receive value prop

## v1.0.0 - 17 July 2017

New features:
- Extended `Icon` component by new types: `external-link`

Breaking changes:
- Migrated to webpack to 3.x with all plugins and loaders

## v0.23.4 - 29 June 2017

New features:
- Extended `Icon` component by new types: `merge-columns`, `merge-rows`

## v0.23.3 - 22 June 2017

Bug fixes:
- Fixed `Input` `onClear` bug

## v0.23.2 - 15 June 2017

New features:
- Added `position` prop for label with `left`, `right` possible values for `Checkbox` and `Radio` components
- Added external `focus()` method for all `Input` types, including `Datepicker` component
- Added ability to prevent notification via returning null from `NotificationReducer`
- Extended `Icon` component by new types: `set-grid`

Breaking changes:
- `cache` configuration set to `false` by default in `client` (this will add noCache query param to all GET requests by default)

Updates:
- Updated `Input` component clearable styles

## v0.23.1 - 26 May 2017

Bug fixes:
- Fixed `Select` and `Autocomplete` `BaseSelect` menu closing
- Fixed `Input` props and state inconsistency

## v0.23.0 - 24 May 2017

New features:
- Added methods for `Scrollbars` component complete customization: `renderTrackVertical`, `renderTrackHorizontal`,
`renderThumbVertical`, `renderThumbHorizontal`, `renderView`
- Updated features for `Scrollbars`: `autoHide` with `autoHideTimeout`, `autoHideDuration`
and `autoHeight` with `autoHeightMin` and `autoHeightMax`
- Added event handler `onUpdate(values)` with values about the current scroll position and content/window height/width
- Added event handler `onScroll(event)` called with the native scroll event
- Added position parameter for `scrollTopDidStop(scrollTopPosition)` and `scrollLeftDidStop(scrollLeftPosition)` callbacks
- Added `Scrollbars` customization features using boilerplate example at styleguide

Bug fixes:
- Fixed `autoWidth` decorator overflow-x

## v0.22.10 - 17 May 2017

New features:
- Extended `Icon` component by new types: `view`, `merge`
- Updated shadows feature for `Scrollbars` component with prop `shadows` (bool) and `autoHide` (bool) for thumbs

Updates:
- Updated `react-custom-scrollbars`

## v0.22.9 - 2 May 2017

Bug fixes:
- Fixed `Overlay` component animation bug

## v0.22.8 - 21 April 2017

New features:
- Added `scrollLeft`, `scrollToLeft` methods with playground examples to the `Scrollbars` component
- Added `scrollLeftDidStop` callback for the `Scrollbars` component
- Added `getScrollLeft` and `getScrollTop` methods to the `Scrollbars` component


## v0.22.7 - 7 April 2017

New features:
- Added stop input for `TextArea` when text is over the limit, changed limit label text
- Added `white` color to variables
- Extended `Icon` component by new types: `info`, `comments`

Updates:
- Updated `rotate-clockwise` icon

## v0.22.6 - 17 March 2017

New features:
- Extended `Icon` component by new types: `text`, `rotate-clockwise`, `question`

## v0.22.5 - 16 March 2017

Bug fixes:
- Fixed issue with `axios` error handling
- Fixed issue with `Pages` export

Breaking changes:
- Removed deprecated `Pages.*` export

## v0.22.4 - 23 February 2017

New features:
- Added saving menu orientation at `dropdownFixed` mode for the `Select` component
- Extended `Icon` component by new types: `acc-calendar`, `acc-monetary`, `acc-mult`, `acc-percantage`, `acc-string`, `acc-unit`, `iap-suggestions`

Bug fixes:
- Fixed `Input` `clearable` bugs
- Fixed `Select` on options menu filtering height recalculating position bug

Updates:
- Updated "http-proxy": "1.13.2" -> "http-proxy": "1.16.2"
- Updated "bowser": "1.0.0" -> "bowser": "1.6.0"

## v0.22.3 - 14 February 2017

New features:
- Added `scrollTopDidStop` method for the `Scrollbars` component
- Added support of number type keys for the `Select` component`
- Added `clearable`, `onChange`, `onClear`, methods for the `Input` component
- Added `label`, `clearIcon`, `clearText` props for the `Input` component

Updates:
- Changed `Input` standard small size to be `30px` with `bsSize="small"

Bug fixes:
- Fixed `Select` component `menuOrientationAuto` random bug

## v0.22.2 - 7 February 2017

New features:
- Added cancelable promises with `cancelToken` at `client` util
- Added `client.cancel()` method to cancel async request
- Added `parentClassName` property to `Select` component and `Autocomplete` for the top `form-group` element
- Extended `Icon` component by new types: `double-arrows-left`, `double-arrows-right`

Updates:
- Made `color` property to be not the part of `defaultProps` for the `Icon` component, to have ability to change it by css
- Updated "axios": "0.9.1" -> "axios": "0.15.3"

Breaking changes:
- In `client` Request adapters Response transformer is now called outside of adapter and Request adapter returns a Promise
- The `client` config option `progress` has been replaced with the `onUploadProgress` and `onDownloadProgress` options
- The `client` `agent` config option has been replaced with two new options: `httpAgent` and `httpsAgent`

## v0.22.1 - 27 January 2017

New features:
- Added `bootstrapUtils`, `StyleConfig` and `ValidComponent` utils
- Added `onScrollStop` and `disableVertical` methods for `Scrollbars` component
- Added `FormGroup` and `Tooltip` components to be owned by `react-moodys` from `react-bootstrap`
- Added ability for styling `Tooltip` component with `innerStyle` and `arrowStyle` props
- Added basic `Cancel` action type for `asyncRequestTypes` in `redux` `requestsReducer`
- Added ability to set separately `width` and `height` for `Icons` with scaling and changing aspect ratio
- Added standard `Input` component creates with `bsSize="defaut"` prop value for all types - `Text`, `Select`, `Date` etc.
- Added possibility to put regular icons in `Input` fields the same way like `Glyphicons` with `formControlFeedback` prop
- Added automatically defining `Select` component menu orientation (left/right) in `dropDownFixed` mode with `menuOrientationAuto` flag
- Extended `Icon` component by new types: `forward`, `settings`

Updates:
- Updated `babel-plugin-transform-runtime`, `babel-runtime`, `classnames`, `fixed-data-table`, `redux`
- Updated all icons base to the right format with possibility for x y separate scaling and cleaned trash

Bug fixes:
- Fixed `Scrollbars` component `renderThumbHorizontal` and `renderThumbVertical`
- Fixed `OverlayTrigger` propTypes

## v0.22.0 - 8 December 2016

Updates:
- Migrated project to Babel 6.x.x with dependencies and to Lodash 4.x.x

devDependencies:

UPDATE:

    "babel-core": "5.8.33" -> "babel-core": "6.11.4"
    "babel-eslint": "5.0.0-beta9" -> "babel-eslint": "6.1.0"
    "babel-loader": "5.3.3" -> "babel-loader": "6.2.4"
    "babel-polyfill": "6.2.0" -> "babel-polyfill": "6.9.1"
    "babel-runtime": "5.8.29" -> "babel-runtime": "6.11.6"
    "eslint": "1.10.3" -> "eslint": "3.11.1"
    "eslint-config-moodys": "0.4.0" ->  "eslint-config-moodys": "0.5.0"
    "eslint-plugin-babel": "3.0.0" ->  "eslint-plugin-babel": "3.3.0"
    "eslint-plugin-lodash": "0.1.4" -> "eslint-plugin-lodash": "1.10.1"
    "eslint-plugin-mocha": "1.1.0" -> "eslint-plugin-mocha": "4.5.1"
    "moodys-coverage-loader": "0.2.0" -> "moodys-coverage-loader": "0.3.0"
    "react-transform-catch-errors": "1.0.0" -> "react-transform-catch-errors": "1.0.2"
    "react-transform-hmr": "0.1.6" -> "react-transform-hmr": "1.0.4"
    "moodys-coverage-loader": "0.2.0"  -> "moodys-coverage-loader": "0.3.0"
    "karma": "0.13.9" -> "karma": "1.3.0"
    "karma-chrome-launcher": "0.2.3" -> "karma-chrome-launcher": "2.0.0"
    "karma-coverage": "0.5.2" -> "karma-coverage": "1.1.1"
    "karma-firefox-launcher": "0.1.7" -> "karma-firefox-launcher": "1.0.0"
    "karma-phantomjs-launcher": "1.0.0" -> "karma-phantomjs-launcher": "1.0.2
    "karma-phantomjs-shim": "1.2.0" -> "karma-phantomjs-shim": "1.4.0",
    "glob": "6.0.4" -> "glob": "7.1.1"

REMOVE:

    "babel": "5.8.29"

ADD:

    "babel-cli": "6.11.4"
    "babel-plugin-lodash": "3.2.8"
    "babel-plugin-transform-runtime": "6.12.0"
    "babel-polyfill": "6.9.1"
    "babel-preset-es2015": "6.9.0"
    "babel-preset-react": "6.11.1"
    "babel-preset-stage-1": "6.5.0"
    "babel-runtime": "6.11.6"

dependencies:

 "lodash": "3.10.1" -> "lodash": "4.15.0"
 "dom-helpers": "2.3.0" -> "dom-helpers": "2.4.0"


New features:
- `Select` component dropdown menu sets to be the same width as `Input` by default in `dropDownFixed` mode

## v0.21.19 - 22 November 2016

New features:
- Added ability to styling with custom theme for `Input`, `Checkbox` and `Radio` components, use theme prop for this components.
- Added ability to pass theme to `PageHeaderNavbar` and to `ProfileDetails`
- Added customTheme prop for `Select` and `Autocomplete` components to style all inner parts of this components.
- Extended `Icon` component by new type: `no-document`

Breaking changes:
- The following props should be considered as deprecated for `Checkbox` and `Radio`: `className`, `labelClassName`
use `theme.root` and `theme.label` instead
- The following props should be considered as deprecated for `Input`:  `className`, `groupClassName`, `wrapperClassName`, `labelClassName`
use `theme.root`, `theme.inputGroup`, `theme.wrapper`, `theme.label` instead
- The following props should be considered as deprecated for `Select`: `wrapperClassName`, `labelClassName`, `optionsMenuClassName`
use `customTheme.root`, `customTheme.label`, `customTheme.optionMenuWrapper` instead.
- The following props should be considered as deprecated for `Autocomplete`: `wrapperClassName`, `labelClassName`, `optionsMenuClassName`
use `customTheme.root`, `customTheme.label`, `customTheme.optionMenuWrapper` instead.

## v0.21.18 - 7 November 2016

Updates:
- Changed `Autocomplete` and `Select` component `onBlur` logic to restore options list
- Remove white color for focused buttons
- Add border between buttons in input group

Bug fixes:
- Fixed `Autocomplete` component `onInputChange` behaviour

## v0.21.17 - 31 October 2016

New features:
- Added ability to automatically define `Select` component menu orientation (up/down) in `dropDownFixed` mode with `menuOrientationAuto` flag
- Added `onEntered` callback prop (fired after Collapse expanded) to `Accordion` component
- Added ability to styling `Autocomplete` and `Select` components selected `Values` with `valueStyle` prop
- Added ability to styling `Scrollbars` thumb pointers with `trackVerticalStyle` and `trackHorizontalStyle` props

Updates:
- Set `disabled` property when `readOnly` specified for `Checkbox` and `Radio`

## v0.21.16 - 21 October 2016

New features:
- Added `headerComponent` property to `Accordion` component for ability to replace `Accordion` header title with custom component
- Extended `Icon` component by new types: `zoom-in`, `zoom-out`

Updates:
- Changed `Select` component `onBlur` method to clear `inputValue` by default
- Updated playground with `unmount`, nested `accordions` examples

Bug fixes:
- Fixed playground iterator issue

## v0.21.15 - 17 October 2016

New features:
- Added ability to style `Spinner` with `spinColor`, `circleColor` and `type`
- Added ability to pass `spinColor`, `circleColor` for `Spinner` through `LoadingContainer`
- Added possibility to build nested `Accordions`
- Extended `Icon` component by new types: `account-type-date`, `account-type-integer`, `account-type-monetary`,
`account-type-multiplier`, `account-type-percentage`, `account-type-string`

Breaking changes:
- Changed colors in variables.js

## v0.21.14 - 12 October 2016

New features:
- Added ability to styling `Select` `optionsMenu` with `optionsMenuStyle` and `optionsMenuClassName` properties
- Added ability to add title to `Select` `optionsMenu` with `optionsMenuTitle` property
- Change `Select` component `optionsMenu` arrow to turn up on open and added `arrowStateStyles` for styling all arrow states

Breaking changes:
- Import `Pages.*` should be considered as deprecated, use `Page403/Page404/Page500/BasePage` instead
- Completely changed styles of all buttons

## v0.21.13 - 05 October 2016

Bug fixes:
- Fixed missing Input methods and tests added

## v0.21.12 - 03 October 2016

New features:
- Added event with `preventMenuClose()` to `Select` `onChange()` method
- Extended `Icon` component by new type `exchange`

Bug fixes:
- Fixed bug with disabled xs `Button` size

Updates:
- Updated playground styleguide

Breaking changes:
- Removed `onClick` event handler from `Select` `Option` component

## v0.21.11 - 23 September 2016

Fixes:
- Fixed `Autocomplete` component `onBlur` clear options bug
- Fixed `Select` component style ineritance in disabled state

## v0.21.10 - 22 September 2016

New features:
- Added `Input` component to be owned by `react-moodys` from `react-bootstrap`
- Added generating default id for `Input` component and it's `label` for property, if it was not passed in props
- Added `calendar`, `historical-data`, `lock`, `view-less`, `view-more` icons

Breaking changes:
- changed Pages components contract (subheader => title, message => content)

Fixes:
- Fixed `Datepicker` component unmount bug with unability to define parent
- Refactored Pages components, extracted BasePage component

Updates:
- Updated `react-datepicker` dependency up to `0.23.2`
- Updated 'plus' and 'minus' icons

## v0.21.9 - 15 September 2016

New features:

- Added ability to save extra response status data in `requestsReducer`: `$statusCode`
- Added ability to save extra response meassage in `requestsReducer`: `$responseMessage`
- Added ability to reset request status externally in `requestsReducer`
- Added property type checker(s) for `requestsReducer`
- Extracted buildUrl util from axios https client
- Added page 403 component
- Extended bootstrap Button component with new bsStyle="white"
- Added redux action utils (ActionsNamespace, ActionsNamespaceFactory, createAction, createAsyncAction)
- Added asyncStatusType and asyncRequestType props

Updates:

- Updated `babel-eslint` dependency up to `5.0.0-beta9`

Breaking changes:

- `asyncConstant` should be considered as deprecated, use `createAsyncAction` instead

## v0.21.8 - 25 August 2016

New features:

- Added `generateTransactionId` for guid generation
- Added `bin`, updated `save` icons

## v0.21.7 - 1 August 2016

Bug fixes and improvements:

- `Spreadsheet` text color, border for merged cells.

## v0.21.6 - 28 July 2016

New features

- Updated `Spreadsheet` component, supported cell styling: text decoration (italic, underlined),
text alignment, fill color, border color, border thickness.


## v0.21.5 - 27 July 2016

New features

- Added ability to set `valueClassName` and `valueWrapperClassName` for `SingleValue` in `Select` component
- Added `blur()` and `focus()` actions for `Select` component
- Added `drawing-cell`, `select-content`, `select-active` icons

## v0.21.4 - 22 July 2016

New features

- Added ability to get wrapped component instance from `autoWidth` decorator with method:
 - `getWrappedInstance`
- Added `arrow-left`, `arrow-right`, `back`, `erase-borders`, `undo` icons

## v0.21.3 - 19 July 2016

New features

- Added `Spreadsheet` component

## v0.21.2 - 11 July 2016

New features:

- Added `edit` icon
- Added ability to configure style and add classes for 'Scrollbars' view wrapper container:
 - 'viewWrapperClassName'
 - 'viewWrapperStyle'

Bug fixes and improvements:
- 'Scrollbars' 'height' changed from calculating specific value in pixels to be '100%'

Updates:

- `react-custom-scrollbars` to `3.1.0`

## v0.21.1 - 23 June 2016

- Changed `OverlayTrigger` and `Overlay` components, supported _keepOverlayOnHover_ property to prevent Overlay closing.
- Changed styles for `FileSelector` component

## v0.21.0 - 10 June 2016

- Changed `Tooltip` and `Popover` styles according to Moodys UIKit
- Added `Counter` component
- Added `TextArea` component
- Added `IconInput` component
- Added ability to pass custom classes to some elements in `Select` component.

## v0.20.2 - 3 June 2016

- Bug fixes:
 - fixed throttle issue with `autoWidth` decorator

## v0.20.1 - 2 June 2016

- Fixed `Table` styles and added ability to pass custom className.
- Added `error` svg and fixed some existing svgs.

## v0.20.0 - 1 June 2016

Improvements:

- Added custom `Table` component instead of BootstrapTable
- Changed `Notification` styles according to Moodys UIKit
- Changed multi `Select` styles according to Moodys UIKit
- Changed `Modal` styles according to Moodys UIKit
- Added ability to pass custom svgs to `Icon` component

Breaking changes:

- Be careful all Bootstrap table styles were deleted.

## v0.19.4 - 24 May 2016

- Bug fixes and Improvements in `Select` component
  - Fixed small bug with `OptionsMenu` component list scrolling on up/down keyboard key press and mouse selection

## v0.19.3 - 20 May 2016

- Bug fixes and Improvements in `Select` component
  - Fixed bug with `OptionsMenu` component list scrolling on up/down keyboard key press
  - Fixed bug with error in console on Esc keyboard key press

## v0.19.2 - 17 May 2016

- Added new types of Icon component: downloadfile, play, collapseTop, expandBottom

## v0.19.1 - 4 May 2016

- Improvements and bug fixes in `Select` component
  - Added new `maxHeight` property.
  - Fixed bug with deleting input value with backspace
- Added description for types in `Icon` component

## v0.19.0 - 26 April 2016

Breaking changes:
- Removed `ssoWorkaroundUtils` was removed from `react-moodys/utils` due to hot reloading issues. Use direct load in servers:

```js
require('react-moodys/lib/utils/ssoWorkaroundUtils');
```

New features:

- `Select` component has new properties: `dropdownWidth`, `dropdownFixed` and `theme`. Added new theme: `noBorder`.

Updates:
- `redux` to `3.4.0`
- `react-redux` to `4.4.5`
- `redux-thunk` to `2.0.1`

**Don't forget to upgrade application dependencies**

## v0.18.0 - 19 April 2016

New features:
- `Scrollbars`: Added new property `disableHorizontal` to hide horizontal scrollbar when it necessary

Breaking changes:
- Change `Icon` API. Uses inline SVG under the hood.  Please, refer documentation.

Bug fixes and improvements:
- `Notification` generates unique uid. Deletion of notifications should work better.
- Removed 'z-index' property from `Scrollbars` thumb elements.
- Added onExited prop to AccordionItem. Used to fire callback when Collapse component collapsed
- `PageHeaderNavbar`. With overflow:hidden set on element with .center-container class, the children components like Select cannot expand. Added fix for that.

Updated:
- `axios` to `0.9.1`,
- `react-input-autosize` to `0.6.10`,
- `shortid` to `2.2.6`,
- some development dependencies.

## v0.17.0 - 24 March 2016

New features:

- Introduced new `Icon` component, based on Moodys SVG fonts assets.
- Added `ssoWorkaroundUtils` for local frontend development with sso enabled

Bug fixes and improvements:

- Minor change for `Scrollbars` component: added z-index for thumb element.
- Fixed bug with inability to create ref for `Dropdown`, `DropdownButton` and `Button`.

## v0.16.0 - 9 March 2016

- Introduced new `Accordion` and `AccordionItem` components.
- Breaking changes in `Scrollbars` component:
  - Renamed `onScroll(event, values)` to `onScrollFrame(values)` and `onScroll(event)`
  - Added `onScrollEnd`, `onScrollStart` and `autoHide`
- Updated:
  - `redux-logger` to `2.6.1`
  - `react-datepicker` to `0.23.1`
  - `react-helmet` to `2.3.1`
- Added testUtils.js to 'react-moodys/utils'.
  - `markup` function
  - `providerWithRedux` function

## v0.15.0 - 18 Feb 2016

New features:

- Introduced new `Scrollbars` component.
- Added `react-moodys/styleguide` package with examples of all components.
- Introduced new `requestsReducer` for keeping eye on async requests' states.
- Introduced ability to swap full application from browser console. It can be useful to integration testing:

```js

// 1 step
// modules/reducers.js

import { makeSwappable } from 'react-moodys/redux';

const rootReducer = combineReducers({
  ...
});

export default makeSwappable(rootReducer);

// 2 step
// main.js

import { connectConsoleUtils } from 'react-moodys/redux';

const store = configureStore();

connectConsoleUtils(store);

// Use

window.getState() // returns application state
window.applyState(state: Object) // applies passed state
window.saveStateToFile(filename: String) // saves application state to json file

```

Bug fixes and improvements:

- Updated `react-datepicker` to 0.20.0. Fixed some bugs.
- Fixed extra small `Button` CSS error


## v0.14.0 - 4 Feb 2016

New features:

- Added `browserUtils` available at `react-moodys/utils`:
  - `isIE`, `isChrome`, `isEdge`, `getVersion`, `isOneOf` functions
  - `browserTypes` dictionary for use with `isOneOf` method
- Added `asyncStatusUtils` - a bunch of function for comparing and combining values from `asyncStatus`. Available at `react-moodys/utils`.
- Bootstrap source LESS files were added. Introduced new theme for bootstrap.
- Added `Page404`, `Page500` components, available via `import { Pages } from 'react-moodys'`.
- Added `Checkbox` and `Radio` components.
- Added `label` property to DatePicker to be compatible with Bootstrap inputs.
- `Select` and `Autocomplete` components are Bootstrap compatible right now. `label`, `labelClassName`, `wrapperClassName` and `bsStyle` params are supported.

Bug fixes and improvements:

- Improved column width calculation in `DataTable` component
- Fixed blinked `DatePicker` in IE11.

Breaking changes:

- `Spinner`: renamed `type` param values - 'grey' -> 'default', 'blue' -> 'primary'
- `LoadingContainer`: renamed `spinner` param values - 'grey' -> 'default', 'blue' -> 'primary'
- `PageHeaderNavbar` has completely new API. Refer docs to update.
- PostCSS configuration in webpack.config.js requires to import `variables.js` from `react-moodys`:

```js
postcss: [
  ...,
  require('postcss-simple-vars')({ variables: function requireVariables() {
      return require('react-moodys/lib/variables.js');
  }}),
  ...
]

```

## v0.13.2 - 25 Jan 2016

- Fixed `BaseSelect` error with custom valueKey and labelKey params.

## v0.13.1 - 21 Jan 2016

- Fixed broken `OverlayTrigger` component
- Moved `react-addons-test-utils` to dev dependencies

## v0.13.0 - 15 Jan 2016

- Updated to `react` and `react-dom` 0.14.6
- Updated dependencies
- Added `DatePicker` component
- Changed the way `LoadingContainer` works. API is not affected.

## v0.12.2 - 23 Dec 2015

- Removed `anchorWrapper` from all `Modal` components due to issues.

## v0.12.1 - 22 Dec 2015

- Downgrade `react-css-modules` dependency to 3.6.1.
- Due to inability to set `ref` to stateless component, we removed `anchorWrapper` in `Input` component.

## v0.12.0 - 18 Dec 2015

- `FileSelector` improvements and new features
 - isValid and isError states
 - Ability to filter by file size
 - see docs for more information...
- New `Spinner` and `LoadingContainer` components
- Added one argument to rowClassNameGetter property in `DataTable`.
- Improved coverage
- Added `data-test` attributes that can be used as anchors for Selenium tests
- Exported new `Breadcrumb`, `BreadcrumbItem`, `Image` components from `react-bootstrap`

## v0.11.0 - 8 Dec 2015

- Updated react up to 0.14.3
- Updated dependencies
- DataTable
  - Exported `DataTableBare` as DataTable but without filter and sorter container.
  - Exported `DataTableCell` and `DataTableOverflowCell` as a cell components for `DataTable`
    - By default `DataTableCell` is used. Once you set `cell` property in `DataTable` - it's up to you what to use. You can create own or use one of these two.
  - Added `headerCell` property - ability to create custom header cell.
- Exported `client` from `react-moodys/utils` - wrapper above `axios` library.
- Rewritten `documentTitleDecorator` and `autoWidth` decorators according to Babel 6 recommendations.

## v0.10.1 - 2 Dec 2015

- Exported `Autocomplete` component properly

## v0.10.0 - 1 Dec 2015

- Added `FileSelector` component
- `react-moodys/router` is removed. `react-moodys/utils` is exported instead.
- Added `autoWidth` decorator, which calculates width of parent div and passes the value down as `width` property.
- `DataTable`
  - Added `width: auto` to `DataTable`
  - `dataKeys` renamed to `columns`
  - `cellRenderer` renamed to `cell`
  - Added ability to set width to data columns
- Added `asyncStatus` to `react-moodys/utils`
- Improved test coverage

## v0.9.3 - 26 Nov 2015

- Fixed issue with not assigned `defaultProps` on IE10.

## v0.9.2 - 23 Nov 2015

- Removed `Handsontable` from package. It breaks IE10 at the moment. Later it will be distributed in another package.

## v0.9.1 - 17 Nov 2015

- `DataTable`
  - Fixed error during sorting non-string data
  - Added `sortData` and `filterData` properties that can override default ones.
  - `cellRenderer` has third attribute `rowData`
  - New more light and clear design

## v0.9.0 - 12 Nov 2015

- Changes in `PageHeaderNavbar`
  - Semantic markup for logo component
  - Added default userImage logo
  - onLogoutClick moved from `user` to be one of `PageHeaderNavbar` attributes
- Removed `filterKey` from `filterTable` action creator
- `dataTableReducer` stores only table settings, since now you should store data in your own reducer
- Updated Bootstrap theme

## v0.8.1 - 3 Nov 2015

- Updated tests configuration according to Sonar requirements
- Updated to `react@0.14.2`

## v0.8.0 - 30 Oct 2015

- Updated dependencies
- Updated to React@0.14.1
- Removed `ContextMenu`
- Removed `batched` middleware
- Added `NavBrand`
- Added `Select` and `Autocomplete` components
- `notify` middleware has only config parameter since now, no need to pass action type
- Changed `actions/action-creators` exports by reason of avoid name conflicts
**before**:
```js
import { hideNotification, ... } from 'react-moodys/redux/actions';

@connect(
  (state) => {
    return {
      notifications: state.notifications
    };
  },
  (dispatch) => {
    return {
      onHide: (uid) => dispatch(hideNotification(uid))
    };
  }
)
...
```

**after**:
```js
import { notificationActions, ... } from 'react-moodys/redux/actions';

const { hideNotification, ... } = notificationActions;

@connect(
  (state) => {
    return {
      notifications: state.notifications
    };
  },
  (dispatch) => {
    return {
      onHide: (uid) => dispatch(hideNotification(uid))
    };
  }
)
...
```

## v0.7.0 - 16 Oct 2015

- Added `playground` for development need to speed up and ease the process of development.
- Added sorting arrows to `DataTable` component.
- Updated `redux-logger` 2.0.1 => 2.0.3
- Fixed a bug with `DataTable` sorting arrows.
- Changed tests configuration
 - Added `npm run test:ci` and `npm run test:coverage`
 - Added cobertura and junit reports for CI.
- Improved test coverage.

## v0.6.0 - 5 Oct 2015

- All Redux middlewares was moved from `react-moodys/redux` to `react-moodys/redux/middlewares` package.
- Introduced `handsontableActions` and `handsontableReducer`
- Updated dependencies

## v0.5.0 - 25 Sept 2015

- Updated `redux-thunk` to v1.0.0.
- Updated `react-helmet` to v1.1.5
- Updated `redux-logger` to v1.0.9
- Updated `react-css-modules` to v3.2.3
- Added `react-moodys/redux/actions` package
- Added `react-moodys/redux/reducers` package
- Added separate `react-moodys/router` package
  - `onRouteResolveHandler` - interceptor for route resolving process, which seeks for `onRouteResolve` static method in route component and invokes it before resolving navigation.
- Added new component `Handsontable`, which wraps `handsontable` library.
- Rethink of `ContextMenu` component. Added `ContextMenuItem` component.
- Added `Notification` helper for `NotificationCenter` component.
- Added `delay` middleware.

## v0.4.2 - 17 Sept 2015

- Fixed major problem with broken `NotificationCenter`

## v0.4.1 - 17 Sept 2015

- Fixed issue with overriding default params in `NotificationCenter`. Resolved problems with positioning and other props.
- Fixed issue with `PageHeaderNavnar` on small screens.

## v0.4.0 - 16 Sept 2015

- Added `redux-batched-updates` package and exported `createBatched` middleware.
- Added `NotificationCenter` component
- Added Redux createNotifier middleware

## v0.3.0 - 15 Sept 2015

- Added `redux` module available by `react-moodys/redux`:
  - Redux middlewares
    - createLogger
    - createThunk
    - createCapture
    - createPromise
  - Redux utils
    - handleActions
    - asyncConstant

## v0.2.0 - 10 Sept 2015

- All styles (including bootstrap) are exported from `react-moodys`
- `ProfileDetails` component are removed from external components and only used in `PageHeaderNavnar`
- All dependencies have fixed version.
- Changed some build tasks.

## v0.1.0 - 04 Sept 2015

- Fixed code style warnings according to new rules
- Introduced new components:
  - ContextMenu
  - DataTable
  - ProfileDetails
  - PageHeaderNavbar
- Build system was rewritten, only lib folder is exposed from now
- Added possibility to expose css, jpg and png files.
- Changed coverage tool. We're using `moodys-coverage-loader` since now.
- Updated react-bootstrap to 0.25.1
- Removed some `react-bootstrap` components:
  - ListGroup
  - ListGroupItem
  - CollapsibleNav
  - ButtonInput
  - PageHeader
  - Thumbnail
  - FormGroup
  - Badge

## v0.0.4 - 17 August 2015

- Removed from react-bootstrap exports:
  - MoodysAlert
  - Jumbotron
  - Carousel, CarouselItem
  - Position
  - AffixMixin
  - BootstrapMixin
  - CollapsibleMixin
  - Interpolate
  - SafeAnchor
  - FormControls
  - styleMaps
  - utils

## v0.0.3 - 13 August 2015

- Added WrappedComponent static field to documentTitleDecorator. Each decorator should have this field from now.

## v0.0.2 - 01 August 2015

- Added DocumentTitle component and documentTitleDecorator

## v0.0.1 - 24 Jul 2015
- Initial version that wraps react-bootstrap components
