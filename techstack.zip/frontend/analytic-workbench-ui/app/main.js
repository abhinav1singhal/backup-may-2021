/* global __DEVELOPMENT__ */

import 'babel-polyfill';
import 'utils/CustomEventIEPolyfill';

import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import createBrowserHistory from 'history/lib/createBrowserHistory';
import { Router, useRouterHistory } from 'react-router';
import { syncHistoryWithStore } from 'react-router-redux';

import getRoutes from './routes';
import configureStore from './store';
import { BASE_ROUTE_URL } from './config';

const browserHistory = useRouterHistory(createBrowserHistory)({
  basename: __DEVELOPMENT__ ? '/' : BASE_ROUTE_URL
});

const store = configureStore(browserHistory);
export const history = syncHistoryWithStore(browserHistory, store);

class App extends React.Component {

  render() {
    return (
      <Provider store={store}>
        <Router history={history}>
          {getRoutes(store)}
        </Router>
      </Provider>
    );
  }

}

render(
  <App />,
  document.getElementById('app-container')
);
