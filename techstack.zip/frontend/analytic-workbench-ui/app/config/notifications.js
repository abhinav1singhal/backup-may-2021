import { issuerSelectorNotifications } from 'modules/issuer/notifications';
import { legacyDataViewNotifications } from 'modules/issuerData/notifications';

import { analyticNotifications } from 'modules/analytic/notifications';
import { issuerLibraryNotifications } from 'modules/issuerLibrary/notifications';
import { configurationNotifications } from 'modules/configuration/notifications';
import { surveillanceNotifications } from 'modules/surveillance/notifications';
import { issuerManagementNotifications } from 'modules/issuerManagement/notifications';
import { libraryArtifactsNotifications } from 'modules/issuerLibrary/notifications';

export default {
  ...issuerSelectorNotifications,

  ...legacyDataViewNotifications,
  ...analyticNotifications,
  ...issuerLibraryNotifications,
  ...configurationNotifications,
  ...surveillanceNotifications,
  ...issuerManagementNotifications,
  ...libraryArtifactsNotifications
};
