import { common, tableau } from 'modules/common/messages';
import { issuerSelector, issuerData, issuerSummary, statementsSelector } from 'modules/issuer/messages';
import { libraryArtifacts, libraryFilters, issuerLibrary } from 'modules/issuerLibrary/messages';
import { statementsSearch, dataView, issuerDataControl} from 'modules/issuerData/messages';
import {
  attributesForm,
  analyticRecalculation,
  bulkCalculation,
  lockedAnalytic,
  analyticDependencies,
  analyticSimulation,
  deactivatedAnalytic,
  maSharing
} from 'modules/analytic/messages';
import {activateNewIssuer, issuerManagementConfig, segmentPreview} from 'modules/issuerManagement/messages';
import {consolidatedIssuerFilter, groupForm, eventScenarioAssignment} from 'modules/configuration/messages';
import {
  surveillanceExecutionTrigger,
  surveillanceCreateTrigger,
  surveillanceEditTrigger,
  surveillanceCreateGroup,
  surveillanceEditGroup
} from 'modules/surveillance/messages';

export default {
  common,
  issuerSelector,
  issuer: {
    statementsSelector,
    dataView
  },
  issuerData,
  issuerSummary,
  statementsSearch,
  libraryArtifacts,
  libraryFilters,
  issuerLibrary,
  issuerDataView: dataView,
  issuerDataControl,
  activateNewIssuer,
  issuerManagementConfig,
  segmentPreview,
  attributesForm,
  analyticRecalculation,
  lockedAnalytic,
  analyticDependencies,
  analyticSimulation,
  bulkCalculation,
  deactivatedAnalytic,
  maSharing,
  consolidatedIssuerFilter,
  groupForm,
  eventScenarioAssignment,
  tableau,
  surveillanceExecutionTrigger,
  surveillanceCreateTrigger,
  surveillanceEditTrigger,
  surveillanceCreateGroup,
  surveillanceEditGroup
};
