export const BASE_URL = '/workbench-service';
export const BASE_API_URL = `${BASE_URL}/api`;
export const BASE_ROUTE_URL = BASE_URL;
