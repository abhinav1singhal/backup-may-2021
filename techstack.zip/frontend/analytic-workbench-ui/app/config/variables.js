import globalVariables from 'react-techstack/lib/variables';
import { assign } from 'lodash/object';

// ToDo: implement this configuration
const variables = {
  pageTopMargin: '15px',
  pageSideMargin: '10px',
  pageBottomMargin: '15px',
  pageHeaderHeight: '50px',

  pageSidebarZIndex: 300,
  modalDialogZIndex: 500,
  headerZIndex: 700,

  defaultBorderRadius: '4px',

  // main colors
  'gray-base-color': '#000',
  'gray-darker-color': '',
  'gray-dark-color': '',
  'gray-color': '',
  'gray-light-color': '',
  'gray-lighter-color': '',

  'primary-color': '#62c2ef',

  'background-color': '#fff',
  'text-color': ''
};

variables['gray-lighter'] = '#eee';
variables.gray = '#999';
variables['almost-white'] = '#f2f2f2';
variables.white = '#fff';
variables.black = '#000';
variables['gray-darker'] = '#666666';
variables['blue-darker'] = '#337ab7';
variables['table-text-color'] = '3e3e3e';

module.exports = assign({}, globalVariables, variables);
