const MESSAGES = {
  pageTitle: 'Analytic Objects Simulation'
};

export default MESSAGES;
