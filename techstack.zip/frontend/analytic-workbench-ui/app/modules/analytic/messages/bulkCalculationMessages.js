const MESSAGES = {
  pageTitle: 'Bulk Calculation'
};

export default MESSAGES;
