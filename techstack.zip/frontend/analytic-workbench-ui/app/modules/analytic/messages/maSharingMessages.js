const MESSAGES = {
  pageTitle: 'MA Sharing Management'
};

export default MESSAGES;
