const MESSAGES = {
  pageTitle: 'Analytic Object Dependencies'
};

export default MESSAGES;
