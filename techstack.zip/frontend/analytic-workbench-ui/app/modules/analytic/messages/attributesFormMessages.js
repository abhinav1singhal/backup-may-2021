const MESSAGES = {
  errorMessages: {
    NAME_ALREADY_EXISTS: 'Analytic object with name: "%s" already exists.',
    AO_ALREADY_EXISTS: 'Analytic object with names "%s" already exists',
    DEACTIVATED_AO_ALREADY_EXISTS: 'Analytic object with names "%s" already exists, but is currently deactivated',
    DUPLICATE_IN_FILE: 'File cannot contain duplicate analytic object names: "%s"',
    NAME_VALIDATOR: 'AO Name can contain only letters (a-z, A-Z), numbers (0-9), dashes, underscores (_), and not more than one period (.) in a row. Max length 60 symbols.'
  },

  locked: 'One or more of the selected analytic objects are locked. Changing of the attributes is unavailable.',
  createdAO: 'AO "%s" has been created.',

  fields: {
    lob: {label: '$message:common.lob'},
    sector: {label: '$message:common.sector'},
    region: {label: '$message:common.region'},
    country: {label: '$message:common.country'}
  }
};

export default MESSAGES;
