const MESSAGES = {
  pageTitle: 'Inactive Analytic Objects List'
};

export default MESSAGES;
