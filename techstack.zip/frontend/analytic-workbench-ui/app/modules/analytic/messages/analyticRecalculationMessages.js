const MESSAGES = {
  pageTitle: 'Analytic Objects Recalculation'
};

export default MESSAGES;
