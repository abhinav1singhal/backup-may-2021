const MESSAGES = {
  pageTitle: 'Analytic Objects List'
};

export default MESSAGES;
