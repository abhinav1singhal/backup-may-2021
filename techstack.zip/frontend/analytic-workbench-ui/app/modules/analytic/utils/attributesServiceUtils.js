import { isEqual, isArray, isPlainObject, isEmpty } from 'lodash';
import { FORM_CONTROL_TYPES } from 'react-techstack/FormBuilder';
import { UPLOAD_FILE_ACCEPT } from 'modules/analytic/utils';

export function getPropertiesConfig(isUpdate, isBulk) {
  const createFields = isUpdate ? [] : [
    {key: 'file', type: FORM_CONTROL_TYPES.FILE, label: 'File', required: true, accept: UPLOAD_FILE_ACCEPT},
    {key: 'executable', type: FORM_CONTROL_TYPES.SELECT, label: 'NON-SAF AO', required: true, multi: false, clearable: false, dictionary: { list: [{ id: true, name: 'NO'}, { id: false, name: 'YES'}]} }
  ];
  const singleAOFields = isBulk ? [] : [
    {key: 'name', type: FORM_CONTROL_TYPES.TEXT, label: 'Object Name', required: true, disabled: isUpdate, validators: ['NAME_VALIDATOR']},
    {key: 'description', type: FORM_CONTROL_TYPES.TEXTAREA, label: 'Display Name'}
  ];

  return [
    ...createFields,
    ...singleAOFields,
    {key: 'type', type: FORM_CONTROL_TYPES.SELECT, label: 'Object Type', dictionary: { dataEntityId: 'ao_type' }, disabled: isUpdate, required: !isUpdate, clearable: false},
    {key: 'privacy', type: FORM_CONTROL_TYPES.SELECT, label: 'Privacy', dictionary: { list: [{id: 'Y', name: 'Yes'}, {id: 'N', name: 'No'}] }},
    {key: 'rankorder', type: FORM_CONTROL_TYPES.NUMBER, label: 'Rank Order', validators: ['INTEGER', { key: 'MIN', min: 0 }, { key: 'MAX', max: 99999 }]},
    {key: 'valid', type: FORM_CONTROL_TYPES.DATE_RANGE, label: 'Valid', validators: ['FROM_BEFORE_TO']},
    {key: 'periodOffsetPast', type: FORM_CONTROL_TYPES.NUMBER, label: 'Period Offset (Past)', validators: ['INTEGER', { key: 'MIN', min: 0 }, { key: 'MAX', max: 99999 }]},
    {key: 'periodOffsetFuture', type: FORM_CONTROL_TYPES.NUMBER, label: 'Period Offset (Future)', validators: ['INTEGER', { key: 'MIN', min: 0 }, { key: 'MAX', max: 99999 }]},
    {key: 'orderOfExecution', type: FORM_CONTROL_TYPES.NUMBER, label: 'Order of Execution', validators: ['INTEGER', { key: 'MIN', min: 0 }, { key: 'MAX', max: 99999 }]}
  ];
}

export function unrequireForBulk(config, data, isBulk) {
  if (isBulk) {
    return config.map((item) => {
      return {
        ...item,
        required: false
      };
    });
  }

  return config;
}

export function getNotChangedFields(data, oldData) {
  if (data.uuids.length === 1) {
    return [];
  }

  function getIds(x) {
    if (isArray(x)) {
      return x.map(({ id }) => id);
    }
    if (isPlainObject(x)) {
      return x.id;
    }
    return x;
  }

  function areFieldsEqual(a, b) {
    if (isEmpty(a) && isEmpty(b)) {
      return true;
    }
    const valA = getIds(a);
    const valB = getIds(b);
    return isEqual(valA, valB);
  }

  const res = Object.keys(data).filter((key) => key !== 'valid' && areFieldsEqual(data[key], oldData[key]));
  if (oldData.valid.from === data.valid.from) {
    res.push('validFrom');
  }
  if (oldData.valid.to === data.valid.to) {
    res.push('validTo');
  }
  return res;
}
