import { hasPermission } from 'modules/common/utils/permissionsUtils';
import PropTypes from 'prop-types';
import { isArray, omit, pick, reduce, isString } from 'lodash';
import { FORM_CONTROL_TYPES } from 'react-techstack/FormBuilder';
import { analyticObjectStatuses } from 'modules/analytic/services/analyticObjectsService';
import { getMessage } from 'modules/common/utils/messagesUtils';
import { findInDictionary, findLeaf } from 'react-techstack/utils/treeSelect';

export { balanceTrees } from 'react-techstack/utils/treeSelect';

export function prepareFromConfig(config, data, dictionary) {
  const res = {};
  config.forEach(({ key, type }) => {
    const value = data[key];

    if (dictionary[key]) {
      if (type === FORM_CONTROL_TYPES.SELECT) {
        if (isArray(value)) {
          if (value.length === 0) {
            res[key] = null;
          } else {
            res[key] = findInDictionary(dictionary[key], value[0], key);
          }
        } else if (value) {
          res[key] = findInDictionary(dictionary[key], value, key);
        } else {
          res[key] = value;
        }
      } else if (type === FORM_CONTROL_TYPES.MULTISELECT) {
        res[key] = [];
        (value || []).forEach((id) => {
          const cur = findInDictionary(dictionary[key], id, key);
          if (cur) {
            res[key].push(cur);
          }
        });
      } else if (type === FORM_CONTROL_TYPES.TREEVIEW_MULTISELECT) {
        res[key] = [];
        (value || []).forEach((id) => {
          const cur = findLeaf(dictionary[key], id, key);
          if (cur) {
            res[key].push(cur);
          }
        });
      } else if (type === FORM_CONTROL_TYPES.TREEVIEW_SELECT) {
        if (isArray(value)) {
          if (value.length === 0) {
            res[key] = null;
          } else {
            res[key] = findLeaf(dictionary[key], value[0], key);
          }
        } else if (value) {
          res[key] = findLeaf(dictionary[key], value, key);
        } else {
          res[key] = value;
        }
      }
    } else {
      if (type === FORM_CONTROL_TYPES.SELECT || type === FORM_CONTROL_TYPES.MULTISELECT || type === FORM_CONTROL_TYPES.TREEVIEW_MULTISELECT || type === FORM_CONTROL_TYPES.TREEVIEW_SELECT) {
        console.warn(`No dictionary found for ${key}`); // eslint-disable-line no-console
      } else {
        res[key] = value;
      }
    }
  });

  return res;
}

export function prepareDataFromDictionary(data, dictionary, config) {
  return {
    ...omit(data, 'validFrom', 'validTo'),
    ...prepareFromConfig(config.props, data, dictionary),
    ...prepareFromConfig(config.attrs, data, dictionary),
    valid: { from: data.validFrom, to: data.validTo }
  };
}

export const analyticObjectStatusType = PropTypes.oneOf(Object.values(analyticObjectStatuses));

function getRequiredPermission(props) {
  return props.isCreateNewMode ?
    'create_new_AnalyticObject' :
    `update_${props.analyticObjectsStatus}_AnalyticObjects_attributes`;
}

export function isReadOnly(props) {
  const { locked } = props.data;
  const permission = getRequiredPermission(props);

  return locked || !hasPermission(props.userPermissions, permission);
}

function prepareBEDataFromList(data, config, isProps) {
  const res = {};
  config.forEach((item) => {
    if (item.key === 'valid') {
      return;
    }

    if (item.type === FORM_CONTROL_TYPES.SELECT || item.type === FORM_CONTROL_TYPES.MULTISELECT || item.type === FORM_CONTROL_TYPES.TREEVIEW_MULTISELECT || item.type === FORM_CONTROL_TYPES.TREEVIEW_SELECT) {
      if (isProps) {
        res[item.key] = data[item.key] ? data[item.key].id : data[item.key];
      } else {
        if (isArray(data[item.key])) {
          res[item.key] = data[item.key].map((cur) => cur.id);
        } else if (data[item.key]) {
          res[item.key] = [data[item.key].id];
        } else {
          res[item.key] = [];
        }
      }
    } else {
      res[item.key] = data[item.key];
    }
  });

  return res;
}

export function prepareBEData(data, config, omiting = []) {
  const configKeys = new Set(
    config.props.map(({ key }) => key).concat(
      config.attrs.map(({ key }) => key).concat(
        ['isDefinition', 'locked', 'uuids', 'valid']
      )
    ));
  const extraKeys = Object.keys(data).filter((key) => !configKeys.has(key));

  const res = {
    uuids: data.uuids,
    ...pick(data, 'isDefinition', 'locked'),
    properties: omit({
      ...prepareBEDataFromList(data, config.props, true),
      validFrom: data.valid.from,
      validTo: data.valid.to
    }, omiting),
    attributes: {
      ...pick(data, extraKeys),
      ...omit(prepareBEDataFromList(data, config.attrs, false), omiting)
    }
  };

  return res;
}

export function removeEmpty(data) {
  return reduce(data, (result, value, key) => {
    if (key === 'executable') {
      return {
        ...result,
        executable: value
      };
    }
    if (!value || (isString(value) && value.length === 0)) {
      return result;
    }

    result[key] = value;
    return result;
  }, {});
}

export function prepareValidatorMessage(errorCode) {
  return (fieldKey, error) => {
    const names = (error.params || []).join(', ');
    return getMessage(`attributesForm.errorMessages.${errorCode}`, names);
  };
}

export function unsetNonconfigFields(data, config) {
  const res = {};
  const configKeys = new Set(config.map(({ key }) => key));

  Object.keys(data).forEach((key) => {
    if (configKeys.has(key) || ['validFrom', 'validTo'].includes(key)) {
      res[key] = data[key];
    } else {
      res[key] = null;
    }
  });

  return res;
}
