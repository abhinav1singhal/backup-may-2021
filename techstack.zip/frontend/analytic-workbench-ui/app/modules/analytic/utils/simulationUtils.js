import { take, drop } from 'lodash/array';
import { every, some, sortBy } from 'lodash/collection';
import { transform } from 'lodash/object';
import { isArray } from 'lodash/lang';

import { prepareIssuer } from 'modules/issuer/utils/issuerUtils';

export const isStatementSelected = (id, selectedStatements) => some(selectedStatements, {id});

export const allStatementsSelected = (statements, selectedStatements) => {
  return selectedStatements.length > 0 && every(statements, ({id}) => some(selectedStatements, {id}));
};

export const getStatementsForPage = (statements, page, sortOrder) => {
  const data = take(drop(statements, page.size * (page.number - 1)), page.size);
  const sortedData = sortBy(data, sortOrder.sortKey);

  return {
    data: sortOrder.sortAscending ? sortedData : sortedData.reverse(),
    page: {
      ...page,
      totalElements: statements.length,
      totalPages: Math.ceil(statements.length / page.size)
    }
  };
};

export const transformStatementsResponse = (statements) => {
  return statements.map(({statementId, organisationName, organisationId, ...rest}) => {
    const issuer = prepareIssuer({id: organisationId, name: organisationName});

    return {
      id: statementId,
      issuer,
      ...rest
    };
  });
};

export const FILTERS_MAPPING = {
  lineOfBusiness: 'lobIds',
  sector: 'subsectorIds',
  region: 'regionIds',
  country: 'countryIds'
};

export const transformIssuersFilters = (filters) => {
  if (filters.issuerId) {
    return filters;
  }

  return transform(filters, (result, value, key) => {
    result[FILTERS_MAPPING[key]] = isArray(value) ? value.map(({id}) => parseInt(id, 10)) : [parseInt(value.id, 10)];
  });
};
