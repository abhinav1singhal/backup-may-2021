export function preparePageData({ data, page }) {
  const toIndex  = page.number * page.size;
  const fromIndex = toIndex - page.size;

  return {
    data: data.slice(fromIndex, toIndex),
    page: {
      ...page,
      totalPages: Math.ceil(page.totalElements / page.size)
    }
  };
}

export const ACCEPTABLE_UPLOAD_FILE_TYPES = [
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-excel.sheet.macroEnabled.12',
  'application/vnd.ms-excel.template.macroEnabled.12'
];

export const UPLOAD_FILE_ACCEPT = ACCEPTABLE_UPLOAD_FILE_TYPES.join();

export function isDisabledUpdateAO(analyticObjects) {
  const types = analyticObjects.reduce((acc, cur) => acc.add(cur.typeId), new Set);
  return types.size > 1;
}
