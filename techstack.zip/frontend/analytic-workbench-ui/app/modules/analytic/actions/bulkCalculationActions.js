import { ActionsNamespaceFactory } from 'react-techstack/redux';

export const actionsNamespace = ActionsNamespaceFactory('BULK_CALCULATION');

export const LOAD_BULK_ISSUERS_FILTERS = actionsNamespace.createAsyncAction('LOAD_BULK_ISSUERS_FILTERS');
export const LOAD_BULK_CALCULATION_TYPES = actionsNamespace.createAsyncAction('LOAD_BULK_CALCULATION_TYPES');
export const LOAD_BULK_ISSUER_STATEMENTS = actionsNamespace.createAsyncAction('LOAD_BULK_ISSUER_STATEMENTS');
export const SUBMIT_BATCH_CALCULATION = actionsNamespace.createAsyncAction('SUBMIT_BATCH_CALCULATION');
export const EXECUTE_BATCH_CALCULATION = actionsNamespace.createAsyncAction('EXECUTE_BATCH_CALCULATION');
export const LOAD_BULK_STATEMENTS_FILTERS = actionsNamespace.createAsyncAction('LOAD_BULK_STATEMENTS_FILTERS');
export const RESET_BULK_STATEMENTS_FILTERS = actionsNamespace.createAction('RESET_BULK_STATEMENTS_FILTERS');
export const APPLY_BULK_STATEMENTS_SORTING = actionsNamespace.createAction('APPLY_BULK_STATEMENTS_SORTING');
export const APPLY_BULK_STATEMENTS_FILTER = actionsNamespace.createAction('APPLY_BULK_STATEMENTS_FILTER');
export const TOGGLE_BULK_STATEMENT = actionsNamespace.createAction('TOGGLE_BULK_STATEMENT');
export const TOGGLE_ALL_BULK_STATEMENTS = actionsNamespace.createAsyncAction('TOGGLE_ALL_BULK_STATEMENTS');
export const TOGGLE_SELECTED_ONLY_BULK_STATEMENTS = actionsNamespace.createAction('TOGGLE_SELECTED_ONLY_BULK_STATEMENTS');
export const TOGGLE_BULK_STATEMENTS_MANUAL_SELECTION = actionsNamespace.createAction('TOGGLE_BULK_STATEMENTS_MANUAL_SELECTION');
export const SET_PAGE_NUMBER_FOR_SELECTED_ONLY_BULK_STATEMENT = actionsNamespace.createAction('SET_PAGE_NUMBER_FOR_SELECTED_ONLY_BULK_STATEMENT');

export function loadIssuersFilters() {
  return {
    type: LOAD_BULK_ISSUERS_FILTERS,
    promise: ({simulationService}) => simulationService.loadIssuersFilters()
  };
}

export function loadCalculationTypes() {
  return {
    type: LOAD_BULK_CALCULATION_TYPES,
    promise: ({bulkCalculationService}) => bulkCalculationService.loadCalculationTypes()
  };
}

export function loadIssuerStatementsFilters(issuerParams) {
  return {
    type: LOAD_BULK_STATEMENTS_FILTERS,
    promise: ({bulkCalculationService}) => bulkCalculationService.loadIssuerStatementsFilters(issuerParams)
  };
}

export function resetIssuerStatementsFilters() {
  return {
    type: RESET_BULK_STATEMENTS_FILTERS
  };
}

export function loadIssuerStatements(issuersParams, page, sortOrder, filters) {
  return {
    type: LOAD_BULK_ISSUER_STATEMENTS,
    promise: ({bulkCalculationService}) => bulkCalculationService.loadIssuerStatements(issuersParams, page, sortOrder, filters),
    meta: {
      issuersParams
    }
  };
}

export function submitBatchCalculation(calculationType, manualSelection, statements, issuerParams) {
  return {
    type: SUBMIT_BATCH_CALCULATION,
    promise: ({bulkCalculationService}) => bulkCalculationService.submitBatchCalculation(calculationType, manualSelection, statements, issuerParams)
  };
}

export function executeBatchCalculation(calculationType) {
  return {
    type: EXECUTE_BATCH_CALCULATION,
    promise: ({bulkCalculationService}) => bulkCalculationService.executeBatchCalculation(calculationType)
  };
}

export function applyStatementsSorting(sortOrder) {
  return {
    type: APPLY_BULK_STATEMENTS_SORTING,
    meta: {
      sortOrder
    }
  };
}

export function applyStatementsFilter(attributeName, options) {
  return {
    type: APPLY_BULK_STATEMENTS_FILTER,
    meta: {
      attributeName,
      options
    }
  };
}

export function toggleStatement(statement) {
  return {
    type: TOGGLE_BULK_STATEMENT,
    meta: {
      statement
    }
  };
}

export function toggleAllStatements(statementsToToggle) {
  return {
    type: TOGGLE_ALL_BULK_STATEMENTS,
    promise: () => {
      return new Promise((resolve) => {
        resolve();
      });
    },
    meta: {
      statementsToToggle
    }
  };
}

export function toggleSelectedOnly() {
  return {
    type: TOGGLE_SELECTED_ONLY_BULK_STATEMENTS
  };
}

export function toggleManualSelection() {
  return {
    type: TOGGLE_BULK_STATEMENTS_MANUAL_SELECTION
  };
}

export function setPageNumberForSelectedOnly(page) {
  return {
    type: SET_PAGE_NUMBER_FOR_SELECTED_ONLY_BULK_STATEMENT,
    meta: {
      page
    }
  };
}
