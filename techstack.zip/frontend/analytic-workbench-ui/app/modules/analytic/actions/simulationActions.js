import { ActionsNamespaceFactory } from 'react-techstack/redux';

export const actionsNamespace = ActionsNamespaceFactory('SIMULATION');

export const LOAD_ANALYTIC_OBJECTS_WITH_VERSIONS = actionsNamespace.createAsyncAction('LOAD_ANALYTIC_OBJECTS_WITH_VERSIONS');
export const LOAD_ISSUERS_FILTERS = actionsNamespace.createAsyncAction('LOAD_ISSUERS_FILTERS');
export const LOAD_ISSUER_STATEMENTS = actionsNamespace.createAsyncAction('LOAD_ISSUER_STATEMENTS');
export const LOAD_STATEMENT_ADJUSTMENTS = actionsNamespace.createAsyncAction('LOAD_STATEMENT_ADJUSTMENTS');
export const TOGGLE_STATEMENT_ADJUSTMENT = actionsNamespace.createAction('TOGGLE_STATEMENT_ADJUSTMENT');
export const CREATE_ANALYTIC_OBJECTS_SIMULATION = actionsNamespace.createAsyncAction('CREATE_ANALYTIC_OBJECTS_SIMULATION');
export const RECALCULATE_ANALYTIC_OBJECTS = actionsNamespace.createAsyncAction('RECALCULATE_ANALYTIC_OBJECTS');
export const LOAD_ISSUERS_STATEMENTS_FILTERS = actionsNamespace.createAsyncAction('LOAD_ISSUERS_STATEMENTS_FILTERS');
export const RESET_ISSUERS_STATEMENTS_FILTERS = actionsNamespace.createAction('RESET_ISSUERS_STATEMENTS_FILTERS');
export const APPLY_STATEMENTS_SORTING = actionsNamespace.createAction('APPLY_STATEMENTS_SORTING');
export const APPLY_STATEMENTS_FILTER = actionsNamespace.createAction('APPLY_STATEMENTS_FILTER');
export const TOGGLE_SIMULATION_TAB = actionsNamespace.createAction('TOGGLE_SIMULATION_TAB');
export const TOGGLE_STATEMENT = actionsNamespace.createAction('TOGGLE_STATEMENT');
export const TOGGLE_ALL_STATEMENTS = actionsNamespace.createAsyncAction('TOGGLE_ALL_STATEMENTS');
export const TOGGLE_SELECTED_ONLY = actionsNamespace.createAction('TOGGLE_SELECTED_ONLY');
export const SET_PAGE_NUMBER_FOR_SELECTED_ONLY = actionsNamespace.createAction('SET_PAGE_NUMBER_FOR_SELECTED_ONLY');

export function loadAnalyticObjectsWithVersions(analyticObjectsIds) {
  return {
    type: LOAD_ANALYTIC_OBJECTS_WITH_VERSIONS,
    promise: ({simulationService}) => simulationService.loadAnalyticObjectsWithVersions(analyticObjectsIds)
  };
}

export function loadIssuersFilters() {
  return {
    type: LOAD_ISSUERS_FILTERS,
    promise: ({simulationService}) => simulationService.loadIssuersFilters()
  };
}

export function loadIssuerStatementsFilters(issuerId) {
  return {
    type: LOAD_ISSUERS_STATEMENTS_FILTERS,
    promise: ({simulationService}) => simulationService.loadIssuerStatementsFilters(issuerId)
  };
}

export function resetIssuerStatementsFilters() {
  return {
    type: RESET_ISSUERS_STATEMENTS_FILTERS
  };
}

export function loadIssuerStatements(issuersParams, page, sortOrder, filters) {
  return {
    type: LOAD_ISSUER_STATEMENTS,
    promise: ({simulationService}) => simulationService.loadIssuerStatements(issuersParams, page, sortOrder, filters),
    meta: {
      issuersParams
    }
  };
}

export function loadStatementAdjustments(statement) {
  return {
    type: LOAD_STATEMENT_ADJUSTMENTS,
    promise: ({simulationService}) => simulationService.loadStatementAdjustments(statement),
    meta: {
      statement
    }
  };
}

export function toggleStatementAdjustment(adjustment) {
  return {
    type: TOGGLE_STATEMENT_ADJUSTMENT,
    meta: {
      adjustment
    }
  };
}

export function createAnalyticObjectsSimulation(analyticObjects, analyticObjectsVersions, statements, adjustments, simulationName) {
  return {
    type: CREATE_ANALYTIC_OBJECTS_SIMULATION,
    promise: ({simulationService}) => {
      return simulationService.createAnalyticObjectsSimulation(
        analyticObjects, analyticObjectsVersions, statements, adjustments, simulationName
      );
    }
  };
}

export function recalculateAnalyticObjects(analyticObjectsVersions, statements) {
  return {
    type: RECALCULATE_ANALYTIC_OBJECTS,
    promise: ({simulationService}) => simulationService.recalculateAnalyticObjects(analyticObjectsVersions, statements)
  };
}

export function applyStatementsSorting(sortOrder) {
  return {
    type: APPLY_STATEMENTS_SORTING,
    meta: {
      sortOrder
    }
  };
}

export function applyStatementsFilter(attributeName, options) {
  return {
    type: APPLY_STATEMENTS_FILTER,
    meta: {
      attributeName,
      options
    }
  };
}

export function toggleSimulationTab(showSingleIssuerTab) {
  return {
    type: TOGGLE_SIMULATION_TAB,
    meta: {
      showSingleIssuerTab
    }
  };
}

export function toggleStatement(statement) {
  return {
    type: TOGGLE_STATEMENT,
    meta: {
      statement
    }
  };
}

export function toggleAllStatements(showOnlySelectedMode = false, statementsToToggle) {
  return {
    type: TOGGLE_ALL_STATEMENTS,
    promise: () => {
      return new Promise((resolve) => {
        showOnlySelectedMode ? setTimeout(resolve, 400) : resolve();
      });
    },
    meta: {
      statementsToToggle
    }
  };
}

export function toggleSelectedOnly() {
  return {
    type: TOGGLE_SELECTED_ONLY
  };
}

export function setPageNumberForSelectedOnly(page) {
  return {
    type: SET_PAGE_NUMBER_FOR_SELECTED_ONLY,
    meta: {
      page
    }
  };
}
