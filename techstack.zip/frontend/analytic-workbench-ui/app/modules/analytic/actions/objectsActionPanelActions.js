import { createAsyncAction } from 'react-techstack/redux';

export const UPLOAD_NEW_ANALYTIC_OBJECT_VERSION = createAsyncAction('UPLOAD_NEW_ANALYTIC_OBJECT_VERSION');

export function uploadNewAnalyticObjectVersion(analyticObject, file) {
  return (dispatch) => {
    dispatch({
      type: UPLOAD_NEW_ANALYTIC_OBJECT_VERSION,
      promise: ({ analyticObjectsService }) => analyticObjectsService.uploadNewAnalyticObjectVersion(analyticObject, file)
    });
  };
}
