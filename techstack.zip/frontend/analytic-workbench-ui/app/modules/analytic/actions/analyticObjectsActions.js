import { createAction, createAsyncAction } from 'react-techstack/redux';

import { changeAnalyticObjectsTablePage } from 'modules/analytic/actions/analyticObjectsTableActions';
import { analyticObjectStatuses } from 'modules/analytic/services/analyticObjectsService';
import {downloadFile} from 'modules/common/actions/downloadFileActions';

import {
  getDownloadEmptyTemplateUrl,
  getDownloadAnalyticObjectUrl,
  getDownloadAnalyticObjectRevisionUrl
} from '../services/analyticObjectsService';

export const LOAD_ANALYTIC_OBJECTS = createAsyncAction('LOAD_ANALYTIC_OBJECTS');
export const LOAD_AUDIT_TRAIL_DATA = createAsyncAction('LOAD_AUDIT_TRAIL_DATA');
export const TOGGLE_SELECTED_ANALYTIC_OBJECTS = createAction('TOGGLE_SELECTED_ANALYTIC_OBJECTS');
export const UNLOCK_ANALYTIC_OBJECTS = createAsyncAction('UNLOCK_ANALYTIC_OBJECTS');
export const DEACTIVATE_ANALYTIC_OBJECTS = createAsyncAction('DEACTIVATE_ANALYTIC_OBJECTS');
export const TOGGLE_SHOW_SELECTED_ONLY = createAction('TOGGLE_SHOW_SELECTED_ONLY');
export const GET_SELECTED_OBJECTS = createAction('GET_SELECTED_OBJECTS');

export function loadAnalyticObjects(status, searchDto, page) {
  return {
    type: LOAD_ANALYTIC_OBJECTS,
    promise: ({ analyticObjectsService }) => analyticObjectsService.loadAnalyticObjects(status, searchDto, page)
  };
}

export function loadAuditTrailData(ids) {
  return {
    type: LOAD_AUDIT_TRAIL_DATA,
    promise: ({ analyticObjectsService }) => analyticObjectsService.loadAuditTrailData(ids)
  };
}

export function getSelectedObjects(status) {
  return {
    type: GET_SELECTED_OBJECTS,
    status
  };
}

export function toggleSelectedAnalyticObjects(status, selected, pageToggled, params) {
  return {
    type: TOGGLE_SELECTED_ANALYTIC_OBJECTS,
    selected,
    pageToggled,
    status,
    ...params
  };
}

export function downloadEmptyTemplate() {
  return (dispatch) => {
    dispatch(downloadFile(getDownloadEmptyTemplateUrl()));
  };
}

export function downloadAnalyticObject(id, copy) {
  return (dispatch) => {
    dispatch(downloadFile(getDownloadAnalyticObjectUrl(id, copy)));
  };
}

export function downloadAnalyticObjectRevision(id, revision) {
  return (dispatch) => {
    dispatch(downloadFile(getDownloadAnalyticObjectRevisionUrl(id, revision)));
  };
}

export function unlockAnalyticObjects(ids, status, searchDto, page) {
  return (dispatch) => {
    dispatch({
      type: UNLOCK_ANALYTIC_OBJECTS,
      promise: ({ analyticObjectsService }) => analyticObjectsService.unlockAnalyticObjects(ids)
        .then((payload) => {
          if (status === analyticObjectStatuses.LOCKED) {
            dispatch(loadAnalyticObjects(status, searchDto, page));
          }
          return payload;
        })
    });
  };
}

export function deactivateAnalyticObjects(ids) {
  return {
    type: DEACTIVATE_ANALYTIC_OBJECTS,
    promise: ({ analyticObjectsService }) => analyticObjectsService.deactivateAnalyticObjects(ids)
  };
}

export function toggleShowSelectedOnly(status, isShowingSelectedOnly) {
  return (dispatch) => {
    dispatch({
      type: TOGGLE_SHOW_SELECTED_ONLY,
      isShowingSelectedOnly
    });
    dispatch(changeAnalyticObjectsTablePage(status, { number: 1 }));
  };
}
