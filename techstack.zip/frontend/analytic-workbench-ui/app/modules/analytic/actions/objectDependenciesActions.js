import { createAction, createAsyncAction } from 'react-techstack/redux';
import {downloadFile} from 'modules/common/actions/downloadFileActions';
import {
  getLoadObjectDependenciesXlsRequestConfig
} from '../services/objectDependenciesService';

export const LOAD_OBJECT_DEPENDENCIES_DATA = createAsyncAction('LOAD_OBJECT_DEPENDENCIES_DATA');
export const OBJECT_DEPENDECIES_FILTERS = createAsyncAction('OBJECT_DEPENDECIES_FILTERS');
export const LOAD_TABLE_ELEMENT_DEPENDENCIES_DATA = createAsyncAction('LOAD_TABLE_ELEMENT_DEPENDENCIES_DATA');
export const LOAD_OBJECT_DEPENDECIES_XLS_FILE = createAction('LOAD_OBJECT_DEPENDECIES_XLS_FILE');

export function loadObjectDependencies(id, filters) {
  return {
    type: LOAD_OBJECT_DEPENDENCIES_DATA,
    meta: {filtersValue: filters},
    promise: ({ objectDependenciesService }) => {
      return objectDependenciesService.loadObjectDependencies(id, {
        dependency: filters.dependency.length ? filters.dependency.map((el) => el.id) : [],
        dependencyType: filters.dependencyType.length ? filters.dependencyType.map((el) => el.id) : [],
        objectType: filters.objectType.length ? filters.objectType.map((el) => el.id) : []
      });
    }
  };
}

export function loadObjectDependenciesFilters() {
  return {
    type: OBJECT_DEPENDECIES_FILTERS,
    promise: ({ objectDependenciesService }) => {
      return objectDependenciesService.loadObjectDependenciesFilters();
    }
  };
}

export function loadObjectSubDependencies(item, dependency, filters, level, expended) {
  return {
    type: LOAD_TABLE_ELEMENT_DEPENDENCIES_DATA,
    meta: {
      item,
      dependency,
      level,
      expended
    },
    promise: ({ objectDependenciesService }) => {
      return objectDependenciesService.loadObjectDependencies(item.id, {
        dependency: [dependency.id],
        dependencyType: filters.dependencyType.length ? filters.dependencyType.map((el) => el.id) : [],
        objectType: filters.objectType.length ? filters.objectType.map((el) => el.id) : []
      });
    }
  };
}

export function loadObjectDependenciesXlsFile(id, filters) {
  const getDownloadDependenciesData = getLoadObjectDependenciesXlsRequestConfig(
    id,
    {
      dependency: filters.dependency.map((el) => el.id),
      dependencyType: filters.dependencyType.map((el) => el.id),
      objectType: filters.objectType.map((el) => el.id)
    }
  );
  return (dispatch) => {
    dispatch(downloadFile(getDownloadDependenciesData.url, getDownloadDependenciesData.params));
    dispatch({
      type: LOAD_OBJECT_DEPENDECIES_XLS_FILE,
      meta: {filtersValue: filters}
    });
  };
}
