/* global beforeEach afterEach describe it */
/* eslint-disable no-console */

import expect from 'expect';

import {
  LOAD_ANALYTIC_OBJECT_VERSIONS,
  loadAnalyticObjectVersions,
  openVersionsDrillDown,
  closeVersionsDrillDown
} from '../versionsActions';

describe('app.modules.analytic.actions.__tests__.versionsActionsSpec', () => {
  it('should create an action to openVersionsDrillDown', () => {
    const realAction = openVersionsDrillDown('', '');

    expect(
      'function'
    ).toEqual(
      typeof(realAction)
    );
  });

  it('should create an action to closeVersionsDrillDown', () => {
    const realAction = closeVersionsDrillDown();

    expect(
      'function'
    ).toEqual(
      typeof(realAction)
    );
  });

  it('should create an action to loadAnalyticObjectVersions', () => {
    const mockId = 1;
    const expectedAction = {
      type: LOAD_ANALYTIC_OBJECT_VERSIONS,
      id: mockId
    };
    const realAction = loadAnalyticObjectVersions(mockId);
    const mockPromise = {
      versionsService: {
        loadAnalyticObjectVersions: (id) => id
      }
    };

    expect(
      expectedAction.type
    ).toEqual(
      realAction.type
    );
    expect(
      expectedAction.id
    ).toEqual(
      realAction.id
    );
    expect(
      mockId
    ).toEqual(
      realAction.promise(mockPromise)
    );
  });
});
