/* global beforeEach afterEach describe it */
/* eslint-disable no-console */

import expect from 'expect';

import {
  RESET_FILTERS,
  APPLY_NAME_SEARCH,
  APPLY_ATTRIBUTE_FILTER,
  resetFilters,
  applyNameSearch,
  applyAttributeFilter
} from '../attributesFilterActions.js';

describe('app.modules.analytic.actions.__tests__.attributesFilterActionsSpec', () => {
  it('should create an action to resetFilters', () => {
    const expectedAction = {
      type: RESET_FILTERS
    };

    expect(expectedAction).toEqual(resetFilters());
  });

  it('should create an action to applyNameSearch', () => {
    const needle = 'needle';
    const expectedAction = {
      type: APPLY_NAME_SEARCH,
      needle
    };

    expect(expectedAction).toEqual(applyNameSearch(needle));
  });

  it('should create an action to applyAttributeFilter', () => {
    const attributeName = 'some string';
    const options = [1, 2, 3, 4, 5, 6];
    const expectedAction = {
      type: APPLY_ATTRIBUTE_FILTER,
      attributeName,
      options
    };

    expect(expectedAction).toEqual(applyAttributeFilter(attributeName, options));
  });
});
