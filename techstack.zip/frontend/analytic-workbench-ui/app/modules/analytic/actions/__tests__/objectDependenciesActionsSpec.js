/* global beforeEach afterEach describe it xit */
/* eslint-disable no-console */

import expect from 'expect';

import {
  LOAD_OBJECT_DEPENDENCIES_DATA,
  OBJECT_DEPENDECIES_FILTERS,
  LOAD_OBJECT_DEPENDECIES_XLS_FILE,
  LOAD_TABLE_ELEMENT_DEPENDENCIES_DATA,
  loadObjectDependencies,
  loadObjectDependenciesFilters,
  loadObjectDependenciesXlsFile,
  loadObjectSubDependencies
} from '../objectDependenciesActions';
import {FILE_DOWNLOAD} from '../../../common/actions/downloadFileActions';


let spy;

describe('app.modules.analytic.actions.__tests__.objectDependenciesActionsSpec', () => {
  beforeEach(() => (spy = expect.createSpy()));
  afterEach(() => (spy = null));

  const filters = {
    dependency: [{ id: 1 }, { id: 2 }],
    dependencyType: [{ id: 1 }, { id: 2 }],
    objectType: [{ id: 1 }, { id: 2 }]
  };

  it('should create an action to loadObjectDependencies', () => {
    const id = 1;
    const promiseSpy = expect.createSpy();
    const promiseMock = {
      objectDependenciesService: {
        loadObjectDependencies: promiseSpy
      }
    };
    const expectedAction = {
      type: LOAD_OBJECT_DEPENDENCIES_DATA,
      meta: {filtersValue: filters}
    };
    const expectedArguments = {
      id,
      filters: {
        dependency: filters.dependency.length ? filters.dependency.map((el) => el.id) : [],
        dependencyType: filters.dependencyType.length ? filters.dependencyType.map((el) => el.id) : [],
        objectType: filters.objectType.length ? filters.objectType.map((el) => el.id) : []
      }
    };

    const realAction = loadObjectDependencies(id, filters);
    realAction.promise(promiseMock);

    expect(
      expectedAction.type
    ).toEqual(
      realAction.type
    );
    expect(
      expectedAction.meta
    ).toEqual(
      realAction.meta
    );
    expect(
      promiseSpy
    ).toHaveBeenCalledWith(
      expectedArguments.id,
      expectedArguments.filters
    );
  });

  it('should create an action to loadObjectDependenciesFilters', () => {
    const promiseSpy = expect.createSpy();
    const promiseMock = {
      objectDependenciesService: {
        loadObjectDependenciesFilters: promiseSpy
      }
    };
    const expectedAction = {
      type: OBJECT_DEPENDECIES_FILTERS
    };
    const realAction = loadObjectDependenciesFilters();
    realAction.promise(promiseMock);

    expect(
      expectedAction.type
    ).toEqual(
      realAction.type
    );
    expect(
      promiseSpy
    ).toHaveBeenCalled();
  });

  it('should create an action to loadObjectDependenciesXlsFile', () => {
    const id = 1;

    loadObjectDependenciesXlsFile(id, filters)(spy);
    const [{ type: type0, promise }] = spy.calls[0].arguments;
    const [{ type: type1, meta }] = spy.calls[1].arguments;

    expect(type0).toEqual(FILE_DOWNLOAD);
    expect(type1).toEqual(LOAD_OBJECT_DEPENDECIES_XLS_FILE);
    expect(typeof promise).toEqual('function');
    expect(meta).toEqual({ filtersValue: filters });
  });

  it('should create an action to loadObjectSubDependencies', () => {
    const item = {
      id: 1
    };
    const dependency = {
      id: 1
    };
    const level = 1;
    const expended = true;
    const promiseSpy = expect.createSpy();
    const mockPromise = {
      objectDependenciesService: {
        loadObjectDependencies: promiseSpy
      }
    };

    const expectedArguments = {
      id: item.id,
      dependencies: {
        dependency: [dependency.id],
        dependencyType: filters.dependencyType.length ? filters.dependencyType.map((el) => el.id) : [],
        objectType: filters.objectType.length ? filters.objectType.map((el) => el.id) : []
      }
    };
    const expectedAction = {
      type: LOAD_TABLE_ELEMENT_DEPENDENCIES_DATA,
      meta: {
        item,
        dependency,
        level,
        expended
      }
    };
    const realAction = loadObjectSubDependencies(item, dependency, filters, level, expended);
    realAction.promise(mockPromise);

    expect(
      expectedAction.type
    ).toEqual(
      realAction.type
    );
    expect(
      expectedAction.meta
    ).toEqual(
      realAction.meta
    );
    expect(
      promiseSpy
    ).toHaveBeenCalledWith(
      expectedArguments.id,
      expectedArguments.dependencies
    );
  });
});
