/* global beforeEach afterEach describe it xit */
/* eslint-disable no-console */

import expect from 'expect';
import { analyticObjectStatuses } from 'modules/analytic/services/analyticObjectsService';

import { changeAnalyticObjectsTablePage, reloadAnalyticObjectsTable } from '../analyticObjectsTableActions.js';
import {createAction, createAsyncAction} from 'react-techstack/lib/redux';


let spy;

describe('app.modules.analytic.actions.__tests__.analyticObjectsTableActionsSpec', () => {
  beforeEach(() => (spy = expect.createSpy()));
  afterEach(() => (spy = null));

  it('should create a CHANGE_PAGE action when called `changeAnalyticObjectsTablePage` with INACTIVE', () => {
    const pageNumber = 3;
    const CHANGE_PAGE = createAction('CHANGE_PAGE');

    changeAnalyticObjectsTablePage(analyticObjectStatuses.INACTIVE, pageNumber)(spy);

    const [{ type, page }] = spy.calls[0].arguments;
    const [{ payload: { args: [path] } }] = spy.calls[1].arguments;

    expect(type).toEqual(CHANGE_PAGE);
    expect(page).toBe(pageNumber);
    expect(path).toMatch(/\/inactive$/);
  });

  it('should create a CHANGE_PAGE action when called `changeAnalyticObjectsTablePage` with ACTIVE', () => {
    const pageNumber = 8;
    changeAnalyticObjectsTablePage(analyticObjectStatuses.ACTIVE, pageNumber)(spy);

    const [{ payload: { args: [path] } }] = spy.calls[1].arguments;
    expect(path).toNotMatch(/!(inactive|locked)$/);
  });

  it('should create a CHANGE_PAGE action when called `changeAnalyticObjectsTablePage` with LOCKED', () => {
    const pageNumber = 9;
    changeAnalyticObjectsTablePage(analyticObjectStatuses.LOCKED, pageNumber)(spy);

    const [{ payload: { args: [path] } }] = spy.calls[1].arguments;
    expect(path).toMatch(/\/locked$/);
  });

  it('should create a CHANGE_PAGE action when `reloadAnalyticObjectsTable` called with 0 page', () => {
    const status = analyticObjectStatuses.ACTIVE;
    const CHANGE_PAGE = createAction('CHANGE_PAGE');
    const searchDto = ' ';
    const page = {
      number: 0
    };
    const page2 = {
      number: 1
    };

    reloadAnalyticObjectsTable(status, searchDto, page)(spy);
    const [{ type, page: _page }] = spy.calls[0].arguments;

    expect(type).toEqual(CHANGE_PAGE);
    expect(_page).toEqual(page2);
  });

  it('should create a CHANGE_PAGE action when `reloadAnalyticObjectsTable` called with no page specified', () => {
    const status = analyticObjectStatuses.ACTIVE;
    const CHANGE_PAGE = createAction('CHANGE_PAGE');
    const searchDto = ' ';
    const page2 = {
      number: 1
    };

    reloadAnalyticObjectsTable(status, searchDto)(spy);
    const [{ type, page: _page }] = spy.calls[0].arguments;

    expect(type).toEqual(CHANGE_PAGE);
    expect(_page).toEqual(page2);
  });

  it('should create a LOAD_ANALYTIC_OBJECTS action when `reloadAnalyticObjectsTable` called with page 1', () => {
    const status = analyticObjectStatuses.ACTIVE;
    const LOAD_ANALYTIC_OBJECTS = createAsyncAction('LOAD_ANALYTIC_OBJECTS');
    const searchDto = ' ';
    const page2 = {
      number: 1
    };

    const { type, promise } = reloadAnalyticObjectsTable(status, searchDto, page2);
    expect(type).toEqual(LOAD_ANALYTIC_OBJECTS);
    expect(typeof promise).toEqual('function');
  });

});
