/* global beforeEach afterEach describe it xit */
/* eslint-disable no-console */

import expect from 'expect';

import {
  LOAD_ANALYTIC_OBJECTS_WITH_VERSIONS, LOAD_ISSUERS_FILTERS, LOAD_ISSUERS_STATEMENTS_FILTERS,
  LOAD_ISSUER_STATEMENTS, CREATE_ANALYTIC_OBJECTS_SIMULATION, RECALCULATE_ANALYTIC_OBJECTS,
  APPLY_STATEMENTS_SORTING, APPLY_STATEMENTS_FILTER, TOGGLE_SIMULATION_TAB, TOGGLE_STATEMENT,
  TOGGLE_ALL_STATEMENTS, TOGGLE_SELECTED_ONLY,
  loadAnalyticObjectsWithVersions, loadIssuersFilters, loadIssuerStatementsFilters,
  loadIssuerStatements, createAnalyticObjectsSimulation, recalculateAnalyticObjects,
  applyStatementsSorting, applyStatementsFilter, toggleSimulationTab, toggleStatement,
  toggleAllStatements, toggleSelectedOnly
} from '../simulationActions';

describe('app.modules.analytic.actions.__tests__.simulationActionsSpec', () => {

  it('should create an action to loadAnalyticObjectsWithVersions', () => {
    const mockedAnalyticObjectIds = ['123', '234', '345'];

    const realAction = loadAnalyticObjectsWithVersions(mockedAnalyticObjectIds);
    const mockPromise = {
      simulationService: {
        loadAnalyticObjectsWithVersions: (analyticObjectIds) => analyticObjectIds
      }
    };

    expect(LOAD_ANALYTIC_OBJECTS_WITH_VERSIONS).toEqual(realAction.type);
    expect(mockedAnalyticObjectIds).toEqual(realAction.promise(mockPromise));
  });

  it('should create an action to loadIssuersFilters', () => {
    const promiseSpy = expect.createSpy();
    const realAction = loadIssuersFilters();
    const mockPromise = {
      simulationService: {
        loadIssuersFilters: promiseSpy
      }
    };

    expect(LOAD_ISSUERS_FILTERS).toEqual(realAction.type);
    realAction.promise(mockPromise);
    expect(promiseSpy).toHaveBeenCalled();
  });

  it('should create an action to loadIssuerStatementsFilters', () => {
    const promiseSpy = expect.createSpy();
    const realAction = loadIssuerStatementsFilters();
    const mockPromise = {
      simulationService: {
        loadIssuerStatementsFilters: promiseSpy
      }
    };

    expect(LOAD_ISSUERS_STATEMENTS_FILTERS).toEqual(realAction.type);
    realAction.promise(mockPromise);
    expect(promiseSpy).toHaveBeenCalled();
  });

  it('should create an action to loadIssuerStatements', () => {
    const promiseSpy = expect.createSpy();
    const realAction = loadIssuerStatements();
    const mockPromise = {
      simulationService: {
        loadIssuerStatements: promiseSpy
      }
    };

    expect(LOAD_ISSUER_STATEMENTS).toEqual(realAction.type);
    realAction.promise(mockPromise);
    expect(promiseSpy).toHaveBeenCalled();
  });

  it('should create an action to createAnalyticObjectsSimulation', () => {
    const promiseSpy = expect.createSpy();
    const realAction = createAnalyticObjectsSimulation();
    const mockPromise = {
      simulationService: {
        createAnalyticObjectsSimulation: promiseSpy
      }
    };

    expect(CREATE_ANALYTIC_OBJECTS_SIMULATION).toEqual(realAction.type);
    realAction.promise(mockPromise);
    expect(promiseSpy).toHaveBeenCalled();
  });

  it('should create an action to recalculateAnalyticObjects', () => {
    const promiseSpy = expect.createSpy();
    const realAction = recalculateAnalyticObjects();
    const mockPromise = {
      simulationService: {
        recalculateAnalyticObjects: promiseSpy
      }
    };

    expect(RECALCULATE_ANALYTIC_OBJECTS).toEqual(realAction.type);
    realAction.promise(mockPromise);
    expect(promiseSpy).toHaveBeenCalled();
  });

  it('should create an action to applyStatementsSorting', () => {
    const sortOrder = 'ASC';
    expect({
      type: APPLY_STATEMENTS_SORTING,
      meta: { sortOrder }
    }).toEqual(applyStatementsSorting(sortOrder));
  });

  it('should create an action to applyStatementsFilter', () => {
    const attributeName = 'testAttributeName';
    const options = { x: 1, y: 2 };
    expect({
      type: APPLY_STATEMENTS_FILTER,
      meta: {
        attributeName,
        options
      }
    }).toEqual(applyStatementsFilter(attributeName, options));
  });

  it('should create an action to toggleSimulationTab', () => {
    expect({
      type: TOGGLE_SIMULATION_TAB,
      meta: {
        showSingleIssuerTab: true
      }
    }).toEqual(toggleSimulationTab(true));
  });

  it('should create an action to toggleStatement', () => {
    const statement = 'dummyTestStatement';
    expect({
      type: TOGGLE_STATEMENT,
      meta: { statement }
    }).toEqual(toggleStatement(statement));
  });

  it('should create an action to toggleAllStatements', () => {
    const { type, promise } = toggleAllStatements();
    expect(type).toEqual(TOGGLE_ALL_STATEMENTS);
    expect(typeof promise).toEqual('function');
  });

  it('should create an action to toggleSelectedOnly', () => {
    expect({
      type: TOGGLE_SELECTED_ONLY
    }).toEqual(toggleSelectedOnly());
  });
});
