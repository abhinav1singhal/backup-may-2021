/* global beforeEach afterEach describe it xit */
/* eslint-disable no-console */

import expect from 'expect';

import {
  toggleSelectedAnalyticObjects,
  downloadEmptyTemplate,
  downloadAnalyticObject,
  downloadAnalyticObjectRevision,
  TOGGLE_SELECTED_ANALYTIC_OBJECTS
} from '../analyticObjectsActions.js';
import {FILE_DOWNLOAD} from '../../../common/actions/downloadFileActions';


let spy;

describe('app.modules.analytic.actions.__tests__.analyticObjectsActionsSpec', () => {
  beforeEach(() => (spy = expect.createSpy()));
  afterEach(() => (spy = null));

  it('should create an action to TOGGLE_SELECTED_ANALYTIC_OBJECTS', () => {
    const status = 'status';
    const objectId = 2;
    const expectedAction = {
      type: TOGGLE_SELECTED_ANALYTIC_OBJECTS,
      status,
      selected: true,
      pageToggled: false,
      objectId
    };
    expect(toggleSelectedAnalyticObjects(status, true, false, { objectId })).toEqual(expectedAction);
  });

  it('should create an async FILE_DOWNLOAD action when `downloadEmptyTemplate` called', () => {
    downloadEmptyTemplate()(spy);
    const [{ type, promise }] = spy.calls[0].arguments;

    expect(type).toEqual(FILE_DOWNLOAD);
    expect(typeof promise).toEqual('function');
  });

  it('should create an async FILE_DOWNLOAD action when `downloadAnalyticObject` called', () => {
    const id = '1';
    const copy = true;
    downloadAnalyticObject(id, copy)(spy);

    const [{ type, promise }] = spy.calls[0].arguments;
    expect(type).toEqual(FILE_DOWNLOAD);
    expect(typeof promise).toEqual('function');
  });

  it('should create an async FILE_DOWNLOAD action when `downloadAnalyticObjectRevision` called', () => {
    const id = '1';
    const revision = 13;
    downloadAnalyticObjectRevision(id, revision)(spy);

    const [{ type, promise }] = spy.calls[0].arguments;
    expect(type).toEqual(FILE_DOWNLOAD);
    expect(typeof promise).toEqual('function');
  });

});
