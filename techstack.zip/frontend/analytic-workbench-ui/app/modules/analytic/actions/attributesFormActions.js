import { ActionsNamespaceFactory } from 'react-techstack/redux';

import { reloadAnalyticObjectsTable } from './analyticObjectsTableActions';
import { analyticObjectStatuses } from 'modules/analytic/services/analyticObjectsService';

export const actionsNamespace = ActionsNamespaceFactory('ATTRIBUTES_FORM');

export const LOAD_UPDATE_FORM = actionsNamespace.createAsyncAction('LOAD_UPDATE_FORM');
export const SAVE_UPDATE_FORM = actionsNamespace.createAsyncAction('SAVE_UPDATE_FORM');
export const LOAD_CREATE_FORM = actionsNamespace.createAsyncAction('LOAD_CREATE_FORM');
export const SAVE_CREATE_FORM = actionsNamespace.createAsyncAction('SAVE_CREATE_FORM');
export const UPDATE_ATTRIBUTES_FOR_TYPE = actionsNamespace.createAsyncAction('UPDATE_ATTRIBUTES_FOR_TYPE');

export function loadUpdateForm(ids) {
  return {
    type: LOAD_UPDATE_FORM,
    promise: ({ attributesFormService }) => attributesFormService.loadUpdateForm(ids)
  };
}

export function saveUpdateForm(formData, tableOptions) {
  return (dispatch, getState) => {
    const { config, data } = getState().attributesForm;
    dispatch({
      type: SAVE_UPDATE_FORM,
      promise: ({ attributesFormService }) => attributesFormService.saveUpdateForm(formData, config, data).then(() => {
        dispatch(reloadAnalyticObjectsTable(analyticObjectStatuses.ACTIVE, tableOptions.searchDto, tableOptions.page));
      })
    });
  };
}

export function loadCreateForm(file) {
  return (dispatch) => {
    dispatch({
      type: UPDATE_ATTRIBUTES_FOR_TYPE.RESET
    });
    dispatch({
      type: LOAD_CREATE_FORM,
      promise: ({ attributesFormService }) => attributesFormService.loadCreateForm(file)
    });
  };
}

export function saveCreateForm(formData, tableOptions) {
  return (dispatch, getState) => {
    const { config } = getState().attributesForm;
    dispatch({
      type: SAVE_CREATE_FORM,
      aoName: formData.name,
      promise: ({ attributesFormService }) => attributesFormService.saveCreateForm(formData, config).then(() => {
        dispatch(reloadAnalyticObjectsTable(analyticObjectStatuses.ACTIVE, tableOptions.searchDto, tableOptions.page));
      })
    });
  };

}

export function updateAttributesForType(typeId) {
  return (dispatch, getState) => {
    const { attributesForm } = getState();
    dispatch({
      type: UPDATE_ATTRIBUTES_FOR_TYPE,
      promise: ({ attributesFormService }) => attributesFormService.updateAttributesForType(typeId, attributesForm)
    });
  };
}
