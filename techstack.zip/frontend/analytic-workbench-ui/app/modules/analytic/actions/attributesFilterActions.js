import { createAction, createAsyncAction } from 'react-techstack/redux';

export const LOAD_ATTRIBUTES = createAsyncAction('LOAD_ATTRIBUTES');
export const RESET_FILTERS = createAction('RESET_FILTERS');
export const APPLY_NAME_SEARCH = createAction('APPLY_NAME_SEARCH');
export const APPLY_ATTRIBUTE_FILTER = createAction('APPLY_ATTRIBUTE_FILTER');

export function loadAttributes() {
  return {
    type: LOAD_ATTRIBUTES,
    promise: ({ attributesService }) => attributesService.loadAttributes()
  };
}

export function resetFilters() {
  return {
    type: RESET_FILTERS
  };
}

export function applyNameSearch(needle: string) {
  return {
    type: APPLY_NAME_SEARCH,
    needle
  };
}

export function applyAttributeFilter(attributeName: string, options: Array) {
  return {
    type: APPLY_ATTRIBUTE_FILTER,
    attributeName,
    options
  };
}
