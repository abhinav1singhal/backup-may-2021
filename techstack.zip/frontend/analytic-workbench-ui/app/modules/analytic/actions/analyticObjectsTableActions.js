import { routerActions } from 'react-router-redux';
import { createAction } from 'react-techstack/redux';

import { analyticObjectStatuses } from 'modules/analytic/services/analyticObjectsService';
import { loadAnalyticObjects } from './analyticObjectsActions';

export const CHANGE_PAGE = createAction('CHANGE_PAGE');

export function getBaseUrl(status) {
  const baseUrl = '/analytic-objects';

  switch (status) {
    case analyticObjectStatuses.INACTIVE:
      return `${baseUrl}/inactive`;
    case analyticObjectStatuses.LOCKED:
      return `${baseUrl}/locked`;
    case analyticObjectStatuses.ACTIVE:
    default:
      return baseUrl;
  }
}

export function changeAnalyticObjectsTablePage(status, page) {
  return (dispatch) => {
    dispatch({
      type: CHANGE_PAGE,
      page
    });
    dispatch(routerActions.push(getBaseUrl(status)));
  };
}

export function reloadAnalyticObjectsTable(status, searchDto, page = {}) {
  if (page.number === 1) {
    return loadAnalyticObjects(status, searchDto, page);
  }

  return changeAnalyticObjectsTablePage(status, { number: 1 });
}
