import { createAction, createAsyncAction } from 'react-techstack/redux';
import { routerActions } from 'react-router-redux';

export const OPEN_VERSIONS_DRILL_DOWN = createAction('OPEN_VERSIONS_DRILL_DOWN');
export const CLOSE_VERSIONS_DRILL_DOWN = createAction('CLOSE_VERSIONS_DRILL_DOWN');
export const LOAD_ANALYTIC_OBJECT_VERSIONS = createAsyncAction('LOAD_ANALYTIC_OBJECT_VERSIONS');
export const APPROVE_ANALYTIC_OBJECT_VERSION = createAsyncAction('APPROVE_ANALYTIC_OBJECT_VERSION');
export const LOAD_APPROVE_VERSION_DATA = createAsyncAction('LOAD_APPROVE_VERSION_DATA');

export function openVersionsDrillDown(openUrl: string, closeUrl: string) {
  return (dispatch) => {
    dispatch({
      type: OPEN_VERSIONS_DRILL_DOWN,
      closeUrl
    });
    dispatch(routerActions.push(openUrl));
  };
}

export function closeVersionsDrillDown() {
  return (dispatch, getState) => {
    const state = getState();
    const closeUrl = state.versions._meta.closeUrl || '/';
    dispatch({
      type: CLOSE_VERSIONS_DRILL_DOWN
    });
    dispatch(routerActions.push(closeUrl));
  };
}

export function loadAnalyticObjectVersions(id: string) {
  return {
    type: LOAD_ANALYTIC_OBJECT_VERSIONS,
    id,
    promise: ({ versionsService }) => versionsService.loadAnalyticObjectVersions(id)
  };
}

export function approveAnalyticObjectVersion(objectId, { value: version }) {
  return {
    type: APPROVE_ANALYTIC_OBJECT_VERSION,
    promise: ({ versionsService }) => {
      if (version !== null) {
        return versionsService.approveAnalyticObjectVersion(objectId, version);
      }

      return versionsService.withdrawAnalyticObjectsVersion(objectId);
    }
  };
}

export function loadApproveVersionData(objectId) {
  return {
    type: LOAD_APPROVE_VERSION_DATA,
    promise: ({ versionsService }) => versionsService.loadApproveVersionData(objectId)
  };
}
