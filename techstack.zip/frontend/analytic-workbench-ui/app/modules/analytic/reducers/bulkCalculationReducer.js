import { handleActions } from 'react-techstack/redux';
import { filter, some } from 'lodash/collection';
import {
  LOAD_BULK_ISSUERS_FILTERS, LOAD_BULK_STATEMENTS_FILTERS, LOAD_BULK_ISSUER_STATEMENTS,
  APPLY_BULK_STATEMENTS_SORTING, APPLY_BULK_STATEMENTS_FILTER, TOGGLE_BULK_STATEMENT,
  TOGGLE_ALL_BULK_STATEMENTS, TOGGLE_SELECTED_ONLY_BULK_STATEMENTS, SET_PAGE_NUMBER_FOR_SELECTED_ONLY_BULK_STATEMENT,
  RESET_BULK_STATEMENTS_FILTERS, LOAD_BULK_CALCULATION_TYPES, TOGGLE_BULK_STATEMENTS_MANUAL_SELECTION
} from '../actions/bulkCalculationActions';
import { allStatementsSelected, isStatementSelected } from '../utils/simulationUtils';

const initialState = {
  issuersFilters: {},
  calculationTypes: [],
  totalIssuers: null,
  statementsRequestIssuersParams: {},
  section: {
    statements: [],
    selectedStatements: [],
    manualSelection: false,
    showOnlySelected: false,
    pageNumberForSelectedOnly: 1
  },
  sortOrder: {
    sortKey: '',
    sortAscending: false
  },
  statementFilters: {
    data: {},
    filters: {}
  },
  page: {
    number: 1,
    totalPages: 1
  }
};

export const getInitialState = () => {
  return initialState;
};

export default handleActions({

  [LOAD_BULK_ISSUERS_FILTERS.SUCCESS](state, action) {
    return {
      ...state,
      issuersFilters: action.payload
    };
  },

  [LOAD_BULK_CALCULATION_TYPES.SUCCESS](state, action) {
    return {
      ...state,
      calculationTypes: action.payload
    };
  },

  [LOAD_BULK_STATEMENTS_FILTERS.REQUEST](state) {
    return {
      ...state,
      statementFilters: {
        ...state.statementFilters,
        data: initialState.statementFilters.data
      }
    };
  },

  [LOAD_BULK_STATEMENTS_FILTERS.SUCCESS](state, {payload}) {
    return {
      ...state,
      statementFilters: {
        ...state.statementFilters,
        data: payload
      }
    };
  },

  [RESET_BULK_STATEMENTS_FILTERS](state) {
    return {
      ...state,
      statementFilters: initialState.statementFilters
    };
  },

  [LOAD_BULK_ISSUER_STATEMENTS.REQUEST](state) {
    return {
      ...state,
      statements: initialState.section.statements,
      showOnlySelected: initialState.section.showOnlySelected,
      manualSelection: initialState.section.manualSelection
    };
  },

  [LOAD_BULK_ISSUER_STATEMENTS.SUCCESS](state, {payload, meta: {issuersParams}}) {
    return {
      ...state,
      section: {
        ...state.section,
        statements: payload.statementRevisions
      },
      totalIssuers: payload.totalIssuers,
      page: payload.page || initialState.page,
      sortOrder: payload.sortOrder || initialState.sortOrder,
      statementsRequestIssuersParams: issuersParams
    };
  },

  [APPLY_BULK_STATEMENTS_SORTING](state, {meta: {sortOrder}}) {
    return {
      ...state,
      sortOrder
    };
  },

  [APPLY_BULK_STATEMENTS_FILTER](state, {meta: {attributeName, options}}) {
    return {
      ...state,
      statementFilters: {
        ...state.statementFilters,
        filters: {
          ...state.statementFilters.filters,
          [attributeName]: options
        }
      }
    };
  },

  [TOGGLE_BULK_STATEMENT](state, {meta: {statement}}) {
    const { selectedStatements } = state.section;
    let updatedSelectedStatements;

    if (isStatementSelected(statement.id, selectedStatements)) {
      updatedSelectedStatements = filter(selectedStatements, ({id}) =>  id !== statement.id);
    } else {
      updatedSelectedStatements = [...selectedStatements, statement];
    }

    return {
      ...state,
      section: {
        ...state.section,
        selectedStatements: updatedSelectedStatements
      }
    };
  },

  [TOGGLE_ALL_BULK_STATEMENTS.SUCCESS](state, {meta: {statementsToToggle}}) {
    const {selectedStatements, showOnlySelected} = state.section;
    let updatedSelectedStatements;

    if (showOnlySelected || allStatementsSelected(statementsToToggle, selectedStatements)) {
      updatedSelectedStatements = selectedStatements.filter(({id}) => !some(statementsToToggle, {id}));
    } else {
      const notSelectedStatements = statementsToToggle.filter(({id}) => !isStatementSelected(id, selectedStatements));
      updatedSelectedStatements = [...selectedStatements, ...notSelectedStatements];
    }

    return {
      ...state,
      section: {
        ...state.section,
        selectedStatements: updatedSelectedStatements
      }
    };
  },

  [TOGGLE_SELECTED_ONLY_BULK_STATEMENTS](state) {
    return {
      ...state,
      section: {
        ...state.section,
        showOnlySelected: !state.section.showOnlySelected
      }
    };
  },

  [TOGGLE_BULK_STATEMENTS_MANUAL_SELECTION](state) {
    return {
      ...state,
      section: {
        ...state.section,
        selectedStatements: [],
        manualSelection: !state.section.manualSelection
      }
    };
  },

  [SET_PAGE_NUMBER_FOR_SELECTED_ONLY_BULK_STATEMENT](state, {meta}) {
    return {
      ...state,
      section: {
        ...state.section,
        pageNumberForSelectedOnly: meta.page.number
      },
      page: {
        ...state.page,
        size: meta.page.size
      }
    };
  }

}, getInitialState());
