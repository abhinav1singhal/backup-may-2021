import ImmutableStore from 'immutable-store';
import { handleActions } from 'react-techstack/redux';
import { asyncStatus } from 'react-techstack/utils';
import {
  OPEN_VERSIONS_DRILL_DOWN,
  CLOSE_VERSIONS_DRILL_DOWN,
  LOAD_ANALYTIC_OBJECT_VERSIONS,
  LOAD_APPROVE_VERSION_DATA
} from '../actions/versionsActions';

export const getInitialState = () => {
  return ImmutableStore({
    data: [],
    approveVersionData: {
      dependencies: [],
      versions: [],
      approvedVersion: null
    },
    _meta: {
      closeUrl: null
    },
    loadingStatus: asyncStatus.NONE,
    isLoading: () => {
      return {
        value: false,
        deps: {
          loadingStatus: [ 'loadingStatus' ]
        },
        get: (value, deps) => {
          return deps.loadingStatus === asyncStatus.REQUEST;
        }
      };
    }
  });
};

export default handleActions({

  [OPEN_VERSIONS_DRILL_DOWN](state, action) {
    if (action.closeUrl) {
      return state.set('_meta', { closeUrl: action.closeUrl });
    }
    return state;
  },

  [CLOSE_VERSIONS_DRILL_DOWN](state) {
    return state
            .set('_meta', { closeUrl: null })
            .set('data', []);
  },

  [LOAD_ANALYTIC_OBJECT_VERSIONS.REQUEST](state) {
    return state
            .set('loadingStatus', asyncStatus.REQUEST);
  },

  [LOAD_ANALYTIC_OBJECT_VERSIONS.FAILURE](state) {
    return state
            .set('loadingStatus', asyncStatus.FAILURE);
  },

  [LOAD_ANALYTIC_OBJECT_VERSIONS.SUCCESS](state, action) {
    return state
            .set('data', action.payload)
            .set('loadingStatus', asyncStatus.SUCCESS);
  },

  [LOAD_APPROVE_VERSION_DATA.REQUEST](state) {
    return state.set('approveVersionData', getInitialState().approveVersionData);
  },

  [LOAD_APPROVE_VERSION_DATA.SUCCESS](state, { payload: { versions, approvedVersion, dependents: dependencies } }) {
    return state.set('approveVersionData', {
      ...state.approveVersionData,
      versions,
      approvedVersion,
      dependencies
    });
  }

}, getInitialState());
