import ImmutableStore from 'immutable-store';
import { handleActions } from 'react-techstack/redux';
import { asyncStatus } from 'react-techstack/utils';
import { isPlainObject, isArray } from 'lodash/lang';
import { sortedIndexOf } from 'lodash/array';

import { analyticObjectStatuses } from 'modules/analytic/services/analyticObjectsService';
import {
  LOAD_ANALYTIC_OBJECTS,
  LOAD_AUDIT_TRAIL_DATA,
  TOGGLE_SELECTED_ANALYTIC_OBJECTS,
  UNLOCK_ANALYTIC_OBJECTS,
  DEACTIVATE_ANALYTIC_OBJECTS,
  TOGGLE_SHOW_SELECTED_ONLY,
  GET_SELECTED_OBJECTS
} from '../actions/analyticObjectsActions';

import {
  UPLOAD_NEW_ANALYTIC_OBJECT_VERSION
} from '../actions/objectsActionPanelActions';

import { CHANGE_PAGE } from '../actions/analyticObjectsTableActions';

const initialState = {
  analyticObjects: {
    data: [],
    page: {
      number: 1,
      size: 10
    }
  },
  analyticsTable: {
    selectAllAnalyticObjects: false,
    filterText: '',
    sortKey: null,
    sortDirection: null
  },
  auditTrail: {
    data: [],
    loadingStatus: asyncStatus.NONE
  },
  loadingStatus: asyncStatus.NONE,
  isShowingSelectedOnly: false,
  selectedObjects: [],
  uploadingFile: false
};

export const getInitialState = () => {
  return ImmutableStore({
    ...initialState,
    isLoading: () => {
      return {
        value: false,
        deps: {
          loadingStatus: [ 'loadingStatus' ]
        },
        get: (value, deps) => {
          return deps.loadingStatus === asyncStatus.REQUEST;
        }
      };
    }
  });
};

function isAnalyticObjectsResponseData(response) {
  return isPlainObject(response) && isArray(response.data) && isPlainObject(response.page);
}

function analyticObjectsRequest(state) {
  // ToDo: fix issue with .set('analyticObjects', initialState.analyticObjects)
  return state.set('loadingStatus', asyncStatus.REQUEST);
}

function analyticObjectsFailure(state, action) { // ToDo: refactor/improve this
  if (action.payload.status === 404 && isAnalyticObjectsResponseData(action.payload.data)) {
    return state
      .set('analyticObjects', action.payload.data)
      .set('loadingStatus', asyncStatus.SUCCESS);
  }

  return state
    .set('analyticObjects', initialState.analyticObjects)
    .set('loadingStatus', asyncStatus.FAILURE);
}

function analyticObjectsSuccess(state, action) {
  if (action.payload) {
    const selectedIds = state.selectedObjects.map((ao) => ao.id).sort();
    let selectAllAnalyticObjects = true;
    const data = action.payload.data.map((ao) => {
      const selected = sortedIndexOf(selectedIds, ao.id) !== -1;
      selectAllAnalyticObjects = selectAllAnalyticObjects && selected;
      return {
        ...ao,
        selected
      };
    });

    return state
      .set('analyticsTable', {
        ...state.analyticsTable,
        selectAllAnalyticObjects
      })
      .set('analyticObjects', {
        ...action.payload,
        data
      })
      .set('loadingStatus', asyncStatus.SUCCESS);
  }

  return state;
}

function getSelectedObjects(state, { status }) {
  if (!state.isShowingSelectedOnly) {
    return state;
  }

  const newData = status === analyticObjectStatuses.LOCKED ? state.selectedObjects.filter((ao) => ao.locked) : state.selectedObjects;

  return state
    .set('isShowingSelectedOnly', state.isShowingSelectedOnly && !!newData.length)
    .set('analyticObjects', {
      data: newData,
      page: {
        ...state.analyticObjects.page,
        totalElements: newData.length,
        totalPages: Math.ceil(newData.length / state.analyticObjects.page.size)
      }
    })
    .analyticsTable.set('selectAllAnalyticObjects', !!newData.length);
}

function setUploadingFileFlag(uploading) {
  return (state) => {
    return state.set('uploadingFile', uploading);
  };
}

export default handleActions({

  [LOAD_ANALYTIC_OBJECTS.REQUEST]: analyticObjectsRequest,

  [LOAD_ANALYTIC_OBJECTS.FAILURE]: analyticObjectsFailure,

  [LOAD_ANALYTIC_OBJECTS.SUCCESS]: analyticObjectsSuccess,

  [LOAD_AUDIT_TRAIL_DATA.REQUEST](state) {
    return state
      .auditTrail.set('data', [])
      .auditTrail.set('loadingStatus', asyncStatus.REQUEST);
  },

  [LOAD_AUDIT_TRAIL_DATA.FAILURE](state) {
    return state.auditTrail.set('loadingStatus', asyncStatus.FAILURE);
  },

  [LOAD_AUDIT_TRAIL_DATA.SUCCESS](state, action) {
    if (action.payload) {
      return state
        .auditTrail.set('data', action.payload)
        .auditTrail.set('loadingStatus', asyncStatus.SUCCESS);
    }

    return state;
  },

  // ToDo: keepeing duplicated analytic objects in 'selectedObjects' is redundant and not safe, refactor?
  [TOGGLE_SELECTED_ANALYTIC_OBJECTS](state, action) {
    let selectedAO;
    if (state.isShowingSelectedOnly) {
      if (action.selected) {
        return state;
      }

      if (!action.pageToggled) {
        selectedAO = state.selectedObjects.filter((ao) => ao.id !== action.objectId);
      } else {
        const idsOnPage = action.objectIds.sort();
        selectedAO = state.selectedObjects.filter((ao) => sortedIndexOf(idsOnPage, ao.id) === -1);
      }

      return getSelectedObjects(state.set('selectedObjects', selectedAO), action);
    }

    const data = state.analyticObjects.data.map((object) => {
      let selected = false;
      if (!object.deactivated) {
        selected = (action.pageToggled || object.id === action.objectId) ? action.selected : object.selected;
      }

      return {...object, selected};
    });
    const changedAO = data.filter((ao, index) => ao.selected !== state.analyticObjects.data[index].selected);
    const changedIds = changedAO.map((ao) => ao.id).sort();

    if (action.selected) {
      selectedAO = [ ...state.selectedObjects, ...changedAO];
    } else {
      selectedAO = state.selectedObjects.filter((ao) => sortedIndexOf(changedIds, ao.id) === -1);
    }

    const selectAllAnalyticObjects = data.every((ao) => ao.selected);

    return state
      .analyticsTable.set('selectAllAnalyticObjects', selectAllAnalyticObjects)
      .analyticObjects.set('data', data)
      .set('selectedObjects', selectedAO);
  },

  [UPLOAD_NEW_ANALYTIC_OBJECT_VERSION.REQUEST]: setUploadingFileFlag(true),
  [UPLOAD_NEW_ANALYTIC_OBJECT_VERSION.CANCEL]: setUploadingFileFlag(false),
  [UPLOAD_NEW_ANALYTIC_OBJECT_VERSION.FAILURE]: setUploadingFileFlag(false),
  [UPLOAD_NEW_ANALYTIC_OBJECT_VERSION.SUCCESS]: setUploadingFileFlag(false),

  [UNLOCK_ANALYTIC_OBJECTS.SUCCESS](state, action) {
    if (action.payload) {
      const data = state.analyticObjects.data.map((object) => {
        if (action.payload.success.indexOf(object.id) !== -1) {
          return {
            ...object,
            locked: false
          };
        }

        return object;
      });

      const selectedObjects = state.selectedObjects.map((ao) => {
        if (action.payload.success.indexOf(ao.id) !== -1) {
          return {
            ...ao,
            locked: false
          };
        }
        return ao;
      });

      return state
        .analyticObjects.set('data', data)
        .set('selectedObjects', selectedObjects);
    }

    return state;
  },

  [DEACTIVATE_ANALYTIC_OBJECTS.SUCCESS](state, action) {
    if (action.payload) {
      const deactivatedAOsIds = action.payload.success;
      const data = state.analyticObjects.data.map((object) => {
        if (action.payload.success.indexOf(object.id) !== -1) {
          return {
            ...object,
            deactivated: true,
            selected: false
          };
        }

        return object;
      });

      return state.analyticObjects.set('data', data)
        .set('selectedObjects', state.selectedObjects.filter(
          ({id}) => !deactivatedAOsIds.includes(id)
        )
      );
    }

    return state;
  },

  [TOGGLE_SHOW_SELECTED_ONLY](state, { isShowingSelectedOnly }) {
    return state.set('isShowingSelectedOnly', isShowingSelectedOnly);
  },

  [GET_SELECTED_OBJECTS]: getSelectedObjects,

  [CHANGE_PAGE](state, { page }) {
    return state.analyticObjects.set('page', {
      ...state.analyticObjects.page,
      ...page
    });
  }

}, getInitialState());
