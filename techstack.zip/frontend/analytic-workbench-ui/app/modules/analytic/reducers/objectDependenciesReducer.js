import ImmutableStore from 'immutable-store';
import { handleActions } from 'react-techstack/redux';

import {
  LOAD_OBJECT_DEPENDENCIES_DATA,
  OBJECT_DEPENDECIES_FILTERS,
  LOAD_TABLE_ELEMENT_DEPENDENCIES_DATA,
  LOAD_OBJECT_DEPENDECIES_XLS_FILE
} from '../actions/objectDependenciesActions';

function childrenMapper(list, parentType) {
  return list.map(({childs: children, dependency, expandable = false, ...item}) => {
    return {
      ...item,
      children,
      dependency: [dependency, parentType],
      $expandable: expandable
    };
  });
}

function prepareDependenciesList(list, data, dependency, key) {
  const children = dependency && dependency.indexOf(key) !== -1 ? childrenMapper(list, data.type) : [];
  return [{
    ...data,
    children,
    $expandable: true,
    $expand: true
  }];
}

function search(data, needle, currentLevel, needleLevel, children, type) {
  let result;

  data[type][0].children = data[type][0].children.map((item) => {
    if (item.id === needle.id && currentLevel === needleLevel) {
      result = {
        ...item,
        children: childrenMapper(children[type], needle.type),
        $expandable: children[type].length > 0
      };
    } else {
      const newObj = {};
      newObj[type] = [item];

      search(newObj, needle, currentLevel + 1, needleLevel, children, type);

      result = item;
    }

    return result;
  });

  return data;
}

const initialState = {
  data: {
    successors: [],
    predecessors: [],
    dependency: '',
    name: '',
    id: '',
    type: '',
    dependencyType: [],
    aoType: [],
    objectType: []
  },
  filtersDictionary: {
    dependency: [],
    objectType: [],
    dependencyType: []
  },
  filtersDictionaryRequest: '',
  filtersValue: {
    dependency: [],
    objectType: [],
    dependencyType: []
  }
};

export const getInitialState = () => {
  return ImmutableStore(initialState);
};

export default handleActions({
  [LOAD_OBJECT_DEPENDENCIES_DATA.REQUEST](state, action) {
    return state.set('filtersValue', action.meta.filtersValue);
  },
  [LOAD_OBJECT_DEPENDENCIES_DATA.SUCCESS](state, action) {
    const { predecessors = [], successors = [], dependency, ...data } = action.payload;

    return state.set('data', {
      predecessors: prepareDependenciesList(predecessors, data, dependency, 'Predecessors'),
      successors: prepareDependenciesList(successors, data, dependency, 'Successors')
    });

  },
  [OBJECT_DEPENDECIES_FILTERS.SUCCESS](state, action) {
    return state
            .set('filtersDictionary', action.payload);
  },
  [LOAD_TABLE_ELEMENT_DEPENDENCIES_DATA.SUCCESS](state, action) {
    const data = state.data.toJS();

    return state.set('data', search(data, action.meta.item, 0, action.meta.level - 1, action.payload, action.meta.dependency.name));
  },
  [LOAD_OBJECT_DEPENDECIES_XLS_FILE](state, action) {
    return state.set('filtersValue', action.meta.filtersValue);
  }
}, getInitialState());
