import ImmutableStore from 'immutable-store';
import { handleActions } from 'react-techstack/redux';
import { filter, some } from 'lodash/collection';
import {
  LOAD_ANALYTIC_OBJECTS_WITH_VERSIONS, LOAD_ISSUERS_FILTERS, LOAD_ISSUERS_STATEMENTS_FILTERS,
  LOAD_ISSUER_STATEMENTS, CREATE_ANALYTIC_OBJECTS_SIMULATION, APPLY_STATEMENTS_SORTING,
  APPLY_STATEMENTS_FILTER, TOGGLE_SIMULATION_TAB, TOGGLE_STATEMENT, TOGGLE_ALL_STATEMENTS,
  TOGGLE_SELECTED_ONLY, RECALCULATE_ANALYTIC_OBJECTS, SET_PAGE_NUMBER_FOR_SELECTED_ONLY,
  RESET_ISSUERS_STATEMENTS_FILTERS, LOAD_STATEMENT_ADJUSTMENTS, TOGGLE_STATEMENT_ADJUSTMENT
} from '../actions/simulationActions';
import { allStatementsSelected, isStatementSelected } from '../utils/simulationUtils';

const initialState = {
  analyticObjects: [],
  issuersFilters: {},
  totalIssuers: null,
  statementsRequestIssuersParams: {},
  createdSimulation: null,
  errorCode: null,
  form: {
    showSingleIssuerTab: true,
    analyticObjectsVersions: {}
  },
  section: {
    statements: [],
    selectedStatements: [],
    statementsAdjustments: {},
    simulationName: null,
    simulationNameNotValid: false,
    showOnlySelected: false,
    pageNumberForSelectedOnly: 1
  },
  sortOrder: {
    sortKey: '',
    sortAscending: false
  },
  statementFilters: {
    data: {},
    filters: {}
  },
  page: {
    number: 1,
    totalPages: 1
  }
};

export const getInitialState = () => {
  return ImmutableStore(initialState);
};

export default handleActions({

  [LOAD_ANALYTIC_OBJECTS_WITH_VERSIONS.SUCCESS](state, action) {
    return state.set('analyticObjects', action.payload);
  },

  [LOAD_ISSUERS_FILTERS.SUCCESS](state, action) {
    return state.set('issuersFilters', action.payload);
  },

  [LOAD_ISSUERS_STATEMENTS_FILTERS.REQUEST](state) {
    return state.statementFilters.set('data', initialState.statementFilters.data);
  },

  [LOAD_ISSUERS_STATEMENTS_FILTERS.SUCCESS](state, {payload}) {
    return state.statementFilters.set('data', payload);
  },

  [RESET_ISSUERS_STATEMENTS_FILTERS](state) {
    return state.set('statementFilters', initialState.statementFilters);
  },

  [LOAD_ISSUER_STATEMENTS.REQUEST](state, {meta: {issuersParams: {issuerId}}}) {
    let newState = state;

    if (!!issuerId && state.statementsRequestIssuersParams.issuerId !== issuerId) {
      newState = state.section.set('selectedStatements', initialState.section.selectedStatements);
    }

    return newState.section.set('statements', initialState.section.statements)
      .section.set('showOnlySelected', initialState.section.showOnlySelected);
  },

  [LOAD_ISSUER_STATEMENTS.SUCCESS](state, {payload, meta: {issuersParams}}) {
    return state
      .section.set('statements', payload.statementRevisions)
      .set('totalIssuers', payload.totalIssuers)
      .set('page', payload.page || initialState.page)
      .set('sortOrder', payload.sortOrder || initialState.sortOrder)
      .set('statementsRequestIssuersParams', issuersParams);
  },

  [LOAD_STATEMENT_ADJUSTMENTS.FAILURE](state, {payload, meta: {statement}}) {
    if (payload.status === 404) {
      return state.section.set('statementsAdjustments', {
        ...state.section.statementsAdjustments.toJS(),
        [statement.id]: []
      });
    }

    return state;
  },

  [LOAD_STATEMENT_ADJUSTMENTS.SUCCESS](state, {payload, meta: {statement}}) {
    return state.section.set('statementsAdjustments', {
      ...state.section.statementsAdjustments.toJS(),
      [statement.id]: payload
    });
  },

  [TOGGLE_STATEMENT_ADJUSTMENT](state, {meta: {adjustment: adjustmentToToggle}}) {
    const adjustments = state.section.statementsAdjustments[adjustmentToToggle.statementId];

    return state.section.set('statementsAdjustments', {
      ...state.section.statementsAdjustments.toJS(),
      [adjustmentToToggle.statementId]: adjustments.map((item) => {
        if (item.id === adjustmentToToggle.id) {
          return {
            ...adjustmentToToggle,
            selected: !adjustmentToToggle.selected
          };
        }

        return item;
      })
    });
  },

  [CREATE_ANALYTIC_OBJECTS_SIMULATION.REQUEST](state) {
    return state.set('createdSimulation', null);
  },

  [CREATE_ANALYTIC_OBJECTS_SIMULATION.SUCCESS](state, {payload}) {
    return state.set('createdSimulation', payload);
  },

  [RECALCULATE_ANALYTIC_OBJECTS.REQUEST](state) {
    return state.set('errorCode', initialState.errorCode);
  },

  [RECALCULATE_ANALYTIC_OBJECTS.FAILURE](state, {payload}) {
    return state.set('errorCode', payload.data.code);
  },

  [APPLY_STATEMENTS_SORTING](state, {meta: {sortOrder}}) {
    return state.set('sortOrder', sortOrder);
  },

  [APPLY_STATEMENTS_FILTER](state, {meta: {attributeName, options}}) {
    const { filters } = state.statementFilters;

    return state.statementFilters.set('filters', {
      ...filters,
      [attributeName]: options
    });
  },

  [TOGGLE_SIMULATION_TAB](state, {meta: {showSingleIssuerTab}}) {
    return state
      .form.set('showSingleIssuerTab', showSingleIssuerTab)
      .set('sortOrder', initialState.sortOrder)
      .set('section', initialState.section)
      .set('statementFilters', initialState.statementFilters)
      .set('page', initialState.page);
  },

  [TOGGLE_STATEMENT](state, {meta: {statement}}) {
    const { selectedStatements } = state.section;
    let updatedSelectedStatements;

    if (isStatementSelected(statement.id, selectedStatements)) {
      updatedSelectedStatements = filter(selectedStatements, ({id}) =>  id !== statement.id);
    } else {
      updatedSelectedStatements = [...selectedStatements, statement];
    }

    return state.section.set('selectedStatements', updatedSelectedStatements);
  },

  [TOGGLE_ALL_STATEMENTS.SUCCESS](state, {meta: {statementsToToggle}}) {
    const {selectedStatements, showOnlySelected} = state.section;
    let updatedSelectedStatements;

    if (showOnlySelected || allStatementsSelected(statementsToToggle, selectedStatements)) {
      updatedSelectedStatements = selectedStatements.filter(({id}) => !some(statementsToToggle, {id}));
    } else {
      const notSelectedStatements = statementsToToggle.filter(({id}) => !isStatementSelected(id, selectedStatements));
      updatedSelectedStatements = [...selectedStatements, ...notSelectedStatements];
    }

    return state.section.set('selectedStatements', updatedSelectedStatements);
  },

  [TOGGLE_SELECTED_ONLY](state) {
    return state.section.set('showOnlySelected', !state.section.showOnlySelected);
  },

  [SET_PAGE_NUMBER_FOR_SELECTED_ONLY](state, {meta}) {
    return state
      .section.set('pageNumberForSelectedOnly', meta.page.number)
      .page.set('size', meta.page.size);
  }

}, getInitialState());
