/* global beforeEach afterEach describe it */
/* eslint-disable no-console */

import expect from 'expect';
import { asyncStatus } from 'react-techstack/utils';

import {
  OPEN_VERSIONS_DRILL_DOWN,
  CLOSE_VERSIONS_DRILL_DOWN,
  LOAD_ANALYTIC_OBJECT_VERSIONS
} from '../../actions/versionsActions';
import reducer, {getInitialState} from '../versionsReducer.js';

describe('app.modules.analytic.reducers.__tests__.versionsReducerSpec', () => {
  const initialState = getInitialState();

  it('should retrun state after OPEN_VERSIONS_DRILL_DOWN', () => {
    const closeUrl = 'someUrl.domain';

    expect(reducer(
      initialState,
      {
        closeUrl,
        type: OPEN_VERSIONS_DRILL_DOWN
      }
    )._meta.closeUrl).toEqual(closeUrl);

    expect(reducer(
      initialState,
      {
        type: OPEN_VERSIONS_DRILL_DOWN
      }
    )).toEqual(initialState);

  });

  it('should return state after CLOSE_VERSIONS_DRILL_DOWN', () => {
    const closeUrl = 'someUrl.domain';
    const data = [1, 2, 3, 4, 5];

    const setCloseUrl = reducer(
      initialState,
      {
        closeUrl,
        type: OPEN_VERSIONS_DRILL_DOWN
      }
    );

    const setData = reducer(
      setCloseUrl,
      {
        type: LOAD_ANALYTIC_OBJECT_VERSIONS.SUCCESS,
        payload: data
      }
    );

    const closeDrill = reducer(
      setData,
      {
        type: CLOSE_VERSIONS_DRILL_DOWN
      }
    );

    expect(closeDrill._meta.closeUrl).toEqual(null);
    expect(closeDrill.data).toEqual([]);

  });

  it('should return state after LOAD_ANALYTIC_OBJECT_VERSIONS.REQUEST', () => {
    expect(
      reducer(
        initialState,
        {type: LOAD_ANALYTIC_OBJECT_VERSIONS.REQUEST}
      ).loadingStatus
    ).toEqual(asyncStatus.REQUEST);
  });

  it('should return state after LOAD_ANALYTIC_OBJECT_VERSIONS.FAILURE', () => {
    expect(
      reducer(
        initialState,
        {type: LOAD_ANALYTIC_OBJECT_VERSIONS.FAILURE}
      ).loadingStatus
    ).toEqual(asyncStatus.FAILURE);
  });

  it('should return state after LOAD_ANALYTIC_OBJECT_VERSIONS.SUCCESS', () => {
    const data = 12;
    const state = reducer(
      initialState,
      {
        type: LOAD_ANALYTIC_OBJECT_VERSIONS.SUCCESS,
        payload: data
      }
    );

    expect(state.data).toEqual(data);
    expect(state.loadingStatus).toEqual(asyncStatus.SUCCESS);

  });

});
