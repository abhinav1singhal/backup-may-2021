/* global beforeEach afterEach describe it */
/* eslint-disable no-console */

import expect from 'expect';

import {
  LOAD_OBJECT_DEPENDENCIES_DATA,
  OBJECT_DEPENDECIES_FILTERS,
  LOAD_OBJECT_DEPENDECIES_XLS_FILE
} from '../../actions/objectDependenciesActions';
import reducer, {getInitialState} from '../objectDependenciesReducer.js';

describe('app.modules.analytic.reducers.__tests__.objectDependenciesReducerSpec', () => {
  it('should return the initial state', () => {
    const initialState = getInitialState();

    expect(reducer(undefined, {})).toEqual(initialState);
    expect(reducer(initialState, {type: 'asdasd'})).toEqual(initialState);
  });

  it('should return state when LOAD_OBJECT_DEPENDENCIES_DATA.REQUEST', () => {
    const filters = {
      dependency: [{ id: 1 }, { id: 2 }],
      dependencyType: [{ id: 1 }, { id: 2 }],
      objectType: [{ id: 1 }, { id: 2 }]
    };
    const initialState = getInitialState();
    const expectedState = initialState.set('filtersValue', filters);

    expect(
      reducer(
        getInitialState(),
        {type: LOAD_OBJECT_DEPENDENCIES_DATA.REQUEST,
          meta: {filtersValue: filters}}
      )
    ).toEqual(
      expectedState
    );
  });

  it('should return state when LOAD_OBJECT_DEPENDENCIES_DATA.SUCCESS with dependencies', () => {
    const payload = {
      type: 'predecessors',
      dependency: 'Predecessors Successors',
      predecessors: [{
        id: 1,
        dependency: 'Predecessors'
      }, {
        id: 2,
        dependency: 'Predecessors'
      }],
      successors: [{
        id: 1,
        dependency: 'Predecessors'
      }, {
        id: 2,
        dependency: 'Predecessors'
      }]
    };
    const expectedDependencies = [{
      'type': 'predecessors',
      'children': [{
        'id': 1,
        'dependency': ['Predecessors', 'predecessors'],
        '$expandable': false
      }, {
        'id': 2,
        'dependency': ['Predecessors', 'predecessors'],
        '$expandable': false
      }],
      '$expandable': true,
      '$expand': true
    }];
    const initialState = getInitialState();
    const expectedState = initialState.set('data', {
      predecessors: expectedDependencies,
      successors: expectedDependencies
    });
    const realState = reducer(
      getInitialState(),
      {type: LOAD_OBJECT_DEPENDENCIES_DATA.SUCCESS,
        payload}
    );

    expect(
      realState.predecessors
    ).toEqual(
      expectedState.predecessors
    );
    expect(
      realState.successors
    ).toEqual(
      expectedState.successors
    );
  });

  it('should return state when LOAD_OBJECT_DEPENDENCIES_DATA.SUCCESS with empty payload', () => {
    const payload = {
      type: 'predecessors',
      dependency: 'Predecessors Successors'
    };
    const initialState = getInitialState();
    const expectedState = initialState.set('data', {
      predecessors: undefined,
      successors: undefined
    });
    const realState = reducer(
      getInitialState(),
      {type: LOAD_OBJECT_DEPENDENCIES_DATA.SUCCESS,
        payload}
    );

    expect(
      realState.predecessors
    ).toEqual(
      expectedState.predecessors
    );
    expect(
      realState.successors
    ).toEqual(
      expectedState.successors
    );
  });

  it('should return state when OBJECT_DEPENDECIES_FILTERS.SUCCESS', () => {
    const filters = {
      dependency: [{ id: 1 }, { id: 2 }]
    };
    const initialState = getInitialState();
    const expectedState = initialState.set('filtersDictionary', filters);

    expect(
      reducer(
        getInitialState(),
        {type: OBJECT_DEPENDECIES_FILTERS.SUCCESS,
          payload: filters}
      )
    ).toEqual(
      expectedState
    );
  });

  it('should return state when LOAD_OBJECT_DEPENDECIES_XLS_FILE', () => {
    const filters = {
      dependency: [{ id: 1 }, { id: 2 }],
      dependencyType: [{ id: 1 }, { id: 2 }],
      objectType: [{ id: 1 }, { id: 2 }]
    };
    const initialState = getInitialState();
    const expectedState = initialState.set('filtersValue', filters);

    expect(
      reducer(
        getInitialState(),
        {type: LOAD_OBJECT_DEPENDECIES_XLS_FILE,
          meta: {filtersValue: filters}}
      )
    ).toEqual(
      expectedState
    );
  });
});
