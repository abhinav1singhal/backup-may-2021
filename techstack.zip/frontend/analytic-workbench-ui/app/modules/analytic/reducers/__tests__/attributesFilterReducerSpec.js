/* global beforeEach afterEach describe it */
/* eslint-disable no-console */

import expect from 'expect';
import { asyncStatus } from 'react-techstack/utils';

import reducer, {getInitialState} from '../attributesFilterReducer.js';
import {
  LOAD_ATTRIBUTES,
  RESET_FILTERS,
  APPLY_NAME_SEARCH,
  APPLY_ATTRIBUTE_FILTER
} from '../../actions/attributesFilterActions';

describe('app.modules.analytic.reducers.__tests__.attributesFilterReducerSpec', () => {

  it('should return the initial state', () => {
    const initialState = getInitialState();

    expect(reducer(undefined, {})).toEqual(getInitialState());
    expect(reducer(initialState, {type: 'asdasd'})).toEqual(initialState);
  });

  it('should return state when LOAD_ATTRIBUTES.REQUEST', () => {
    expect(
      reducer(
        getInitialState(),
        {type: LOAD_ATTRIBUTES.REQUEST}
      ).loadingStatus
    ).toEqual(asyncStatus.REQUEST);
  });

  it('should return state when LOAD_ATTRIBUTES.SUCCESS', () => {
    const payload = 3;
    const stateAftetLoadSuccess = reducer(
      getInitialState(),
      {
        payload,
        type: LOAD_ATTRIBUTES.SUCCESS
      }
    );

    expect(stateAftetLoadSuccess.loadingStatus).toEqual(asyncStatus.SUCCESS);
    expect(stateAftetLoadSuccess.data).toEqual(payload);
  });

  it('should return state when LOAD_ATTRIBUTES.FAILURE', () => {
    const stateAftetLoadFailure = reducer(
      getInitialState(),
      {
        type: LOAD_ATTRIBUTES.FAILURE
      }
    );

    expect(stateAftetLoadFailure.loadingStatus).toEqual(asyncStatus.FAILURE);
  });

  it('should return state when RESET_FILTERS', () => {
    const initialState = getInitialState();
    const payload = {
      a: 12,
      b: 42
    };
    const state = reducer(
      reducer(
        initialState,
        {
          payload,
          type: LOAD_ATTRIBUTES.SUCCESS
        }
      ),
      {
        type: APPLY_NAME_SEARCH,
        needle: 'some name'
      }
    );

    const resetState = reducer(
      state,
      {
        type: RESET_FILTERS
      }
    );

    expect(resetState.data).toEqual(initialState.data);
    expect(resetState.name).toEqual(initialState.name);
    expect(resetState.loadingStatus).toEqual(initialState.loadingStatus);
  });

  it('should return state when APPLY_NAME_SEARCH', () => {
    expect(
      reducer(
        getInitialState(),
        {
          type: APPLY_NAME_SEARCH,
          needle: 'some word'
        }
      ).name
    ).toEqual('some word');
  });

  it('should return state when APPLY_ATTRIBUTE_FILTER', () => {
    const attributeName = 'searchAtribute';
    const options = [1, 2, 3, 4, 56];
    const initialState = getInitialState();

    expect(
      reducer(
        initialState,
        {
          attributeName,
          options,
          type: APPLY_ATTRIBUTE_FILTER
        }
      ).filters[attributeName]
    ).toEqual(options);

    expect(
      reducer(
        initialState,
        {
          type: APPLY_ATTRIBUTE_FILTER
        }
      )
    ).toEqual(initialState);

  });

});
