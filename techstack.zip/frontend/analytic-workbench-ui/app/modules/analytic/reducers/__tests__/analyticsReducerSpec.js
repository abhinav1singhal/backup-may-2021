/* global beforeEach afterEach describe it xit */
/* eslint-disable no-console */

import expect from 'expect';
import { asyncStatus } from 'react-techstack/utils';

import reducer, {getInitialState} from '../analyticsReducer.js';
import {
  LOAD_ANALYTIC_OBJECTS,
  LOAD_AUDIT_TRAIL_DATA,
  TOGGLE_SELECTED_ANALYTIC_OBJECTS,
  DOWNLOAD_EMPTY_TEMPLATE,
  DOWNLOAD_ANALYTIC_OBJECT,
  DOWNLOAD_ANALYTIC_OBJECT_REVISION,
  UNLOCK_ANALYTIC_OBJECTS,
  DEACTIVATE_ANALYTIC_OBJECTS
} from '../../actions/analyticObjectsActions';
import { AnalyticObjectsDataMock } from '../../services/__tests__/analyticObjectsServiceMock';

describe('app.modules.analytic.reducers.__tests__.analyticsReducerSpec', () => {

  it('should return the initial state', () => {
    const initialState = getInitialState();

    expect(reducer(undefined, {})).toEqual(getInitialState());
    expect(reducer(initialState, {type: 'asdasd'})).toEqual(getInitialState());
  });

  it('should return state when LOAD_AUDIT_TRAIL_DATA.REQUEST', () => {
    expect(
      reducer(
        getInitialState(),
        {type: LOAD_AUDIT_TRAIL_DATA.REQUEST}
      ).auditTrail.loadingStatus
    ).toEqual(asyncStatus.REQUEST);
  });

  it('should return state when LOAD_AUDIT_TRAIL_DATA.FAILURE', () => {
    const stateAfterREQUEST = reducer(
      getInitialState(),
      {type: LOAD_AUDIT_TRAIL_DATA.REQUEST}
    );

    expect(
      reducer(
        stateAfterREQUEST,
        {type: LOAD_AUDIT_TRAIL_DATA.FAILURE}
      ).auditTrail.loadingStatus
    ).toEqual(asyncStatus.FAILURE);
  });

  it('should return state when LOAD_AUDIT_TRAIL_DATA.SUCCESS with payload', () => {
    expect(
      reducer(
        getInitialState(),
        {type: LOAD_AUDIT_TRAIL_DATA.SUCCESS}
      ).auditTrail.loadingStatus
    ).toEqual(asyncStatus.NONE);
  });

  it('should return state when LOAD_AUDIT_TRAIL_DATA.SUCCESS with payload', () => {
    const stateAfterREQUEST = reducer(
      getInitialState(),
      {
        type: LOAD_AUDIT_TRAIL_DATA.REQUEST
      }
    );
    const stateAfterSuccess = reducer(
      stateAfterREQUEST,
      {
        type: LOAD_AUDIT_TRAIL_DATA.SUCCESS,
        payload: {
          status: 404,
          data: {
            data: AnalyticObjectsDataMock,
            page: {
              a: 2
            }
          }
        }
      }
    );

    expect(stateAfterSuccess.auditTrail.loadingStatus).toEqual(asyncStatus.SUCCESS);
  });

  it('should return state when LOAD_AUDIT_TRAIL_DATA.SUCCESS without payload', () => {
    expect(
      reducer(
        getInitialState(),
        {type: LOAD_AUDIT_TRAIL_DATA.SUCCESS}
      ).auditTrail.loadingStatus
    ).toEqual(asyncStatus.NONE);
  });

  it('should return state when LOAD_ANALYTIC_OBJECTS.REQUEST', () => {
    expect(
      reducer(
        getInitialState(),
        {type: LOAD_ANALYTIC_OBJECTS.REQUEST}
      ).loadingStatus
    ).toEqual(asyncStatus.REQUEST);
  });


  it('should return state when LOAD_ANALYTIC_OBJECTS.FAILURE', () => {
    let state = reducer(
      reducer(
        getInitialState(),
        {type: LOAD_ANALYTIC_OBJECTS.REQUEST}
      ),
      {
        type: LOAD_ANALYTIC_OBJECTS.REQUEST
      }
    );

    let failedState = reducer(
      reducer(
        getInitialState(),
        {type: LOAD_ANALYTIC_OBJECTS.REQUEST}
      ),
      {
        type: LOAD_ANALYTIC_OBJECTS.REQUEST
      }
    );

    let wrongAnanyticObjectState = reducer(
      reducer(
        getInitialState(),
        {type: LOAD_ANALYTIC_OBJECTS.REQUEST}
      ),
      {
        type: LOAD_AUDIT_TRAIL_DATA.REQUEST
      }
    );

    state = reducer(
      state,
      {
        type: LOAD_ANALYTIC_OBJECTS.FAILURE,
        payload: {
          status: 404,
          data: {
            data: AnalyticObjectsDataMock,
            page: {
              a: 2
            }
          }
        }
      }
    );

    failedState = reducer(
      failedState,
      {
        type: LOAD_ANALYTIC_OBJECTS.FAILURE,
        payload: {
          status: 405,
          data: {
            data: AnalyticObjectsDataMock,
            page: {
              a: 2
            }
          }
        }
      }
    );

    wrongAnanyticObjectState = reducer(
      wrongAnanyticObjectState,
      {
        type: LOAD_ANALYTIC_OBJECTS.FAILURE,
        payload: {
          status: 404,
          data: {
            data: AnalyticObjectsDataMock[0],
            page: {
              a: 2
            }
          }
        }
      }
    );

    expect(
      state.loadingStatus
    ).toEqual(asyncStatus.SUCCESS);
    expect(
      failedState.loadingStatus
    ).toEqual(asyncStatus.FAILURE);
    expect(
      wrongAnanyticObjectState.loadingStatus
    ).toEqual(asyncStatus.FAILURE);

    expect(state.analyticObjects.data.toJS()).toEqual(AnalyticObjectsDataMock);

    expect(failedState.analyticObjects.data.length).toBe(0);
    expect(wrongAnanyticObjectState.analyticObjects.data.length).toBe(0);
  });

  it('should return state when LOAD_ANALYTIC_OBJECTS.SUCCESS with correc params', () => {
    const req = reducer(
      reducer(
        getInitialState(),
        {
          type: LOAD_ANALYTIC_OBJECTS.REQUEST
        }
      ),
      {
        type: LOAD_ANALYTIC_OBJECTS.SUCCESS,
        payload: {
          status: 404,
          data: AnalyticObjectsDataMock,
          page: {
            a: 2
          }
        }
      }
    );

    expect(req.analyticObjects.data.toJS()).toEqual(AnalyticObjectsDataMock.map((ao) => ({ ...ao, selected: false })));

    expect(req.analyticsTable.selectAllAnalyticObjects).toEqual(false);
    expect(req.loadingStatus).toEqual(asyncStatus.SUCCESS);
  });

  it('should return state when LOAD_ANALYTIC_OBJECTS.SUCCESS without payload', () => {
    const state = reducer(
      getInitialState(),
      {
        type: LOAD_ANALYTIC_OBJECTS.REQUEST
      }
    );
    const noPayload = reducer(
      state,
      {
        type: LOAD_ANALYTIC_OBJECTS.SUCCESS
      }
    );

    expect(noPayload).toEqual(state);
  });

  it('should return state when TOGGLE_SELECTED_ANALYTIC_OBJECTS', () => {
    // ToDo: need to discuss logic of working, not sure how to select analyticObjects
    const req = reducer(
      reducer(
        getInitialState(),
        {
          type: LOAD_ANALYTIC_OBJECTS.REQUEST
        }
      ),
      {
        type: LOAD_ANALYTIC_OBJECTS.SUCCESS,
        payload: {
          status: 404,
          data: AnalyticObjectsDataMock,
          page: {
            a: 2
          }
        }
      }
    );

    const toggleFirst = reducer(
      req,
      {
        type: TOGGLE_SELECTED_ANALYTIC_OBJECTS,
        pageToggled: true,
        selected: true
      }
    );

    let dataLen = toggleFirst.analyticObjects.data.length;
    let data = toggleFirst.analyticObjects.data;

    for (let i = 0; i < dataLen; i += 1) {
      expect(data[i].selected).toEqual(true);
    }

    const toggleSecond = reducer(
      toggleFirst,
      {
        type: TOGGLE_SELECTED_ANALYTIC_OBJECTS,
        pageToggled: true,
        selected: false
      }
    );

    dataLen = toggleSecond.analyticObjects.data.length;
    data = toggleSecond.analyticObjects.data;

    for (let i = 0; i < dataLen; i += 1) {
      expect(data[i].selected).toEqual(false);
    }

  });

  // need check empty payload and if elems exists in success
  it('should return state when UNLOCK_ANALYTIC_OBJECTS.SUCCESS', () => {
    const haveLockedObjects = reducer(
      reducer(
        getInitialState(),
        {
          type: LOAD_ANALYTIC_OBJECTS.REQUEST
        }
     ), {
       type: LOAD_ANALYTIC_OBJECTS.SUCCESS,
       payload: {
         status: 404,
         data: [{
           ...AnalyticObjectsDataMock[0],
           locked: true
         }, {
           ...AnalyticObjectsDataMock[1],
           locked: false
         }],
         page: {
           a: 2
         }
       }
     }
   );

    const unlokedObjects = reducer(
      haveLockedObjects,
      {
        type: UNLOCK_ANALYTIC_OBJECTS.SUCCESS,
        payload: {
          success: AnalyticObjectsDataMock.map((el) => el.id)
        }
      }
    );

    expect(unlokedObjects.analyticObjects.data[0].locked).toEqual(false);
    expect(unlokedObjects.analyticObjects.data[1].locked).toEqual(false);
  });

  it('should return state when UNLOCK_ANALYTIC_OBJECTS.SUCCESS with empty payload and when in success list', () => {
    const req = reducer(
      reducer(
        getInitialState(),
        {
          type: LOAD_ANALYTIC_OBJECTS.REQUEST
        }
      ), {
        type: LOAD_ANALYTIC_OBJECTS.SUCCESS,
        payload: {
          status: 404,
          data: [{
            ...AnalyticObjectsDataMock[0],
            locked: true
          }, {
            ...AnalyticObjectsDataMock[1],
            locked: false
          }],
          page: {
            a: 2
          }
        }
      }
    );

    const noPayload = reducer(req, { type: UNLOCK_ANALYTIC_OBJECTS.SUCCESS });
    const inSuccess = reducer(
      req,
      {
        type: UNLOCK_ANALYTIC_OBJECTS.SUCCESS,
        payload: {
          status: 404,
          success: [1, 2],
          data: [
            {
              ...AnalyticObjectsDataMock[0],
              locked: true
            }, {
              ...AnalyticObjectsDataMock[1],
              locked: false
            }
          ],
          page: {
            a: 2
          }
        }
      }
    );

    expect(noPayload).toEqual(req);
    expect(inSuccess.analyticObjects.data[0].locked).toEqual(true);
    expect(inSuccess.analyticObjects.data[1].locked).toEqual(false);
  });

  it('should return state when DEACTIVATE_ANALYTIC_OBJECTS.SUCCESS', () => {
    const activatedObjects = reducer(
      reducer(
        getInitialState(),
        {
          type: LOAD_ANALYTIC_OBJECTS.REQUEST
        }
      ), {
        type: LOAD_ANALYTIC_OBJECTS.SUCCESS,
        payload: {
          status: 404,
          data: [
            {
              ...AnalyticObjectsDataMock[0],
              deactivated: false,
              selected: true
            }, {
              ...AnalyticObjectsDataMock[1],
              deactivated: true,
              selected: false
            }
          ],
          page: {
            a: 2
          }
        }
      }
    );

    const deactivatedObjects = reducer(
      activatedObjects,
      {
        type: DEACTIVATE_ANALYTIC_OBJECTS.SUCCESS,
        payload: {
          success: AnalyticObjectsDataMock.map((el) => el.id)
        }
      }
    );

    expect(deactivatedObjects.analyticObjects.data[0].deactivated).toEqual(true);
    expect(deactivatedObjects.analyticObjects.data[1].deactivated).toEqual(true);
    expect(deactivatedObjects.analyticObjects.data[0].selected).toEqual(false);
    expect(deactivatedObjects.analyticObjects.data[1].selected).toEqual(false);
  });

  // ToDo: broken due to changes in functionality, fix
  it('should return state when DEACTIVATE_ANALYTIC_OBJECTS.SUCCESS send\'s with no payload', () => {
    const activatedObjects = reducer(
      reducer(
        getInitialState(),
        {
          type: LOAD_ANALYTIC_OBJECTS.REQUEST
        }
      ),
      {
        type: LOAD_ANALYTIC_OBJECTS.SUCCESS,
        payload: {
          status: 404,
          data: [
            {
              ...AnalyticObjectsDataMock[0],
              deactivated: false,
              selected: true
            }, {
              ...AnalyticObjectsDataMock[1],
              deactivated: true,
              selected: false
            }
          ],
          page: {
            a: 2
          }
        }
      }
    );

    const noPayload = reducer(
      activatedObjects,
      {
        type: DEACTIVATE_ANALYTIC_OBJECTS.SUCCESS
      }
    );

    const existsSuccess = reducer(
      activatedObjects,
      {
        type: DEACTIVATE_ANALYTIC_OBJECTS.SUCCESS,
        payload: {
          status: 404,
          success: [1, 2],
          data: [
            {
              ...AnalyticObjectsDataMock[0],
              deactivated: false,
              selected: true
            }, {
              ...AnalyticObjectsDataMock[1],
              deactivated: true,
              selected: false
            }
          ],
          page: {
            a: 2
          }
        }
      }
    );

    expect(noPayload).toEqual(activatedObjects);
    expect(existsSuccess).toEqual(activatedObjects);
  });

  it('should return state when DOWNLOAD_EMPTY_TEMPLATE', () => {
    // ToDo: need to check window location, now i'm not checking if it has changed
    const initialState = getInitialState();
    const state = reducer(
      initialState,
      {
        type: DOWNLOAD_EMPTY_TEMPLATE
      }
    );

    expect(state).toEqual(initialState);
  });
  it('should return state when DOWNLOAD_ANALYTIC_OBJECT', () => {
    // ToDo: need to check window location, now i'm not checking if it has changed
    const initialState = getInitialState();
    const state = reducer(
      initialState,
      {
        type: DOWNLOAD_ANALYTIC_OBJECT
      }
    );

    expect(state).toEqual(initialState);
  });

  it('should return state when DOWNLOAD_ANALYTIC_OBJECT_REVISION', () => {
    // ToDo: need to check window location, now i'm not checking if it has changed
    const initialState = getInitialState();
    const state = reducer(
      initialState,
      {
        type: DOWNLOAD_ANALYTIC_OBJECT_REVISION
      }
    );

    expect(state).toEqual(initialState);
  });

});
