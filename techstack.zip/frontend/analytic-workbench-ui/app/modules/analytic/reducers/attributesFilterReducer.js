import ImmutableStore from 'immutable-store';
import { handleActions } from 'react-techstack/redux';
import { asyncStatus } from 'react-techstack/utils';
import _ from 'lodash';
import {
  LOAD_ATTRIBUTES,
  RESET_FILTERS,
  APPLY_NAME_SEARCH,
  APPLY_ATTRIBUTE_FILTER
} from '../actions/attributesFilterActions';

const initialState = {
  data: {},
  name: '',
  filters: {
    country: [],
    lob: [],
    methodology: [],
    region: [],
    subsector: [],
    type: [],
    privacy: [],
    sourceFile: []
  },
  loadingStatus: asyncStatus.NONE
};

export const getInitialState = () => {
  return ImmutableStore({
    ...initialState,
    isLoading: () => {
      return {
        value: false,
        deps: {
          loadingStatus: [ 'loadingStatus' ]
        },
        get: (value, deps) => {
          return deps.loadingStatus === asyncStatus.REQUEST;
        }
      };
    }
  });
};

export default handleActions({

  [LOAD_ATTRIBUTES.REQUEST](state) {
    return state
            .set('loadingStatus', asyncStatus.REQUEST);
  },

  [LOAD_ATTRIBUTES.FAILURE](state) {
    return state
            .set('loadingStatus', asyncStatus.FAILURE);
  },

  [LOAD_ATTRIBUTES.SUCCESS](state, action) {
    return state
            .set('data', action.payload)
            .set('loadingStatus', asyncStatus.SUCCESS);
  },

  [RESET_FILTERS](state) {
    return state
      .set('data', initialState.data)
      .set('name', initialState.name)
      .set('filters', initialState.filters)
      .set('loadingStatus', initialState.loadingStatus);
  },

  [APPLY_NAME_SEARCH](state, action) {
    return state.set('name', action.needle);
  },

  [APPLY_ATTRIBUTE_FILTER](state, action) {
    if (_.has(action, 'attributeName') &&
        _.isArray(action.options)) {
      return state.set('filters', {
        ...state.filters,
        [action.attributeName]: action.options
      });
    }
    return state;
  }

}, getInitialState());
