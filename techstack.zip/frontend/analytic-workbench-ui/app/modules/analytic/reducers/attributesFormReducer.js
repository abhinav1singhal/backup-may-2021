import { handleActions } from 'react-techstack/redux';
import { LOAD_UPDATE_FORM, SAVE_UPDATE_FORM, LOAD_CREATE_FORM, SAVE_CREATE_FORM, UPDATE_ATTRIBUTES_FOR_TYPE } from 'modules/analytic/actions/attributesFormActions';

const INITIAL_STATE = {
  data: {},
  dictionaries: {},
  config: { attrs: [], props: [] },
  errorCode: null,
  errorMessage: null
};

function getInitialState() {
  return { ...INITIAL_STATE };
}

export default handleActions({
  [LOAD_UPDATE_FORM.REQUEST]() {
    return getInitialState();
  },
  [LOAD_UPDATE_FORM.SUCCESS](storage, { payload }) {
    return {
      ...storage,
      ...payload
    };
  },
  [LOAD_CREATE_FORM.REQUEST]() {
    return getInitialState();
  },
  [LOAD_CREATE_FORM.SUCCESS](storage, { payload }) {
    return {
      ...storage,
      ...payload
    };
  },
  [UPDATE_ATTRIBUTES_FOR_TYPE.SUCCESS](storage, { payload }) {
    return {
      ...storage,
      ...payload
    };
  },
  [SAVE_UPDATE_FORM.SUCCESS]() {
    return getInitialState();
  },
  [SAVE_CREATE_FORM.SUCCESS]() {
    return getInitialState();
  },
  [SAVE_CREATE_FORM.REQUEST](storage) {
    return {
      ...storage,
      errorCode: null,
      errorMessage: null
    };
  },
  [SAVE_CREATE_FORM.REQUEST](storage) {
    return {
      ...storage,
      errorCode: null,
      errorMessage: null
    };
  },
  [SAVE_UPDATE_FORM.FAILURE](storage, { payload }) {
    return {
      ...storage,
      ...payload
    };
  },
  [SAVE_CREATE_FORM.FAILURE](storage, { payload }) {
    return {
      ...storage,
      ...payload
    };
  }
}, getInitialState());
