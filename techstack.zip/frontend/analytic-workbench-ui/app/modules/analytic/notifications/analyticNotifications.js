import { Notification } from 'react-techstack';
import { getMessage } from 'modules/common/utils/messagesUtils';

import { LOAD_ANALYTIC_OBJECT_VERSIONS } from 'modules/analytic/actions/versionsActions';
import { LOAD_STATEMENT_ADJUSTMENTS } from 'modules/analytic/actions/simulationActions';
import { UPLOAD_NEW_ANALYTIC_OBJECT_VERSION } from 'modules/analytic/actions/objectsActionPanelActions';
import { SAVE_CREATE_FORM } from 'modules/analytic/actions/attributesFormActions';

function showSimpleError({payload}) {
  return Notification.error(
    'Sorry',
    payload.data.message || 'An unexpected error occurred while new analytic object.',
    {
      autoDismiss: 5
    }
  );
}

export default {
  [LOAD_ANALYTIC_OBJECT_VERSIONS.FAILURE]: (action) => {
    return Notification.error('Sorry', `Can't find versions history for this analytic object: ${action.id}`, {
      autoDismiss: 5
    });
  },

  [LOAD_STATEMENT_ADJUSTMENTS.FAILURE]: ({payload}) => {
    if (payload.status === 404) {
      return Notification.warning(
        'Sorry',
        'No adjustments found for this statement.',
        {
          autoDismiss: 5
        }
      );
    }

    return Notification.error(
      'Sorry',
      'An unexpected error occurred.',
      {
        autoDismiss: 5
      }
    );
  },

  [UPLOAD_NEW_ANALYTIC_OBJECT_VERSION.SUCCESS]: ({payload}) => {
    return Notification.success('', `New version of AO "${payload.name}" has been created`, {
      autoDismiss: 5
    });
  },

  [UPLOAD_NEW_ANALYTIC_OBJECT_VERSION.FAILURE]: showSimpleError,
  [SAVE_CREATE_FORM.SUCCESS]: ({ aoName }) => {
    return Notification.success('', getMessage('attributesForm.createdAO', aoName), {
      autoDismiss: 5
    });
  }
};
