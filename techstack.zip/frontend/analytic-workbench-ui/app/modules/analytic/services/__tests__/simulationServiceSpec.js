/* global beforeEach afterEach describe it xdescribe xit */
/* eslint-disable no-console */

import { BASE_API_URL } from 'config/index';
import expect from 'expect';

import SimulationService from '../simulationService.js';
import * as mocks from '../../components/SimulationForm/__tests__/simulationMocks';


describe('app.modules.analytic.services.__tests__.simulationServiceSpec', () => {

  const createServiceWithMockedClient = (data, checkGet = () => {}, checkPost = () => {}) => {
    return new SimulationService({
      get: (str, config) => {
        checkGet(str, config);
        return new Promise((resolve) => {
          resolve({data});
        });
      },
      post: (str, params) => {
        checkPost(str, params);
        return new Promise((resolve) => {
          resolve({data});
        });
      }
    });
  };

  it('testing method of loadAnalyticObjectsWithVersions', (done) => {
    const aoIds = [1, 2];
    const aos = [
      {
        revisions: [
          {production: true, version: 1},
          {production: false, version: 2}
        ]
      }
    ];

    createServiceWithMockedClient({aos}, (str, config) => {
      expect(str).toEqual(`${BASE_API_URL}/analytic-objects/with-revisions`);
      expect(config).toEqual({
        params: {
          aoIds
        },
        cache: false
      });
    }).loadAnalyticObjectsWithVersions(aoIds).then((data) => {
      expect(data.length).toEqual(aos.length);
      expect(data[0].versions[0].label).toEqual('1 (approved)');
      expect(data[0].versions[1].label).toEqual('2');
    }).then(() => { done(); });
  });

  it('testing method of loadIssuersFilters', (done) => {
    const filters = {
      lob: 'testLob',
      subsector: 'testSubsector',
      dummyFilter: 'dummyFilter'
    };

    createServiceWithMockedClient(filters, (str, config) => {
      expect(str).toEqual(`${BASE_API_URL}/simulation/issuer-filters`);
      expect(config).toEqual({
        cache: false
      });
    }).loadIssuersFilters().then((data) => {
      expect(data).toEqual({
        lineOfBusiness: filters.lob,
        sector: filters.subsector,
        dummyFilter: filters.dummyFilter
      });
    }).then(() => { done(); });
  });

  it('testing method of loadIssuerStatementsFilters for single issuer', (done) => {
    const issuersParams = {
      issuerId: 1234,
      dummyParam1: 'dummyParam1',
      dummyParam2: 'dummyParam2'
    };

    createServiceWithMockedClient({
      revisionDate: {
        list: [{
          description: '2016-11-02 12:57:45.754'
        }]
      }
    }, undefined, (str, config) => {
      expect(str).toEqual(`${BASE_API_URL}/simulation/simulation-filters`);
      expect(config).toEqual(issuersParams);
    }).loadIssuerStatementsFilters(issuersParams).then((data) => {
      expect(data.revisionDate.list[0].description).toEqual('02 Nov 2016');
    }).then(() => { done(); });
  });

  it('testing method of loadIssuerStatementsFilters for multiple issuers', (done) => {
    const issuersParams = {
      lineOfBusiness: {id: '123'},
      sector: [{id: '1'}, {id: '2'}, {id: '3'}],
      region: [{id: '4'}],
      country: []
    };

    createServiceWithMockedClient({
      revisionDate: {
        list: [{
          description: '2016-11-02 12:57:45.754'
        }]
      }
    }, undefined, (str, config) => {
      expect(str).toEqual(`${BASE_API_URL}/simulation/simulation-filters`);
      expect(config).toEqual({
        lobIds: [123],
        subsectorIds: [1, 2, 3],
        regionIds: [4],
        countryIds: []
      });
    }).loadIssuerStatementsFilters(issuersParams).then(() => { done(); });
  });

  describe('loadIssuerStatements', () => {
    describe('testing endpoint calling', () => {
      const createService = (test) => {
        return new SimulationService({
          post: (str, params) => {
            test(str, params);
            return {
              then: () => {}
            };
          }
        });
      };
      const issuerId = 1234;
      const multiIssuersParams = {
        lineOfBusiness: {id: '123'},
        sector: [{id: '1'}, {id: '2'}, {id: '3'}],
        region: [{id: '4'}],
        country: []
      };
      const transformedMultiIssuersParams = {
        lobIds: [123],
        subsectorIds: [1, 2, 3],
        regionIds: [4],
        countryIds: []
      };
      const endpoint = `${BASE_API_URL}/simulation/simulation-revisions`;

      it('should pass in request proper issuerId and default other params', (done) => {
        createService((str, params) => {
          expect(str).toEqual(endpoint);
          expect(params).toEqual({
            issuerId,
            page: {
              number: 1,
              size: 10
            },
            sortOrder: undefined,
            filters: {}
          });
          done();
        }).loadIssuerStatements({issuerId});
      });

      it('should pass in request proper issuerId, page, sorting and filters', (done) => {
        createService((str, params) => {
          expect(str).toEqual(endpoint);
          expect(params).toEqual({
            issuerId,
            page: 5,
            sortOrder: {
              property: 'testKey',
              direction: 'ASC'
            },
            filters: 'dummyFilters'
          });
          done();
        }).loadIssuerStatements({issuerId}, 5, {
          sortKey: 'testKey',
          sortAscending: true
        }, 'dummyFilters');
      });

      it('should pass proper request params on multi issuers', (done) => {
        createService((str, params) => {
          expect(params).toEqual({
            ...transformedMultiIssuersParams,
            page: 10,
            sortOrder: {
              property: 'testKey',
              direction: 'DESC'
            },
            filters: 'dummyFilters'
          });
          done();
        }).loadIssuerStatements(multiIssuersParams, 10, {
          sortKey: 'testKey',
          sortAscending: false
        }, 'dummyFilters');
      });
    });

    it('should correctly process response', (done) => {
      const service = new SimulationService({
        post: () => {
          return Promise.resolve({
            data: {
              data: [
                {
                  statementRevisionId: '3b5a74f5-7edd-4266-9894-f8bf4303171f',
                  statementId: '304e02ac-5a20-4952-893b-03abd4ac47e3',
                  revisionDate: '2016-11-02T12:57:45.754',
                  fiscalYear: 2014,
                  periodType: 'Annual',
                  consolidationType: 'Consolidated',
                  regimeType: 'IFRS',
                  organisationId: 17980,
                  organisationName: 'Standard Insurance Company'
                }
              ],
              totalIssuers: 207,
              page: {
                size: 10,
                totalElements: 14,
                totalPages: 2,
                number: 1
              },
              sortOrder: {
                property: 'revisionDate',
                direction: 'DESC'
              },
              filters: {}
            }
          });
        }
      });
      service.loadIssuerStatements({issuerId: 1234}).then((data) => {
        expect(data).toEqual({
          'statementRevisions': [
            {
              'id': '304e02ac-5a20-4952-893b-03abd4ac47e3',
              'issuer': {
                'id': 17980,
                'lobId': void 0,
                'name': 'Standard Insurance Company',
                'label': 'Standard Insurance Company - 17980'
              },
              'statementRevisionId': '3b5a74f5-7edd-4266-9894-f8bf4303171f',
              'revisionDate': '2016-11-02T12:57:45.754',
              'fiscalYear': 2014,
              'periodType': 'Annual',
              'consolidationType': 'Consolidated',
              'regimeType': 'IFRS'
            }
          ],
          'totalIssuers': 207,
          'page': {
            'size': 10,
            'totalElements': 14,
            'totalPages': 2,
            'number': 1
          },
          'sortOrder': {
            'sortKey': 'revisionDate',
            'sortAscending': false
          }
        });
        done();
      });
    });
  });

  it('testing method of createAnalyticObjectsSimulation', (done) => {
    const idx = 1;
    const object = mocks.analyticObjects[idx];
    const simulationName = 'testSimulationName';
    const testFormData = {
      'title': 'testSimulationName',
      'statementRevisions': [
        {
          'key': {
            'statementRevisionId': mocks.statements[0].statementRevisionId,
            'statementId': mocks.statements[0].id,
            'revisionDate': mocks.statements[0].revisionDate
          },
          'excludedAdjustments': []
        },
        {
          'key': {
            'statementRevisionId': mocks.statements[1].statementRevisionId,
            'statementId': mocks.statements[1].id,
            'revisionDate': mocks.statements[1].revisionDate
          },
          'excludedAdjustments': []
        }
      ],
      'simulationAoRevisions': [
        {
          'aoId': object.id,
          'name': object.name,
          'version': void 0,
          'aoRevisionId': void 0
        }
      ]
    };
    const service = new SimulationService({
      post: (str, params) => {
        expect(str).toEqual(`${BASE_API_URL}/simulation/statement/create-simulation`);
        expect(params).toEqual(testFormData);
        return Promise.resolve({
          data: {
            dummyProperty: 'test'
          }
        });
      }
    });

    service.createAnalyticObjectsSimulation(
      mocks.analyticObjects,
      { [object.id]: { name: 'testName' } }, // analyticObjectsVersions
      mocks.statements,
      [], // adjustments
      simulationName,
    ).then((data) => {
      expect(data).toEqual({
        simulationName,
        dummyProperty: 'test'
      });
      done();
    });
  });

  it('testing method of recalculateAnalyticObjects', (done) => {
    const idx = 1;
    const object = mocks.analyticObjects[idx];
    const testData = {
      dummyProperty: 'test'
    };
    const service = new SimulationService({
      post: (str, params) => {
        expect(str).toEqual(`${BASE_API_URL}/bulk-execution/recalculate`);
        expect(params).toEqual({
          'statementRevisions': [
            {
              'key': {
                'statementRevisionId': mocks.statements[0].statementRevisionId,
                'statementId': mocks.statements[0].id,
                'revisionDate': mocks.statements[0].revisionDate
              },
              'excludedAdjustments': []
            },
            {
              'key': {
                'statementRevisionId': mocks.statements[1].statementRevisionId,
                'statementId': mocks.statements[1].id,
                'revisionDate': mocks.statements[1].revisionDate
              },
              'excludedAdjustments': []
            }
          ],
          'recalculationAoIds': [object.id]
        });
        return Promise.resolve({
          data: testData
        });
      }
    });

    service.recalculateAnalyticObjects(
      { [object.id]: { name: 'testName' } }, // analyticObjectsVersions
      mocks.statements
    ).then((data) => {
      expect(data).toEqual(testData);
      done();
    });
  });
});
