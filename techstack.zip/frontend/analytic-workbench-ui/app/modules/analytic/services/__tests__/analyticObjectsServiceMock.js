export const AnalyticObjectsDataMock = [
  {
    id: 42, name: 'Test 1', version: 7, type: 'Rule', description: 'description for test 1',
    updated: 1450268391140, updatedBy: 'user 1', createdBy: 'user 2'
  }, {
    id: 7, name: 'Test 2', version: 42, type: 'Model', description: 'description for test 2',
    updated: 1450268391041, updatedBy: 'user 2', createdBy: 'user 3'
  }
];
