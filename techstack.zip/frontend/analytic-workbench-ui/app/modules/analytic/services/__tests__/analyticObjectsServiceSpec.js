/* global beforeEach afterEach describe it */
/* eslint-disable no-console */

import { BASE_URL, BASE_API_URL } from 'config/index';
import expect from 'expect';

import AnalyticObjectsService, {
  getDownloadAnalyticObjectUrl,
  analyticObjectStatuses
} from '../analyticObjectsService.js';

describe('app.modules.analytic.services.__tests__.analyticObjectsServiceSpec', () => {
  const elem = new AnalyticObjectsService({
    get: (str, config) => {
      return new Promise((resolve) => {
        resolve({
          data: {
            str,
            config
          }
        });
      });
    },
    post: (str, ids) => {
      return new Promise((resolve) => {
        resolve({
          data: {
            str,
            ids
          }
        });
      });
    }
  });

  it('testing of getDownloadAnalyticObjectUrl not copy', () => {
    const id = 2;
    const expectedData = new RegExp(`^${BASE_URL}/xlsx-content/${id}$`, 'i');
    const realData = getDownloadAnalyticObjectUrl(id, false);

    expect(realData).toMatch(expectedData);
  });

  it('testing of getDownloadAnalyticObjectUrl copy', () => {
    const id = 2;
    const expectedData = new RegExp(`^${BASE_URL}/xlsx-content/copy/${id}$`, 'i');
    const realData = getDownloadAnalyticObjectUrl(id, true);

    expect(realData).toMatch(expectedData);
  });

  it('testing method of loadAuditTrailData', (done) => {
    const ids = [1, 2, 3, 4, 5, 6, 7];
    const expectedData = {
      str: `${BASE_API_URL}/analytic-objects/audit-trail`,
      config: {
        params: {
          ids: ids.join(',')
        },
        cache: false
      }
    };

    elem.loadAuditTrailData(ids).then((data) => {
      expect(expectedData).toEqual(data);
    }).then(() => {
      done();
    });
  });

  it('testing method of unlockAnalyticObjects', (done) => {
    const ids = [1, 2, 3, 4, 5, 6, 7];
    const expectedData = {
      ids,
      str: `${BASE_API_URL}/analytic-objects/unlock`
    };

    elem.unlockAnalyticObjects(ids).then((data) => {
      expect(expectedData).toEqual(data);
    }).then(() => {
      done();
    });
  });

  it('testing method of deactivateAnalyticObjects', (done) => {
    const ids = [1, 2, 3, 4, 5, 6, 7];
    const expectedData = {
      ids,
      str: `${BASE_API_URL}/analytic-objects/deactivate`
    };

    elem.deactivateAnalyticObjects(ids).then((data) => {
      expect(expectedData).toEqual(data);
    }).then(() => {
      done();
    });
  });

  it('testing method of loadAnalyticObjects with inactive status and undefined searchDto', (done) => {
    const status = analyticObjectStatuses.INACTIVE;
    const searchDto = undefined;
    const page = {
      number: 12,
      size: 24
    };
    const expectedData = {
      str: `${BASE_API_URL}/analytic-objects/inactive`,
      config: {
        params: {
          page: page.number,
          size: page.size
        },
        cache: false
      }
    };

    elem.loadAnalyticObjects(status, searchDto, page).then((data) => {
      expect(expectedData).toEqual(data);
    }).then(() => {
      done();
    });
  });

  it('testing method of loadAnalyticObjects with locked status and undefined searchDto', (done) => {
    const status = analyticObjectStatuses.LOCKED;
    const searchDto = undefined;
    const page = {
      number: 12,
      size: 24
    };
    const expectedData = {
      str: `${BASE_API_URL}/analytic-objects/locked`,
      config: {
        params: {
          page: page.number,
          size: page.size
        },
        cache: false
      }
    };

    elem.loadAnalyticObjects(status, searchDto, page).then((data) => {
      expect(expectedData).toEqual(data);
    }).then(() => {
      done();
    });
  });

  it('testing method of loadAnalyticObjects with active status and undefined searchDto', (done) => {
    const status = analyticObjectStatuses.ACTIVE;
    const searchDto = undefined;
    const page = {
      number: 12,
      size: 24
    };
    const expectedData = {
      str: `${BASE_API_URL}/analytic-objects`,
      config: {
        params: {
          page: page.number,
          size: page.size
        },
        cache: false
      }
    };

    elem.loadAnalyticObjects(status, searchDto, page).then((data) => {
      expect(expectedData).toEqual(data);
    }).then(() => {
      done();
    });
  });

  it('testing method of loadAnalyticObjects with inactive status and not empty searchDto', (done) => {
    const status = analyticObjectStatuses.INACTIVE;
    const searchDto = {
      name: 'Some name',
      filters: [1, 2, 3, 4, 5]
    };
    const page = {
      number: 12,
      size: 24
    };
    const expectedData = {
      str: `${BASE_API_URL}/analytic-objects/inactive`,
      ids: {
        name: searchDto.name,
        filters: searchDto.filters
      }
    };

    elem.loadAnalyticObjects(status, searchDto, page).then((data) => {
      expect(expectedData).toEqual(data);
    }).then(() => {
      done();
    });
  });

  it('testing method of loadAnalyticObjects with active status and not empty searchDto', (done) => {
    const status = analyticObjectStatuses.ACTIVE;
    const searchDto = {
      name: 'Some name',
      filters: [[1, 2, 3, 4, 5]]
    };
    const page = {
      number: 12,
      size: 24
    };
    const expectedData = {
      str: `${BASE_API_URL}/analytic-objects`,
      ids: {
        name: searchDto.name,
        filters: searchDto.filters
      }
    };

    elem.loadAnalyticObjects(status, searchDto, page).then((data) => {
      expect(expectedData).toEqual(data);
    }).then(() => {
      done();
    });
  });


});
