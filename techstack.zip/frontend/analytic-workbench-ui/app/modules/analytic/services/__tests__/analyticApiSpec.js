/* global expect */

import frisby from 'frisby';
import baseJoi from 'joi';
import joiDateExtensions from 'joi-date-extensions';
const joi = baseJoi.extend(joiDateExtensions);

export default function(apiBaseUrl) {
  frisby.create('artifact-details')
    .get(`${apiBaseUrl}/api/issuer-library/artifact-details?typeId=11&objectNativeId=76BB3FC35ED24E77A72C9506D6B95B2E`)
    .expectStatus(200)
    .afterJSON((responseBody) => {
      expect(responseBody).toHaveJoiSchema(joi.object().keys({
        created: joi.object().keys({
          label: joi.string(),
          value: joi.date().format('MMM D, YYYY [at] h:mm A')
        })
      }), { allowUnknown: true, convert: true });
    })
    .toss();

  frisby.create('download-empty-template')
    .get(`${apiBaseUrl}/xlsx-content/empty`)
    .expectStatus(200)
    .expectHeader('Content-Disposition', 'filename=template.xlsx') // tests if the header has the following key-value pair; validates the transmitted file name
    .expectHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8') // checks that the transmitted attachment is xlsx file
    .toss();

  frisby.create('load-analytic-objects')
    .post(`${apiBaseUrl}/api/analytic-objects?page=1&size=10`, {
      filters: {
        country: [],
        lob: [],
        methodology: [],
        privacy: [],
        region: [],
        sourceFile: [],
        subsector: [],
        type: []
      },
      name: 'test'
    })
    .expectHeaderContains('Content-Type', 'json')
    .expectStatus(200)
    .afterJSON((responseBody) => {
      expect(responseBody).toHaveJoiSchema(joi.object().keys({
        data: joi.array().items(joi.object().keys({
          accounting_regime: joi.array(),
          active: joi.boolean(),
          adjustment_type: joi.array(),
          component: joi.array(),
          country: joi.array(),
          created: joi.date().format('YYYY-MM-DD[T]HH:mm:ss.SSSZZ'),
          createdBy: joi.string(),
          description: joi.string().allow(null),
          doc_type: joi.array(),
          id: joi.string(),
          isDefinition: joi.boolean(),
          lob: joi.array(),
          locked: joi.boolean(),
          methodology: joi.array(),
          name: joi.string(),
          version: joi.number()
        }))
      }), { allowUnknown: true, convert: true });
    })
    .toss();
}
