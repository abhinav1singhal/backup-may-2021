import { BASE_API_URL } from 'config/index';
import moment from 'moment';
import { find, isPlainObject, isArray } from 'lodash';
import { transformStatementsResponse, transformIssuersFilters } from '../utils/simulationUtils';

import { prepareIssuerLabel } from 'modules/issuer/utils/issuerUtils';

export const mapStatementsToContract = (statements, adjustments = {}) => {
  return statements.map(({statementRevisionId, id, revisionDate}) => {
    return {
      key: {
        statementRevisionId,
        statementId: id,
        revisionDate
      },
      excludedAdjustments: (adjustments[id] || []).filter(({selected}) => !selected)
        .map((adjustment) => adjustment.id)
    };
  });
};

export default (client) => {

  return {
    loadAnalyticObjectsWithVersions(aoIds) {
      return client
        .get(`${BASE_API_URL}/analytic-objects/with-revisions`, {
          params: {
            aoIds
          },
          cache: false
        })
        .then(({data}) => {
          return data.aos.map(({revisions, ...object}) => ({
            ...object,
            versions: revisions.map((revision) => {
              return {
                ...revision,
                label: revision.production ? `${revision.version} (approved)` : `${revision.version}`
              };
            })
          }));
        });
    },

    loadIssuersFilters() {
      return client
        .get(`${BASE_API_URL}/simulation/issuer-filters`, {
          cache: false
        })
        .then(({data: {lob, subsector, ...rest}}) => ({
          lineOfBusiness: lob,
          sector: subsector,
          ...rest
        }));
    },

    loadIssuerStatementsFilters(issuersParams) {
      const params = {
        ...issuersParams.issuerId ? issuersParams : transformIssuersFilters(issuersParams)
      };
      return client
        .post(`${BASE_API_URL}/simulation/simulation-filters`, params)
        .then(({data}) => ({
          ...data,
          issuer: (isPlainObject(data.organisationId) && isArray(data.organisationId.list)) ? {
            ...data.organisationId,
            list: data.organisationId.list.map((issuer) => {
              return {
                ...issuer,
                description: prepareIssuerLabel(issuer)
              };
            })
          } : undefined,
          revisionDate: {
            ...data.revisionDate,
            list: data.revisionDate.list.map(({description, ...date}) => ({
              ...date,
              description: moment(description).format('DD MMM YYYY')
            }))
          }
        }));
    },

    loadIssuerStatements(issuersParams, page = { number: 1, size: 10 }, sortParams = {}, filters = {}) {
      let sortOrder;

      if (sortParams.sortKey) {
        sortOrder = {
          property: sortParams.sortKey,
          direction: sortParams.sortAscending ? 'ASC' : 'DESC'
        };
      }

      const params = {
        ...transformIssuersFilters(issuersParams),
        page,
        sortOrder,
        filters
      };

      return client
        .post(`${BASE_API_URL}/simulation/simulation-revisions`, params)
        .then(({data}) => ({
          statementRevisions: transformStatementsResponse(data.data),
          totalIssuers: data.totalIssuers,
          page: data.page,
          sortOrder: data.sortOrder && {
            sortKey: data.sortOrder.property,
            sortAscending: data.sortOrder.direction === 'ASC'
          }
        }));
    },

    loadStatementAdjustments({id, statementRevisionId}) {
      return client.get(`${BASE_API_URL}/simulation/simulation-adjustments/${statementRevisionId}`, {
        cache: false
      }).then(({data}) => {
        return data.map((adjustment) => ({
          ...adjustment,
          selected: true,
          adjustment: true,
          statementId: id
        }));
      });
    },

    createAnalyticObjectsSimulation(analyticObjects, analyticObjectsVersions, statements, adjustments, simulationName) {
      const params = {
        title: simulationName,
        statementRevisions: mapStatementsToContract(statements, adjustments),
        simulationAoRevisions: Object.keys(analyticObjectsVersions).map((objectId) => ({
          aoId: objectId,
          aoRevisionId: analyticObjectsVersions[objectId].id,
          name: find(analyticObjects, {id: objectId}).name,
          version: analyticObjectsVersions[objectId].version
        }))
      };

      return client.post(`${BASE_API_URL}/simulation/statement/create-simulation`, params).then(({data}) => ({
        simulationName,
        ...data
      }));
    },

    recalculateAnalyticObjects(analyticObjectsVersions, statements) {
      return client.post(`${BASE_API_URL}/bulk-execution/recalculate`, {
        statementRevisions: mapStatementsToContract(statements),
        recalculationAoIds: Object.keys(analyticObjectsVersions).map((objectId) => objectId)
      }).then(({data}) => data);
    }
  };

};
