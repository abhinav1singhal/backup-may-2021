import { BASE_API_URL } from 'config/index';

export default (client) => {

  return {

    loadAnalyticObjectVersions(id) {
      return client.get(`${BASE_API_URL}/analytic-object/${id}/revisions`, { cache: false })
        .then(({data}) => data);
    },

    approveAnalyticObjectVersion(id, productionVersion) {
      return client.post(`${BASE_API_URL}/approval/${id}`, {productionVersion}).then(({data}) => data);
    },

    withdrawAnalyticObjectsVersion(id) {
      return client.delete(`${BASE_API_URL}/approval/${id}`).then(({data}) => data);
    },

    loadApproveVersionData(id) {
      return client.get(`${BASE_API_URL}/approval/${id}`).then(({ data }) => data);
    }
  };

};
