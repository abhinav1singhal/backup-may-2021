import { BASE_API_URL } from 'config/index';
import { loadDictionaries } from 'react-techstack/redux/services';
import { FormBuilderConfigDTO } from 'react-techstack/utils';
import { omit, forEach, isObject } from 'lodash';
import { FORM_CONTROL_TYPES } from 'react-techstack/FormBuilder';

import {
  prepareDataFromDictionary,
  prepareBEData, removeEmpty,
  unsetNonconfigFields
} from 'modules/analytic/utils/attributesUtils';
import { getPropertiesConfig, unrequireForBulk, getNotChangedFields } from 'modules/analytic/utils/attributesServiceUtils';
import { prepareTreeOptions } from 'modules/shared/utils/treeSelectUtils';

export default (client) => {
  const Service = {
    loadUpdateForm: (ids) => {
      return Service.loadUpdateFormDataConfig(ids)
        .then(({ config, data }) => {
          return Service.loadFormDictionary(config)
            .then((treeDictionaries) => {
              return {
                data: prepareDataFromDictionary(data, treeDictionaries, config),
                config: {
                  props: config.properties.getControlsList(),
                  attrs: config.attributes.getControlsList()
                },
                dictionaries: treeDictionaries
              };
            });
        });
    },
    loadCreateForm: (file) => {
      return Service.loadCreateFormDataConfig()
        .then(({ config, data }) => {
          return Service.loadFormDictionary(config)
            .then((dictionaries) => {
              return {
                data: {
                  ...prepareDataFromDictionary(data, dictionaries, config),
                  file
                },
                config: {
                  props: config.properties.getControlsList(),
                  attrs: config.attributes.getControlsList()
                },
                dictionaries
              };
            });
        });
    },
    saveUpdateForm: (feData, config, savedData) => {
      const notChangedFields = getNotChangedFields(feData, savedData);
      const beData = prepareBEData(feData, config, notChangedFields);
      return client.post(`${BASE_API_URL}/v2/attributes`, beData)
        .then(({ data }) => data)
        .catch(({data}) => {
          const errorCode = isObject(data) ? data.code : 'UNEXPECTED';
          const errorParams = data.params ? data.params : [];
          return Promise.reject({errorCode, errorParams});
        });
    },
    saveCreateForm: (feData, config) => {
      const postConfig = {
        cache: false,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      };
      const beData = prepareBEData(feData, config);

      const staticParams = removeEmpty(beData.properties);
      const attributes = removeEmpty(beData.attributes);

      const requestData = new FormData();
      forEach(staticParams, (value, key) => {
        requestData.append(key, value);
      });
      requestData.append('attributes', JSON.stringify(attributes));

      return client.post(`${BASE_API_URL}/upload/ao`, requestData, postConfig)
        .then(({data: payload}) => payload)
        .catch(({data}) => {
          const errorCode = isObject(data) ? data.code : 'UNEXPECTED';
          const errorParams = data.params ? data.params : [];
          if (errorCode === 'NAME_ALREADY_EXISTS') {
            errorParams.push(beData.properties.name);
          }
          return Promise.reject({errorCode, errorParams});
        });
    },
    updateAttributesForType: (typeId, {config: oldConfig, dictionaries: oldDictionaries}) => {
      const attrsKeys = oldConfig.attrs.map(({ key }) => key);
      return Service.loadAttributesConfig(typeId)
        .then((config) => {
          return {
            attrs: config,
            props: [],
            attributes: new FormBuilderConfigDTO(config),
            properties: new FormBuilderConfigDTO([])
          };
        })
        .then((config) => {
          return Service.loadFormDictionary(config)
            .then((dictionaries) => {
              return {
                config: {
                  props: oldConfig.props,
                  attrs: config.attributes.getControlsList()
                },
                dictionaries: {
                  ...omit(oldDictionaries, ...attrsKeys),
                  ...dictionaries
                }
              };
            });
        });
    },

    loadFormDictionary: (config) => {
      const DictionariesConfig = config.properties.cloneDictionariesConfig();
      DictionariesConfig.merge(config.attributes.cloneDictionariesConfig());

      return loadDictionaries(client, DictionariesConfig.getRequestConfigList(), BASE_API_URL)
        .then((dictionaries) => {
          config.properties.setDictionariesValues(dictionaries);
          config.attributes.setDictionariesValues(dictionaries);
          const treeDictionaries = {
            ...config.attributes.getControlDictionaries(),
            ...config.properties.getControlDictionaries()
          };
          const controlsList = config.properties.getControlsList().concat(config.attributes.getControlsList());
          controlsList.forEach((item) => {
            if (item.type === FORM_CONTROL_TYPES.TREEVIEW_MULTISELECT || item.type === FORM_CONTROL_TYPES.TREEVIEW_SELECT) {
              treeDictionaries[item.key] = prepareTreeOptions(treeDictionaries[item.key]);
            }
          });
          return treeDictionaries;
        });
    },
    loadAttributesConfig(typeId) {
      return client.get(`${BASE_API_URL}/v2/attributes/attrs-cfg/${typeId}`)
        .then(({ data }) => data.filters);
    },
    loadPropertiesUpdateConfig(isBulk) {
      return Promise.resolve(getPropertiesConfig(true, isBulk));
    },
    loadPropertiesCreateConfig() {
      return Promise.resolve(getPropertiesConfig(false));
    },
    loadUpdateFormDataConfig(ids) {
      const config = {
        params: {
          ids: ids.join(',')
        },
        cache: false
      };
      const isBulk = ids.length > 1;

      return client.get(`${BASE_API_URL}/v2/attributes`, config)
        .then(({ data }) => {
          return Promise.all([Service.loadPropertiesUpdateConfig(isBulk), Service.loadAttributesConfig(data.properties.type)])
            .then(([ propsConfig, attrsConfig ]) => {
              const readyProps = unrequireForBulk(propsConfig, data.properties, isBulk);
              const readyAttrs = unrequireForBulk(attrsConfig, data.attributes, isBulk);

              return {
                data: {
                  ...omit(data, 'properties', 'attributes'),
                  ...unsetNonconfigFields(data.properties, readyProps),
                  ...unsetNonconfigFields(data.attributes, readyAttrs)
                },
                config: {
                  properties: new FormBuilderConfigDTO(readyProps),
                  attributes: new FormBuilderConfigDTO(readyAttrs),
                  props: readyProps,
                  attrs: readyAttrs
                }
              };
            });
        });
    },
    loadCreateFormDataConfig() {
      return Service.loadPropertiesCreateConfig()
        .then((propsConfig) => {
          return {
            data: { executable: true },
            config: {
              properties: new FormBuilderConfigDTO(propsConfig),
              attributes: new FormBuilderConfigDTO([]),
              props: propsConfig,
              attrs: []
            }
          };
        });
    }
  };

  return Service;
};
