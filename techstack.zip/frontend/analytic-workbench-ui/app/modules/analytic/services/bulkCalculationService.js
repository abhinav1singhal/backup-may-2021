import { BASE_API_URL } from 'config/index';
import moment from 'moment';
import { isPlainObject, isArray } from 'lodash';

import { transformStatementsResponse, transformIssuersFilters } from '../utils/simulationUtils';
import { prepareIssuerLabel } from 'modules/issuer/utils/issuerUtils';

// TODO: FND-2996 Use new dictionary EP to load issuer filters
// const filterDictionaryQuery = [
//   { dataEntityId: 'lob' },
//   { dataEntityId: 'subsector' },
//   { dataEntityId: 'region' },
//   { dataEntityId: 'country' }
// ];

export default (client) => {

  return {

    // loadIssuerFilters() {
    //   return loadDictionaries(client, filterDictionaryQuery)
    //     .then((data) => {
    //       const { lob, subsector, ...rest } = data;
    //       return {
    //         lineOfBusiness: lob,
    //         sector: subsector,
    //         ...rest
    //       };
    //     });
    // },

    // TODO: FND-2996 Make request to BE when EP is ready
    loadCalculationTypes() {
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve([
            {
              id: 'RATIOS_RECALCULATION',
              name: 'Recalculate All Ratios'
            },
            {
              id: 'STMT_RECALCULATION',
              name: 'Recalculate Statement'
            }
          ]);
        }, 1000);
      });
    },

    loadIssuerStatements(issuersParams, page = { number: 1, size: 10 }, sortParams = {}, filters = {}) {
      let sortOrder;

      if (sortParams.sortKey) {
        sortOrder = {
          property: sortParams.sortKey,
          direction: sortParams.sortAscending ? 'ASC' : 'DESC'
        };
      }

      const params = {
        ...transformIssuersFilters(issuersParams),
        page,
        sortOrder,
        filters
      };

      return client
        .post(`${BASE_API_URL}/simulation/bulk-revisions`, params)
        .then(({data}) => ({
          statementRevisions: transformStatementsResponse(data.data),
          totalIssuers: data.totalIssuers,
          page: data.page,
          sortOrder: data.sortOrder && {
            sortKey: data.sortOrder.property,
            sortAscending: data.sortOrder.direction === 'ASC'
          }
        }));
    },

    loadIssuerStatementsFilters(issuersParams) {
      const params = {
        ...issuersParams.issuerId ? issuersParams : transformIssuersFilters(issuersParams)
      };
      return client
        .post(`${BASE_API_URL}/simulation/bulk-filters`, params)
        .then(({data}) => ({
          ...data,
          issuer: (isPlainObject(data.organisationId) && isArray(data.organisationId.list)) ? {
            ...data.organisationId,
            list: data.organisationId.list.map((issuer) => {
              return {
                ...issuer,
                description: prepareIssuerLabel(issuer)
              };
            })
          } : undefined,
          revisionDate: {
            ...data.revisionDate,
            list: data.revisionDate.list.map(({description, ...date}) => ({
              ...date,
              description: moment(description).format('DD MMM YYYY')
            }))
          }
        }));
    },

    submitBatchCalculation(calculationType, manualSelection, selectedStatements, issuerParams) {
      const statementsToSubmit = manualSelection ? selectedStatements : [];

      const params = {
        ...transformIssuersFilters(issuerParams),
        batchCalculationType: calculationType.id,
        manualSelected: manualSelection,
        statementIds: statementsToSubmit.map((statement) => statement.id),
        filters: {}
      };

      return client.post(`${BASE_API_URL}/batch/execute`, params);
    },

    // @Deprecated
    executeBatchCalculation(calculationType) {
      const params = {
        calculationType: calculationType.id
      };

      return client.post(`${BASE_API_URL}/batch/execute`, params);
    }
  };

};
