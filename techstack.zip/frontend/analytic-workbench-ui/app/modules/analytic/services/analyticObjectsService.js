import { BASE_URL, BASE_API_URL } from 'config/index';
import { isUndefined, isEmpty, every } from 'lodash';

export function getDownloadEmptyTemplateUrl() {
  return `${BASE_URL}/xlsx-content/empty`;
}

export function getDownloadAnalyticObjectUrl(id, copy) {
  return `${BASE_URL}/xlsx-content/${copy ? 'copy/' : ''}${id}`;
}

export function getDownloadAnalyticObjectRevisionUrl(id, revision) {
  return `${BASE_URL}/xlsx-content/${id}/${revision}`;
}

export const analyticObjectStatuses = {
  ACTIVE: 'ACTIVE',
  INACTIVE: 'INACTIVE',
  LOCKED: 'LOCKED'
};

function searchDtoIsEmpty(searchDto) {
  if (isUndefined(searchDto)) {
    return true;
  }

  return isEmpty(searchDto.name) && every(searchDto.filters, isEmpty);
}

export default (client) => {

  return {

    loadAnalyticObjects(status, searchDto, page) {
      let url = `${BASE_API_URL}/analytic-objects`;
      if (status === analyticObjectStatuses.INACTIVE) {
        url += '/inactive';
      } else if (status === analyticObjectStatuses.LOCKED) {
        url += '/locked';
      }

      const config = {
        params: {
          page: page.number,
          size: page.size
        },
        cache: false
      };

      let request;
      if (searchDtoIsEmpty(searchDto)) {
        request = client.get(url, config);
      } else {
        request = client.post(url, searchDto, config);
      }

      return request.then(({data}) => data);
    },

    loadAuditTrailData(ids) {
      const config = {
        params: {
          ids: ids.join(',')
        },
        cache: false
      };

      return client.get(`${BASE_API_URL}/analytic-objects/audit-trail`, config).then(({data}) => data);
    },

    unlockAnalyticObjects(ids) {
      return client.post(`${BASE_API_URL}/analytic-objects/unlock`, ids).then(({data}) => data);
    },

    deactivateAnalyticObjects(ids) {
      return client.post(`${BASE_API_URL}/analytic-objects/deactivate`, ids)
        .then(({data}) => data);
    },

    uploadNewAnalyticObjectVersion(analyticObject, file) {
      const config = {
        cache: false,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      };

      const requestData = new FormData();
      requestData.append('file', file);

      return client.post(`${BASE_API_URL}/upload/ao/${analyticObject.id}`, requestData, config)
        .then(() => analyticObject);
    }

  };

};
