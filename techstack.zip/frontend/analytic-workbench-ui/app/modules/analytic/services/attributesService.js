import { BASE_API_URL } from 'config/index';

export default (client) => {

  function loadAttributes() {
    return client.get(`${BASE_API_URL}/dictionary/filters`, {cache: false})
      .then(({data}) => ({ ...data, executable: [{ id: 'NO', name: 'NO'}, { id: 'YES', name: 'YES'}] }));
  }

  return {
    loadAttributes
  };
};
