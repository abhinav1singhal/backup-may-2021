import { BASE_URL, BASE_API_URL } from 'config/index';

export function getLoadObjectDependenciesXlsRequestConfig(id, filters) {
  return {
    url: `${BASE_URL}/xlsx-content/dependencies/${id}`,
    params: {
      dep: filters.dependency.join(','),
      depType: filters.dependencyType.join(','),
      objType: filters.objectType.join(',')
    }
  };
}

export default (client) => {

  return {
    loadObjectDependencies(id, filters) {
      const config = {
        params: {
          dep: filters.dependency.join(','),
          depType: filters.dependencyType.join(','),
          objType: filters.objectType.join(',')
        },
        cache: false
      };

      return client
        .get(`${BASE_API_URL}/dependencies/${id}`, config)
        .then(({data}) => {
          return {
            ...data,
            predecessors: (data && data.predecessors) ? data.predecessors : [],
            successors: (data && data.successors) ? data.successors : []
          };
        });

    },
    loadObjectDependenciesFilters() {

      return client
        .get(`${BASE_API_URL}/dictionary/dependency-filters`, {cache: false})
        .then(({data}) => data);

    }

  };
};
