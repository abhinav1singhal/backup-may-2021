/* global describe, it, beforeEach, afterEach, sinon, xdescribe */

import React from 'react';
import TestUtils from 'react-dom/test-utils';
import { findDOMNode } from 'react-dom';
import expect from 'expect';
import { noop } from 'lodash/util';

import ObjectDependenciesTable from '../ObjectDependenciesTable';

describe('app.modules.analytic.components.ObjectDependenciesTable.__tests__.ObjectDependenciesTableSpec', () => {
  // const dataMock = [{
  //   name: 'TestName',
  //   type: 'TestType',
  //   id: 1,
  //   dependency: 'TestDependency',
  //   children: [{
  //     name: 'TestNameChildren',
  //     type: 'TestTypeChildren',
  //     id: 1,
  //     dependency: 'TestDependencyChildren'
  //   }]
  // }, { name: 'TestName',
  //   type: 'TestType',
  //   id: 2,
  //   dependency: 'TestDependency',
  //   children: [{
  //     name: 'TestNameChildren',
  //     type: 'TestTypeChildren',
  //     id: 1,
  //     dependency: 'TestDependencyChildren'
  //   }]
  // }];

  function renderObjectDependenciesTable(customProps) {
    const props = {
      data: [],
      filtersValue: {},
      title: 'TestDependencies',
      loadObjectSubDependencies: noop,
      ...customProps
    };

    return TestUtils.renderIntoDocument(React.createElement(
      ObjectDependenciesTable,
      props
    ));
  }

  it('should render renderNoDataMessage alert if data is empty array', () => {
    const tableInstance = renderObjectDependenciesTable();
    const tableNode = findDOMNode(tableInstance);
    const alertNode = tableNode.querySelector('.alert');

    expect(alertNode).toExist();
  });

  it('should render renderNoDataMessage alert if first data element has empty children', () => {
    const tableInstance = renderObjectDependenciesTable({
      data: [{
        children: []
      }]
    });
    const tableNode = findDOMNode(tableInstance);
    const alertNode = tableNode.querySelector('.alert');

    expect(alertNode).toExist();
  });

  // todo try to resolve `addComponentAsRefTo(...): Only a ReactOwner can have refs.` error
  // it('should render renderDataTable', () => {
  //   const tableInstance = renderObjectDependenciesTable({
  //     data: dataMock
  //   });
  //   const tableNode = findDOMNode(tableInstance);
  //   const alertNode = tableNode.querySelector('.alert');
  //
  //   expect(alertNode).toNotExist();
  // });
});
