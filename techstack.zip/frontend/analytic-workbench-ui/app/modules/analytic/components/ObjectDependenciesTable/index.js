export default from './ObjectDependenciesTableContainer';
