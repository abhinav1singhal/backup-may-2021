import PropTypes from 'prop-types';
import React from 'react';
import { Alert } from 'react-techstack';
import { isArray } from 'lodash/lang';
import TreeDataTable, { DataTableCell, TreeViewCell } from 'modules/shared/components/TreeDataTable';
import DependencyCell from './components/DependencyCell';

class ObjectDependenciesTable extends React.Component {

  static propTypes = {
    data: PropTypes.arrayOf(PropTypes.object).isRequired,
    dependency: PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired
    }),
    filtersValue: PropTypes.object.isRequired,
    title: PropTypes.string.isRequired,
    loadObjectSubDependencies: PropTypes.func.isRequired,

    theme: PropTypes.object.isRequired
  };

  onToggleExpand(expanded, item, level) {
    this.props.loadObjectSubDependencies(item, this.props.dependency, this.props.filtersValue, level, expanded);
  }

  cell(data, key, rowData, cellProps) {
    if (key === 'dependency' && isArray(data) && data.length === 2) {
      return <DependencyCell data={data} />;
    } else if (key === 'description') {
      return <TreeViewCell {...cellProps}>{data || ''}</TreeViewCell>;
    }

    return <DataTableCell>{data || ''}</DataTableCell>;
  }

  rowClassNameGetter(rowIndex, row) {
    return row.$level === 0 ? this.props.theme.topLevelRecord : null;
  }

  renderNoDataMessage() {
    const dependency = this.props.dependency || {};

    return <Alert bsStyle="warning">No {dependency.name} data found</Alert>;
  }

  renderDataTable() {
    const columns = [
      {key: 'name', title: 'Object name', width: 150},
      {key: 'description', title: 'Display name', width: 400, treeView: true},
      {key: 'type', title: 'Object type', width: 200},
      {key: 'dependency', title: 'Dependency type', width: 300}
    ];

    const treeDataTableProps = {
      columns,
      data: this.props.data,
      cell: this.cell.bind(this),
      expandableTreeView: true,
      onToggleExpand: this.onToggleExpand.bind(this),
      width: 'auto',
      maxHeight: 350,
      rowClassNameGetter: this.rowClassNameGetter.bind(this)
    };

    return <TreeDataTable {...treeDataTableProps} />;
  }

  render() {
    const noData = this.props.data.length === 0 || this.props.data[0].children.length === 0;

    return (
      <div className={this.props.theme.root}>
        <h4>{this.props.title}</h4>
        {noData ? this.renderNoDataMessage() : this.renderDataTable()}
      </div>
    );
  }
}

ObjectDependenciesTable.defaultProps = {
  theme: require('./ObjectDependenciesTable.css')
};

export default ObjectDependenciesTable;
