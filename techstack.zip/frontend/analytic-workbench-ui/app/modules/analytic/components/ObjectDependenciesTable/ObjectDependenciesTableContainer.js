import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { find } from 'lodash/collection';

import {
  loadObjectSubDependencies
} from 'modules/analytic/actions/objectDependenciesActions';

import ObjectDependenciesTable from './ObjectDependenciesTable';

function mapStateToProps(state, {type}) {
  const titles = {
    predecessors: 'Predecessors',
    successors: 'Successors'
  };

  const {data, filtersDictionary, filtersValue} = state.objectDependencies;

  return {
    title: titles[type],
    data: data[type],
    dependency: find(filtersDictionary.dependency, {name: type}),
    filtersValue
  };
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    loadObjectSubDependencies
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(ObjectDependenciesTable);
