import PropTypes from 'prop-types';
import React from 'react';

class DependencyCell extends React.Component {

  static propTypes = {
    data: PropTypes.arrayOf(PropTypes.string).isRequired,
    theme: PropTypes.object.isRequired
  };

  render() {
    return (
      <div className={this.props.theme.root}>
        {this.props.data[0]} &rarr; {this.props.data[1]}
      </div>
    );
  }

}

DependencyCell.defaultProps = {
  theme: require('./DependencyCell.css')
};

export default DependencyCell;
