/* global describe, it, beforeEach, afterEach, sinon, xdescribe */

import React from 'react';
import TestUtils from 'react-dom/test-utils';
import { findDOMNode } from 'react-dom';
import expect from 'expect';
import { noop } from 'lodash/util';

import DownloadTemplateButton from '../DownloadTemplateButton';
import { Button } from 'react-techstack';

describe('app.modules.analytic.components.DownloadTemplateButton.__tests__.DownloadTemplateButtonSpec', () => {
  function renderDownloadTemplateButton(customProps) {
    const props = {
      userPermissions: [],
      onClick: noop,
      ...customProps
    };

    return TestUtils.renderIntoDocument(React.createElement(
      DownloadTemplateButton,
      props
    ));
  }

  it('should not render element without proper permissions', () => {
    const buttonInstance = renderDownloadTemplateButton();
    const buttonNode = findDOMNode(buttonInstance);

    expect(buttonNode).toNotExist();
  });

  it('should render if user has permissions', () => {
    const buttonInstance = renderDownloadTemplateButton({
      userPermissions: ['CREATE_NEW_ANALYTICOBJECT']
    });
    const buttonNode = findDOMNode(buttonInstance);

    expect(buttonNode).toExist();
  });

  it('should call onClick function if was clicked', () => {
    const props = {
      userPermissions: ['CREATE_NEW_ANALYTICOBJECT'],
      onClick: expect.createSpy()
    };
    const buttonInstance = renderDownloadTemplateButton(props);
    const innerButton = TestUtils.findRenderedComponentWithType(buttonInstance, Button);
    const buttonNode = findDOMNode(innerButton);
    TestUtils.Simulate.click(buttonNode);

    expect(props.onClick).toHaveBeenCalled();
  });
});
