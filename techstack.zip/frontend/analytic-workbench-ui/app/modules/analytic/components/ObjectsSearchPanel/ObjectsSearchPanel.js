import PropTypes from 'prop-types';
import React from 'react';
import { Input, Button } from 'react-techstack';

import {hasPermission} from 'modules/common/utils/permissionsUtils';
import { analyticObjectStatuses } from 'modules/analytic/services/analyticObjectsService';
import { Icon } from 'modules/shared/components';

export default class ObjectsSearchPanel extends React.Component {

  static propTypes = {
    searchString: PropTypes.string.isRequired,
    analyticObjectsStatus: PropTypes.oneOf([
      analyticObjectStatuses.ACTIVE, analyticObjectStatuses.INACTIVE, analyticObjectStatuses.LOCKED
    ]).isRequired,
    userPermissions: PropTypes.arrayOf(PropTypes.string).isRequired,
    onSearch: PropTypes.func.isRequired,
    applyNameSearch: PropTypes.func.isRequired,
    disabled: PropTypes.bool
  };

  constructor(props) {
    super(props);

    this.state = {
      value: props.searchString
    };
  }

  UNSAFE_componentWillReceiveProps({searchString}) {
    if (this.state.value !== searchString) {
      this.setState({value: searchString}); // eslint-disable-line react/no-set-state
    }
  }

  onChange = (e) => {
    const value = e.target.value;
    this.setState({value}); // eslint-disable-line react/no-set-state
  };

  onSubmit = (e) => {
    e.preventDefault();
    this.props.applyNameSearch(this.state.value);
    this.props.onSearch();
  };

  render() {
    const { disabled } = this.props;
    const requiredUserPermissions = [
      `view_${this.props.analyticObjectsStatus}_AnalyticObjects_list`,
      `search_${this.props.analyticObjectsStatus}_AnalyticObjects`
    ];

    if (hasPermission(this.props.userPermissions, requiredUserPermissions, true)) {
      const searchButton = (
        <Button disabled={disabled} type="submit" bsStyle="primary">
          <Icon type="search" color="#fff" />
        </Button>
      );

      const inputProps = {
        ref: 'searchInput',
        type: 'text',
        value: this.state.value,
        onChange: this.onChange,
        buttonAfter: searchButton,
        placeholder: 'Search by Analytic Object Name',
        disabled
      };

      return (
        <form onSubmit={this.onSubmit}>
          <Input {...inputProps} />
        </form>
      );
    }

    return null;
  }

}
