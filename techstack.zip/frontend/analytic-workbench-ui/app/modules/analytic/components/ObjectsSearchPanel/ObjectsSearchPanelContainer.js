import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import {
  applyNameSearch
} from 'modules/analytic/actions/attributesFilterActions';

import ObjectsSearchPanel from './ObjectsSearchPanel';

export function mapStateToProps(state) {
  return {
    searchString: state.attributesFilter.name,
    userPermissions: state.user.permissions
  };
}

export function mapDispatchToProps(dispatch) {
  return {
    ...bindActionCreators({
      applyNameSearch
    }, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(ObjectsSearchPanel);
