export default from './ObjectsSearchPanelContainer';
