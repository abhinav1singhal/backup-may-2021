/* global describe, it, beforeEach, afterEach, sinon, xdescribe */

import React from 'react';
import ShallowRenderer from 'react-test-renderer/shallow';
import expect from 'expect';
import { noop } from 'lodash/util';

import ObjectsSearchPanel from '../ObjectsSearchPanel';
import { analyticObjectStatuses } from 'modules/analytic/services/analyticObjectsService';
import { PermissionKeys } from 'modules/analytic/components/ObjectsActionPanel/__tests__/permisionsMock';

describe('app.modules.analytic.components.ObjectsSearchPanel.__tests__.ObjectsSearchPanelSpec', () => {

  const defaultProps = {
    searchString: '',
    analyticObjectsStatus: analyticObjectStatuses.LOCKED,
    userPermissions: PermissionKeys,
    onSearch: noop,
    applyNameSearch: noop
  };

  function createObjectsSearchPanelElement(customProps) {
    return React.createElement(
      ObjectsSearchPanel, {
        ...defaultProps,
        ...customProps
      }
    );
  }

  // function checkOnSearchBeingCalled(onSearchTrigger) {
  //   const onSearchSpy = expect.createSpy();
  //
  //   const component = TestUtils.renderIntoDocument(
  //     createObjectsSearchPanelElement({
  //       onSearch: onSearchSpy
  //     })
  //   );
  //
  //   onSearchTrigger(component);
  //   expect(onSearchSpy).toHaveBeenCalled();
  // }

  // function checkApplyNameSearchBeingCalled(applyNameSearchTrigger) {
  //   const searchString = 'test';
  //   const applyNameSearchSpy = expect.createSpy();
  //
  //   const component = TestUtils.renderIntoDocument(
  //     createObjectsSearchPanelElement({
  //       searchString,
  //       applyNameSearch: applyNameSearchSpy
  //     })
  //   );
  //
  //   applyNameSearchTrigger(component);
  //   expect(applyNameSearchSpy).toHaveBeenCalledWith(searchString);
  // }

  it('should not render component when user has no permissions', () => {
    const shallowRenderer = new ShallowRenderer();

    shallowRenderer.render(
      createObjectsSearchPanelElement({
        userPermissions: []
      })
    );

    const component = shallowRenderer.getRenderOutput();
    expect(component).toBe(null);
  });

  it('should render a form when user has required permissions', () => {
    const shallowRenderer = new ShallowRenderer();

    shallowRenderer.render(createObjectsSearchPanelElement());

    const component = shallowRenderer.getRenderOutput();
    expect(component.type).toBe('form');
  });

  // todo fix ` addComponentAsRefTo(...): Only a ReactOwner can have refs.` error for the 5 tests below
  // it('should call applyNameSearch with searchString as an argument on form submit', () => {
  //   checkApplyNameSearchBeingCalled((component) => {
  //     const form = TestUtils.findRenderedDOMComponentWithTag(component, 'form');
  //     TestUtils.Simulate.submit(form);
  //   });
  // });
  //
  // it('should call applyNameSearch with searchString as an argument on search button click', () => {
  //   checkApplyNameSearchBeingCalled((component) => {
  //     const button = TestUtils.findRenderedDOMComponentWithTag(component, 'button');
  //     TestUtils.Simulate.submit(button);
  //
  //     // TestUtils.findRenderedDOMComponentWithTag(component, 'button').click();
  //   });
  // });
  //
  // it('should call onSearch on form submit', () => {
  //   checkOnSearchBeingCalled((component) => {
  //     const form = TestUtils.findRenderedDOMComponentWithTag(component, 'form');
  //     TestUtils.Simulate.submit(form);
  //   });
  // });
  //
  // it('should call onSearch on search button click', () => {
  //   checkOnSearchBeingCalled((component) => {
  //     TestUtils.findRenderedDOMComponentWithTag(component, 'button').click();
  //   });
  // });
  //
  // it('should call applyNameSearch with new string after resetting input and submitting form', () => {
  //   const initialSearchString = 'test';
  //   const newSearchString = '';
  //   const applyNameSearchSpy = expect.createSpy();
  //
  //   const component = TestUtils.renderIntoDocument(
  //     createObjectsSearchPanelElement({
  //       searchString: initialSearchString,
  //       applyNameSearch: applyNameSearchSpy
  //     })
  //   );
  //
  //   const searchInput = component.refs.searchInput.refs.input;
  //   expect(searchInput.value).toBe(initialSearchString);
  //
  //   searchInput.value = newSearchString;
  //   TestUtils.Simulate.change(searchInput);
  //
  //   const form = TestUtils.findRenderedDOMComponentWithTag(component, 'form');
  //   TestUtils.Simulate.submit(form);
  //
  //   expect(applyNameSearchSpy).toHaveBeenCalledWith(newSearchString);
  // });

});
