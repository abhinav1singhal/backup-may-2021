import PropTypes from 'prop-types';
import React, { Component } from 'react';

import moment from 'moment';
import { DataTable, DataTableCell } from 'react-techstack';

export default class VersionsDrillDownTable extends Component {

  static propTypes = {
    versions: PropTypes.array.isRequired,
    width: PropTypes.number
  };

  _cell = (data, key, row, cellProps) => {
    let content;
    switch (key) {
      case 'name':
      case 'type':
      case 'description':
        content = cellProps.rowIndex === 0 ? data : null;
        break;
      case 'updated':
        content = moment(data).format('L');
        break;
      default:
        content = data;
    }

    return (
      <DataTableCell {...cellProps}>
        { content || '' }
      </DataTableCell>
    );
  };

  render() {
    return (
      <DataTable {...{
        data: this.props.versions,
        columns: [
          { key: 'name', label: 'Name' },
          { key: 'type', label: 'Type'  },
          { key: 'description', label: 'Description' },
          { key: 'updated', label: 'Created'  },
          { key: 'updatedBy', label: 'Created by' },
          { key: 'version', label: 'Version', width: 150 }
        ],
        cell: this._cell,
        width: this.props.width || 'auto',
        height: 500
      } } />
    );
  }

}
