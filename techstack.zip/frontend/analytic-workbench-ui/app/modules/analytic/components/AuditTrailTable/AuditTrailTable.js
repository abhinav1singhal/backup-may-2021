import PropTypes from 'prop-types';
import React from 'react';
import moment from 'moment';
import { isArray } from 'lodash/lang';
import { asyncStatus } from 'react-techstack/utils';
import { DataTableBare, DataTableCell, Button, LoadingContainer, Alert } from 'react-techstack';

import booleanValues from 'utils/booleanValues';
import theme from './AuditTrailTable.css';

export default class AuditTrailTable extends React.Component {
  static propTypes = {
    analyticObjectsIds: PropTypes.arrayOf(PropTypes.string).isRequired,
    data: PropTypes.arrayOf(PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      auditRecords: PropTypes.arrayOf(PropTypes.object).isRequired
    })).isRequired,
    loadingStatus: PropTypes.string.isRequired,

    loadAuditTrailData: PropTypes.func.isRequired,
    downloadAnalyticObjectRevision: PropTypes.func.isRequired
  };

  UNSAFE_componentWillMount() {
    this.props.loadAuditTrailData(this.props.analyticObjectsIds);
  }

  onExpressionButtonClick(id, revision) {
    return (event) => {
      event.preventDefault();
      this.props.downloadAnalyticObjectRevision(id, revision);
    };
  }

  headerCell(cellProps, cellContent) {
    cellProps.className = theme.headerCell;
    return cellContent;
  }

  cell = (data, key, row) => {
    let content;

    switch (key) {
      case 'fromValue':
      case 'toValue':
        content = data;
        if (row.field === 'Expression' && data) {
          content = (
            <Button onClick={this.onExpressionButtonClick(row.id, data)} className={theme.expressionButton}
                    bsStyle="link" href="#">
              {key === 'fromValue' ? 'Previous version' : 'New version'}
            </Button>
          );
        } else if (isArray(data)) {
          content = data.join(', ');
        } else if (booleanValues.hasOwnProperty(data)) {
          content = booleanValues[data];
        }

        break;
      case 'auditDt':
        content = moment(data).format('L LTS');
        break;
      default:
        content = data;
    }

    return (
      <DataTableCell>
        {content || ''}
      </DataTableCell>
    );
  };

  renderErrorMessage() {
    if (this.props.loadingStatus !== asyncStatus.FAILURE) {
      return null;
    }

    return <Alert bsStyle="danger">An unexpected error occurred.</Alert>;
  }

  renderTable() {
    if (this.props.loadingStatus !== asyncStatus.SUCCESS) {
      return null;
    }

    const columns = [
      {key: 'action', label: 'Action performed', width: 100},
      {key: 'userId', label: 'Performed by', width: 150},
      {key: 'field', label: 'Parameter updated', width: 150},
      {key: 'fromValue', label: 'From value', width: 120},
      {key: 'toValue', label: 'To value', width: 120},
      {key: 'auditDt', label: 'Last update date/time'},
      {key: 'revisionVersion', label: 'Version #', width: 84}
    ];

    return (
      <div>
        {this.props.data.map(({id, name, auditRecords}) => {
          const calculatedHeight = auditRecords.length * 50 + 55;
          const dataTableProps = {
            data: auditRecords.map((record) => {
              return {...record, id};
            }),
            columns,
            width: 855, // ToDo: switch to 'auto' after bug will be fixed
            height: calculatedHeight > 550 ? 550 : calculatedHeight,
            headerCell: this.headerCell,
            cell: this.cell
          };

          return (
            <div key={id}>
              <h4>{name}</h4>
              <DataTableBare {...dataTableProps} />
            </div>
          );
        })}
      </div>
    );
  }

  render() {
    return (
      <LoadingContainer isLoading={this.props.loadingStatus === asyncStatus.REQUEST}>
        {this.renderErrorMessage()}
        {this.renderTable()}
      </LoadingContainer>
    );
  }
}
