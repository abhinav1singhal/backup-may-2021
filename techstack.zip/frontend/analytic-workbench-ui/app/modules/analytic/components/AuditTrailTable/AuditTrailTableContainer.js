import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import {
  loadAuditTrailData,
  downloadAnalyticObjectRevision
} from 'modules/analytic/actions/analyticObjectsActions';

import AuditTrailTable from './AuditTrailTable';

export function mapStateToProps(state) {
  return {
    data: state.analytic.auditTrail.data,
    loadingStatus: state.analytic.auditTrail.loadingStatus
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    loadAuditTrailData,
    downloadAnalyticObjectRevision
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(AuditTrailTable);
