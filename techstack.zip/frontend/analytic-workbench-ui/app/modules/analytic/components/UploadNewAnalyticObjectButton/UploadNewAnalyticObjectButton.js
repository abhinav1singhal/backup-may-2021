import React from 'react';
import { ButtonWithPermissions } from 'modules/shared/components';

export default class UploadNewAnalyticObjectButton extends React.Component {
  render() {
    return (
      <ButtonWithPermissions
        {...this.props}
        bsStyle="primary"
        label="Import new analytic object"
        requestedPermissions="create_new_AnalyticObject"
      />
    );
  }

}
