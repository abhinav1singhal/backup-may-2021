import PropTypes from 'prop-types';
import React from 'react';
import MultiSelect from 'modules/shared/components/MultiSelect';


class FilterSelect extends React.Component {

  static propTypes = {
    options: PropTypes.arrayOf(PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired
    })).isRequired,
    value: PropTypes.arrayOf(PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired
    })).isRequired,
    onChange: PropTypes.func.isRequired,
    showSelectAll: PropTypes.bool,

    label: PropTypes.string.isRequired
  };

  render() {
    const multiSelectProps = {
      options: this.props.options,
      value: this.props.value,
      onChange: this.props.onChange,
      disabled: this.props.options.length === 0,
      label: this.props.label,
      labelKey: 'name',
      valueKey: 'id',
      showSelectAll: this.props.showSelectAll
    };

    return <MultiSelect {...multiSelectProps} />;
  }
}

export default FilterSelect;
