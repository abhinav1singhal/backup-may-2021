import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import ObjectDependenciesFilter from './ObjectDependenciesFilter';
import {
  loadObjectDependenciesFilters,
  loadObjectDependencies,
  loadObjectDependenciesXlsFile
} from 'modules/analytic/actions/objectDependenciesActions';

export function mapStateToProps(state) {
  return {
    filtersDictionary: state.objectDependencies.filtersDictionary.toJS(),
    filtersValue: state.objectDependencies.filtersValue.toJS(),
    objectDependencies: state.objectDependencies.data,
    userPermissions: state.user.permissions
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    loadObjectDependenciesFilters,
    loadObjectDependencies,
    loadObjectDependenciesXlsFile
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(ObjectDependenciesFilter);
