import PropTypes from 'prop-types';
import React from 'react';
import {
  Well, Row, Col, Button, Glyphicon, Alert
} from 'react-techstack';
import FilterSelect from './components/FilterSelect';
import { forOwn } from 'lodash/object';
import {hasPermission} from 'modules/common/utils/permissionsUtils';

class ObjectDependenciesFilter extends React.Component {
  static propTypes = {
    filtersDictionary: PropTypes.shape({
      dependency: PropTypes.arrayOf(PropTypes.object),
      objectType: PropTypes.arrayOf(PropTypes.object),
      dependencyType: PropTypes.arrayOf(PropTypes.object)
    }).isRequired,
    filtersValue: PropTypes.shape({
      dependency: PropTypes.arrayOf(PropTypes.object),
      objectType: PropTypes.arrayOf(PropTypes.object),
      dependencyType: PropTypes.arrayOf(PropTypes.object)
    }).isRequired,
    objectDependencies: PropTypes.object.isRequired,
    objectId: PropTypes.string,
    userPermissions: PropTypes.arrayOf(PropTypes.string).isRequired,
    loadObjectDependenciesFilters: PropTypes.func.isRequired,
    loadObjectDependencies: PropTypes.func.isRequired,
    loadObjectDependenciesXlsFile: PropTypes.func.isRequired,

    theme: PropTypes.object.isRequired
  };

  constructor(props) {
    super(props);
    this.state = {
      filtersValue: props.filtersValue
    };
  }

  UNSAFE_componentWillMount() {
    this.props.loadObjectDependenciesFilters();
  }

  changeFilter(name, value) {
    const { filtersValue } = this.state;
    filtersValue[name] = value;
    this.setState({filtersValue}); // eslint-disable-line react/no-set-state
  }

  validateFiltersSelection() {
    let valid = true;
    forOwn(this.state.filtersValue, (value) => {
      if (value.length === 0) {
        valid = false;
      }
    });

    return valid;
  }

  validateExcelButton() {
    const {successors, predecessors} = this.props.objectDependencies;
    const hasPredecessors = predecessors.length > 0 && predecessors[0].children.length > 0;
    const hasSuccessors = successors.length > 0 && successors[0].children.length > 0;

    return (hasPredecessors || hasSuccessors) && this.validateFiltersSelection(); // ToDo: improve this
  }

  renderFilterSelect(key) {
    const labels = {
      dependency: 'Dependency',
      objectType: 'Object type',
      dependencyType: 'Dependency type'
    };

    const filterSelectProps = {
      options: this.props.filtersDictionary[key],
      value: this.state.filtersValue[key],
      onChange: (value) => this.changeFilter(key, value),
      label: labels[key]
    };

    return <FilterSelect {...filterSelectProps} />;
  }

  renderSelectFiltersMessage() {
    return (
      <Row>
        <Col xs={12}>
          <Alert bsStyle="warning">
            Please choose all required filters first
          </Alert>
        </Col>
      </Row>
    );
  }

  renderActionButtons() {
    const theme = this.props.theme;

    const onRefreshButtonClick = (event) => {
      event.preventDefault();
      if (this.validateFiltersSelection()) {
        this.props.loadObjectDependencies(this.props.objectId, this.state.filtersValue);
      }
    };

    const onExcelButtonClick = (event) => {
      event.preventDefault();
      if (this.validateExcelButton()) {
        this.props.loadObjectDependenciesXlsFile(this.props.objectId, this.state.filtersValue);
      }
    };

    const hasExportPermission = hasPermission(this.props.userPermissions, 'export_AnalyticObject_dependencies');

    return (
      <Col xs={5} className={theme.actions}>
        <Button onClick={onRefreshButtonClick} disabled={!this.validateFiltersSelection()}
                bsStyle="primary" className={theme.button} href="#">
          <Glyphicon glyph="refresh" /> Refresh
        </Button>
        {hasExportPermission && (
          <Button onClick={onExcelButtonClick} disabled={!this.validateExcelButton()}
                  bsStyle="primary" className={theme.button} href="#">
            <Glyphicon glyph="export" /> Export
          </Button>
        )}
      </Col>
    );
  }

  render() {
    return (
      <div>
        <Well>
          <Row>
            <Col xs={7}>
              <Row>
                <Col xs={4}>
                  {this.renderFilterSelect('dependency')}
                </Col>
                <Col xs={4}>
                  {this.renderFilterSelect('objectType')}
                </Col>
                <Col xs={4}>
                  {this.renderFilterSelect('dependencyType')}
                </Col>
              </Row>
            </Col>
            {this.renderActionButtons()}
          </Row>
        </Well>
        {this.validateFiltersSelection() || this.renderSelectFiltersMessage()}
      </div>
    );
  }
}

ObjectDependenciesFilter.defaultProps = {
  theme: require('./ObjectDependenciesFilter.css')
};

export default ObjectDependenciesFilter;
