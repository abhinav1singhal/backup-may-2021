import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  loadIssuersFilters, loadIssuerStatements, resetIssuerStatementsFilters
} from 'modules/analytic/actions/bulkCalculationActions';
import MultipleIssuersForm from './MultipleIssuersForm';

export function mapStateToProps(state) {
  return {
    filters: state.bulkCalculation.issuersFilters,
    filtersInStore: state.bulkCalculation.statementsRequestIssuersParams,
    totalIssuers: state.bulkCalculation.totalIssuers,
    filtersRequest: state.requests.bulkIssuersFilters,
    statementsRequest: state.requests.bulkIssuerStatements
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    loadIssuersFilters,
    loadIssuerStatements,
    resetIssuerStatementsFilters
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(MultipleIssuersForm);
