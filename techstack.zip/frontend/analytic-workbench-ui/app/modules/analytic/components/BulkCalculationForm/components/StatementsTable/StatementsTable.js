import PropTypes from 'prop-types';
import React from 'react';
import { Alert, Checkbox, LoadingContainer } from 'react-techstack';
import TreeDataTable, { DataTableCell } from 'modules/shared/components/TreeDataTable';
import { asyncStatusUtils } from 'react-techstack/utils';
import classnames from 'classnames';
import { isEqual } from 'lodash/lang';
import moment from 'moment';
import Pagination from 'modules/shared/components/Pagination';

import StatementsHeaderCell from './StatementsHeaderCell';
import theme from './StatementsTable.css';
import { isStatementSelected, allStatementsSelected } from 'modules/analytic/utils/simulationUtils';

const { isPending } = asyncStatusUtils;
const COLUMNS = [
  {key: 'selected', width: 30},
  {key: 'issuer', label: 'Issuer', width: 360},
  {key: 'periodType', label: 'Period Type', width: 150},
  {key: 'fiscalYear', label: 'Period', width: 110},
  {key: 'consolidationType', label: 'Consolidation', width: 190},
  {key: 'regimeType', label: 'Accounting regime', width: 185},
  {key: 'revisionDate', label: 'Created', width: 115}
];
const ROW_HEIGHT = 50;
const TABLE_OFFSET = 55;
const MAX_TABLE_HEIGHT = ROW_HEIGHT * 10 + TABLE_OFFSET;

class StatementsTable extends React.Component {

  static propTypes = {
    statements: PropTypes.array.isRequired,
    selectedStatements: PropTypes.array.isRequired,
    manualSelection: PropTypes.bool.isRequired,
    showOnlySelected: PropTypes.bool.isRequired,
    loadIssuerStatements: PropTypes.func.isRequired,
    toggleStatement: PropTypes.func.isRequired,
    toggleAllStatements: PropTypes.func.isRequired,
    applyStatementsSorting: PropTypes.func.isRequired,
    setPageNumberForSelectedOnly: PropTypes.func.isRequired,
    issuersParams: PropTypes.object.isRequired,
    page: PropTypes.shape({
      number: PropTypes.number.isRequired,
      totalPages: PropTypes.number.isRequired,
      size: PropTypes.number.isRequired
    }).isRequired,
    statementsRequest: PropTypes.object.isRequired,
    toggleAllStatementsRequest: PropTypes.object.isRequired,
    sortOrder: PropTypes.shape({
      sortKey: PropTypes.string,
      sortAscending: PropTypes.bool
    }),
    filters: PropTypes.object
  };

  constructor(props) {
    super(props);

    this.changePage = this.changePage.bind(this);
    this.setSorting = this.setSorting.bind(this);
    this._headerCell = this._headerCell.bind(this);
    this._cell = this._cell.bind(this);
  }

  componentDidUpdate({sortOrder, filters, showOnlySelected}) {
    if (!isEqual(this.props.sortOrder, sortOrder) || !isEqual(this.props.filters, filters) || this.props.manualSelection && showOnlySelected && !this.props.showOnlySelected) {
      this.props.loadIssuerStatements(this.props.issuersParams, { number: 1, size: this.props.page.size }, this.props.sortOrder, this.props.filters);
    }
  }

  changePage(page) {
    const {
      loadIssuerStatements, issuersParams, manualSelection, showOnlySelected,
      setPageNumberForSelectedOnly, sortOrder, filters
    } = this.props;

    if (manualSelection && showOnlySelected) {
      setPageNumberForSelectedOnly(page);
    } else {
      loadIssuerStatements(issuersParams, page, sortOrder, filters);
    }
  }

  setSorting(key, ascending) {
    const { sortKey, sortAscending } = this.props.sortOrder;

    this.props.applyStatementsSorting({
      sortKey: key,
      sortAscending: sortKey !== key ? ascending : !sortAscending
    });
  }

  _headerCell = (data, key) => {
    const {sortOrder: {sortKey, sortAscending}, toggleAllStatements, statements, selectedStatements} = this.props;
    if (key === 'selected') {
      return (
        <Checkbox checked={allStatementsSelected(statements, selectedStatements)}
                  onClick={() => toggleAllStatements(statements)}/>
      );
    }

    const props = {
      onSort: this.setSorting,
      attributeType: key,
      sortKey,
      sortAscending,
      activeFilter: false
    };

    return <StatementsHeaderCell {...props}>{data}</StatementsHeaderCell>;
  };

  _cell = (data, key, row, cellProps) => {
    const {selectedStatements, toggleStatement} = this.props;

    let content = data || '';

    if (key === 'selected') {
      content = <Checkbox checked={isStatementSelected(row.id, selectedStatements)}/>;
    } else if (key === 'issuer') {
      content = data.label;
    } else if (key === 'revisionDate') {
      content = moment(data).format('DD MMM YYYY');
    }

    cellProps.onClick = (e) => {
      e.preventDefault();
      if (this.props.manualSelection) {
        toggleStatement(row);
      }
    };

    return <DataTableCell>{content}</DataTableCell>;
  };

  _rowClassNameGetter = (rowIndex, rowData) => {
    const {manualSelection, selectedStatements} = this.props;

    return classnames({
      [theme.selectedRow]: manualSelection && isStatementSelected(rowData.id, selectedStatements)
    });
  };

  render() {
    const { statements = [], page, manualSelection, showOnlySelected, statementsRequest, toggleAllStatementsRequest} = this.props;

    const [, ...restColumns] = COLUMNS;
    const props = {
      data: statements,
      columns: manualSelection ? COLUMNS : restColumns,
      headerCell: this._headerCell,
      cell: this._cell,
      rowClassNameGetter: this._rowClassNameGetter,
      width: 1140,
      height: statements.length > 0 ? Math.min(ROW_HEIGHT * statements.length + TABLE_OFFSET, MAX_TABLE_HEIGHT) : ROW_HEIGHT
    };
    const showLoaderWhenDeselectingAll = manualSelection && showOnlySelected && isPending(toggleAllStatementsRequest.status);

    return (
      <LoadingContainer isLoading={isPending(statementsRequest.status) || showLoaderWhenDeselectingAll}
                        spinner="primary" title="Loading statements..." offset={100}>
        <div className={theme.root}>
          <div>
                <TreeDataTable {...props} />
                { statements.length === 0  ? <Alert bsStyle="warning">No statements found.</Alert> : '' }
                <Pagination page={page} onSelect={this.changePage} />
          </div>
        </div>
      </LoadingContainer>
    );
  }
}

export default StatementsTable;
