import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { asyncStatusUtils } from 'react-techstack/utils';
const { isPending, isSuccessful } = asyncStatusUtils;

import {
  applyStatementsFilter, loadIssuerStatementsFilters
} from 'modules/analytic/actions/bulkCalculationActions';

import StatementsHeaderCell from './StatementsHeaderCell';

export function mapStateToProps(state, ownProps) {
  const options = state.bulkCalculation.statementFilters.data[ownProps.attributeType] || {};
  const statementsFiltersRequestStatus = state.requests.bulkIssuerStatementsFilters.status;
  const isLoading = isPending(statementsFiltersRequestStatus);
  const needToLoad = (!isLoading && !isSuccessful(statementsFiltersRequestStatus)) || !options.list;
  const filterKey = ownProps.attributeType === 'issuer' ? 'organisationId' : ownProps.attributeType;
  const selectedOptions = state.bulkCalculation.statementFilters.filters[filterKey] || [];

  return {
    options,
    isLoading,
    issuersParams: state.bulkCalculation.statementsRequestIssuersParams,
    selectedOptions,
    needToLoad,
    activeFilter: isSuccessful(statementsFiltersRequestStatus) && selectedOptions.length > 0,
    manualSelection: state.bulkCalculation.section.manualSelection,
    showOnlySelected: state.bulkCalculation.section.showOnlySelected
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    onApplyFilter: applyStatementsFilter,
    loadIssuerStatementsFilters
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(StatementsHeaderCell);
