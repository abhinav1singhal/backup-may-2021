import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import {
  submitBatchCalculation
} from 'modules/analytic/actions/bulkCalculationActions';

import BulkCalculationForm from './BulkCalculationForm';

export function mapStateToProps(state) {
  return {
    selectedStatements: state.bulkCalculation.section.selectedStatements,
    statementsRequestIssuersParams: state.bulkCalculation.statementsRequestIssuersParams,
    manualSelection: state.bulkCalculation.section.manualSelection,
    statementsRequest: state.requests.bulkIssuerStatements,
    calculationTypesRequest: state.requests.bulkCalculationTypes,
    submitBatchRequest: state.requests.bulkSubmitBatch
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    submitBatchCalculation
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(BulkCalculationForm);
