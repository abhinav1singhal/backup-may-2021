/* eslint-disable react/no-set-state */
import PropTypes from 'prop-types';

import React from 'react';
import { Select, MultiSelect } from 'react-techstack';
import { transform } from 'lodash/object';
import { every } from 'lodash/collection';
import { isEmpty } from 'lodash/lang';
import { asyncStatusUtils } from 'react-techstack/utils';
import { Button } from 'modules/shared/components';
import { getMessage } from 'modules/common/utils/messagesUtils';
import theme from './MultipleIssuersForm.css';

const { isPending } = asyncStatusUtils;

const FIELDS = [
  {key: 'lineOfBusiness', label: getMessage('attributesForm.fields.lob.label'), multi: true},
  {key: 'sector', label: getMessage('attributesForm.fields.sector.label'), multi: true},
  {key: 'region', label: getMessage('attributesForm.fields.region.label'), multi: true},
  {key: 'country', label: getMessage('attributesForm.fields.country.label'), multi: true}
];


class MultipleIssuersForm extends React.Component {

  static propTypes = {
    totalIssuers: PropTypes.number,
    filters: PropTypes.object.isRequired,
    filtersInStore: PropTypes.object.isRequired,
    loadIssuersFilters: PropTypes.func.isRequired,
    loadIssuerStatements: PropTypes.func.isRequired,
    resetIssuerStatementsFilters: PropTypes.func.isRequired,
    filtersRequest: PropTypes.object.isRequired,
    statementsRequest: PropTypes.object.isRequired
  };

  constructor(props) {
    super(props);

    this.state = {
      filtersValues: transform(FIELDS, (result, {key, multi}) => {
        result[key] = multi ? [] : null;
      }, {})
    };

    this.onShowStatementsClick = this.onShowStatementsClick.bind(this);
  }

  componentDidMount() {
    this.props.loadIssuersFilters();
  }

  onShowStatementsClick() {
    this.props.resetIssuerStatementsFilters();
    this.props.loadIssuerStatements(this.state.filtersValues);
  }

  allFiltersSelected() {
    const {filtersValues} = this.state;

    return every(FIELDS, ({key, multi}) => {
      return multi ? filtersValues[key].length !== 0 : !!filtersValues[key];
    });
  }

  renderSelect({key, label, multi}, i) {
    const {filters, filtersRequest} = this.props;
    const {filtersValues} = this.state;

    const onChange = (option) => {
      this.setState({
        filtersValues: {...filtersValues, [key]: option}
      });
    };
    const options = filters[key] || [];

    const props = {
      label,
      onChange,
      value: filtersValues[key],
      options,
      valueKey: 'name',
      labelKey: 'name',
      disabled: options.length === 0,
      placeholder: (isPending(filtersRequest.status) && 'Loading...') || undefined
    };

    const Component = multi ? MultiSelect : Select;

    return (
      <div key={i} className={theme.formElement}>
        <Component {...props} />
      </div>
    );
  }

  render() {
    const {filtersInStore, totalIssuers, statementsRequest: {status}} = this.props;

    const statementsLoading = isPending(status);
    const buttonProps = {
      loading: statementsLoading,
      onClick: this.onShowStatementsClick,
      disabled: !this.allFiltersSelected()
    };

    return (
      <div className={theme.root}>
        <form className="clearfix">
          <div data-test="issuersFilters">
            {FIELDS.map((field, i) => this.renderSelect(field, i))}
          </div>
          <div className={theme.findButton} data-test="showStatementsButton">
            <Button {...buttonProps}>Show statements</Button>
          </div>
        </form>
        {!isEmpty(filtersInStore) && !!totalIssuers && totalIssuers > 0 && (
          <div className={theme.totalIssuers} data-test="totalIssuersMessage">
            <strong>{totalIssuers}</strong> Issuers matching the criteria
          </div>
        )}
      </div>
    );
  }
}

export default MultipleIssuersForm;
