import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { loadCalculationTypes, toggleSelectedOnly, toggleManualSelection,
  loadIssuerStatements, resetIssuerStatementsFilters
 } from 'modules/analytic/actions/bulkCalculationActions';
import StatementsSection from './StatementsSection';

export function mapStateToProps(state) {
  return {
    selectedStatements: state.bulkCalculation.section.selectedStatements,
    showOnlySelected: state.bulkCalculation.section.showOnlySelected,
    manualSelection: state.bulkCalculation.section.manualSelection,
    calculationTypes: state.bulkCalculation.calculationTypes,
    totalElementsCount: state.bulkCalculation.page.totalElements,
    calculationTypesRequest: state.requests.bulkCalculationTypes,
    statementsRequest: state.requests.bulkIssuerStatements,
    issuersParams: state.bulkCalculation.statementsRequestIssuersParams
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    loadCalculationTypes,
    toggleSelectedOnly,
    toggleManualSelection,
    loadIssuerStatements,
    resetIssuerStatementsFilters
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(StatementsSection);
