/* eslint-disable react/no-set-state */

import PropTypes from 'prop-types';

import React, { Component } from 'react';
import { some } from 'lodash/collection';
import { isEmpty } from 'lodash/lang';
import { pick, values } from 'lodash/object';
import { LoadingContainer, Alert } from 'react-techstack';
import { asyncStatusUtils } from 'react-techstack/utils';
import StatementsSection from './components/StatementsSection';
import MultipleIssuersForm from './components/MultipleIssuersForm';
import theme from './BulkCalculationForm.css';

const { isPending, isSuccessful, isFailed } = asyncStatusUtils;

class BulkCalculationForm extends Component {

  static propTypes = {
    selectedStatements: PropTypes.array,
    statementsRequest: PropTypes.object.isRequired,
    statementsRequestIssuersParams: PropTypes.object.isRequired,
    manualSelection: PropTypes.bool.isRequired,
    calculationTypesRequest: PropTypes.object.isRequired,
    submitBatchRequest: PropTypes.object.isRequired,
    submitBatchCalculation: PropTypes.func.isRequired
  };

  onSubmit = (calculationType) => {
    const { selectedStatements, statementsRequestIssuersParams, manualSelection } = this.props;
    this.props.submitBatchCalculation(calculationType, manualSelection, selectedStatements, statementsRequestIssuersParams);
  };


  shouldShowStatementsSection() {
    const  { statementsRequestIssuersParams } = this.props;
    return !isEmpty(statementsRequestIssuersParams);
  }

  renderErrorMessage() {
    const requests = values(pick(this.props, ['statementsRequest', 'calculationTypesRequest', 'submitBatchRequest']));

    if (some(requests, ({status}) => isFailed(status))) {
      return (
        <div data-test="errorMessages">
          <Alert bsStyle="danger">
            An unexpected error occurred.
          </Alert>
        </div>
      );
    }

    return null;
  }

  renderIssuerSection() {
    return (
      <div data-test="issuerSection">
        <MultipleIssuersForm />
      </div>
    );
  }

  renderStatementsSection() {
    if (!this.shouldShowStatementsSection()) {
      return null;
    }

    return <StatementsSection onSubmit={this.onSubmit} />;
  }

  render() {
    const { submitBatchRequest } = this.props;
    const isSubmitting = isPending(submitBatchRequest.status);

    const loadingContainerProps = {
      isLoading: isSubmitting,
      title: isSubmitting ? 'Submitting batch for calculation...' : '',
      offset: 100
    };

    return (
      <LoadingContainer {...loadingContainerProps}>
        <div className={theme.root}>
          {this.renderErrorMessage()}
          <div data-test="successMessages">
            {isSuccessful(submitBatchRequest.status) && (
              <Alert bsStyle="success">
                Statements for calculation were successfully submitted and sent for execution.
              </Alert>
            )}
          </div>
          <div className="clearfix">
            {this.renderIssuerSection()}
            {this.renderStatementsSection()}
          </div>
        </div>
      </LoadingContainer>
    );
  }
}

export default BulkCalculationForm;
