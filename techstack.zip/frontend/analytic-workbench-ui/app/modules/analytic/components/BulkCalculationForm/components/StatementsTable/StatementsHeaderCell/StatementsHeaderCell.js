import PropTypes from 'prop-types';
import React, { Component } from 'react';
import classNames from 'classnames';
import { omit } from 'lodash/object';

import { Glyphicon, OverlayTrigger } from 'react-techstack';

import theme from './StatementsHeaderCell.css';
import { FilterPopover, Icon } from 'modules/shared/components';

class StatementsHeaderCell extends Component {

  static propTypes = {
    activeFilter: PropTypes.bool.isRequired,
    issuersParams: PropTypes.object.isRequired,
    loadIssuerStatementsFilters: PropTypes.func.isRequired,
    onApplyFilter: PropTypes.func.isRequired,
    options: PropTypes.object,
    onSort: PropTypes.func.isRequired,
    attributeType: PropTypes.string,
    sortKey: PropTypes.string,
    sortAscending: PropTypes.bool,
    showOnlySelected: PropTypes.bool.isRequired,
    manualSelection: PropTypes.bool.isRequired,
    children: PropTypes.node.isRequired
  };

  constructor(props) {
    super(props);

    this.onApplyFilter = this.onApplyFilter.bind(this);
  }

  onSort(sortAscending) {
    const attributeType = this.props.attributeType ===  'issuer' ? 'organisationName' : this.props.attributeType;
    this.props.onSort(attributeType, sortAscending);
  }

  onApplyFilter(selectedOptions) {
    const attributeType = this.props.attributeType ===  'issuer' ? 'organisationId' : this.props.attributeType;
    this.props.onApplyFilter(attributeType, selectedOptions);
    this.refs.overlay.hide();
  }

  renderSorting() {
    const { attributeType, sortAscending } = this.props;
    const sortKey = this.props.sortKey === 'organisationName' ? 'issuer' : this.props.sortKey;

    const sortButtonUpClassnames = classNames(
      theme.sortButtonUp,
      sortKey === attributeType && sortAscending && theme.sortingActive
    );

    const sortButtonDownClassnames = classNames(
      theme.sortButtonDown,
      sortKey === attributeType && !sortAscending && theme.sortingActive
    );

    return (
      <span className={theme.sortButton}>
        <span className={sortButtonUpClassnames} onClick={this.onSort.bind(this, true)}>
          <Glyphicon glyph="triangle-top"/>
        </span>
        <span className={sortButtonDownClassnames} onClick={this.onSort.bind(this, false)}>
          <Glyphicon glyph="triangle-bottom"/>
        </span>
      </span>
    );
  }

  renderFilter() {
    const { options, loadIssuerStatementsFilters, issuersParams, attributeType } = this.props;

    if (attributeType === 'revisionDate') {
      return null;
    }

    const popoverProps = {
      ...omit(this.props, 'options', 'loadIssuerStatementsFilters', 'children', 'issuerId'),
      onApply: this.onApplyFilter,
      onCancel: () => this.refs.overlay.hide(),
      options: options.list || [],
      loadAttributes: loadIssuerStatementsFilters.bind(null, issuersParams),
      valueParam: 'id',
      title: options.name,
      labelParam: 'description'
    };

    const overlay = (
      <FilterPopover {...popoverProps} />
    );

    const classes = classNames({
      [theme.filter]: !this.props.activeFilter,
      [theme.activeFilter]: this.props.activeFilter
    });

    return (
      <div className={classes}>
        <OverlayTrigger ref="overlay"
                        trigger="click"
                        placement="bottom"
                        rootClose
                        overlay={overlay}>
          <Icon type={this.props.activeFilter ? 'filter-full' : 'filter'} />
        </OverlayTrigger>
      </div>
    );
  }

  render() {
    const {manualSelection, showOnlySelected, children} = this.props;

    return (
      <div className={theme.root}>
        {manualSelection && !showOnlySelected && this.renderSorting()}
        <div className={theme.content}>
          {children}
        </div>
        {manualSelection && !showOnlySelected && this.renderFilter()}
      </div>
    );
  }

}

export default StatementsHeaderCell;
