import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import {
  applyStatementsSorting, toggleStatement, toggleAllStatements, loadIssuerStatements,
  loadIssuerStatementsFilters, setPageNumberForSelectedOnly
} from 'modules/analytic/actions/bulkCalculationActions';
import StatementsTable from './StatementsTable';
import { getStatementsForPage } from 'modules/analytic/utils/simulationUtils';


export function mapStateToProps(state) {
  const {
    section: {manualSelection, showOnlySelected, statements, selectedStatements, pageNumberForSelectedOnly},
    page, sortOrder, statementsRequestIssuersParams, statementFilters
  } = state.bulkCalculation;
  let props = {statements, page};

  if (manualSelection && showOnlySelected) {
    const {data, page: onlySelectedPage} = getStatementsForPage(
      selectedStatements, {size: page.size, number: pageNumberForSelectedOnly}, sortOrder
    );

    props = {
      statements: data,
      page: onlySelectedPage
    };
  }

  return {
    ...props,
    selectedStatements,
    manualSelection,
    showOnlySelected,
    issuersParams: statementsRequestIssuersParams,
    sortOrder,
    filters: statementFilters.filters,
    statementsRequest: state.requests.bulkIssuerStatements,
    toggleAllStatementsRequest: state.requests.bulkToggleAllStatements
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    applyStatementsSorting,
    loadIssuerStatements,
    loadIssuerStatementsFilters,
    toggleStatement,
    toggleAllStatements,
    setPageNumberForSelectedOnly
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(StatementsTable);
