/* eslint-disable react/no-set-state */
import PropTypes from 'prop-types';

import React from 'react';
import classnames from 'classnames';
import { Checkbox, Select } from 'react-techstack';
import { asyncStatusUtils } from 'react-techstack/utils';
import theme from './StatementsSection.css';
import StatementsTable from '../StatementsTable';
import { Button } from 'modules/shared/components';
const { isSuccessful, isPending } = asyncStatusUtils;

class StatementsSection extends React.Component {

  static propTypes = {
    selectedStatements: PropTypes.array.isRequired,
    statementsRequest: PropTypes.object.isRequired,
    calculationTypes: PropTypes.array.isRequired,
    calculationTypesRequest: PropTypes.object.isRequired,
    onSubmit: PropTypes.func.isRequired,
    showOnlySelected: PropTypes.bool.isRequired,
    manualSelection: PropTypes.bool.isRequired,
    totalElementsCount: PropTypes.number.isRequired,
    loadCalculationTypes: PropTypes.func.isRequired,
    loadIssuerStatements: PropTypes.func.isRequired,
    issuersParams: PropTypes.object.isRequired,
    resetIssuerStatementsFilters: PropTypes.func.isRequired,
    toggleSelectedOnly: PropTypes.func.isRequired,
    toggleManualSelection: PropTypes.func.isRequired
  };

  constructor() {
    super();

    this.state = {
      calculationType: null
    };
    this.toggleManualSelection = this.toggleManualSelection.bind(this);
  }

  componentDidMount() {
    this.props.loadCalculationTypes();
  }

  noStatementsSelected() {
    return this.props.totalElementsCount === 0 || this.props.manualSelection && this.props.selectedStatements.length === 0;
  }

  isSubmitDisabled() {
    const { statementsRequest, calculationTypesRequest } = this.props;

    return this.noStatementsSelected() ||
      !isSuccessful(statementsRequest.status) ||
      !isSuccessful(calculationTypesRequest.status) ||
      !this.state.calculationType;
  }


  submit = () => {
    this.props.onSubmit(this.state.calculationType);
  };

  toggleManualSelection() {
    this.props.resetIssuerStatementsFilters();
    this.props.loadIssuerStatements(this.props.issuersParams);
    this.props.toggleManualSelection();
  }

  renderSelectionBlock() {
    const {
      selectedStatements,
      showOnlySelected,
      manualSelection,
      totalElementsCount,
      toggleSelectedOnly
    } = this.props;

    let selectedItems;

    if (manualSelection) {
      if (this.noStatementsSelected()) {
        selectedItems = 'No items selected';
      } else {
        selectedItems = `${selectedStatements.length} Selected`;
      }
    } else {
      selectedItems = `${totalElementsCount} Selected`;
    }

    return (
      <div className={theme.selectionBlock} data-test="showSelectedCheckbox">
        <Checkbox label="Select items manually" checked={manualSelection} onClick={this.toggleManualSelection} />
        <span className={theme.selectedLabel}>{selectedItems}</span>
        {manualSelection ? <Checkbox label="Show selected only" checked={showOnlySelected} onClick={toggleSelectedOnly} /> : null}
      </div>
    );
  }

  renderCalculationTypeSelect() {
    const { calculationTypes, calculationTypesRequest } = this.props;
    const { calculationType } = this.state;

    const onChange = (option) => {
      this.setState({
        calculationType: option
      });
    };

    const props = {
      label: 'Calculation Type',
      onChange,
      value: calculationType,
      options: calculationTypes,
      valueKey: 'name',
      labelKey: 'name',
      disabled: calculationTypes.length === 0,
      placeholder: (isPending(calculationTypesRequest.status) && 'Loading...') || undefined
    };

    return (
      <div className={theme.formElement}>
        <Select {...props} />
      </div>
    );
  }

  renderButtons() {
    const submitButtonProps = {
      onClick: this.submit,
      disabled: this.isSubmitDisabled(),
      bsStyle: 'primary',
      className: theme.actionButton
    };

    return (
      <div className={theme.buttonsContainer}>
        <Button {...submitButtonProps}>Execute</Button>
      </div>
    );
  }

  render() {
    return (
      <div>
        <span className={theme.sectionTitle}>Statements</span>
        <div className={classnames('clearfix', theme.form)}>
          {this.renderSelectionBlock()}
          <div className="pull-right">
            <form className={classnames('clearfix', theme.form)} data-test="simulationNameForm">
              {this.renderCalculationTypeSelect()}
              {this.renderButtons()}
            </form>
          </div>
        </div>
        <div>
          <StatementsTable />
        </div>
      </div>
    );
  }
}

export default StatementsSection;
