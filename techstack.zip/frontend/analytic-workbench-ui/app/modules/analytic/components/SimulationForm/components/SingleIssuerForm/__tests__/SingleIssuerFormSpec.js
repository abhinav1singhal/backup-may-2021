/* global describe, it, beforeEach, afterEach, sinon, xdescribe, xit */

import React from 'react';
import { Select } from 'react-techstack';
import expect from 'expect';
import { noop } from 'lodash/util';
// todo The import below causes `TypeError: undefined is not an object (evaluating 'WrappedComponent.displayName') at undefined:57` error
import SingleIssuerForm from '../SingleIssuerForm';
import * as mocks from '../../../__tests__/simulationMocks';
import { asyncStatus } from 'react-techstack/utils';
import Adapter from 'enzyme-adapter-react-16';
import { shallow, configure } from 'enzyme';
configure({adapter: new Adapter()});


describe('app.modules.analytic.components.SimulationForm.components.SingleIssuerForm.__tests__.SingleIssuerFormSpec', () => {
  const requiredProps = {
    issuersList: [],
    statementsRequestIssuersParams: {},
    issuersListRequest: {},
    loadIssuersList: noop,
    loadIssuerStatements: noop,
    resetIssuerStatementsFilters: noop,
    statementsRequest: {
      status: asyncStatus.SUCCESS,
      error: false
    }
  };

  // TODO: functionality changed
  xit('should pass correct props to issuers select', () => {
    const wrapper = shallow(<SingleIssuerForm {...requiredProps} />);
    const getSelectProps = () => wrapper.childAt(0).find(Select).at(0).props();

    expect(getSelectProps()).toInclude({
      options: requiredProps.issuersList,
      value: null,
      valueKey: 'description',
      labelKey: 'description',
      clearable: false,
      backspaceRemoves: false,
      disabled: true,
      placeholder: 'Select...'
    });

    wrapper.setProps({issuersList: mocks.issuers});
    expect(getSelectProps()).toInclude({
      options: mocks.issuers,
      disabled: false
    });
  });

  it('should pass correct props to button', () => {
    const formProps = {
      ...requiredProps,
      currentIssuer: mocks.issuers[0]
    };
    const wrapper = shallow(<SingleIssuerForm {...formProps} />);
    const getButtonProps = () => wrapper.childAt(1).props();

    expect(getButtonProps()).toInclude({
      disabled: false,
      loading: false
    });
  });

  // TODO: functionality changed
  xit('should write correct issuer to state on issuer select change', () => {
    const wrapper = shallow(<SingleIssuerForm {...requiredProps} />);
    const select = wrapper.childAt(0).find(Select).at(0);

    select.simulate('change', mocks.issuers[0]);
    expect(wrapper.state('selectedIssuer')).toEqual(mocks.issuers[0]);
  });

  it('should call loadIssuerStatements with proper params when button clicked', () => {
    const props = {
      ...requiredProps,
      currentIssuer: mocks.issuers[0],
      loadIssuerStatements: expect.createSpy()
    };
    const wrapper = shallow(<SingleIssuerForm {...props} />);
    wrapper.childAt(1).simulate('click');
    expect(props.loadIssuerStatements).toHaveBeenCalledWith({issuerId: mocks.issuers[0].id});
  });
});
