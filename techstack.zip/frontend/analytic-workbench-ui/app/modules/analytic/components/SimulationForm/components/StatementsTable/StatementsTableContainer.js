import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import {
  applyStatementsSorting, toggleStatement, toggleAllStatements, loadIssuerStatements,
  loadStatementAdjustments, loadIssuerStatementsFilters, setPageNumberForSelectedOnly,
  toggleStatementAdjustment
} from 'modules/analytic/actions/simulationActions';
import StatementsTable from './StatementsTable';
import { getStatementsForPage } from 'modules/analytic/utils/simulationUtils';


export function mapStateToProps(state) {
  const {
    section: {showOnlySelected, statements, selectedStatements, selectedStatementsForPage, pageNumberForSelectedOnly, statementsAdjustments},
    page, sortOrder, statementsRequestIssuersParams, statementFilters
  } = state.simulation;
  let props = {statements, page};

  if (showOnlySelected) {
    const {data, page: onlySelectedPage} = getStatementsForPage(
      selectedStatements, {size: page.size, number: pageNumberForSelectedOnly}, sortOrder
    );

    props = {
      statements: selectedStatementsForPage ? selectedStatementsForPage : data,
      page: selectedStatementsForPage ? page : onlySelectedPage
    };
  }

  return {
    ...props,
    selectedStatements,
    statementsAdjustments,
    showOnlySelected,
    issuersParams: statementsRequestIssuersParams,
    sortOrder,
    filters: statementFilters.filters,
    statementsRequest: state.requests.simulationIssuerStatements,
    adjustmentsRequest: state.requests.simulationStatementAdjustments,
    toggleAllStatementsRequest: state.requests.simulationToggleAllStatements
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    applyStatementsSorting,
    loadIssuerStatements,
    loadStatementAdjustments,
    toggleStatementAdjustment,
    loadIssuerStatementsFilters,
    toggleStatement,
    toggleAllStatements,
    setPageNumberForSelectedOnly
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(StatementsTable);
