/* global describe, it, beforeEach, afterEach, sinon, xdescribe, xit */

import React from 'react';
import { Select } from 'react-techstack';
import MultiSelect from 'modules/shared/components/MultiSelect';
import expect from 'expect';
import { noop } from 'lodash/util';
import MultipleIssuersForm from '../MultipleIssuersForm';
import { Button } from 'modules/shared/components';
import * as mocks from '../../../__tests__/simulationMocks';
import Adapter from 'enzyme-adapter-react-16';
import { shallow, configure } from 'enzyme';
configure({adapter: new Adapter()});

describe('app.modules.analytic.components.SimulationForm.components.MultipleIssuersForm.__tests__.MultipleIssuersFormSpec', () => {
  const requiredProps = {
    filters: {},
    filtersInStore: {},
    loadIssuersFilters: noop,
    loadIssuerStatements: noop,
    resetIssuerStatementsFilters: noop,
    resetSection: noop,
    filtersRequest: {},
    statementsRequest: {}
  };

  // ToDo: broken due to changes in functionality, fix
  xit('should render proper filters', () => {
    const wrapper = shallow(<MultipleIssuersForm {...requiredProps} />);
    const filters = wrapper.find('[data-test="issuersFilters"]').children();
    expect(filters.length).toEqual(4);
    expect(filters.at(0).find(Select).length).toEqual(1);
    expect(filters.at(1).find(MultiSelect).length).toEqual(1);
    expect(filters.at(2).find(MultiSelect).length).toEqual(1);
    expect(filters.at(3).find(MultiSelect).length).toEqual(1);
  });

  it('should render showStatementsButton', () => {
    const {issuersFilters} = mocks;
    const wrapper = shallow(<MultipleIssuersForm {...requiredProps} />);
    const getButton = () => wrapper.find('[data-test="showStatementsButton"]').find(Button);
    const button = getButton();
    expect(button.isEmpty()).toEqual(false);
    expect(getButton().props()).toInclude({
      children: 'Show statements',
      disabled: true
    });

    wrapper.setState({
      filtersValues: {
        lineOfBusiness: issuersFilters.lineOfBusiness[0],
        sector: [issuersFilters.sector[1]],
        region: [issuersFilters.region[0], issuersFilters.region[1]],
        country: [issuersFilters.country[1]]
      }
    });
    expect(getButton().props()).toInclude({disabled: false});
  });

  it('should render message about total issuers', () => {
    const {issuersFilters} = mocks;
    const wrapper = shallow(<MultipleIssuersForm {...requiredProps} />);
    const getMessage = () => wrapper.find('[data-test="totalIssuersMessage"]');
    expect(getMessage().isEmpty()).toEqual(true);

    wrapper.setProps({
      filtersInStore: {
        lineOfBusiness: issuersFilters.lineOfBusiness[0],
        sector: [issuersFilters.sector[1]],
        region: [issuersFilters.region[0], issuersFilters.region[1]],
        country: [issuersFilters.country[1]]
      }
    });
    expect(getMessage().isEmpty()).toEqual(true);

    wrapper.setProps({totalIssuers: 0});
    expect(getMessage().isEmpty()).toEqual(true);

    wrapper.setProps({totalIssuers: 123});
    expect(getMessage().isEmpty()).toEqual(false);
    expect(getMessage().text()).toEqual('123 Issuers matching the criteria');
  });

  // ToDo: broken due to changes in functionality, fix
  xit('should call resetSection and loadIssuerStatements when show statementsButton clicked', () => {
    const {issuersFilters} = mocks;
    const filtersValues = {
      lineOfBusiness: issuersFilters.lineOfBusiness[0],
      sector: [issuersFilters.sector[1]],
      region: [issuersFilters.region[0], issuersFilters.region[1]],
      country: [issuersFilters.country[1]]
    };
    const props = {
      ...requiredProps,
      resetSection: expect.createSpy(),
      loadIssuerStatements: expect.createSpy()
    };
    const wrapper = shallow(<MultipleIssuersForm {...props} />);
    wrapper.setState({filtersValues});
    wrapper.find('[data-test="showStatementsButton"]').find(Button).simulate('click');
    expect(props.resetSection).toHaveBeenCalled();
    expect(props.loadIssuerStatements).toHaveBeenCalledWith(filtersValues);
  });
});
