/* eslint-disable react/no-set-state */
import PropTypes from 'prop-types';

import React from 'react';
import { Alert, Checkbox, LoadingContainer, Glyphicon, Spinner } from 'react-techstack';
import TreeDataTable, { DataTableCell } from 'modules/shared/components/TreeDataTable';
import { asyncStatusUtils } from 'react-techstack/utils';
import classnames from 'classnames';
import { isEqual } from 'lodash/lang';
import { every } from 'lodash/collection';
import moment from 'moment';
import Pagination from 'modules/shared/components/Pagination';

import StatementsHeaderCell from './StatementsHeaderCell';
import theme from './StatementsTable.css';
import { isStatementSelected, allStatementsSelected } from 'modules/analytic/utils/simulationUtils';

const { isPending } = asyncStatusUtils;
const COLUMNS = [
  {key: 'selected', width: 30},
  {key: 'periodType', label: 'Period Type', width: 510},
  {key: 'fiscalYear', label: 'Period', width: 110},
  {key: 'consolidationType', label: 'Consolidation', width: 190},
  {key: 'regimeType', label: 'Accounting regime', width: 185},
  {key: 'revisionDate', label: 'Created', width: 115}
];

class StatementsTable extends React.Component {

  static propTypes = {
    statements: PropTypes.array.isRequired,
    selectedStatements: PropTypes.array.isRequired,
    statementsAdjustments: PropTypes.object.isRequired,
    showOnlySelected: PropTypes.bool.isRequired,
    loadIssuerStatements: PropTypes.func.isRequired,
    loadStatementAdjustments: PropTypes.func.isRequired,
    toggleStatement: PropTypes.func.isRequired,
    toggleAllStatements: PropTypes.func.isRequired,
    toggleStatementAdjustment: PropTypes.func.isRequired,
    applyStatementsSorting: PropTypes.func.isRequired,
    setPageNumberForSelectedOnly: PropTypes.func.isRequired,
    issuersParams: PropTypes.object.isRequired,
    page: PropTypes.shape({
      number: PropTypes.number.isRequired,
      totalPages: PropTypes.number.isRequired,
      size: PropTypes.number.isRequired
    }).isRequired,
    statementsRequest: PropTypes.object.isRequired,
    adjustmentsRequest: PropTypes.object.isRequired,
    toggleAllStatementsRequest: PropTypes.object.isRequired,
    sortOrder: PropTypes.shape({
      sortKey: PropTypes.string,
      sortAscending: PropTypes.bool
    }),
    filters: PropTypes.object,
    recalculate: PropTypes.bool
  };

  constructor(props) {
    super(props);

    this.state = {
      currentAdjustmentsFetchingStatement: null
    };

    this.changePage = this.changePage.bind(this);
    this.setSorting = this.setSorting.bind(this);
    this._headerCell = this._headerCell.bind(this);
    this._cell = this._cell.bind(this);
  }

  componentDidUpdate({sortOrder, filters, showOnlySelected}) {
    if (!isEqual(this.props.sortOrder, sortOrder) || !isEqual(this.props.filters, filters)  || showOnlySelected && !this.props.showOnlySelected) {
      this.props.loadIssuerStatements(this.props.issuersParams, { number: 1, size: this.props.page.size }, this.props.sortOrder, this.props.filters);
    }
  }

  onToggleExpand(expanded, item) {
    const {recalculate, statementsAdjustments, loadStatementAdjustments} = this.props;

    if (!recalculate && expanded && !statementsAdjustments[item.id]) {
      this.setState({currentAdjustmentsFetchingStatement: item.id});
      loadStatementAdjustments(item);
    }
  }

  changePage(page) {
    const {
      loadIssuerStatements, issuersParams, showOnlySelected,
      setPageNumberForSelectedOnly, sortOrder, filters
    } = this.props;

    if (showOnlySelected) {
      setPageNumberForSelectedOnly(page);
    } else {
      loadIssuerStatements(issuersParams, page, sortOrder, filters);
    }
  }

  setSorting(key, ascending) {
    const { sortKey, sortAscending } = this.props.sortOrder;

    this.props.applyStatementsSorting({
      sortKey: key,
      sortAscending: sortKey !== key ? ascending : !sortAscending
    });
  }

  shouldShowExpandButton(key) {
    const {recalculate, issuersParams} = this.props;
    return !recalculate && !!issuersParams.issuerId ? key === 'periodType' : key === 'issuer';
  }

  _headerCell = (data, key) => {
    const {showOnlySelected, sortOrder: {sortKey, sortAscending}, toggleAllStatements, statements, selectedStatements} = this.props;
    if (key === 'selected') {
      return (
        <Checkbox checked={allStatementsSelected(statements, selectedStatements)}
                  onClick={() => toggleAllStatements(showOnlySelected, statements)}/>
      );
    }

    const props = {
      onSort: this.setSorting,
      attributeType: key,
      sortKey,
      sortAscending,
      activeFilter: false
    };

    return <StatementsHeaderCell {...props}>{data}</StatementsHeaderCell>;
  };

  _cell = (data, key, row, cellProps) => {
    const {selectedStatements, toggleStatement, toggleStatementAdjustment} = this.props;

    let content = data || '';
    if (row.adjustment) {
      if (COLUMNS[0].key === key) {
        content = (
          <Checkbox label={row.name} checked={row.selected} onClick={() => toggleStatementAdjustment(row)} />
        );
      }
    } else {
      if (key === 'selected') {
        content = <Checkbox checked={isStatementSelected(row.id, selectedStatements)}/>;
      } else if (key === 'revisionDate') {
        content = moment(data).format('DD MMM YYYY');
      } else if (this.shouldShowExpandButton(key)) {
        content = this.renderExpandCell(key === 'issuer' ? data.label : data, row, cellProps);
      }

      cellProps.onClick = () => toggleStatement(row);
    }

    return <DataTableCell>{content}</DataTableCell>;
  };

  _rowClassNameGetter = (rowIndex, rowData) => {
    return classnames({
      [theme.selectedRow]: isStatementSelected(rowData.id, this.props.selectedStatements),
      [theme.adjustmentRow]: rowData.adjustment
    });
  };

  renderExpandCell(data, row, cellProps) {
    const onClick = (e) => {
      e.stopPropagation();
      cellProps.toggleExpandRow();
    };
    const adjustments = this.props.statementsAdjustments[row.id];

    const allAdjustmentSelected = every(adjustments, {selected: true});
    const buttonStyles = classnames(theme.expandButton, !allAdjustmentSelected && theme.active);

    let icon;
    if (this.state.currentAdjustmentsFetchingStatement === row.id && isPending(this.props.adjustmentsRequest.status)) {
      icon = <Spinner size={17} />;
    } else {
      icon = <Glyphicon glyph={`triangle-${row.$expand ? 'top' : 'bottom'}`} onClick={onClick.bind(this)} />;
    }

    return (
      <div className={theme.toggleAdjustmentsCell}>
        <span className={theme.content}>{data}</span>
        {(!adjustments || adjustments.length > 0) && (
          <span className={buttonStyles}>{icon}</span>
        )}
      </div>
    );
  }

  render() {
    const {
      statements, statementsAdjustments, issuersParams, page,
      showOnlySelected, statementsRequest, toggleAllStatementsRequest
    } = this.props;

    let columns = COLUMNS;
    if (!issuersParams.issuerId) {
      const [selected, periodType, ...restColumns] = columns;
      columns = [
        selected,
        {key: 'issuer', label: 'Issuer', width: 360},
        {...periodType, width: 150},
        ...restColumns
      ];
    }

    const props = {
      data: statements.map((statement) => {
        if (statementsAdjustments[statement.id]) {
          return {
            ...statement,
            adjustments: statementsAdjustments[statement.id]
          };
        }
        return statement;
      }),
      columns,
      headerCell: this._headerCell,
      cell: this._cell,
      dataChildrenKey: 'adjustments',
      rowClassNameGetter: this._rowClassNameGetter,
      width: 1140,
      onToggleExpand: this.onToggleExpand.bind(this)
    };
    const showLoaderWhenDeselectingAll = showOnlySelected && isPending(toggleAllStatementsRequest.status);

    return (
      <LoadingContainer isLoading={isPending(statementsRequest.status) || showLoaderWhenDeselectingAll}
                        spinner="primary" title="Loading statements..." offset={100}>
        <div className={theme.root}>
          <TreeDataTable {...props} />
          {statements.length === 0 && (
            <Alert bsStyle="warning">
              No statements found.
            </Alert>
          )}
          <Pagination page={page} onSelect={this.changePage}/>
        </div>
      </LoadingContainer>
    );
  }
}

export default StatementsTable;
