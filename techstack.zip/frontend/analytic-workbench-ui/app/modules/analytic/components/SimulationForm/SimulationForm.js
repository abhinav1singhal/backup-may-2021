/* eslint-disable react/no-set-state */
import PropTypes from 'prop-types';

import React from 'react';
import classnames from 'classnames';
import { some } from 'lodash/collection';
import { isEmpty, isEqual} from 'lodash/lang';
import { pick, values, transform } from 'lodash/object';
import { Select, LoadingContainer, Alert } from 'react-techstack';
import { asyncStatusUtils } from 'react-techstack/utils';
import theme from './SimulationForm.css';
import StatementsSection from './components/StatementsSection';
import SingleIssuerForm from './components/SingleIssuerForm';
import MultipleIssuersForm from './components/MultipleIssuersForm';
import Switcher from 'modules/shared/components/Switcher';

const { isPending, isSuccessful, isFailed } = asyncStatusUtils;

class SimulationForm extends React.Component {

  static propTypes = {
    analyticObjects: PropTypes.array.isRequired,
    selectedStatements: PropTypes.array,
    statementsAdjustments: PropTypes.object,
    statementsRequestIssuersParams: PropTypes.object.isRequired,
    createdSimulation: PropTypes.object,
    analyticObjectsRequest: PropTypes.object.isRequired,
    issuersListRequest: PropTypes.object.isRequired,
    statementsRequest: PropTypes.object.isRequired,
    createSimulationRequest: PropTypes.object.isRequired,
    recalculateSimulationRequest: PropTypes.object.isRequired,
    loadAnalyticObjectsWithVersions: PropTypes.func.isRequired,
    createAnalyticObjectsSimulation: PropTypes.func.isRequired,
    recalculateAnalyticObjects: PropTypes.func.isRequired,
    toggleSimulationTab: PropTypes.func.isRequired,
    urlQuery: PropTypes.object.isRequired,
    showSingleIssuerTab: PropTypes.bool.isRequired,
    recalculate: PropTypes.bool,
    errorCode: PropTypes.string
  };

  constructor(props) {
    super(props);

    this.state = {
      analyticObjectsVersions: {}
    };

    this.onSubmit = this.onSubmit.bind(this);
  }

  componentDidMount() {
    this.props.loadAnalyticObjectsWithVersions(this.props.urlQuery.objectsIds);
  }

  UNSAFE_componentWillReceiveProps({analyticObjects}) {
    const newState = {};

    if (!isEqual(this.props.analyticObjects, analyticObjects) && analyticObjects.length > 0) {
      newState.analyticObjectsVersions = transform(analyticObjects, (result, analyticObject) => {
        result[analyticObject.id] = analyticObject.versions[0];
      }, {});
    }

    this.setState(newState);
  }

  onSubmit = (simulationName) => {
    const {
      selectedStatements, statementsAdjustments, createAnalyticObjectsSimulation,
      recalculateAnalyticObjects, analyticObjects, recalculate
    } = this.props;
    const {analyticObjectsVersions} = this.state;

    if (!recalculate) {
      createAnalyticObjectsSimulation(
        analyticObjects, analyticObjectsVersions, selectedStatements,
        statementsAdjustments, simulationName
      );
    } else {
      recalculateAnalyticObjects(analyticObjectsVersions, selectedStatements);
    }
  };

  shouldShowStatementsSection() {
    const {statementsRequestIssuersParams: {issuerId, ...issuersFilters}, showSingleIssuerTab} = this.props;

    return (showSingleIssuerTab && !!issuerId) || (!showSingleIssuerTab && !isEmpty(issuersFilters));
  }

  renderErrorMessage() {
    const requests = values(pick(
      this.props,
      [
        'analyticObjectsRequest', 'statementsRequest', 'issuersListRequest',
        'createSimulationRequest', 'recalculateSimulationRequest'
      ]
    ));

    if (some(requests, ({status}) => isFailed(status))) {
      const message = this.props.errorCode === 'NO_PRODUCTION_VERSION_AVAILABLE'
        ? 'One or more of the selected analytic objects do not have approved version. Сalculation is unavailable.'
        : 'An unexpected error occurred.';

      return (
        <div data-test="errorMessages">
          <Alert bsStyle="danger">
            {message}
          </Alert>
        </div>
      );
    }

    return null;
  }

  renderVersionSelect(analyticObject) {
    const {analyticObjectsVersions} = this.state;

    const props = {
      options: analyticObject.versions,
      onChange: (option) => {
        this.setState({
          analyticObjectsVersions: {...analyticObjectsVersions, [analyticObject.id]: option}
        });
      },
      value: analyticObjectsVersions[analyticObject.id],
      valueKey: 'label',
      labelKey: 'label',
      clearable: false,
      backspaceRemoves: false
    };

    return <Select {...props}/>;
  }

  renderIssuerSection() {
    const { showSingleIssuerTab, toggleSimulationTab } = this.props;

    return (
      <div data-test="issuerSection">
        <span className={theme.sectionTitle}>Issuers</span>
        <hr />
        <Switcher buttons={['Single Issuer', 'Multiple Issuers']} onChange={(index) => toggleSimulationTab(index === 0)} />
        {showSingleIssuerTab && <SingleIssuerForm />}
        {!showSingleIssuerTab && <MultipleIssuersForm />}
      </div>
    );
  }

  renderStatementsSection() {
    if (!this.shouldShowStatementsSection()) {
      return null;
    }

    return <StatementsSection onSubmit={this.onSubmit} recalculate={this.props.recalculate} />;
  }

  render() {
    const {
      analyticObjects, createdSimulation, analyticObjectsRequest,
      createSimulationRequest, recalculateSimulationRequest, recalculate
    } = this.props;

    const mainTitle = recalculate ? 'Saving recalculation...' : 'Saving simulation...';
    const sectionTitle = `Analytic Objects${recalculate ? '' : ' Versions'}`;

    return (
      <LoadingContainer isLoading={isPending(createSimulationRequest.status) || isPending(recalculateSimulationRequest.status)}
                        spinner="primary" title={mainTitle} offset={100}>
        <div className={theme.root}>
          {this.renderErrorMessage()}
          <div data-test="successMessages">
            {!!createdSimulation && (
              <Alert bsStyle="success">
                Simulation <strong>{createdSimulation.simulationName}</strong> was successfully created.
              </Alert>
            )}
            {isSuccessful(recalculateSimulationRequest.status) && (
              <Alert bsStyle="success">
                Statements were successfully recalculated.
              </Alert>
            )}
          </div>
          <div className="clearfix">
            <LoadingContainer isLoading={isPending(analyticObjectsRequest.status)} spinner="primary"
                              title="Loading analytic objects..." offset={100}>
              <div>
                <span className={theme.sectionTitle} data-test="objectsSectionTitle">{sectionTitle}</span>
                <hr />
                <div className={theme.grid}>
                  {analyticObjects.map((object, i) => {
                    return (
                      <div className={theme.gridItem} key={i}>
                        <div className={theme.versionSelect} data-test="versionSelect">
                          <div className={classnames(theme.selectLabel, recalculate && theme.recalculate)} data-test="objectName">
                            {object.description || object.name}
                          </div>
                          {!recalculate && (
                            <div className={theme.select} data-test="objectVersion">
                              {this.renderVersionSelect(object)}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </LoadingContainer>
            {this.renderIssuerSection()}
            {this.renderStatementsSection()}
          </div>
        </div>
      </LoadingContainer>
    );
  }
}

export default SimulationForm;
