import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { loadIssuerStatements, resetIssuerStatementsFilters } from 'modules/analytic/actions/simulationActions';

import SingleIssuerForm from './SingleIssuerForm';

export function mapStateToProps(state) {
  return {
    currentIssuer: state.issuer.currentIssuer,
    statementsRequestIssuersParams: state.simulation.statementsRequestIssuersParams.toJS(),
    statementsRequest: state.requests.simulationIssuerStatements
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    loadIssuerStatements,
    resetIssuerStatementsFilters
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(SingleIssuerForm);
