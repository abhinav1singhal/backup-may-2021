import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { asyncStatusUtils, asyncStatusTypes } from 'react-techstack/utils';

import { Button } from 'modules/shared/components';
import { IssuerSelector, ISSUER_SELECTOR_INLINE_CONTROLS_STYLE } from 'modules/issuer/components';

import theme from './SingleIssuerForm.css';
import { issuerType } from 'modules/issuer/types';
const { isPending } = asyncStatusUtils;
const { asyncRequestType } = asyncStatusTypes;

class SingleIssuerForm extends React.Component {

  static propTypes = {
    currentIssuer: issuerType,

    statementsRequestIssuersParams: PropTypes.object.isRequired,
    statementsRequest: asyncRequestType.isRequired,
    loadIssuerStatements: PropTypes.func.isRequired,
    resetIssuerStatementsFilters: PropTypes.func.isRequired
  };

  render() {
    const {
      currentIssuer = {}, statementsRequestIssuersParams: {issuerId},
      resetIssuerStatementsFilters, loadIssuerStatements, statementsRequest
    } = this.props;

    const IssuerSelectorProps = {
      theme: {
        root: classNames(ISSUER_SELECTOR_INLINE_CONTROLS_STYLE, theme.issuerSelector)
      }
    };

    const ButtonProps = {
      onClick: () => {
        resetIssuerStatementsFilters();
        loadIssuerStatements({issuerId: currentIssuer.id});
      },
      disabled: !currentIssuer.id || issuerId !== currentIssuer.id && isPending(statementsRequest.status),
      loading: currentIssuer.id && issuerId !== currentIssuer.id && isPending(statementsRequest.status),
      theme: {
        root: theme.showStatementsButton
      }
    };

    return (
      <div className={classNames(theme.singleIssuerSection, theme.form, 'clearfix')}>
        <IssuerSelector {...IssuerSelectorProps} />
        <Button {...ButtonProps}>Show statements</Button>
      </div>
    );
  }
}

export default SingleIssuerForm;
