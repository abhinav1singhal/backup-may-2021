/* global describe, it, beforeEach, afterEach, sinon, xdescribe, xit */

import React from 'react';
import { Checkbox, Input, Alert } from 'react-techstack';
import expect from 'expect';
import { noop } from 'lodash/util';
import StatementsSection from '../StatementsSection';
import { Button } from 'modules/shared/components';
import * as mocks from '../../../__tests__/simulationMocks';
import Adapter from 'enzyme-adapter-react-16';
import { shallow, configure } from 'enzyme';
configure({adapter: new Adapter()});

describe('app.modules.analytic.components.SimulationForm.components.StatementsSection.__tests__.StatementsSectionSpec', () => {
  const requiredProps = {
    statements: [],
    selectedStatements: [],
    selectedStatementsForPage: [],
    page: {},
    createSimulationRequest: {},
    statementsRequest: {},
    onSubmit: noop,
    showOnlySelected: false,
    createAnalyticObjectsSimulation: noop,
    toggleSelectedOnly: noop
  };

  it('should render showSelectedCheckbox', () => {
    const wrapper = shallow(<StatementsSection {...requiredProps} />);
    const showSelectedCheckbox = wrapper.find('[data-test="showSelectedCheckbox"]');

    expect(showSelectedCheckbox.containsAllMatchingElements([
      <div>No items selected</div>,
      <Checkbox {...{label: 'Show selected only', checked: false}} />
    ])).toEqual(true);
  });

  it('should render showSelectedCheckbox with correct message and checkbox selection', () => {
    const props = {
      ...requiredProps,
      selectedStatements: mocks.statements,
      showOnlySelected: true
    };
    const wrapper = shallow(<StatementsSection {...props} />);
    const showSelectedCheckbox = wrapper.find('[data-test="showSelectedCheckbox"]');

    expect(showSelectedCheckbox.containsAllMatchingElements([
      <div>2 Selected</div>,
      <Checkbox {...{label: 'Show selected only', checked: true}} />
    ])).toEqual(true);
  });

  it('should call toggleSelectedOnly when checkbox clicked', () => {
    const props = {
      ...requiredProps,
      toggleSelectedOnly: expect.createSpy()
    };
    const wrapper = shallow(<StatementsSection {...props} />);
    const showSelectedCheckbox = wrapper.find('[data-test="showSelectedCheckbox"]');
    showSelectedCheckbox.find(Checkbox).simulate('click');

    expect(props.toggleSelectedOnly).toHaveBeenCalled();
  });

  it('should pass proper props to simulation name input', () => {
    const wrapper = shallow(<StatementsSection {...requiredProps} />);
    const getInputProps = () => wrapper.find('[data-test="simulationNameForm"]').find(Input).props();
    const props = {
      value: null,
      type: 'text',
      maxLength: 500,
      label: 'Simulation Name',
      labelClassName: 'col-xs-4',
      wrapperClassName: 'col-xs-8',
      bsStyle: undefined,
      disabled: true
    };

    expect(getInputProps()).toInclude(props);

    wrapper.setState({simulationName: 'testName'});
    expect(getInputProps().value).toEqual('testName');

    wrapper.setState({simulationNameNotValid: true});
    expect(getInputProps().bsStyle).toEqual('error');

    wrapper.setProps({selectedStatements: mocks.statements});
    expect(getInputProps().disabled).toEqual(false);
  });

  it('should pass proper props to submit button', () => {
    const wrapper = shallow(<StatementsSection {...requiredProps} />);
    const getLoadingButton = () => wrapper.find('[data-test="simulationNameForm"]').find(Button);

    expect(getLoadingButton().props()).toInclude({
      disabled: true,
      bsStyle: 'primary'
    });
    expect(getLoadingButton().prop('children').join('')).toEqual('Calculate and Save');

    wrapper.setProps({
      selectedStatements: mocks.statements,
      recalculate: true
    });
    expect(getLoadingButton().prop('disabled')).toEqual(false);
    expect(getLoadingButton().prop('children').join('')).toEqual('Recalculate and Save');
  });

  it('should render validation error message', () => {
    const wrapper = shallow(<StatementsSection {...requiredProps} />);

    wrapper.setState({simulationNameNotValid: true});
    expect(wrapper.contains((
      <Alert bsStyle="danger">
        Simulation statement name can only contain letters (a-z, A-Z), numbers (0-9), dashes (-),
        underscores (_) and a period (.) with a maximum of 500 characters.
      </Alert>
    ))).toEqual(true);
  });

  it('should not call onSubmit when simulation name simuation name is empty', () => {
    const props = {
      ...requiredProps,
      onSubmit: expect.createSpy()
    };
    const wrapper = shallow(<StatementsSection {...props} />);
    const getLoadingButton = () => wrapper.find('[data-test="simulationNameForm"]').find(Button);

    getLoadingButton().simulate('click');
    expect(wrapper.state('simulationNameNotValid')).toEqual(true);
    expect(props.onSubmit).toNotHaveBeenCalled();
  });

  it('should not call onSubmit when simulation name contains forbidden characters', () => {
    const props = {
      ...requiredProps,
      onSubmit: expect.createSpy()
    };
    const wrapper = shallow(<StatementsSection {...props} />);
    const getLoadingButton = () => wrapper.find('[data-test="simulationNameForm"]').find(Button);

    const restrictedStrings = ['!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '..', '.fasdf.'];
    restrictedStrings.forEach((string) => {
      wrapper.setState({
        simulationNameNotValid: false,
        simulationName: string
      });
      getLoadingButton().simulate('click');
      expect(wrapper.state('simulationNameNotValid')).toEqual(true);
      expect(props.onSubmit).toNotHaveBeenCalled();
    });
  });

  it('should call onSubmit when simulation name is 500 char long', () => {
    const props = {
      ...requiredProps,
      onSubmit: expect.createSpy()
    };
    const wrapper = shallow(<StatementsSection {...props} />);
    const getLoadingButton = () => wrapper.find('[data-test="simulationNameForm"]').find(Button);

    const longString = 'x'.repeat(500);
    wrapper.setState({
      simulationNameNotValid: false,
      simulationName: longString
    });
    getLoadingButton().simulate('click');
    expect(wrapper.state('simulationNameNotValid')).toEqual(false);
    expect(props.onSubmit).toHaveBeenCalled();
  });

  it('should not call onSubmit when simulation name is 501 char long', () => {
    const props = {
      ...requiredProps,
      onSubmit: expect.createSpy()
    };
    const wrapper = shallow(<StatementsSection {...props} />);
    const getLoadingButton = () => wrapper.find('[data-test="simulationNameForm"]').find(Button);

    const longString = 'x'.repeat(501);
    wrapper.setState({
      simulationName: longString
    });
    getLoadingButton().simulate('click');
    expect(wrapper.state('simulationNameNotValid')).toEqual(true);
    expect(props.onSubmit).toNotHaveBeenCalled();
  });

  // ToDo: broken due to changes in functionality, fix
  xit('should call onSubmit with correct params when correct simulation name', () => {
    const props = {
      ...requiredProps,
      onSubmit: expect.createSpy(),
      selectedStatements: mocks.statements
    };
    const wrapper = shallow(<StatementsSection {...props} />);
    const getLoadingButton = () => wrapper.find('[data-test="simulationNameForm"]').find(Button);

    const simulationName = 'azAZ09---___.';
    wrapper.setState({simulationName});
    getLoadingButton().simulate('click');
    expect(props.onSubmit).toHaveBeenCalledWith(props.selectedStatements, simulationName);
  });
});
