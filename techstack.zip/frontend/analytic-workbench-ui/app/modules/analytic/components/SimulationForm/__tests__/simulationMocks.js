export const analyticObjects = [
  {
    'id': '1675550b-03a8-4a96-8fee-a4af94624703',
    'name': 'demo_2216516693',
    'description': 'Demo ratio',
    'versions': [
      {
        'id': 'bb4c9771-c7b1-4a86-b621-b59a7acbae50',
        'aoId': '1675550b-03a8-4a96-8fee-a4af94624703',
        'version': 3,
        'production': false,
        'label': '3'
      },
      {
        'id': '82311c29-daed-4cb5-80d8-31345374f9d8',
        'aoId': '1675550b-03a8-4a96-8fee-a4af94624703',
        'version': 2,
        'production': true,
        'label': '2 (approved)'
      },
      {
        'id': '6a25d28a-68ae-42b3-ad58-0fa437c472be',
        'aoId': '1675550b-03a8-4a96-8fee-a4af94624703',
        'version': 1,
        'production': false,
        'label': '1'
      }
    ]
  },
  {
    'id': 'a2e44281-e4c7-4319-b397-957163e8e595',
    'name': 'demo_2216516917',
    'versions': [
      {
        'id': 'bd57d8b3-a3bb-4e7e-81a4-4dcc45720dd0',
        'aoId': 'a2e44281-e4c7-4319-b397-957163e8e595',
        'version': 3,
        'production': false,
        'label': '3'
      },
      {
        'id': '6f499816-37c1-4a1b-8602-7eeb849e2b72',
        'aoId': 'a2e44281-e4c7-4319-b397-957163e8e595',
        'version': 2,
        'production': true,
        'label': '2 (approved)'
      },
      {
        'id': '61e32836-1b36-4741-9ea1-901a9551b616',
        'aoId': 'a2e44281-e4c7-4319-b397-957163e8e595',
        'version': 1,
        'production': false,
        'label': '1'
      }
    ]
  }
];

export const statements = [
  {
    'statementRevisionId': 'c7f2cc78-53c7-459c-93fc-832892314326',
    'id': '36d15302-d216-1930-e053-254e0e0a3f59',
    'periodType': 'Annual',
    'fiscalYear': 2014,
    'revisionDate': '2014-08-18T00:00',
    'consolidationType': 'Consolidated',
    'regimeType': 'LOCAL GAAP',
    'organisationId': '820239847 - AAI Limited',
    'selected': true
  },
  {
    'statementRevisionId': '0921a89d-10a2-4fa6-a710-81d6c254911b',
    'id': '36d15302-ccd5-1930-e053-254e0e0a3f59',
    'periodType': 'Annual',
    'fiscalYear': 2013,
    'revisionDate': '2013-11-19T00:00',
    'consolidationType': 'Consolidated',
    'regimeType': 'LOCAL GAAP',
    'organisationId': '820239847 - AAI Limited',
    'selected': true
  }
];

export const issuers = [
  {
    'label': '4 Ever Life Insurance Company - 6000',
    'lobId': 6000,
    'id': 823963998,
    'name': '4 Ever Life Insurance Company'
  },
  {
    'label': 'AachenMuenchener Lebensversicherung AG - 5001',
    'lobId': 5001,
    'id': 808549497,
    'name': 'AachenMuenchener Lebensversicherung AG'
  }
];

export const issuersFilters = {
  country: [
    {
      description: 'null',
      id: '806356887',
      name: 'Afghanistan'
    },
    {
      description: 'null',
      id: '806356888',
      name: 'Albania'
    }
  ],
  lineOfBusiness: [
    {
      description: 'Banking and Finance Companies',
      id: '5000',
      name: 'Bankin Finance Comp'
    },
    {
      description: 'Insurance',
      id: '6000',
      name: 'Insurance'
    }
  ],
  region: [
    {
      description: 'Insurance',
      id: '6000',
      name: 'Insurance'
    },
    {
      description: 'Central Asia',
      id: '4195',
      name: 'Central Asia'
    }
  ],
  sector: [
    {
      description: 'Credit Insurance',
      id: '6159',
      name: 'Credit'
    },
    {
      description: 'Other',
      id: '4195',
      name: 'Other'
    }
  ]
};

export const statements2 = [
  {
    'statementRevisionId': '50becdb8-f36a-4167-b25f-a57f00f96398',
    'id': 'd8b868c6-c39a-466b-8c3b-d4f6ca1945e9',
    'periodType': 'Annual',
    'fiscalYear': 2016,
    'revisionDate': '2016-11-03T06:08:16.020',
    'consolidationType': 'Consolidated',
    'regimeType': 'IFRS',
    'organisationId': '798850 - Aegon USA Life Group (Cons)',
    'selected': true
  },
  {
    'statementRevisionId': '31d5c275-2d5a-4801-a27c-29e9d50f0fb3',
    'id': 'ac652c42-d683-4f0e-a9a1-b336100783ef',
    'periodType': 'Annual',
    'fiscalYear': 2013,
    'revisionDate': '2016-11-04T12:42:00.321',
    'consolidationType': 'Consolidated',
    'regimeType': 'IFRS',
    'organisationId': '600012189 - MetLife Investors USA Insurance Company',
    'selected': true
  }
];
