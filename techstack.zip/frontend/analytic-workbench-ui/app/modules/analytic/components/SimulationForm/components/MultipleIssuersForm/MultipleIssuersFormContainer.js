import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { omit } from 'lodash/object';
import {
  loadIssuersFilters, loadIssuerStatements, resetIssuerStatementsFilters
} from 'modules/analytic/actions/simulationActions';
import MultipleIssuersForm from './MultipleIssuersForm';

export function mapStateToProps(state) {
  return {
    filters: state.simulation.issuersFilters.toJS(),
    filtersInStore: omit(state.simulation.statementsRequestIssuersParams.toJS(), 'issuerId'),
    totalIssuers: state.simulation.totalIssuers,
    filtersRequest: state.requests.simulationIssuersFilters,
    statementsRequest: state.requests.simulationIssuerStatements
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    loadIssuersFilters,
    loadIssuerStatements,
    resetIssuerStatementsFilters
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(MultipleIssuersForm);
