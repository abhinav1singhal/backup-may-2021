import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { toggleSelectedOnly } from 'modules/analytic/actions/simulationActions';
import StatementsSection from './StatementsSection';

export function mapStateToProps(state) {
  return {
    selectedStatements: state.simulation.section.selectedStatements,
    showOnlySelected: state.simulation.section.showOnlySelected,
    statementsRequest: state.requests.simulationIssuerStatements
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    toggleSelectedOnly
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(StatementsSection);
