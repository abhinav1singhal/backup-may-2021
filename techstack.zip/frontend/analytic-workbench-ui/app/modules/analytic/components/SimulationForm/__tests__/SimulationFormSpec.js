/* global describe, it, beforeEach, afterEach, sinon, xdescribe, xit */

import React from 'react';
import expect from 'expect';
import { noop } from 'lodash/util';
import { asyncStatus } from 'react-techstack/utils';
import { Alert, Button, Select, LoadingContainer } from 'react-techstack';
import * as mocks from './simulationMocks';
import StatementsSection from '../components/StatementsSection';
import MultipleIssuersForm from '../components/MultipleIssuersForm';
import Adapter from 'enzyme-adapter-react-16';
import { shallow, configure } from 'enzyme';
configure({adapter: new Adapter()});

// todo Including these 2 imports breaks the tests!!! why?
import SingleIssuerForm from '../components/SingleIssuerForm';
import SimulationForm from '../SimulationForm';


// ToDo: broken due to changes in functionality, fix
xdescribe('app.modules.analytic.components.SimulationForm.__tests__.SimulationFormSpec', () => {
  const requiredProps = {
    analyticObjects: [],
    statementsRequestIssuersParams: {},
    analyticObjectsRequest: {},
    issuersListRequest: {},
    statementsRequest: {},
    createSimulationRequest: {},
    recalculateSimulationRequest: {},
    loadAnalyticObjectsWithVersions: noop,
    createAnalyticObjectsSimulation: noop,
    recalculateAnalyticObjects: noop,
    toggleSimulationTab: noop,
    urlQuery: {},
    showSingleIssuerTab: true,
    theme: {}
  };

  it('should render success message when simulation created', () => {
    const props = {
      ...requiredProps,
      createdSimulation: {
        simulationName: 'testName'
      }
    };
    const wrapper = shallow(<SimulationForm {...props} />);
    expect(wrapper.find('[data-test="successMessages"]').contains((
      <Alert bsStyle="success">
        Simulation <strong>testName</strong> was successfully created.
      </Alert>
    ))).toEqual(true);
  });

  it('should render success message when recalculate request succeed', () => {
    const props = {
      ...requiredProps,
      recalculateSimulationRequest: {
        status: asyncStatus.SUCCESS
      }
    };
    const wrapper = shallow(<SimulationForm {...props} />);
    expect(wrapper.find('[data-test="successMessages"]').contains((
      <Alert bsStyle="success">
        Statements was successfully recalculated.
      </Alert>
    ))).toEqual(true);
  });

  it('should render version selects for analytic objects passed', () => {
    const wrapper = shallow(<SimulationForm {...requiredProps} />);
    const selector = '[data-test="versionSelect"]';
    expect(wrapper.find(selector).length).toEqual(0);

    wrapper.setProps({analyticObjects: mocks.analyticObjects});
    expect(wrapper.find(selector).length).toEqual(2);
  });

  it('should show correct main and section titles for simulation/recalculation', () => {
    const wrapper = shallow(<SimulationForm {...requiredProps} />);
    expect(wrapper.closest(LoadingContainer).prop('title')).toEqual('Saving simulation...');
    expect(wrapper.find('[data-test="objectsSectionTitle"]').text()).toEqual('Analytic Objects Versions');

    wrapper.setProps({recalculate: true});
    expect(wrapper.closest(LoadingContainer).prop('title')).toEqual('Saving recalculation...');
    expect(wrapper.find('[data-test="objectsSectionTitle"]').text()).toEqual('Analytic Objects');
  });

  it('should show analytic object description first, if not existent then name', () => {
    const props = {
      ...requiredProps,
      analyticObjects: mocks.analyticObjects
    };
    const wrapper = shallow(<SimulationForm {...props} />);
    const objectsNames = wrapper.find('[data-test="objectName"]');
    expect(objectsNames.at(0).text()).toEqual('Demo ratio');
    expect(objectsNames.at(1).text()).toEqual('demo_2216516917');
  });

  it('should not show version selects when recalculation', () => {
    const props = {
      ...requiredProps,
      recalculate: true,
      analyticObjects: mocks.analyticObjects
    };
    const wrapper = shallow(<SimulationForm {...props} />);

    const versionSelects = wrapper.find('[data-test="versionSelect"]');
    expect(versionSelects.length).toEqual(2);
    expect(versionSelects.find('[data-test="objectName"]').length).toEqual(2);
    expect(versionSelects.find('[data-test="objectVersion"]').length).toEqual(0);
  });

  it('should show proper error messages', () => {
    const wrapper = shallow(<SimulationForm {...requiredProps} />);
    const errorsSelector = '[data-test="errorMessages"]';
    expect(wrapper.find(errorsSelector).length).toEqual(0);

    wrapper.setProps({
      recalculateSimulationRequest: {
        status: asyncStatus.FAILURE
      }
    });
    expect(wrapper.find(errorsSelector).contains((
      <Alert bsStyle="danger">
        An unexpected error occurred.
      </Alert>
    ))).toEqual(true);

    wrapper.setProps({
      errorCode: 'NO_PRODUCTION_VERSION_AVAILABLE'
    });
    expect(wrapper.find(errorsSelector).contains((
      <Alert bsStyle="danger">
        One or more of the selected analytic objects do not have approved version. Сalculation is unavailable.
      </Alert>
    ))).toEqual(true);
  });

  it('should show or hide statements section according to passed params', () => {
    const wrapper = shallow(<SimulationForm {...requiredProps} />);
    expect(wrapper.find(StatementsSection).length).toEqual(0);

    wrapper.setProps({statementsRequestIssuersParams: {
      issuerId: 1234
    }});
    expect(wrapper.find(StatementsSection).length).toEqual(1);

    wrapper.setProps({showSingleIssuerTab: false});
    expect(wrapper.find(StatementsSection).length).toEqual(0);

    wrapper.setProps({statementsRequestIssuersParams: {
      filter1: 1,
      filter2: 2
    }});
    expect(wrapper.find(StatementsSection).length).toEqual(1);
  });

  it('should show correct appearance of single/multi issuers tabs buttons and SingleIssuerForm', () => {
    const wrapper = shallow(<SimulationForm {...requiredProps} />);

    const issuerSection = wrapper.find('[data-test="issuerSection"]');
    const buttons = issuerSection.find('[data-test="tabsSwitch"]').find(Button);
    expect(buttons.at(0).prop('active')).toEqual(false);
    expect(buttons.at(1).prop('active')).toEqual(true);
    expect(issuerSection.find(SingleIssuerForm).length).toEqual(1);
    expect(issuerSection.find(MultipleIssuersForm).length).toEqual(0);
  });

  it('should show correct appearance of single/multi issuers tabs buttons and MultipleIssuersForm', () => {
    const props = {
      ...requiredProps,
      showSingleIssuerTab: false
    };
    const wrapper = shallow(<SimulationForm {...props} />);

    const issuerSection = wrapper.find('[data-test="issuerSection"]');
    const buttons = issuerSection.find('[data-test="tabsSwitch"]').find(Button);
    expect(buttons.at(0).prop('active')).toEqual(true);
    expect(buttons.at(1).prop('active')).toEqual(false);
    expect(issuerSection.find(SingleIssuerForm).length).toEqual(0);
    expect(issuerSection.find(MultipleIssuersForm).length).toEqual(1);
  });

  it('should show correct appearance of single/multi issuers tabs buttons and MultipleIssuersForm', () => {
    const props = {
      ...requiredProps,
      showSingleIssuerTab: false
    };
    const wrapper = shallow(<SimulationForm {...props} />);

    const issuerSection = wrapper.find('[data-test="issuerSection"]');
    const buttons = issuerSection.find('[data-test="tabsSwitch"]').find(Button);
    expect(buttons.at(0).prop('active')).toEqual(true);
    expect(buttons.at(1).prop('active')).toEqual(false);
    expect(issuerSection.find(SingleIssuerForm).length).toEqual(0);
    expect(issuerSection.find(MultipleIssuersForm).length).toEqual(1);
  });

  it('should call toggleSimulationTab when single/multi issuers tabs buttons clicked', () => {
    const toggleSimulationTab = expect.createSpy();
    const props = {
      ...requiredProps,
      toggleSimulationTab
    };
    const wrapper = shallow(<SimulationForm {...props} />);

    const issuerSection = wrapper.find('[data-test="issuerSection"]');
    const buttons = issuerSection.find('[data-test="tabsSwitch"]').find(Button);

    buttons.at(1).simulate('click');
    expect(toggleSimulationTab).toHaveBeenCalledWith(false);

    buttons.at(0).simulate('click');
    expect(toggleSimulationTab).toHaveBeenCalledWith(true);
  });

  it('should write new version to state after select change', () => {
    const props = {
      ...requiredProps,
      analyticObjects: mocks.analyticObjects
    };
    const wrapper = shallow(<SimulationForm {...props} />);
    const versionMock = {
      aoId: '2e3e4d08-29fa-4dfc-a752-b51c5fd92b02',
      id: '6ac56a2e-b29c-4bde-9072-4b2f7d4aeaf6',
      label: '633',
      production: false,
      version: 633
    };
    wrapper.find('[data-test="objectVersion"]').at(0).find(Select).simulate('change', versionMock);
    expect(wrapper.state('analyticObjectsVersions')['1675550b-03a8-4a96-8fee-a4af94624703']).toEqual(versionMock);
  });

  describe('testing onSubmit', () => {
    const expectedParams = {
      statementRevisions: [
        {
          statementRevisionId: 'c7f2cc78-53c7-459c-93fc-832892314326',
          statementId: '36d15302-d216-1930-e053-254e0e0a3f59',
          revisionDate: '2014-08-18T00:00'
        },
        {
          statementRevisionId: '0921a89d-10a2-4fa6-a710-81d6c254911b',
          statementId: '36d15302-ccd5-1930-e053-254e0e0a3f59',
          revisionDate: '2013-11-19T00:00'
        }
      ],
      simulationAoRevisions: [
        {
          aoId: '1675550b-03a8-4a96-8fee-a4af94624703',
          aoRevisionId: 'bb4c9771-c7b1-4a86-b621-b59a7acbae50',
          name: 'demo_2216516693',
          version: 3
        },
        {
          aoId: 'a2e44281-e4c7-4319-b397-957163e8e595',
          aoRevisionId: 'bd57d8b3-a3bb-4e7e-81a4-4dcc45720dd0',
          name: 'demo_2216516917',
          version: 3
        }
      ]
    };

    const props = {
      ...requiredProps,
      showSingleIssuerTab: false,
      statementsRequestIssuersParams: {
        filter1: 1,
        filter2: 2
      }
    };
    const wrapper = shallow(<SimulationForm {...props} />);
    wrapper.setProps({analyticObjects: mocks.analyticObjects});

    it('should call createAnalyticObjectsSimulation with correct params', () => {
      const createAnalyticObjectsSimulation = expect.createSpy();
      const simulationTitle = 'testName';
      wrapper.setProps({createAnalyticObjectsSimulation});
      wrapper.find(StatementsSection).prop('onSubmit')(mocks.statements, simulationTitle);
      expect(createAnalyticObjectsSimulation).toHaveBeenCalledWith({
        ...expectedParams,
        title: simulationTitle
      });
    });

    it('should call recalculateAnalyticObjects with correct params for recalculation ', () => {
      const recalculateAnalyticObjects = expect.createSpy();
      wrapper.setProps({
        recalculateAnalyticObjects,
        recalculate: true
      });
      wrapper.find(StatementsSection).prop('onSubmit')(mocks.statements);
      expect(recalculateAnalyticObjects).toHaveBeenCalledWith(expectedParams);
    });

  });

});
