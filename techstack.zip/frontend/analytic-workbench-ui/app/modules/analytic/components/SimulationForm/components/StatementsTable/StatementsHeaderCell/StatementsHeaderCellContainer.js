import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { asyncStatusUtils } from 'react-techstack/utils';
const { isPending, isSuccessful } = asyncStatusUtils;

import {
  applyStatementsFilter, loadIssuerStatementsFilters
} from 'modules/analytic/actions/simulationActions';

import StatementsHeaderCell from './StatementsHeaderCell';

export function mapStateToProps(state, ownProps) {
  const options = state.simulation.statementFilters.data[ownProps.attributeType] || {};
  const isLoading = isPending(state.requests.simulationIssuerStatementsFilters.status);
  const needToLoad = (!isLoading && !isSuccessful(state.requests.simulationIssuerStatementsFilters.status))
    || !options.list;
  const filterKey = ownProps.attributeType === 'issuer' ? 'organisationId' : ownProps.attributeType;
  const selectedOptions = state.simulation.statementFilters.filters[filterKey] || [];

  return {
    options,
    isLoading,
    issuersParams: state.simulation.statementsRequestIssuersParams,
    selectedOptions,
    needToLoad,
    activeFilter: isSuccessful(state.requests.simulationIssuerStatementsFilters.status) && selectedOptions.length > 0,
    showOnlySelected: state.simulation.section.showOnlySelected
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    onApplyFilter: applyStatementsFilter,
    loadIssuerStatementsFilters
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(StatementsHeaderCell);
