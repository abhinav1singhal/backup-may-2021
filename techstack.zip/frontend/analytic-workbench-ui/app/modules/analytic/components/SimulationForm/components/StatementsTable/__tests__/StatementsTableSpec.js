/* global describe, it, beforeEach, afterEach, sinon, xdescribe, xit */

import React from 'react';
import { DataTable } from 'react-techstack';
import expect from 'expect';
import { noop } from 'lodash/util';
import StatementsTable from '../StatementsTable';
import Adapter from 'enzyme-adapter-react-16';
import { shallow, configure } from 'enzyme';
configure({adapter: new Adapter()});

// ToDo: broken due to changes in functionality, fix
xdescribe('app.modules.analytic.components.SimulationForm.components.StatementsTable.__tests__.StatementsTableSpec', () => {
  const requiredProps = {
    statements: [],
    selectedStatements: [],
    allStatementsSelected: false,
    showOnlySelected: false,
    loadIssuerStatements: noop,
    toggleStatement: noop,
    toggleAllStatements: noop,
    applyStatementsSorting: noop,
    getIssuerStatements: noop,
    issuersParams: {},
    page: {
      number: 1,
      totalPages: 1
    },
    statementsRequest: {}
  };

  it('should pass correct columns to table', () => {
    const props = {
      ...requiredProps,
      issuersParams: {
        issuerId: 1234
      }
    };

    const wrapper = shallow(<StatementsTable {...props} />);
    const columns = wrapper.find(DataTable).prop('columns');

    expect(columns[0]).toEqual({key: 'selected', width: 30});
    expect(columns[1]).toEqual({key: 'periodType', label: 'Period Type'});
    expect(columns[2]).toEqual({key: 'fiscalYear', label: 'Period'});
    expect(columns[3]).toEqual({key: 'consolidationType', label: 'Consolidation'});
    expect(columns[4]).toEqual({key: 'regimeType', label: 'Accounting regime'});
    expect(columns[5]).toEqual({key: 'revisionDate', label: 'Created'});

    wrapper.setProps({
      issuersParams: {
        filter1: 1,
        filter2: 2
      }
    });
    expect(wrapper.find(DataTable).prop('columns')[1]).toEqual({key: 'organisationId', label: 'Issuer'});
  });
});
