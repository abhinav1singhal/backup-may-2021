import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import {
  loadAnalyticObjectsWithVersions, createAnalyticObjectsSimulation, recalculateAnalyticObjects,
  toggleSimulationTab
} from 'modules/analytic/actions/simulationActions';

import SimulationForm from './SimulationForm';

export function mapStateToProps(state) {
  return {
    analyticObjects: state.simulation.analyticObjects.toJS(),
    selectedStatements: state.simulation.section.selectedStatements.toJS(),
    statementsAdjustments: state.simulation.section.statementsAdjustments.toJS(),
    statementsRequestIssuersParams: state.simulation.statementsRequestIssuersParams.toJS(),
    createdSimulation: state.simulation.createdSimulation,
    errorCode: state.simulation.errorCode,
    analyticObjectsRequest: state.requests.simulationAnalyticObjects,
    issuersListRequest: state.requests.issuerSelectInitialData,
    statementsRequest: state.requests.simulationIssuerStatements,
    createSimulationRequest: state.requests.simulationCreate,
    recalculateSimulationRequest: state.requests.simulationRecalculate,
    showSingleIssuerTab: state.simulation.form.showSingleIssuerTab
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    loadAnalyticObjectsWithVersions,
    createAnalyticObjectsSimulation,
    recalculateAnalyticObjects,
    toggleSimulationTab
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(SimulationForm);
