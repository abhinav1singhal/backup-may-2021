/* eslint-disable react/no-set-state */
import PropTypes from 'prop-types';

import React from 'react';
import classnames from 'classnames';
import { isEmpty } from 'lodash/lang';
import { Input, Alert, Checkbox } from 'react-techstack';
import theme from './StatementsSection.css';
import StatementsTable from '../StatementsTable';
import { Button } from 'modules/shared/components';

class StatementsSection extends React.Component {

  static propTypes = {
    selectedStatements: PropTypes.array.isRequired,
    statementsRequest: PropTypes.object.isRequired,
    recalculate: PropTypes.bool,
    onSubmit: PropTypes.func.isRequired,
    showOnlySelected: PropTypes.bool.isRequired,
    toggleSelectedOnly: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props);

    this.state = {
      simulationName: null,
      simulationNameNotValid: false
    };
  }

  validateSimulationNameInput() {
    const {simulationName} = this.state;

    return !isEmpty(simulationName) && simulationName.length <= 500 && simulationName.match(/^[\w\-]*\.?[\w\-]*$/);
  }

  noStatementsSelected() {
    return this.props.selectedStatements.length === 0;
  }

  createSimulation() {
    if (!this.props.recalculate && !this.validateSimulationNameInput()) {
      this.setState({simulationNameNotValid: true});
      return;
    }

    this.props.onSubmit(this.state.simulationName);
  }

  renderSelectedCheckbox() {
    const {selectedStatements, showOnlySelected, toggleSelectedOnly} = this.props;
    let selectedItems;

    if (this.noStatementsSelected()) {
      selectedItems = 'No items selected';
    } else {
      selectedItems = `${selectedStatements.length} Selected`;
    }

    return (
      <div className={theme.selectionBlock} data-test="showSelectedCheckbox">
        <div className={theme.selectedLabel}>{selectedItems}</div>
        <Checkbox label="Show selected only" checked={showOnlySelected} onClick={toggleSelectedOnly} />
      </div>
    );
  }

  renderSimulationNameInput() {
    const {simulationName, simulationNameNotValid} = this.state;

    const props = {
      onChange: ({target}) => this.setState({
        simulationName: target.value,
        simulationNameNotValid: false
      }),
      value: simulationName,
      type: 'text',
      maxLength: 500,
      label: 'Simulation Name',
      labelClassName: 'col-xs-4',
      wrapperClassName: 'col-xs-8',
      bsStyle: simulationNameNotValid ? 'error' : undefined,
      disabled: this.noStatementsSelected()
    };

    return <Input {...props} />;
  }

  renderSubmitButton() {
    const props = {
      onClick: this.createSimulation.bind(this),
      disabled: this.noStatementsSelected(),
      bsStyle: 'primary'
    };

    return <Button {...props}>{this.props.recalculate ? 'Recalculate' : 'Calculate'} and Save</Button>;
  }

  render() {
    return (
      <div>
        <span className={theme.sectionTitle}>Statements</span>
        <div className={classnames('clearfix', theme.form)}>
          {this.renderSelectedCheckbox()}
          <div className="pull-right">
            <form className={classnames('form-horizontal', theme.form)} data-test="simulationNameForm">
              {!this.props.recalculate && (
                <div className={theme.simulationNameInput}>{this.renderSimulationNameInput()}</div>
              )}
              {this.renderSubmitButton()}
            </form>
          </div>
        </div>
        <div>
          {this.state.simulationNameNotValid && (
            <Alert bsStyle="danger">
              Simulation statement name can only contain letters (a-z, A-Z), numbers (0-9), dashes (-),
              underscores (_) and a period (.) with a maximum of 500 characters.
            </Alert>
          )}
          <StatementsTable recalculate={this.props.recalculate} />
        </div>
      </div>
    );
  }
}

export default StatementsSection;
