import PropTypes from 'prop-types';
import React from 'react';
import { Popover } from 'react-techstack';
import SearchableOptionsFilter from 'modules/base/components/SearchableOptionsFilter';

class StatementFilterPopover extends React.Component {

  static propTypes = {
    options: PropTypes.array.isRequired,
    onFilterApplied: PropTypes.func.isRequired,
    selectedFilterValues: PropTypes.array
  };

  render() {
    const {options, selectedFilterValues, onFilterApplied, ...popoverProps} = this.props;
    const optionsFilterProps = {
      options,
      selectedOptions: selectedFilterValues,
      onChange: onFilterApplied
    };

    return (
      <Popover {...popoverProps} id="statement-filter-popover">
        <SearchableOptionsFilter {...optionsFilterProps} />
      </Popover>
    );
  }
}

StatementFilterPopover.defaultProps = {};

export default StatementFilterPopover;
