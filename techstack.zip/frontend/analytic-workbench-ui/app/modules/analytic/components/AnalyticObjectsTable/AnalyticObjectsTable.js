import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { asyncStatus } from 'react-techstack/utils';
import { noop } from 'lodash/util';
import { isArray } from 'lodash/lang';
import moment from 'moment';

import {
  DataTableBare, DataTableCell, Button, Alert, LoadingContainer, Checkbox
} from 'react-techstack';

import {hasPermission} from 'modules/common/utils/permissionsUtils';

import { analyticObjectStatuses } from 'modules/analytic/services/analyticObjectsService';
import ObjectsActionPanel from 'modules/analytic/components/ObjectsActionPanel';
import Pagination from 'modules/shared/components/Pagination';
import FilterHeaderCell from 'modules/analytic/components/FilterHeaderCell';
import LockedObjectIcon from './components/LockedObjectIcon';
import ModelDefinitionIcon from 'modules/base/components/ModelDefinitionIcon';

import booleanValues from 'utils/booleanValues';

const ROW_HEIGHT = 50;
const TABLE_OFFSET = 55;
const MAX_TABLE_HEIGHT = ROW_HEIGHT * 10 + TABLE_OFFSET;

class AnalyticObjectsTable extends React.Component {

  static propTypes = {
    analyticObjects: PropTypes.shape({
      data: PropTypes.arrayOf(PropTypes.object).isRequired,
      page: PropTypes.object.isRequired
    }).isRequired,
    analyticObjectsStatus: PropTypes.oneOf([
      analyticObjectStatuses.ACTIVE, analyticObjectStatuses.INACTIVE, analyticObjectStatuses.LOCKED
    ]).isRequired,
    loadingStatus: PropTypes.string.isRequired,
    isLoading: PropTypes.bool.isRequired,

    userPermissions: PropTypes.arrayOf(PropTypes.string).isRequired,

    changePage: PropTypes.func.isRequired,
    onSearch: PropTypes.func.isRequired,
    onDownloadAnalyticObject: PropTypes.func,
    selectAllAnalyticObjects: PropTypes.bool,
    toggleSelectedAnalyticObject: PropTypes.func,
    onUnlockAnalyticObjects: PropTypes.func,
    onDeactivateAnalyticObjects: PropTypes.func,

    onOpenVersionsDrillDown: PropTypes.func.isRequired,
    areFiltersOn: PropTypes.bool.isRequired,
    selectedObjects: PropTypes.array,
    theme: PropTypes.object.isRequired
  };

  userHasPermission(permission, hasAllPermissions) {
    return hasPermission(this.props.userPermissions, permission, hasAllPermissions);
  }

  enableActionPanel() {
    return this.userHasPermission([
      `view_${this.props.analyticObjectsStatus}_AnalyticObject_file`,
      `edit_${this.props.analyticObjectsStatus}_AnalyticObject_file`,
      `copy_${this.props.analyticObjectsStatus}_AnalyticObject_file`,
      'unlock_locked_AnalyticObjects',
      `view_${this.props.analyticObjectsStatus}_AnalyticObjects_attributes`,
      `update_${this.props.analyticObjectsStatus}_AnalyticObjects_attributes`,
      `view_${this.props.analyticObjectsStatus}_AnalyticObjects_AuditTrail`,
      'deactivate_active_AnalyticObjects',
      'view_AnalyticObject_dependencies',
      'create_AnalyticObjects_simulation',
      'approve_AnalyticObject_version'
    ]);
  }

  _isActiveOrLockedObjectsList = () => {
    return [
      analyticObjectStatuses.ACTIVE, analyticObjectStatuses.LOCKED
    ].indexOf(this.props.analyticObjectsStatus) !== -1;
  };

  _onToggleSelected = (selected, id) => {
    return (event) => {
      event.preventDefault();
      this._isActiveOrLockedObjectsList() && this.props.toggleSelectedAnalyticObject(!selected, id);
    };
  };

  _onVersionClick = (id) => {
    return (event) => {
      event.preventDefault();
      event.stopPropagation();
      this.props.onOpenVersionsDrillDown(id);
    };
  };

  _onFirstPageClick = (event) => {
    event.preventDefault();
    this.props.changePage({ number: 1, size: this.props.analyticObjects.page.size });
  };

  _getColumns = () => {
    const columns = [
      {
        key: 'selected',
        status: [analyticObjectStatuses.ACTIVE, analyticObjectStatuses.LOCKED],
        width: 30
      },
      {key: 'name', label: 'Object Name'},
      {key: 'description', label: 'Display Name'},
      {key: 'sourceFile', status: [analyticObjectStatuses.ACTIVE], label: 'Source File'},
      {key: 'type', label: 'Object Type'},
      {key: 'subsector', label: 'Analytic Sector 3'},
      {key: 'methodology', label: 'Methodology'},
      {key: 'region', label: 'Region'},
      {key: 'country', label: 'Country', width: 100},
      {
        key: 'updated',
        status: [analyticObjectStatuses.INACTIVE, analyticObjectStatuses.LOCKED],
        label: this.props.analyticObjectsStatus === analyticObjectStatuses.LOCKED ? 'Locked' : 'Deactivated',
        width: 90
      },
      {
        key: 'updatedBy',
        status: [analyticObjectStatuses.INACTIVE, analyticObjectStatuses.LOCKED],
        label: this.props.analyticObjectsStatus === analyticObjectStatuses.LOCKED ? 'Locked by' : 'Deactivated by',
        width: this.props.analyticObjectsStatus === analyticObjectStatuses.LOCKED ? 93 : 110
      },
      {key: 'version', label: 'Ver. #', width: 65}
    ];

    if (!this.enableActionPanel()) {
      columns.shift();
    }

    return columns.filter((item) => !isArray(item.status) || item.status.indexOf(this.props.analyticObjectsStatus) !== -1);
  };

  _headerCell = (cellProps, cellContent) => {
    if (cellProps.columnKey === 'selected') {
      cellProps.onClick = this._onToggleSelected(this.props.selectAllAnalyticObjects);
      return (
        <Checkbox checked={ this.props.selectAllAnalyticObjects } />
      );
    }

    const columnsWithFilter = ['type', 'sourceFile', 'lob', 'subsector', 'methodology', 'region', 'country', 'privacy'];
    const requiredPermissions = [
      `view_${this.props.analyticObjectsStatus}_AnalyticObjects_list`,
      `filter_${this.props.analyticObjectsStatus}_AnalyticObjects`
    ];
    if (this.props.areFiltersOn && this.userHasPermission(requiredPermissions, true) && columnsWithFilter.indexOf(cellProps.columnKey) !== -1) {
      return (
        <FilterHeaderCell title={cellProps.title}
                          attributeType={cellProps.columnKey}
                          onApply={this.props.onSearch}>
          { cellContent }
        </FilterHeaderCell>
      );
    }

    return cellContent;
  };

  _rowClassNameGetter = (rowIndex, rowData) => {
    const theme = this.props.theme;

    return classNames({
      [theme.selectedRow]: !rowData.deactivated && rowData.selected,
      [theme.deactivatedRow]: rowData.deactivated
    });
  };

  _cell = (data, key, row, cellProps) => {
    let content;
    if (this._isActiveOrLockedObjectsList() && row.deactivated) {
      content = this._deactivatedCellContent(data, key, row);
    } else {
      content = this._cellContent(data, key, row, cellProps);
    }

    return (
      <DataTableCell {...cellProps} >
        { content || '' }
      </DataTableCell>
    );
  };

  _cellContent = (data, key, row, cellProps) => {
    let content;
    const theme = this.props.theme;

    switch (key) {
      case 'selected':
        content = <Checkbox checked={ data }/>;
        break;
      case 'name':
        content = (
          <span className={theme.statusCell}>
            {row.locked ? <LockedObjectIcon data={row} className={theme.statusIcon} /> : null}
            {row.isDefinition ? <ModelDefinitionIcon className={theme.statusIcon} /> : null}
            {data}
            {row.productionVersion && <div className={theme.approvedVersion}>Approved ver. {row.productionVersion}</div>}
          </span>
        );
        break;
      case 'version':
        content = data;
        if (this.userHasPermission(`view_${this.props.analyticObjectsStatus}_AnalyticObject_VersionsHistory`)) {
          content = (
            <Button onClick={this._onVersionClick(row.id)}
                    bsStyle="link"
                    href="#">
              { data }
            </Button>
          );
        }
        break;
      case 'lob':
      case 'subsector':
      case 'methodology':
      case 'country':
      case 'region':
        content = data.join(', ');
        break;
      case 'updated':
        content = moment(data).format('L');
        break;
      case 'privacy':
        content = booleanValues[data];
        break;
      default:
        content = data;
    }

    if (this.enableActionPanel()) {
      cellProps.onClick = this._onToggleSelected(row.selected, row.id);
    }

    return content;
  };

  _deactivatedCellContent = (data, key, row) => {
    let content;
    const theme = this.props.theme;

    switch (key) {
      case 'selected':
        content = (
          <Checkbox
            label={ data }
            checked={ false }
          />
        );
        break;
      case 'name':
        content = <span className={theme.strikeThrough}>{data}</span>;
        if (row.isDefinition || row.locked) {
          content = (
            <span>
              {row.locked ? <LockedObjectIcon data={row} className={theme.statusIcon} /> : null}
              {row.isDefinition ? <ModelDefinitionIcon className={theme.statusIcon} /> : null}
              {content}
            </span>
          );
        }
        break;
      case 'type':
        content = <span className={theme.deactivatedLabel}>Deactivated</span>;
        break;
      default:
        content = '';
    }

    return content;
  };

  _renderActionPanel = () => {
    if (this._isActiveOrLockedObjectsList() && this.enableActionPanel()) {
      const objectsActionPanelProps = {
        analyticObjects: this.props.selectedObjects,
        analyticObjectsStatus: this.props.analyticObjectsStatus,
        onDownloadAnalyticObject: this.props.onDownloadAnalyticObject,
        onUnlockAnalyticObjects: this.props.onUnlockAnalyticObjects,
        onDeactivateAnalyticObjects: this.props.onDeactivateAnalyticObjects,
        page: this.props.analyticObjects.page
      };

      return <ObjectsActionPanel {...objectsActionPanelProps} />;
    }

    return null;
  };

  _renderErrorMessage = (analyticObjects) => {
    const firstPageButton = (
      <Button onClick={this._onFirstPageClick} bsStyle="link" href="#">
        Go to first page
      </Button>
    );

    if (this.props.loadingStatus === asyncStatus.FAILURE) {
      return (
        <Alert bsStyle="danger">
          An unexpected error occurred.
        </Alert>
      );
    }

    if (this.props.loadingStatus === asyncStatus.SUCCESS && analyticObjects.length === 0) {
      return (
        <Alert bsStyle="warning">
          No analytic objects were found. {this.props.analyticObjects.page.number !== 1 && firstPageButton}
        </Alert>
      );
    }

    return null;
  };

  render() {
    const analyticObjects = this.props.analyticObjects.data || [];

    const dataTableProps = {
      data: analyticObjects,
      columns: this._getColumns(),
      width: 'auto',
      height: analyticObjects.length > 0 ? Math.min(ROW_HEIGHT * analyticObjects.length + TABLE_OFFSET, MAX_TABLE_HEIGHT) : ROW_HEIGHT,
      headerCell: this._headerCell,
      rowClassNameGetter: this._rowClassNameGetter,
      cell: this._cell
    };
    const page = {
      totalPages: 1,
      ...this.props.analyticObjects.page
    };

    return (
      <div className={this.props.theme.root}>
        <LoadingContainer isLoading={this.props.isLoading} title="Loading analytic objects..."
                          offset={100} spinner="primary">
          {this._renderActionPanel()}
          <DataTableBare {...dataTableProps} />
          {this._renderErrorMessage(analyticObjects)}
          <Pagination page={page} onSelect={this.props.changePage} />
        </LoadingContainer>
      </div>
    );
  }

}

AnalyticObjectsTable.defaultProps = {
  onDownloadAnalyticObject: noop,
  selectAllAnalyticObjects: false,
  areFiltersOn: true,
  toggleSelectedAnalyticObject: noop,
  onUnlockAnalyticObjects: noop,
  onDeactivateAnalyticObjects: noop,
  theme: require('./AnalyticObjectsTable.css')
};

export default AnalyticObjectsTable;
