/* global describe, it, xit, beforeEach, afterEach, sinon, xdescribe */

import React from 'react';
import TestUtils from 'react-dom/test-utils';
import { findDOMNode } from 'react-dom';
import expect from 'expect';
import { noop } from 'lodash/util';

import AnalyticObjectsTable from '../AnalyticObjectsTable';
import { AnalyticObjectsDataMock } from '../../../services/__tests__/analyticObjectsServiceMock';
import { analyticObjectStatuses } from '../../../services/analyticObjectsService';


// todo FIX: causes ` addComponentAsRefTo(...): Only a ReactOwner can have refs. ` error
xdescribe('app.modules.analytic.components.AnalyticObjectsTable.__tests__.AnalyticObjectsTableSpec', () => {

  function renderAnalyticObjectsTable(customProps) {
    return TestUtils.renderIntoDocument(React.createElement(
      AnalyticObjectsTable, {
        analyticObjects: { data: AnalyticObjectsDataMock, page: { number: 1, size: 2 } },
        analyticObjectsStatus: analyticObjectStatuses.ACTIVE,
        loadingStatus: '',
        isLoading: false,
        userPermissions: ['', ''],
        changePage: noop,
        onSearch: noop,
        onSelect: noop,
        selectAllAnalyticObjects: false,
        toggleSelectedAnalyticObject: noop,
        onSortTable: noop,
        onFilterTable: noop,
        onDownloadAnalyticObject: noop,
        onViewAuditTrailModal: noop,
        auditTrailData: [],
        onDeactivateAnalyticObjects: noop,
        onOpenVersionsDrillDown: noop,
        ...customProps
      }
    ));
  }

  let toggleSelectedAnalyticObjectSpy;
  let onDownloadAnalyticObjectSpy;
  let onSortTableSpy;
  let headerRowNode;
  let dataRowNodes;

  beforeEach(() => {
    toggleSelectedAnalyticObjectSpy = expect.createSpy();
    onSortTableSpy = expect.createSpy();
    onDownloadAnalyticObjectSpy = expect.createSpy();

    const AnalyticObjectsTableInstance = renderAnalyticObjectsTable({
      toggleSelectedAnalyticObject: toggleSelectedAnalyticObjectSpy,
      onSortTable: onSortTableSpy,
      onDownloadAnalyticObject: onDownloadAnalyticObjectSpy
    });

    [headerRowNode, ...dataRowNodes] = Array.prototype.slice.call(
      findDOMNode(AnalyticObjectsTableInstance).querySelectorAll('.public_fixedDataTableRow_main')
    );
  });

  xit('should have have correct number of rows', () => {
    expect(dataRowNodes.length).toBe(2);
  });

  xit('should have correct number of cells in row', () => {
    const headerCellNodes = headerRowNode.querySelectorAll('.public_fixedDataTableCell_wrap1');
    const dataCellNodes = dataRowNodes[0].querySelectorAll('.public_fixedDataTableCell_wrap1');

    expect(headerCellNodes.length).toBe(8);
    expect(dataCellNodes.length).toBe(8);
  });


  xit('should call toggleSelectedAnalyticObjectSpy after click on object name cell', () => {
    const nameCellNode = dataRowNodes[0].querySelectorAll('.public_fixedDataTableCell_wrap1')[1];
    TestUtils.Simulate.click(nameCellNode);

    expect(toggleSelectedAnalyticObjectSpy).toHaveBeenCalledWith(true, AnalyticObjectsDataMock[0].id);
    expect(toggleSelectedAnalyticObjectSpy.call.length).toBe(1);
  });


  xit('should call onSortTable with correct arguments after click on any header cell link', () => {
    const headerCellNodes = headerRowNode.querySelectorAll('.public_fixedDataTableCell_wrap1 a');

    TestUtils.Simulate.click(headerCellNodes[0]);
    TestUtils.Simulate.click(headerCellNodes[3]);
    TestUtils.Simulate.click(headerCellNodes[6]);

    expect(onSortTableSpy.calls.length).toBe(3);
    expect(onSortTableSpy.calls[0].arguments).toEqual(['name', 'ASC']);
    expect(onSortTableSpy.calls[1].arguments).toEqual(['updated', 'ASC']);
    expect(onSortTableSpy.calls[2].arguments).toEqual(['version', 'ASC']);
  });

  xit('should not call onSortTable after click on selectAll header cell', () => {
    TestUtils.Simulate.click(headerRowNode.querySelector('.public_fixedDataTableCell_wrap1'));

    expect(onSortTableSpy).toNotHaveBeenCalled();
  });

  xit('should call toggleSelectedAnalyticObject with correct arguments after click on selectAll header cell', () => {
    TestUtils.Simulate.click(headerRowNode.querySelector('.public_fixedDataTableCell_wrap1'));

    expect(toggleSelectedAnalyticObjectSpy.calls.length).toBe(1);
    expect(toggleSelectedAnalyticObjectSpy).toHaveBeenCalledWith(true, undefined);
  });


  xit('should call toggleSelectedAnalyticObject with correct arguments after click on object select cell', () => {
    TestUtils.Simulate.click(dataRowNodes[0].querySelector('.public_fixedDataTableCell_wrap1'));
    TestUtils.Simulate.click(dataRowNodes[1].querySelector('.public_fixedDataTableCell_wrap1'));

    expect(toggleSelectedAnalyticObjectSpy.calls.length).toBe(2);
    expect(toggleSelectedAnalyticObjectSpy.calls[0].arguments).toEqual([true, AnalyticObjectsDataMock[0].id]);
    expect(toggleSelectedAnalyticObjectSpy.calls[1].arguments).toEqual([true, AnalyticObjectsDataMock[1].id]);
  });

  xit('should call toggleSelectedAnalyticObject with correct arguments after click on any data cell ', () => {
    const dataCellNodes = [
      dataRowNodes[0].querySelectorAll('.public_fixedDataTableCell_wrap1'),
      dataRowNodes[1].querySelectorAll('.public_fixedDataTableCell_wrap1')
    ];

    TestUtils.Simulate.click(dataCellNodes[0][2]);
    TestUtils.Simulate.click(dataCellNodes[0][5]);
    TestUtils.Simulate.click(dataCellNodes[1][7]);

    expect(toggleSelectedAnalyticObjectSpy.calls.length).toBe(3);
    expect(toggleSelectedAnalyticObjectSpy.calls[0].arguments).toEqual([true, AnalyticObjectsDataMock[0].id]);
    expect(toggleSelectedAnalyticObjectSpy.calls[1].arguments).toEqual([true, AnalyticObjectsDataMock[0].id]);
    expect(toggleSelectedAnalyticObjectSpy.calls[2].arguments).toEqual([true, AnalyticObjectsDataMock[1].id]);
  });

});
