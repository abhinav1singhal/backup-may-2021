export default from './LockedObjectIcon';
