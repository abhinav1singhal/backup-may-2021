import PropTypes from 'prop-types';
import React from 'react';
import moment from 'moment';
import { OverlayTrigger, Tooltip } from 'react-techstack';
import classNames from 'classnames';
import { Icon } from 'modules/shared/components';

import theme from './LockedObjectIcon.css';

export default class LockedObjectIcon extends React.Component {
  static propTypes = {
    data: PropTypes.shape({
      id: PropTypes.string.isRequired,
      updatedBy: PropTypes.string.isRequired,
      updated: PropTypes.oneOfType([
        PropTypes.string, PropTypes.number
      ]).isRequired
    }).isRequired,

    theme: PropTypes.object,
    className: PropTypes.any
  };

  render() {
    const tooltipId = `LockedObjectTooltip_${this.props.data.id}`;

    const tooltip = (
      <Tooltip id={tooltipId}>
        Locked by: {this.props.data.updatedBy}<br />{moment(this.props.data.updated).format('L LTS')}
      </Tooltip>
    );

    return (
      <OverlayTrigger placement="bottom" overlay={tooltip}>
        <Icon type="lock" className={classNames(theme.icon, this.props.className)} />
      </OverlayTrigger>
    );
  }
}
