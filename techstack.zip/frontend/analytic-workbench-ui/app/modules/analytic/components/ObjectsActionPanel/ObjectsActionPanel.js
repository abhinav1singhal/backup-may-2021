import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { isUndefined } from 'lodash/lang';
import { some, every } from 'lodash/collection';
import { join } from 'lodash/array';

import { Button as AMAButton } from 'modules/shared/components';
import {ModalDialog} from 'modules/shared/components';
import { Row, Col, Button } from 'react-techstack';

import {hasPermission} from 'modules/common/utils/permissionsUtils';
import { analyticObjectStatuses } from 'modules/analytic/services/analyticObjectsService';

import UpdateAttributesForm from 'modules/analytic/components/AttributesForm';
import AuditTrailTable from 'modules/analytic/components/AuditTrailTable';
import ApproveVersionForm from '../ApproveVersionForm';
import { ACCEPTABLE_UPLOAD_FILE_TYPES, isDisabledUpdateAO } from 'modules/analytic/utils';

import theme from './ObjectsActionPanel.css';

export default class ObjectsActionPanel extends React.Component {

  static propTypes = {
    analyticObjects: PropTypes.arrayOf(PropTypes.object).isRequired,
    analyticObjectsStatus: PropTypes.oneOf([
      analyticObjectStatuses.ACTIVE, analyticObjectStatuses.INACTIVE, analyticObjectStatuses.LOCKED
    ]).isRequired,
    userPermissions: PropTypes.arrayOf(PropTypes.string).isRequired,
    onDownloadAnalyticObject: PropTypes.func.isRequired,
    onUnlockAnalyticObjects: PropTypes.func.isRequired,
    onDeactivateAnalyticObjects: PropTypes.func.isRequired,
    page: PropTypes.object.isRequired,
    searchDto: PropTypes.object.isRequired,
    uploadNewAnalyticObjectVersion: PropTypes.func.isRequired,
    uploadingFile: PropTypes.bool.isRequired
  };

  constructor(props) {
    super(props);

    // TODO: we probably should not have custom properties outside of component's state
    this.analyticObjects = [];
    this.analyticObjectsIds = [];
    this.defaultModalProps = {
      title: '',
      content: ''
    };

    this.state = {
      modalProps: this.defaultModalProps,
      openedModalKey: null
    };
  }

  onDownloadButtonClick = (e) => {
    e.preventDefault();
    this.props.onDownloadAnalyticObject(this.analyticObjectsIds[0], false);
  };

  onDownloadCopyButtonClick = (e) => {
    e.preventDefault();
    this.props.onDownloadAnalyticObject(this.analyticObjectsIds[0], true);
  };

  onUpdateAttributesButtonClick = (e) => {
    e.preventDefault();
    this.openModal('updateAttributes');
  };

  onViewAuditTrailButtonClick = (e) => {
    e.preventDefault();
    this.openModal('viewAuditTrail');
  };

  onViewAuditTrailOkButtonClick = (event) => {
    event.preventDefault();
    this.closeModal();
  };

  onDeactivateButtonClick = (e) => {
    e.preventDefault();
    this.props.onDeactivateAnalyticObjects(this.analyticObjectsIds);
  };

  onUnlockButtonClick = (e) => {
    e.preventDefault();
    this.props.onUnlockAnalyticObjects(this.analyticObjectsIds);
  };

  onUploadClick = (e) => {
    e.preventDefault();
    const fileInput = this.refs.fileInput;
    fileInput.click();
  };

  onUploadFileChanged = (e) => {
    e.preventDefault();
    const ao = this.analyticObjects[0];
    const fileInput = this.refs.fileInput;
    const file = fileInput.files[0];
    if (!isUndefined(file)) {
      this.props.uploadNewAnalyticObjectVersion(ao, file);
      this.refs.fileUploadForm.reset();
    }
  };

  onApproveVersionButtonClick = (e) => {
    e.preventDefault();
    this.openModal('approveVersion');
  };

  userHasPermission(permissions) {
    return hasPermission(this.props.userPermissions, permissions);
  }

  openModal = (key)  => {
    this.setState({ openedModalKey: key });
  }

  closeModal = () => {
    this.setState({ openedModalKey: null });
  }

  renderAuditTrailModal() {
    const auditTrailTableProps = {
      analyticObjectsIds: this.analyticObjectsIds
    };
    const modalProps = {
      show: this.state.openedModalKey === 'viewAuditTrail',
      onHide: this.closeModal,
      header: 'Audit Trail',
      footer: <Button onClick={this.onViewAuditTrailOkButtonClick} bsStyle="primary" href="#">OK</Button>
    };

    return (
      <ModalDialog {...modalProps}>
        <AuditTrailTable {...auditTrailTableProps} />
      </ModalDialog>
    );
  }

  renderApproveVersionsModal() {
    const approveVersionFormProps = {
      object: this.props.analyticObjects[0],
      modalOptions: {
        page: this.props.page,
        searchDto: this.props.searchDto
      },
      closeModal: this.closeModal
    };
    const modalProps = {
      show: this.state.openedModalKey === 'approveVersion',
      onHide: this.closeModal,
      header: 'Approve Version'
    };

    return (
      <ModalDialog {...modalProps}>
        <ApproveVersionForm {...approveVersionFormProps} />
      </ModalDialog>
    );
  }

  renderTitle() {
    let title = 'No objects selected';

    if (this.analyticObjects.length === 1) {
      title = this.analyticObjects[0].description;
    } else if (this.analyticObjects.length > 1) {
      title = `${this.analyticObjects.length} Objects selected`;
    }

    return title;
  }

  // ToDo: improve this method
  renderActionButtons() {
    const readOnly = some(this.analyticObjects, {locked: true});

    let uploadButton = null;
    if (
      this.analyticObjects.length === 1 &&
      !this.analyticObjects[0].locked &&
      this.userHasPermission(`edit_${this.props.analyticObjectsStatus}_AnalyticObject_file`)
    ) {
      uploadButton = (
        <AMAButton bsStyle="primary" className={theme.actionButton} href="#"
                   onClick={this.onUploadClick}
                   loading={this.props.uploadingFile}
                   disabled={this.props.uploadingFile}
                   spinnerType="white">
          Create New Version
        </AMAButton>
      );
    }

    let downloadButton = null;
    if (
      this.analyticObjects.length === 1 &&
      this.userHasPermission([
        `view_${this.props.analyticObjectsStatus}_AnalyticObject_file`,
        `edit_${this.props.analyticObjectsStatus}_AnalyticObject_file`
      ])
    ) {
      downloadButton = (
        <Button onClick={this.onDownloadButtonClick} bsStyle="primary"
                className={theme.actionButton} href="#">
          {readOnly || !this.userHasPermission(`edit_${this.props.analyticObjectsStatus}_AnalyticObject_file`) ? 'View' : 'Open'}
        </Button>
      );
    }

    let downloadCopyButton = null;
    if (
      this.analyticObjects.length === 1 && !this.analyticObjects[0].isDefinition &&
      this.userHasPermission(`copy_${this.props.analyticObjectsStatus}_AnalyticObject_file`)
    ) {
      downloadCopyButton = (
        <Button onClick={this.onDownloadCopyButtonClick} bsStyle="primary"
                className={theme.actionButton} href="#">
          Clone
        </Button>
      );
    }

    let unlockButton = null;
    if (
      every(this.analyticObjects, {locked: true}) &&
      this.userHasPermission('unlock_locked_AnalyticObjects')
    ) {
      unlockButton = (
        <Button onClick={this.onUnlockButtonClick} bsStyle="primary"
                className={theme.actionButton} href="#">
          Unlock
        </Button>
      );
    }

    let attributesButton = null;
    if (
      this.userHasPermission([
        `view_${this.props.analyticObjectsStatus}_AnalyticObjects_attributes`,
        `update_${this.props.analyticObjectsStatus}_AnalyticObjects_attributes`
      ])
    ) {
      const disabled = isDisabledUpdateAO(this.analyticObjects);
      attributesButton = (
        <Button onClick={this.onUpdateAttributesButtonClick} bsStyle="primary"
                className={theme.actionButton} href="#" disabled={disabled}>
          {readOnly || !this.userHasPermission(`update_${this.props.analyticObjectsStatus}_AnalyticObjects_attributes`) ? 'Attributes' : 'Update attributes'}
        </Button>
      );
    }

    let viewAuditTrailButton = null;
    if (this.userHasPermission(`view_${this.props.analyticObjectsStatus}_AnalyticObjects_AuditTrail`)) {
      viewAuditTrailButton = (
        <Button onClick={this.onViewAuditTrailButtonClick} bsStyle="primary"
                className={theme.actionButton} href="#">
          View Audit Trail
        </Button>
      );
    }


    let simulationButton = null;
    let recalculateButton = null;
    const isEveryObjectOfType = (type) => every(this.analyticObjects, {type});

    if (isEveryObjectOfType('Ratio') || isEveryObjectOfType('Adjustment')) {
      const objectsIds = this.props.analyticObjects.map(({id}) => id).join(',');

      if (this.userHasPermission('create_AnalyticObjects_simulation')) {
        const simulationUrl = `analytic-objects-simulation?objectsIds=${objectsIds}`;
        simulationButton = (
          <Button href={simulationUrl} bsStyle="primary"
                  className={theme.actionButton} target="_blank">
            Simulation
          </Button>
        );
      }

      if (this.userHasPermission('launch_StatementRevision_recalculation')) {
        const recalculateUrl = `analytic-objects-recalculation?objectsIds=${objectsIds}`;
        recalculateButton = (
          <Button href={recalculateUrl} bsStyle="primary"
                  className={theme.actionButton} target="_blank">
            Recalculate
          </Button>
        );
      }
    }

    let approveVersionButton = null;
    if (this.analyticObjects.length === 1 && this.userHasPermission('approve_AnalyticObject_version')) {
      approveVersionButton = (
        <Button onClick={this.onApproveVersionButtonClick} bsStyle="primary"
                className={theme.actionButton} href="#">
          Approve Version
        </Button>
      );
    }

    let deactivateButton = null;
    if (this.userHasPermission('deactivate_active_AnalyticObjects')) {
      deactivateButton = (
        <Button onClick={this.onDeactivateButtonClick} disabled={readOnly}
                bsStyle="danger" className={theme.actionButton} href="#">
          Deactivate
        </Button>
      );
    }

    let dependenciesButton = null;
    if (this.userHasPermission('view_AnalyticObject_dependencies') && this.analyticObjects.length === 1) {
      const href = `analytic-object-dependencies/${this.analyticObjectsIds[0]}`;
      const target = `"dependencies_"${this.analyticObjectsIds[0]}`;
      dependenciesButton = (
        <Button
          bsStyle="primary"
          className={theme.actionButton}
          target={target}
          href={href}
        >
        Dependencies
        </Button>
      );
    }

    return (
      <div>
        <div className={theme.actions}>
          {uploadButton}
          {unlockButton}
          {downloadButton}
          {downloadCopyButton}
          {attributesButton}
          {viewAuditTrailButton}
          {dependenciesButton}
          {simulationButton}
          {recalculateButton}
          {approveVersionButton}
          {deactivateButton}
        </div>
        <div className={theme.modals}>
          {this.renderUpdateAOModal()}
          {this.renderAuditTrailModal()}
          {this.renderApproveVersionsModal()}
        </div>
      </div>
    );
  }

  renderUpdateAOModal() {
    if (this.state.openedModalKey === 'updateAttributes') {
      const updateAttributesFormProps = {
        analyticObjectsIds: this.analyticObjectsIds,
        analyticObjectsStatus: this.props.analyticObjectsStatus,
        modalOptions: {
          page: this.props.page,
          searchDto: this.props.searchDto
        },
        closeModalDialog: this.closeModal
      };

      const ModalDialogProps = {
        show: this.state.openedModalKey === 'updateAttributes',
        onHide: this.closeModal,
        header: 'Update Attributes',
        theme: {
          modal: theme.aoModal
        }
      };

      return (
        <ModalDialog {...ModalDialogProps}>
          <UpdateAttributesForm {...updateAttributesFormProps} />
        </ModalDialog>
      );
    }

    return null;
  }

  render() {
    this.analyticObjects = this.props.analyticObjects;
    this.analyticObjectsIds = this.analyticObjects.map((object) => object.id);

    const className = classNames({
      [theme.actionPanel]: this.analyticObjects.length === 0,
      [theme.showActionPanel]: this.analyticObjects.length > 0
    });

    return (
      <div className={theme.root}>
        <Row className={className}>
          <Col xs={3}>
            <div className={theme.title}>
              {this.renderTitle()}
            </div>
          </Col>
          <Col xs={9}>
            {
              this.analyticObjects.length === 1 ?
                <form ref="fileUploadForm">
                  <input type="file" style={{display: 'none'}} ref="fileInput"
                         onChange={this.onUploadFileChanged}
                         accept={join(ACCEPTABLE_UPLOAD_FILE_TYPES)} />
                </form> :
                null
            }
            {this.analyticObjects.length > 0 && this.renderActionButtons()}
          </Col>
        </Row>
      </div>
    );
  }

}
