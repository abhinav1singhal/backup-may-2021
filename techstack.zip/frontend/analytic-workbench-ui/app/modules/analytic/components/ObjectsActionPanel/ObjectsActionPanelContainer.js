import { connect } from 'react-redux';

import {
  uploadNewAnalyticObjectVersion
} from 'modules/analytic/actions/objectsActionPanelActions';

import ObjectsActionPanel from './ObjectsActionPanel';

export function mapStateToProps(state) {
  return {
    searchDto: {
      name: state.attributesFilter.name,
      filters: state.attributesFilter.filters
    },
    userPermissions: state.user.permissions,
    uploadingFile: state.analytic.uploadingFile
  };
}

export const mapDispatchToProps = {
  uploadNewAnalyticObjectVersion
};

export default connect(mapStateToProps, mapDispatchToProps)(ObjectsActionPanel);
