export const Permissions = {
  view_active_AnalyticObjects_list: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  view_locked_AnalyticObjects_list: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  view_inactive_AnalyticObjects_list: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  search_PermissionKeyscObjects: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  search_locked_AnalyticObjects: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  search_inactive_AnalyticObjects: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  filter_active_AnalyticObjects: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  filter_locked_AnalyticObjects: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  filter_inactive_AnalyticObjects: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  view_active_AnalyticObjects_attributes: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  view_locked_AnalyticObjects_attributes: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  view_inactive_AnalyticObjects_attributes: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  update_active_AnalyticObjects_attributes: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer'
  ],
  update_locked_AnalyticObjects_attributes: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer'
  ],
  update_inactive_AnalyticObjects_attributes: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer'
  ],
  view_active_AnalyticObjects_AuditTrail: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  view_locked_AnalyticObjects_AuditTrail: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  view_inactive_AnalyticObjects_AuditTrail: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  view_active_AnalyticObject_VersionsHistory: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  view_locked_AnalyticObject_VersionsHistory: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  view_inactive_AnalyticObject_VersionsHistory: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  unlock_locked_AnalyticObjects: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer'
  ],
  deactivate_active_AnalyticObjects: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer'
  ],
  create_new_AnalyticObject: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer'
  ],
  edit_active_AnalyticObject_file: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer'
  ],
  edit_locked_AnalyticObject_file: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer'
  ],
  edit_inactive_AnalyticObject_file: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer'
  ],
  view_active_AnalyticObject_file: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  view_locked_AnalyticObject_file: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  view_inactive_AnalyticObject_file: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  copy_active_AnalyticObject_file: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer'
  ],
  copy_locked_AnalyticObject_file: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer'
  ],
  copy_inactive_AnalyticObject_file: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer'
  ],
  view_AnalyticObject_dependencies: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ],
  export_AnalyticObject_dependencies: [
    'ug_Dev_AHS_ConfigAdmin', 'ug_Dev_AHS_ConfigAdminOutsourcer', 'ug_Dev_AHS_ReadOnly'
  ]
};

export const PermissionKeys = Object.keys(Permissions).map((item) => item.toUpperCase());
