/* global beforeEach afterEach describe it xit */
/* eslint-disable no-console */

import React from 'react';
import ShallowRenderer from 'react-test-renderer/shallow';
import TestUtils from 'react-dom/test-utils';
import { findDOMNode } from 'react-dom';
import expect from 'expect';
import { noop } from 'lodash/util';

import ObjectsActionPanel from '../ObjectsActionPanel';

import { AnalyticObjectsDataMock } from '../../../services/__tests__/analyticObjectsServiceMock';
import { analyticObjectStatuses } from 'modules/analytic/services/analyticObjectsService';
import { PermissionKeys } from './permisionsMock';


describe('app.modules.analytic.components.ObjectsActionPanel.__tests__.ObjectsActionPanelSpec', () => {

  const statuses = [analyticObjectStatuses.ACTIVE, analyticObjectStatuses.INACTIVE, analyticObjectStatuses.LOCKED];

  const defaultProps = {
    onDownloadAnalyticObject: noop,
    analyticObjects: AnalyticObjectsDataMock,
    onUnlockAnalyticObjects: noop,
    onDeactivateAnalyticObjects: noop,
    showModalDialog: false,
    openModalDialog: noop,
    closeModalDialog: noop,
    analyticObjectsStatus: statuses[0],
    userPermissions: PermissionKeys,
    uploadNewAnalyticObjectVersion: noop,
    uploadingFile: false,
    page: {
      number: 1,
      size: 4
    },
    searchDto: {}
  };

  function renderObjectsActionPanel(spyes) {
    return TestUtils.renderIntoDocument(
      <ObjectsActionPanel {...{
        ...defaultProps,
        onDeactivateAnalyticObjects: spyes.onDeactivateAnalyticObjectsSpy,
        openModalDialog: spyes.openModalDialogSpy
      }}
      />);
  }

  let ObjectsActionPanelInstace;

  let onDeactivateAnalyticObjectsSpy;
  let openModalDialogSpy;

  let actionButtons;

  beforeEach(() => {

    onDeactivateAnalyticObjectsSpy = expect.createSpy();
    openModalDialogSpy = expect.createSpy();

    ObjectsActionPanelInstace = renderObjectsActionPanel({
      onDeactivateAnalyticObjectsSpy,
      openModalDialogSpy
    });

    actionButtons = findDOMNode(ObjectsActionPanelInstace).querySelectorAll('[role="button"]');

  });

  function checkActionButtons(analyticObjectsParam, permissionsParam) {
    let analyticObjects = analyticObjectsParam;
    let permissions = permissionsParam;

    if (!(analyticObjects && permissions)) {
      return 'Error: not all parametrs setted';
    }

    analyticObjects = Array.isArray(analyticObjects) ? analyticObjects : [analyticObjects];
    permissions = Array.isArray(permissions) ? permissions : [permissions];

    const firstComp = TestUtils.renderIntoDocument(<ObjectsActionPanel {...{
      ...defaultProps,
      analyticObjects,
      userPermissions: permissions.map((item) => {
        return item.toUpperCase();
      })
    }}
    />);

    const NodeList = findDOMNode(firstComp).querySelectorAll('[role="button"]');
    const elems = [];

    for (let i = 0; i < NodeList.length; i += 1) {
      elems.push(NodeList[i].innerHTML);
    }

    return elems;
  }

  it('don\'t show Deactivate button if user have wrong permissions', () => {
    const res = checkActionButtons(
      AnalyticObjectsDataMock,
      ['saddeactivate_active_AnalyticObjects']
    );

    expect(res.indexOf('Deactivate')).toBe(-1);
  });

  it('show Deactivate button if user have wright permissions', () => {
    const res = checkActionButtons(
      AnalyticObjectsDataMock,
      ['deactivate_active_AnalyticObjects']
    );

    expect(res.indexOf('Deactivate')).toNotBe(-1);
  });

  it('don\'t show audit trails if user have wrong permissions', () => {
    const res = checkActionButtons(
      AnalyticObjectsDataMock,
      [`view_${statuses[0]}_AnalyticObjects_`]
    );

    expect(res.indexOf('View Audit Trail')).toBe(-1);
  });

  it('show audit trails if user have wright permissions', () => {
    const res = checkActionButtons(
      AnalyticObjectsDataMock, [`view_${statuses[0]}_AnalyticObjects_AuditTrail`]
    );

    expect(res.indexOf('View Audit Trail')).toNotBe(-1);
  });

  it('show adudit trails if user have wright permissions', () => {
    const res = checkActionButtons(
      AnalyticObjectsDataMock[0],
      [`view_${statuses[0]}_AnalyticObjects_AuditTrail`]
    );

    expect(res.indexOf('View Audit Trail')).toNotBe(-1);
  });

  it('don\'t show update attributes if someone from analyticObjects is locked', () => {
    const res = checkActionButtons(
      [{
        ...AnalyticObjectsDataMock[0],
        locked: true
      }, {
        ...AnalyticObjectsDataMock[0],
        locked: false
      }], [
        `view_${statuses[0]}_AnalyticObjects_attributes`,
        `update_${statuses[0]}_AnalyticObjects_attributes`
      ]
    );

    expect(res.indexOf('Update attributes')).toBe(-1);
    expect(res.indexOf('Attributes')).toNotBe(-1);
  });

  it('don\'t show update attributes if someone from analyticObjects is locked', () => {
    const res = checkActionButtons(
      {
        ...AnalyticObjectsDataMock[0],
        locked: true
      },
      [
        `view_${statuses[0]}_AnalyticObjects_attributes`,
        `update_${statuses[0]}_AnalyticObjects_attributes`
      ]
    );

    expect(res.indexOf('Update attributes')).toBe(-1);
    expect(res.indexOf('Attributes')).toNotBe(-1);
  });

  it('don\'t show update attributes if user have wrong permissions', () => {
    const res = checkActionButtons(
      AnalyticObjectsDataMock[0],
      [`view_${statuses[0]}_AnalyticObjects_attributes`]
    );

    expect(res.indexOf('Update attributes')).toBe(-1);
    expect(res.indexOf('Attributes')).toNotBe(-1);
  });

  it('Show update attributes if user have wright permissions', () => {
    const res = checkActionButtons(
      AnalyticObjectsDataMock[0],
      [
        `view_${statuses[0]}_AnalyticObjects_attributes`,
        `update_${statuses[0]}_AnalyticObjects_attributes`
      ]
    );

    expect(res.indexOf('Update attributes')).toNotBe(-1);
    expect(res.indexOf('Attributes')).toBe(-1);
  });

  it('unlockButton shouldn\'t be shown if user don\'t have permissions', () => {
    const res = checkActionButtons([
      {
        ...AnalyticObjectsDataMock[0],
        locked: true
      }
    ]);

    expect(res.indexOf('Unlock')).toBe(-1);
  });

  it('unlockButton shouldn\'t be shown if element is not locked', () => {
    const res = checkActionButtons(
      AnalyticObjectsDataMock[0],
      ['unlock_locked_AnalyticObjects']
    );

    expect(res.indexOf('Unlock')).toBe(-1);
  });

  it('unlockButton shouldn\'t be shown if selected more then one element and one is not locked', () => {
    const res = checkActionButtons(
      [
        {
          ...AnalyticObjectsDataMock[0],
          locked: true
        }, {
          ...AnalyticObjectsDataMock[1],
          locked: false
        }
      ],
      ['unlock_locked_AnalyticObjects']
    );

    expect(res.indexOf('Unlock')).toBe(-1);
  });

  it('unlockButton should be shown if selected more then one element and all of them locked and user have permissions', () => {
    const res = checkActionButtons(
      [
        {
          ...AnalyticObjectsDataMock[0],
          locked: true
        }, {
          ...AnalyticObjectsDataMock[1],
          locked: true
        }
      ],
      ['unlock_locked_AnalyticObjects']
    );

    expect(res.indexOf('Unlock')).toNotBe(-1);
  });

  it('unlockButton should be shown if user have permissions one elent is selected and it is locked', () => {
    const res = checkActionButtons(
      {
        ...AnalyticObjectsDataMock[0],
        locked: true
      },
      ['unlock_locked_AnalyticObjects']
    );

    expect(res.indexOf('Unlock')).toNotBe(-1);
  });

  it('downloadCopyButton shouldn\'t be shown if user have wrong permissions', () => {
    const res = checkActionButtons(
      AnalyticObjectsDataMock[0],
      [`view_${ statuses[0] }_AnalyticObject_file`]
    );

    expect(res.indexOf('Clone')).toBe(-1);
  });

  it('downloadCopyButton shouldn\'t be shown if two elements is selected', () => {
    const res = checkActionButtons(
      AnalyticObjectsDataMock,
      [`copy_${ statuses[0] }_AnalyticObject_file`]
    );

    expect(res.indexOf('Clone')).toBe(-1);
  });

  it('downloadCopyButton should be shown if user have proper permissions and only one is selected', () => {
    const res = checkActionButtons(
      AnalyticObjectsDataMock[0],
      [`copy_${ statuses[0] }_AnalyticObject_file`]
    );

    expect(res.indexOf('Clone')).toNotBe(-1);
  });

  it('Download button shouldn\'t be shown if to objects is selected', () => {
    const res = checkActionButtons(
      AnalyticObjectsDataMock,
      [
        `view_${ statuses[0] }_AnalyticObject_file`,
        `edit_${ statuses[0] }_AnalyticObject_file`
      ]
    );

    expect(res.indexOf('Open')).toBe(-1);
  });

  it('Download button shouldn\'t be shown when analyticObjects is INACTIVE ', () => {
    const res = checkActionButtons(
      AnalyticObjectsDataMock[0],
      [
        `view_${ statuses[1] }_AnalyticObject_file`,
        `edit_${ statuses[1] }_AnalyticObject_file`
      ]
    );

    expect(res.indexOf('Open')).toBe(-1);
  });

  it('Download button shouldn\'t be shown when analyticObjects is LOCKED ', () => {
    const res = checkActionButtons(
      AnalyticObjectsDataMock[0],
      [
        `view_${ statuses[1] }_AnalyticObject_file`,
        `edit_${ statuses[1] }_AnalyticObject_file`
      ]
    );

    expect(res.indexOf('Open')).toBe(-1);
  });

  it('create only downloadButton with permissions tp view and edit', () => {
    const res1 = checkActionButtons(
      AnalyticObjectsDataMock[0],
      [
        `view_${ statuses[0] }_AnalyticObject_file`,
        `edit_${ statuses[0] }_AnalyticObject_file`
      ]
    );

    expect(res1.indexOf('Open')).toNotBe(-1);
    expect(res1.indexOf('View')).toBe(-1);
  });

  it('create only downloadButton with permissions to view', () => {
    const res2 = checkActionButtons(
      AnalyticObjectsDataMock[0],
      [`view_${ statuses[0] }_AnalyticObject_file`]
    );

    expect(res2.indexOf('Open')).toBe(-1);
    expect(res2.indexOf('View')).toNotBe(-1);
  });

  it('test amount of buttons showen with diffrent amount of elems', () => {

    const firstComp = TestUtils.renderIntoDocument(
      <ObjectsActionPanel {
        ...{
          ...defaultProps,
          analyticObjects: AnalyticObjectsDataMock
        }
      } />
    );

    const secondComp = TestUtils.renderIntoDocument(
      <ObjectsActionPanel {
        ...{
          ...defaultProps,
          analyticObjects: [AnalyticObjectsDataMock[0]]
        }
      } />
    );

    const emptyComp = TestUtils.renderIntoDocument(
      <ObjectsActionPanel {
        ...{
          ...defaultProps,
          analyticObjects: []
        }
      } />
    );

    expect(findDOMNode(secondComp).querySelectorAll('[role="button"]').length).toBe(6);
    expect(findDOMNode(firstComp).querySelectorAll('[role="button"]').length).toBe(3);
    expect(findDOMNode(emptyComp).querySelectorAll('[role="button"]').length).toBe(0);
  });

  it('test if callback will fire after user clicks on downloadButton', () => {

    const onDonwloadSpy = expect.createSpy();

    const component = TestUtils.renderIntoDocument(
      <ObjectsActionPanel {
      ...{
        ...defaultProps,
        onDownloadAnalyticObject: onDonwloadSpy,
        analyticObjects: [AnalyticObjectsDataMock[0]]
      }
      }/>
    );

    const dowloadButton = findDOMNode(component).querySelectorAll('[role="button"]')[1];

    TestUtils.Simulate.click(dowloadButton);

    expect(onDonwloadSpy).toHaveBeenCalled();

  });

  it('test if callback will fire after user clicks on downloadCopyButton', () => {

    const onDonwloadCopySpy = expect.createSpy();

    const component = TestUtils.renderIntoDocument(
      <ObjectsActionPanel {
        ...{
          ...defaultProps,
          onDownloadAnalyticObject: onDonwloadCopySpy,
          analyticObjects: [AnalyticObjectsDataMock[0]]
        }
      }/>
    );

    const dowloadCopyButton = findDOMNode(component).querySelectorAll('[role="button"]')[1];

    TestUtils.Simulate.click(dowloadCopyButton);

    expect(onDonwloadCopySpy).toHaveBeenCalled();

  });

  it('test if callback fires after clicking on unlock button', () => {

    const onUnlockSpy = expect.createSpy();

    const component = TestUtils.renderIntoDocument(
      <ObjectsActionPanel {
        ...{
          ...defaultProps,
          onUnlockAnalyticObjects: onUnlockSpy,
          analyticObjects: [{
            ...AnalyticObjectsDataMock[0],
            locked: true
          }]
        }
      } />
    );

    const unlockButton = findDOMNode(component).querySelectorAll('[role="button"]')[0];

    TestUtils.Simulate.click(unlockButton);

    expect(onUnlockSpy).toHaveBeenCalled();

  });

  it('test markup', () => {

    const shallowRenderer = new ShallowRenderer();

    shallowRenderer.render(React.createElement(
      ObjectsActionPanel,
      {
        ...defaultProps,
        analyticObjects: [AnalyticObjectsDataMock[0]]
      }
    ));

    const component = shallowRenderer.getRenderOutput();

    expect(component.type).toBe('div');

  });

  it('clicks on button to deactive analytic object', () => {

    TestUtils.Simulate.click(actionButtons[2]);

    expect(onDeactivateAnalyticObjectsSpy).toHaveBeenCalled();

  });

  // TODO: update: (functionality changed)
  xit('clicks on button to open modal dialog', () => {

    TestUtils.Simulate.click(actionButtons[0]);

    expect(openModalDialogSpy).toHaveBeenCalled();

  });

  // TODO: update: (functionality changed)
  xit('clicks on second button to open modal dialog', () => {

    TestUtils.Simulate.click(actionButtons[1]);

    expect(openModalDialogSpy).toHaveBeenCalled();

  });

});
