import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import ApproveVersionForm from './ApproveVersionForm';

import { loadAnalyticObjectVersions, approveAnalyticObjectVersion, loadApproveVersionData } from 'modules/analytic/actions/versionsActions';
import { reloadAnalyticObjectsTable } from 'modules/analytic/actions/analyticObjectsTableActions';
import { asyncStatusUtils } from 'react-techstack/utils';


export function mapStateToProps({ versions: { approveVersionData: versionsData }, requests }) {
  return {
    versions: versionsData.versions.toJS(),
    dependencies: versionsData.dependencies,
    approvedVersion: versionsData.approvedVersion,
    approveVersionRequest: requests.approveAnalyticObjectVersion,
    isLoading: asyncStatusUtils.isPending(requests.approveVersionData.status)
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    loadAnalyticObjectVersions,
    approveAnalyticObjectVersion,
    reloadAnalyticObjectsTable,
    loadApproveVersionData
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(ApproveVersionForm);
