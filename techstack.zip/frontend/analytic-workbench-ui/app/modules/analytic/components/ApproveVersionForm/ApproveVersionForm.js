import PropTypes from 'prop-types';
import React from 'react';
import { Col, Row, Select, Button, ButtonToolbar, Alert, DataTable, Icon, LoadingContainer } from 'react-techstack';
import { asyncStatusUtils } from 'react-techstack/utils';
import classNames from 'classnames';

import { analyticObjectStatuses } from 'modules/analytic/services/analyticObjectsService';
const { isPending, isSuccessful, isFailed } = asyncStatusUtils;

import theme from './ApproveVersionForm.css';

class ApproveVersionForm extends React.Component {

  static propTypes = {
    object: PropTypes.object.isRequired,
    versions: PropTypes.array.isRequired,
    approveVersionRequest: PropTypes.object.isRequired,
    modalOptions: PropTypes.shape({
      page: PropTypes.object,
      searchDto: PropTypes.object
    }),
    closeModal: PropTypes.func.isRequired,
    approveAnalyticObjectVersion: PropTypes.func.isRequired,
    reloadAnalyticObjectsTable: PropTypes.func.isRequired,
    dependencies: PropTypes.array.isRequired,
    approvedVersion: PropTypes.number,
    loadApproveVersionData: PropTypes.func.isRequired,
    isLoading: PropTypes.bool.isRequired
  };

  constructor(props) {
    super(props);

    this.state = {
      selectedVersion: null,
      errorOccurred: false
    };
  }

  componentDidMount() {
    this.props.loadApproveVersionData(this.props.object.id);
  }

  UNSAFE_componentWillReceiveProps({approveVersionRequest: {status}, approvedVersion }) {
    const {approveVersionRequest, closeModal, reloadAnalyticObjectsTable, modalOptions } = this.props;
    const newState = {};

    if (approveVersionRequest.status !== status) {
      if (isSuccessful(status)) {
        reloadAnalyticObjectsTable(analyticObjectStatuses.ACTIVE, modalOptions.searchDto, modalOptions.page);
        closeModal();
      } else if (isFailed(status)) {
        newState.errorOccurred = true;
      }
    } else if (approvedVersion && this.props.approvedVersion !== approvedVersion) {
      newState.selectedVersion = { value: String(approvedVersion), label: `${approvedVersion} (approved)` };
    }
    this.setState(newState); // eslint-disable-line react/no-set-state
  }

  getVersionSelectProps() {
    const sortedVersions = [...this.props.versions].sort((a, b) => b - a);
    const options = [{ value: null, label: 'None' }, ...sortedVersions.map((version) => {
      const isProduction = this.props.approvedVersion === version;
      return {
        value: String(version),
        label: String(version) + (isProduction ? ' (approved)' : '')
      };
    })];

    return {
      options,
      value: this.state.selectedVersion,
      onChange: (option) => this.setState({selectedVersion: option}), // eslint-disable-line react/no-set-state
      labelClassName: classNames('col-xs-3', theme.selectLabel),
      wrapperClassName: 'col-xs-9',
      label: 'Approved Version',
      clearable: false,
      backspaceRemoves: false,
      searchable: false,
      dropdownWidth: '93%',
      valueRenderer: (option) => <span>{option.label}</span>
    };
  }

  approveVersion = () => {
    this.setState({errorOccurred: false}); // eslint-disable-line react/no-set-state
    this.props.approveAnalyticObjectVersion(this.props.object.id, this.state.selectedVersion);
  };

  renderApproveButton() {
    const { approveVersionRequest } = this.props;

    const props = {
      bsStyle: 'primary',
      onClick: this.approveVersion,
      disabled: isPending(approveVersionRequest.status) || !this.state.selectedVersion
    };

    return (
      <Button {...props}>
        {isPending(approveVersionRequest.status) ? 'Loading...' : 'Approve'}
      </Button>
    );
  }

  renderWarningMessage() {
    if (this.props.dependencies.length) {
      const { object: { sourceFile } } = this.props;
      const message = (
        <div>
          All other Analytic Objects defined in the source file
          <span className={theme.sourceFile}> "{sourceFile}" </span>
          will change approved version to the
          selected value. Please see the list of affected objects below
        </div>
      );

      return (
        <Row>
          <Col xs={9} xsOffset={3} className={theme.warning}>
            <div className={theme.icon}><Icon type="error" color="gray" /></div>
            {message}
          </Col>
        </Row>
      );
    }

    return null;
  }

  renderDependenciesTable() {
    const { dependencies } = this.props;
    if (dependencies.length) {
      const dataTableProps = {
        data: dependencies.map((dep) => dep.description ? dep : { ...dep, description: ''}),
        columns: [
          {label: 'Object Name', key: 'name', width: '25%'},
          {label: 'Display Name', key: 'description'}
        ],
        width: 'auto',
        height: Math.min(50 * (dependencies.length + 1), 350) + 2
      };

      return (
        <DataTable {...dataTableProps} />
      );
    }

    return null;
  }

  render() {
    const {object, closeModal} = this.props;
    const fields = [
      {label: 'Object Name', key: 'name'},
      {label: 'Display Name', key: 'description'}
    ];

    return (
      <div className="clearfix">
        <LoadingContainer isLoading={this.props.isLoading}>
          {this.state.errorOccurred && <Alert bsStyle="danger">An unexpected error occurred.</Alert>}
          <form className="form-horizontal">
            {fields.map(({label, key}, index) => {
              return (
                <div className={theme.field} key={index}>
                  <Row>
                    <Col xs={3}>{label}</Col>
                    <Col xs={9}><span className={theme.value}>{object[key]}</span></Col>
                  </Row>
                </div>
              );
            })}
            <Select {...this.getVersionSelectProps()} />
            {this.renderWarningMessage()}
          </form>
          {this.renderDependenciesTable()}
        </LoadingContainer>
        <div className={theme.footer}>
          <ButtonToolbar>
            <Button onClick={closeModal}>Cancel</Button>
            {this.renderApproveButton()}
          </ButtonToolbar>
        </div>
      </div>
    );
  }
}

export default ApproveVersionForm;
