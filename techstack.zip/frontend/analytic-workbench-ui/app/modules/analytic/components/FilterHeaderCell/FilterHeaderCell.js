import PropTypes from 'prop-types';
import React, { Component } from 'react';
import classNames from 'classnames';
import { omit } from 'lodash/object';

import { OverlayTrigger } from 'react-techstack';

import theme from './FilterHeaderCell.css';
import { FilterPopover, Icon } from 'modules/shared/components';

class FilterHeaderCell extends Component {

  static propTypes = {
    activeFilter: PropTypes.bool.isRequired,
    applyAttributeFilter: PropTypes.func.isRequired,
    onApply: PropTypes.func.isRequired,
    children: PropTypes.node.isRequired
  };

  componentDidMount() {
    window.addEventListener('resize', this.onResize);
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.onResize);
  }

  onResize = () => {
    const overlay = this.refs.overlay;
    if (overlay && overlay.state.isOverlayShown) {
      overlay.hide();
    }
  };

  onApplyFilter(options) {
    this.refs.overlay.hide();
    this.props.applyAttributeFilter(options);
    this.props.onApply();
  }

  onCancel() {
    this.refs.overlay.hide();
  }

  renderFilter() {
    const popoverProps = {
      ...omit(this.props, 'activeFilter', 'children'),
      onApply: this.onApplyFilter.bind(this),
      onCancel: this.onCancel.bind(this),
      valueParam: 'id',
      labelParam: 'name'
    };

    const overlay = (
      <FilterPopover {...popoverProps} />
    );

    const classes = classNames({
      [theme.filter]: !this.props.activeFilter,
      [theme.activeFilter]: this.props.activeFilter
    });

    return (
      <div className={classes}>
        <OverlayTrigger ref="overlay"
                        trigger="click"
                        placement="bottom"
                        rootClose
                        overlay={overlay}>
          <Icon type={this.props.activeFilter ? 'filter-full' : 'filter'} />
        </OverlayTrigger>
      </div>
    );
  }

  render() {

    return (
      <div className={theme.root}>
        <div className={theme.content}>
          { this.props.children }
        </div>
        { this.renderFilter() }
      </div>
    );
  }

}

export default FilterHeaderCell;
