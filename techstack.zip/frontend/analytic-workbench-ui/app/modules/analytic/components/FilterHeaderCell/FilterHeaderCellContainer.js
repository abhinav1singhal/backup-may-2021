import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { asyncStatus } from 'react-techstack/utils';

import {
  loadAttributes,
  applyAttributeFilter
} from 'modules/analytic/actions/attributesFilterActions';

import FilterHeaderCell from './FilterHeaderCell';

export function mapStateToProps(state, ownProps) {
  const { isLoading } = state.attributesFilter;
  const options = state.attributesFilter.data[ownProps.attributeType] || [];
  const selectedOptions = state.attributesFilter.filters[ownProps.attributeType] || [];
  return {
    isLoading,
    needToLoad: !isLoading && state.attributesFilter.loadingStatus !== asyncStatus.SUCCESS,
    options,
    selectedOptions,
    activeFilter: state.attributesFilter.loadingStatus === asyncStatus.SUCCESS &&
                   selectedOptions.length > 0
  };
}

export function mapDispatchToProps(dispatch, ownProps) {
  return {
    ...bindActionCreators({
      loadAttributes
    }, dispatch),
    applyAttributeFilter: (options) => dispatch(applyAttributeFilter(ownProps.attributeType, options))
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(FilterHeaderCell);
