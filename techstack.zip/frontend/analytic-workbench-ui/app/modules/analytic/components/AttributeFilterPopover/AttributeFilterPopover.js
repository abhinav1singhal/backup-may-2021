import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { Popover } from 'react-techstack';
import classNames from 'classnames';
import _ from 'lodash';

import { LoadingContainer } from 'react-techstack';
import { OptionsFilter } from 'modules/base';
import styles from './AttributeFilterPopover.css';

class AttributeFilterPopover extends Component {

  static propTypes = {
    attributeType: PropTypes.string.isRequired,
    isLoading: PropTypes.bool.isRequired,
    needToLoad: PropTypes.bool.isRequired,
    title: PropTypes.string.isRequired,
    options: PropTypes.arrayOf(PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      description: PropTypes.string.isRequired
    })).isRequired,
    selectedOptions: PropTypes.arrayOf(
      PropTypes.string.isRequired
    ),
    loadAttributes: PropTypes.func.isRequired,
    applyAttributeFilter: PropTypes.func.isRequired,
    onApply: PropTypes.func.isRequired,
    style: PropTypes.object,
    className: PropTypes.string
  };

  constructor(props) {
    super(props);
    this.state = {
      selectedOptions: props.selectedOptions || []
    };
  }

  UNSAFE_componentWillMount() {
    if (this.props.needToLoad) {
      this.props.loadAttributes();
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!_.isEqual(nextProps.selectedOptions, this.state.selectedOptions)) {
      this.setState({ selectedOptions: nextProps.selectedOptions }); // eslint-disable-line react/no-set-state
    }
  }

  render() {

    const classes = {
      [styles.root]: true,
      [this.props.className]: true
    };

    return (
      <Popover title={this.props.title}
               {...this.props}
               data-test="AttributeFilterPopover__root"
               id="attribute-filter-popover"
               className={classNames(classes)}>

        <LoadingContainer isLoading={this.props.isLoading}>
          <OptionsFilter {...{
            options: this.props.options,
            onChange: (options) => {
              this.setState({ selectedOptions: options }); // eslint-disable-line
              this.props.applyAttributeFilter(options);
              this.props.onApply();
            },
            selectedOptions: this.state.selectedOptions,
            valueParam: 'id',
            labelParam: 'name'
          }} />
        </LoadingContainer>
      </Popover>
    );
  }

}

export default AttributeFilterPopover;
