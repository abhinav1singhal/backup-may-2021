import PropTypes from 'prop-types';
import React from 'react';
import { Glyphicon } from 'react-techstack';

import { getMessage } from 'modules/common/utils/messagesUtils';

import theme from './ReadOnlyMessage.css';

class ReadOnlyMessage extends React.Component {
  render() {
    if (this.props.show) {
      return (
        <div className={theme.root}>
          <Glyphicon glyph="warning-sign" className={theme.icon}/>
          {getMessage('attributesForm.locked')}
        </div>
      );
    }
    return null;
  }
}

ReadOnlyMessage.propTypes = {
  show: PropTypes.bool
};

export default ReadOnlyMessage;
