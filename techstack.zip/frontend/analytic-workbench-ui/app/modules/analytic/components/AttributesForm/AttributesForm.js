import PropTypes from 'prop-types';
import React from 'react';
import { LoadingContainer } from 'react-techstack';
import FormBuilder, { ResetButton, SubmitButton, ErrorMessage, getControlsList } from 'react-techstack/FormBuilder';
import classNames from 'classnames';
import { omit, find } from 'lodash';

import {
  analyticObjectStatusType, isReadOnly,
  prepareValidatorMessage
} from 'modules/analytic/utils/attributesUtils';
import ReadOnlyMessage from './components/ReadOnlyMessage';
import { FormComponent } from 'react-techstack/FormBuilder';

import theme from './AttributesForm.css';
import { permissionsListType } from 'modules/common/types/permissionsTypes';

class AttributesForm extends FormComponent {
  static propTypes = {
    ...FormComponent.propTypes,
    analyticObjectsIds: PropTypes.arrayOf(PropTypes.string),
    analyticObjectsStatus: analyticObjectStatusType.isRequired,
    userPermissions: permissionsListType.isRequired,
    isCreateNewMode: PropTypes.bool,

    closeModalDialog: PropTypes.func.isRequired,
    modalOptions: PropTypes.shape({
      page: PropTypes.object,
      searchDto: PropTypes.object
    }),
    scrollToTop: PropTypes.func.isRequired,

    analyticObjects: PropTypes.object.isRequired,
    saveForm: PropTypes.func.isRequired,
    loadForm: PropTypes.func.isRequired,
    updateAttributesForType: PropTypes.func.isRequired,

    isLoading: PropTypes.bool,
    isSaved: PropTypes.bool,
    isFullForm: PropTypes.bool
  };

  constructor(props) {
    super(props);

    this.controls = getControlsList(props.config);
    this.validatorMessages = {
      ...this.validatorMessages,
      ...['NAME_ALREADY_EXISTS', 'AO_ALREADY_EXISTS', 'DEACTIVATED_AO_ALREADY_EXISTS', 'DUPLICATE_IN_FILE', 'NAME_VALIDATOR']
        .reduce((object, key) => {
          object[key] = prepareValidatorMessage(key);
          return object;
        }, {})
    };
    this.validatorMessages.ATTRIBUTE_VALIDATION_FAIL = (fieldKey, error) => {
      const ao = find(this.props.analyticObjects.data, {id: error.params[0]});
      return `One of attributes is invalid for "${ao.name}".
      Please switch to single edit mode and resolve this issue.`;
    };
  }

  UNSAFE_componentWillMount() {
    this.props.loadForm(this.props.analyticObjectsIds || this.props.file);
  }

  UNSAFE_componentWillReceiveProps(props) {
    if (this.props.config !== props.config) {
      const newState = {
        ...this.state,
        ...this.prepareStateFromProps(props)
      };
      if (this.props.data === props.data) {
        const oldAttrsKeys = this.props.config.attrs.map(({key}) => key);
        newState.data = omit(this.state.data, oldAttrsKeys);
        const newAttrsKeys = props.config.attrs.map(({key}) => key);
        if (newAttrsKeys.includes('governance_ind')) {
          newState.data.governance_ind = props.options.governance_ind.find(({ id }) => id === 'Y');
        }
        if (newAttrsKeys.includes('sharing_ind')) {
          newState.data.sharing_ind = props.options.sharing_ind.find(({ id }) => id === 'N');
        }

        newState.fieldsErrors = omit(this.state.fieldsErrors, oldAttrsKeys);
        oldAttrsKeys.forEach((key) => {
          if (this.state.data[key] === newState.data[key] && newAttrsKeys.includes(key)) {
            newState.fieldsErrors[key] = this.state.fieldsErrors[key];
          }
        });
      }
      this.setState(newState);
      this.controls = getControlsList(props.config);
    }
    if (this.props.responseError !== props.responseError) {
      this.setState({ errors: props.responseError ? [{ key: props.responseError, message: props.errorMessage, params: props.errorParams }] : []});
    }
    if (!this.props.isSaved && props.isSaved) {
      this.props.closeModalDialog();
    }
  }

  onChange(key, value) {
    super.onChange(key, value);
    if (key === 'type') {
      this.props.updateAttributesForType(value.id);
    }
  }

  onCancel = () => {
    this.props.closeModalDialog();
  };

  scrollTop() {
    this.props.scrollToTop();
  }

  submitData(data) {
    this.props.saveForm(data, this.props.modalOptions);
  }

  isDisabledForm() {
    return isReadOnly(this.props);
  }

  recalculateState(state) {
    const newState = super.recalculateState(state);

    return {
      ...newState,
      errors: []
    };
  }

  renderButtons() {
    const cancelProps = {
      text: 'Cancel',
      bsStyle: 'link',
      reset: this.onCancel
    };
    const saveProps = {
      text: 'Save',
      disabled: this.isDisabledForm() || !this.props.isFullForm,
      onSubmit: this.onSubmit
    };

    return (
      <div className={theme.buttons}>
        <ResetButton {...cancelProps} />
        <SubmitButton {...saveProps} />
      </div>
    );
  }

  renderErrorMessage() {
    const errorMessageProps = {
      ...this.prepareErrorMessageProps(),
      controls: this.controls
    };

    return <ErrorMessage {...errorMessageProps} />;
  }

  renderReadOnlyMessage() {
    return <ReadOnlyMessage show={this.state.data.locked} />;
  }

  renderProps() {
    const formBuilderProps = {
      ...this.prepareFormConstructorProps('properties'),
      controls: this.props.config.props,
      theme: {
        controlLabel: classNames('col-xs-3', theme.label),
        controlWrapper: classNames('col-xs-9', theme.wrapper),
        required: theme.required,
        requiredWrapper: theme.requiredWrapper
      }
    };
    return <FormBuilder {...formBuilderProps} />;
  }

  renderAttrs() {
    const formBuilderProps = {
      ...this.prepareFormConstructorProps('attributes'),
      controls: this.props.config.attrs,
      theme: {
        controlLabel: classNames('col-xs-3', theme.label),
        controlWrapper: classNames('col-xs-9', theme.wrapper),
        required: theme.required,
        requiredWrapper: theme.requiredWrapper
      }
    };
    return <FormBuilder {...formBuilderProps} />;
  }

  renderForm() {
    return (
      <form onSubmit={this.onSubmit} noValidate className="form-horizontal">
        {this.renderProps()}
        {this.renderAttrs()}
        {this.renderButtons()}
      </form>
    );
  }

  render() {
    const { isLoading } = this.props;

    return (
      <LoadingContainer isLoading={isLoading}>
        <div className={theme.root}>
          {this.renderErrorMessage()}
          {this.renderReadOnlyMessage()}
          {this.renderForm()}
        </div>
      </LoadingContainer>
    );
  }
}

export default AttributesForm;
