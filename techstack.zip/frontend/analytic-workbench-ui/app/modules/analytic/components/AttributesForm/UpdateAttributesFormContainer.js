import { connect } from 'react-redux';
import { noop } from 'lodash';
import { asyncStatusUtils } from 'react-techstack/utils';
const { isPending, isSuccessful, combineStatuses } = asyncStatusUtils;

import { loadUpdateForm, saveUpdateForm } from 'modules/analytic/actions/attributesFormActions';
import AttributesForm from './AttributesForm';

function mapStateToProps(state) {
  const { attributesForm, requests, analytic: {analyticObjects}} = state;

  return {
    userPermissions: state.user.permissions,

    data: attributesForm.data,
    config: attributesForm.config,
    options: attributesForm.dictionaries,
    isLoading: isPending(combineStatuses(
      requests.loadUpdateForm.status,
      requests.saveUpdateForm.status
    )),
    isSaved: isSuccessful(requests.saveUpdateForm.status),
    isFullForm: true,

    responseError: attributesForm.errorCode,
    errorMessage: attributesForm.errorMessage,
    errorParams: attributesForm.errorParams,
    analyticObjects
  };
}

const mapDispatchToProps = {
  loadForm: loadUpdateForm,
  saveForm: saveUpdateForm,
  updateAttributesForType: noop
};

export default connect(mapStateToProps, mapDispatchToProps)(AttributesForm);
