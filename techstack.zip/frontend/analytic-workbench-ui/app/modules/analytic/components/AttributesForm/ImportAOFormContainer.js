import { connect } from 'react-redux';
import { analyticObjectStatuses } from 'modules/analytic/services/analyticObjectsService';
import { asyncStatusUtils } from 'react-techstack/utils';
const { isPending, isSuccessful, combineStatuses } = asyncStatusUtils;

import { loadCreateForm, saveCreateForm, updateAttributesForType } from 'modules/analytic/actions/attributesFormActions';
import AttributesForm from './AttributesForm';

function mapStateToProps(state) {
  const { attributesForm, requests } = state;

  return {
    userPermissions: state.user.permissions,
    analyticObjectsStatus: analyticObjectStatuses.ACTIVE,

    data: attributesForm.data,
    config: attributesForm.config,
    options: attributesForm.dictionaries,
    isLoading: isPending(combineStatuses(
      requests.loadCreateForm.status,
      requests.saveCreateForm.status
    )),
    isSaved: isSuccessful(requests.saveCreateForm.status),
    isCreateNewMode: true,
    isFullForm: isSuccessful(requests.loadAttrsByType.status),

    responseError: attributesForm.errorCode,
    errorMessage: attributesForm.errorMessage,
    errorParams: attributesForm.errorParams
  };
}

const mapDispatchToProps = {
  loadForm: loadCreateForm,
  saveForm: saveCreateForm,
  updateAttributesForType
};

export default connect(mapStateToProps, mapDispatchToProps)(AttributesForm);
