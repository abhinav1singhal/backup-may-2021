export default from './UpdateAttributesFormContainer';
