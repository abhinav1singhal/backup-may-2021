import PropTypes from 'prop-types';
import React from 'react';
import { isEqual, omit, isFunction, some, noop, pickBy } from 'lodash';
import { VALIDATOR_MESSAGES, CONTROLS, getDisabledMap } from 'react-techstack/FormBuilder';
import { balanceTrees } from 'react-techstack/utils/treeSelect';

import { isValidForm, isValidField, isDataEqual } from 'modules/shared/utils/formBuilderUtils';

class FormComponent extends React.Component {
  static propTypes = {
    data: PropTypes.object.isRequired,
    config: PropTypes.oneOfType([
      PropTypes.object.isRequired,
      PropTypes.arrayOf(PropTypes.object).isRequired
    ]),
    options: PropTypes.object.isRequired,
    onSubmit: PropTypes.func.isRequired,
    onValidate: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props);

    this.state = {
      ...this.prepareStateFromProps(props),
      submitted: false
    };

    this.onChange = this.onChange.bind(this);
    this.validateField = this.validateField.bind(this);

    this.controlTypes = { ...CONTROLS };
    this.validatorMessages = VALIDATOR_MESSAGES;
    this.errorIconShown = false;
    this.controlRefs = {};
    this.isTopLevelError = () => true;
    this.isFieldLevelError = () => false;
  }

  UNSAFE_componentWillReceiveProps(props) {
    if (this.props.data !== props.data || !isEqual(this.props.options, props.options)) {
      this.setState({
        ...this.state,
        ...this.prepareStateFromProps(props)
      });
    }
  }

  shouldComponentUpdate(props, state) {
    return (
      !isEqual(this.state, state) ||
      !isEqual(omit(this.props, 'data', 'options'), omit(props, 'data', 'options'))
    );
  }

  onSubmit = (event) => {
    if (event && isFunction(event.preventDefault)) {
      event.preventDefault();
    }

    if (!this.isDisabledForm()) {
      this.scrollTop();
      if (isValidForm(this.state.fieldsErrors, this.state.errors)) {
        this.submitData(this.state.data);
      } else {
        this.focusFirstInvalid();
      }

      this.setState({
        submitted: true
      });
    }
  };

  onChange(key, value) {
    this.setState((state) => this.recalculateState({
      ...state,
      data: {
        ...state.data,
        [key]: value
      }
    }));
  }

  prepareStateFromProps(props) {
    const { options, data } = balanceTrees({ data: props.data, options: props.options }, props.options, props.config);
    const disabled = getDisabledMap(props.config, options);

    return {
      data,
      options,
      errors: [],
      fieldsErrors: {},
      disabled
    };
  }

  recalculateState(state) {
    const { options, data } = balanceTrees(state, this.props.options, this.props.config);
    const disabled = getDisabledMap(this.props.config, options);

    return {
      data,
      options,
      disabled
    };
  }

  scrollTop() {
    document.body.scrollTop = document.documentElement.scrollTop = 0;
  }

  focusFirstInvalid() {
    const { fieldsErrors } = this.state;
    return some(this.controls, ({ key }) => {
      if (!isValidField(fieldsErrors[key]) && isFunction(this.controlRefs[key].focus)) {
        this.controlRefs[key].focus();
        return true;
      }
      return false;
    });
  }

  validateField(key, value) {
    this.setState((state) => ({
      fieldsErrors: {
        ...state.fieldsErrors,
        [key]: value
      }
    }), () => this.props.onValidate());
  }

  updateFieldsErrors(controlKeys) {
    this.setState((state) => ({
      fieldsErrors: pickBy(state.fieldsErrors, (errors, fieldKey) => controlKeys.includes(fieldKey))
    }));
  }

  reset() {
    this.setState({ data: this.props.data, submitted: false });
  }

  setRef = (control, key) => {
    this.controlRefs[key] = control;
  };

  setFormBuilderRef(instance, name) {
    this[name] = instance;
  }

  hasUnsavedChanges() {
    return !isDataEqual(this.props.data, this.state.data);
  }

  isDisabledForm() {
    return false;
  }

  isDisabledField(key) {
    const list = Object.values(this.props.config).reduce((acc, cur) => acc.concat(cur), []);
    const field = list.find((item) => item.key === key);
    if (!field) {
      return undefined;
    }
    if (isFunction(field.disabled)) {
      return field.disabled(this.state.data);
    }
    return field.disabled;
  }

  prepareFormConstructorProps(name) {
    return {
      data: this.state.data,
      disabled: this.state.disabled,
      disabledForm: this.isDisabledForm(),
      fieldsErrors: this.state.fieldsErrors,
      options: this.state.options,
      submitted: this.state.submitted,
      onChange: this.onChange,
      validate: this.validateField,
      isFieldLevelError: this.isFieldLevelError,
      validatorMessages: this.validatorMessages,
      errorIconShown: this.errorIconShown,
      setRef: this.setRef,
      controlTypes: this.controlTypes,
      ref: (instance) => this.setFormBuilderRef(instance, name)
    };
  }

  prepareErrorMessageProps() {
    return {
      validatorMessages: this.validatorMessages,
      isTopLevelError: this.isTopLevelError,
      fieldsErrors: this.state.fieldsErrors,
      customErrors: this.state.errors,
      shown: this.state.submitted
    };
  }
}

FormComponent.defaultProps = {
  data: {},
  options: {},
  onSubmit: noop,
  onValidate: noop
};

export default FormComponent;
