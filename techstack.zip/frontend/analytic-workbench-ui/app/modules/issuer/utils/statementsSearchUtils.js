import {
  reduce, every, cloneDeep, isUndefined, isBoolean, isPlainObject, forEach, isArray,
  mapValues, map
} from 'lodash';
import { FORM_CONTROL_TYPES } from 'react-techstack/FormBuilder';

import { FormBuilderConfigDTO, DictionariesConfigDTO, SelectRangeUtils } from 'react-techstack/utils';
const  { parseRangeArrayValue, prepareRangeArray } = SelectRangeUtils;
import {isNotEmptyString} from 'modules/common/utils/stringUtils';
import {isNotEmptyArray} from 'modules/common/utils/arrayUtils';
import {parseBooleanStringValue, prepareBooleanStringFlag} from 'modules/common/utils/booleanUtils';
import { dictionaryUtils } from 'react-techstack/utils';
const { prepareKey, prepareValuesMap, unwrapValue } = dictionaryUtils;

export const SELECTED_STATEMENTS_LIMIT = 20;
export const HEADER_HEIGHT = 30;
export const ROW_HEIGHT = 30;
const MAX_DISPLAY_ROWS = SELECTED_STATEMENTS_LIMIT;
const TABLE_HEIGHT_FIX = 5;

const COLUMNS_EXTRA_CONFIG = {
  period_cd: {
    width: 100
  },
  period: {
    width: 100
  },
  period_end_dtm: {
    width: 125
  },
  revision_type: {
    width: 150
  },
  event_nm: {},
  consolidation_id: {
    width: 130
  },
  acc_regime_id: {
    width: 130
  },
  revision_dtm: {
    width: 150
  },
  created_user_desc: {
    width: 100
  }
};


// ToDo: finish this
function prepareFilterControlConfig(control) {
  const config = cloneDeep(control);

  if (
    isPlainObject(config.dictionary) && config.key === 'fiscal_years' &&
    config.type === FORM_CONTROL_TYPES.MULTISELECT
  ) {
    config.type = FORM_CONTROL_TYPES.SELECT_RANGE;
    config.value = parseRangeArrayValue(config.value);
    config.defaultValue = parseRangeArrayValue(config.defaultValue);
  } else if (config.type === FORM_CONTROL_TYPES.CHECKBOX) {
    config.required = false;
    config.value = parseBooleanStringValue(config.value);
    config.defaultValue = parseBooleanStringValue(config.defaultValue);
    config.dictionary = {};
  }

  config.clearable = false;
  config.bsSize = 'small';

  return config;
}

export function prepareFiltersConfig(config) {
  const filters = reduce(config, (result, item) => {
    if (isNotEmptyString(item.label)) {
      result.push(prepareFilterControlConfig(item));
    }

    return result;
  }, []);

  return new FormBuilderConfigDTO(filters);
}

export function prepareColumnsConfig(config) {
  const columns = [{
    key: '$selected',
    label: 'Selected',
    width: 40
  }];

  forEach(config, (item) => {
    if (!item.hidden && isNotEmptyString(item.label)) {
      columns.push({
        ...COLUMNS_EXTRA_CONFIG[item.key],
        ...item
      });
    }
  });

  return columns;
}

export function prepareDictionariesRequestConfig(config) {
  const DictionariesConfig = config.filters.cloneDictionariesConfig();

  DictionariesConfig.merge(new DictionariesConfigDTO(map(config.columns, (column) => column.dictionary)));

  return DictionariesConfig.getRequestConfigList();
}

export function prepareFiltersRequest(filtersConfig, issuer, shouldUnwrapValues = false) {
  const request = {
    org_id: issuer.id
  };

  forEach(filtersConfig.getControlsList(), (control) => {
    let value;
    if (control.key === 'fiscal_years' && control.type === FORM_CONTROL_TYPES.SELECT_RANGE) {
      if (isPlainObject(control.value)) {
        value = prepareRangeArray({
          from: shouldUnwrapValues ? unwrapValue(control.value.from) : control.value.from,
          to: shouldUnwrapValues ? unwrapValue(control.value.to) : control.value.to
        });
      }
    } else if (control.type === FORM_CONTROL_TYPES.CHECKBOX) {
      value = prepareBooleanStringFlag(control.value);
    } else {
      value = shouldUnwrapValues ? unwrapValue(control.value) : control.value;
    }

    request[control.key] = value;
  });

  return request;
}

export function prepareSearchParams(searchCriteria) {
  return mapValues(searchCriteria, (value) => isArray(value) ? value.join(',') : value);
}

export function prepareStatements(statements, dictionaries) {
  let SELECTED_STATEMENTS_COUNT = 0;

  return map(statements, (item) => {
    const statement = prepareValuesMap(item, dictionaries);

    if (SELECTED_STATEMENTS_COUNT < SELECTED_STATEMENTS_LIMIT) {
      statement.$selected = true;
      SELECTED_STATEMENTS_COUNT++;
    } else {
      statements.$selected = false;
    }

    return statement;
  });
}

export function prepareStatementsDictionaries(config, dictionaries) {
  return reduce(config.columns, (result, column) => {
    const key = prepareKey(column.dictionary);
    if (isNotEmptyString(key) && isNotEmptyArray(dictionaries[key])) {
      result[column.key] = dictionaries[key];
    }

    return result;
  }, {});
}

export function isValidSearch(controls) {
  return every(controls, (control) => {
    if (!control.required && control.type !== FORM_CONTROL_TYPES.CHECKBOX) {
      return true;
    }

    switch (control.type) {
      case FORM_CONTROL_TYPES.SELECT_RANGE:
        return isPlainObject(control.value) && (!isUndefined(control.value.from) || !isUndefined(control.value.to));
      case FORM_CONTROL_TYPES.MULTISELECT:
        return isNotEmptyArray(control.value);
      case FORM_CONTROL_TYPES.CHECKBOX:
        return isBoolean(control.value) && (!control.required || control.value);
      default:
        return !isUndefined(control.value);
    }
  });
}

export function getTableHeight(data) {
  const displayRows = data.length > MAX_DISPLAY_ROWS ? MAX_DISPLAY_ROWS : data.length;

  return (displayRows * ROW_HEIGHT) + HEADER_HEIGHT + TABLE_HEIGHT_FIX;
}

// function findStatementInList(statements, statement) {
//   return find(statements, {id: statement.id});
// }

// export function isStatementSelected(selectedStatements, statement) {
//   return !isUndefined(findStatementInList(selectedStatements, statement));
// }

export function isMaximumNumberOfStatements(selectedStatements, statements) {
  if (selectedStatements.length < SELECTED_STATEMENTS_LIMIT) {
    if (selectedStatements.length < statements.length) {
      return false;
    }

    // for (let i = 0; i < statements.length; i++) {
    //   if (!isStatementSelected(selectedStatements, statements[i])) {
    //     return false;
    //   }
    // }
  }

  return true;
}
