import {find, map, isNumber, isPlainObject} from 'lodash';

import { isNotEmptyArray } from 'react-techstack/utils/array';
import {prepareIntValue} from 'modules/common/utils/urlQueryUtils';

// ToDo: extract this to separate place
export const ERROR_CODES = {
  ERROR_LOADING_DEFAULT_ISSUER: 'ERROR_LOADING_DEFAULT_ISSUER',
  ERROR_LOADING_LOB_LIST: 'ERROR_LOADING_LOB_LIST',
  ERROR_LOADING_ISSUERS_LIST: 'ERROR_LOADING_ISSUERS_LIST'
};

export function prepareCurrentLOB(lobList, issuerId, lobId, defaultIssuer) {
  if (!isNotEmptyArray(lobList)) {
    return undefined;
  }

  let currentLOB;
  if (!isNumber(issuerId) && isNumber(lobId)) {
    currentLOB = find(lobList, {id: lobId});
  } else if (isPlainObject(defaultIssuer) && isNumber(defaultIssuer.lobId)) {
    currentLOB = find(lobList, {id: defaultIssuer.lobId});
  }

  return currentLOB;
}

export function prepareCurrentIssuer(currentLOB, defaultIssuer, defaultLOBIssuer) {
  if (isPlainObject(currentLOB) && isPlainObject(defaultIssuer) && currentLOB.id === defaultIssuer.lobId) {
    return defaultIssuer;
  }

  return defaultLOBIssuer;
}

export function prepareIssuerLabel(issuer) {
  return `${issuer.name} - ${issuer.id}`;
}

export function prepareIssuer(issuer) {
  return {
    id: issuer.id,
    lobId: issuer.lobId,
    name: issuer.name,
    label: prepareIssuerLabel(issuer)
  };
}

export function prepareIssuersList(issuers) {
  return map(issuers, prepareIssuer);
}

export function findIssuerById(issuers, issuerId) {
  return find(issuers, {id: issuerId});
}

export function getIssuerIdFromURLQuery(query) {
  return prepareIntValue(query.issuerId);
}

export function getLOBIdFromURLQuery(query) {
  return prepareIntValue(query.lobId);
}

export function isValidIssuer(issuer) {
  return isPlainObject(issuer) && isNumber(issuer.id);
}
