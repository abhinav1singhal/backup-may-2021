export function shouldLoadShortSummary(props, nextProps) {
  return !!nextProps.currentIssuer && (props.currentIssuer !== nextProps.currentIssuer);
}
