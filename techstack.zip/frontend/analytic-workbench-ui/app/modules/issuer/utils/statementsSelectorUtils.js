import {filter, map, isEmpty, isEqual, isBoolean, isPlainObject} from 'lodash';

export const SELECTED_STATEMENTS_LIMIT = 20;

export function shouldLoadStatementsSearchData(props, oldProps) {
  return (
    (!isBoolean(props.shouldLoadStatementsSearchData) || props.shouldLoadStatementsSearchData)  &&
    !isEmpty(props.currentIssuer) && !isEqual(props.currentIssuer, oldProps.currentIssuer)
  );
}

export function shouldUpdateStatementsState(props, oldProps) {
  return !isEqual(props.statements, oldProps.statements);
}

export function prepareSelectedStatements(statements) {
  return filter(statements, {$selected: true});
}

export function deselectAllStatements(statements) {
  return map(statements, (item) => {
    item.$selected = false;
    return item;
  });
}

export function toggleSelectedStatements(statements, statement) {
  let SELECTED_STATEMENTS_COUNT = prepareSelectedStatements(statements).length;

  if (isPlainObject(statement)) {
    return map(statements, (item) => {
      if (item.id === statement.id) {
        item.$selected = !statement.$selected;
      }

      return item;
    });
  } if (SELECTED_STATEMENTS_COUNT === SELECTED_STATEMENTS_LIMIT || SELECTED_STATEMENTS_COUNT === statements.length) {
    return deselectAllStatements(statements);
  }

  return map(statements, (item) => {
    if (!item.$selected && SELECTED_STATEMENTS_COUNT < SELECTED_STATEMENTS_LIMIT) {
      item.$selected = true;
      SELECTED_STATEMENTS_COUNT++;
    }

    return item;
  });
}
