import PropTypes from 'prop-types';

import { getMessage } from 'modules/common/utils/messagesUtils';
import { isNotEmptyString } from 'react-techstack/utils/string';

export const SelectPropTypes = {
  isLoading: PropTypes.bool.isRequired,
  label: PropTypes.string,
  placeholder: PropTypes.string.isRequired,
  loadingMessage: PropTypes.string.isRequired,
  labelMessageKey: PropTypes.string,
  placeholderMessageKey: PropTypes.string,
  loadingMessageKey: PropTypes.string,

  controlSize: PropTypes.string,

  onChange: PropTypes.func.isRequired,

  theme: PropTypes.shape({
    root: PropTypes.string,
    control: PropTypes.string,
    label: PropTypes.string
  }).isRequired
};

export function prepareSelectProps(props) {
  const { options, value, controlSize, isLoading, theme, searching } = props;

  let placeholder;
  if (isLoading) {
    placeholder = isNotEmptyString(props.loadingMessageKey) ? getMessage(props.loadingMessageKey) : props.loadingMessage;
  } else {
    placeholder = isNotEmptyString(props.placeholderMessageKey) ? getMessage(props.placeholderMessageKey) : props.placeholder;
  }

  return {
    options,
    value,
    disabled: isLoading || (options.length === 0 && !searching),
    label: isNotEmptyString(props.labelMessageKey) ? getMessage(props.labelMessageKey) : props.label,
    placeholder,
    clearable: false,
    backspaceRemoves: false,
    bsSize: controlSize,
    parentClassName: 'clearfix',
    wrapperClassName: theme.control,
    labelClassName: theme.label
  };
}
