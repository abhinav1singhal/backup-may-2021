import PropTypes from 'prop-types';
import { dictionaryItemType } from 'modules/common/types/dictionariesTypes';

export const lobType = dictionaryItemType;

export const lobListType = PropTypes.arrayOf(lobType);

export const issuerIdType = PropTypes.number;

export const lobIdType = PropTypes.number;

export const issuerType = PropTypes.shape({
  id: issuerIdType.isRequired,
  lobId: lobIdType.isRequired,
  name: PropTypes.string.isRequired,
  label: PropTypes.string.isRequired
});

export const issuerListType = PropTypes.arrayOf(issuerType);
