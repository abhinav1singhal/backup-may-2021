import { Notification } from 'react-techstack';

import { getMessage } from 'modules/common/utils/messagesUtils';
import { unexpectedErrorNotification } from 'modules/common/utils/notificationUtils';
import { ERROR_CODES } from 'modules/issuer/utils/issuerUtils';
import { LOAD_INITIAL_DATA, LOAD_ISSUERS_LIST } from 'modules/issuer/actions/issuerActions';

// ToDo: improve notifications here
export default {
  [LOAD_INITIAL_DATA.FAILURE]: ({payload}) => {
    switch (payload.$errorCode) {
      case ERROR_CODES.ERROR_LOADING_LOB_LIST:
        return unexpectedErrorNotification('issuerSelector.messages.errorLoadingLOBList.message');
      case ERROR_CODES.ERROR_LOADING_ISSUERS_LIST:
      default:
        return unexpectedErrorNotification();
    }
  },

  [LOAD_INITIAL_DATA.SUCCESS]: ({payload}) => {
    if (payload.$errorCode === ERROR_CODES.ERROR_LOADING_ISSUERS_LIST) {
      return Notification.warning(getMessage('issuerSelector.messages.errorLoadingIssuersList.title'));
    }

    return null;
  },

  [LOAD_ISSUERS_LIST.FAILURE]: ({payload}) => {
    switch (payload.$errorCode) {
      case ERROR_CODES.ERROR_LOADING_ISSUERS_LIST:
      default:
        return unexpectedErrorNotification('issuerSelector.messages.errorLoadingIssuersList.message');
    }
  }
};
