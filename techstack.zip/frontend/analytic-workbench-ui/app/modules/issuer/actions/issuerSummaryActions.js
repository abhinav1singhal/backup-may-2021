import { ActionsNamespaceFactory } from 'react-techstack/redux';

const actionsNamespace = ActionsNamespaceFactory('ISSUER_SUMMARY');

export const LOAD_SHORT_SUMMARY = actionsNamespace.createAsyncAction('LOAD_SHORT');
export const LOAD_FULL_SUMMARY = actionsNamespace.createAsyncAction('LOAD_FULL');

export function loadShortSummary() {
  return (dispatch, getState) => {
    const issuerId = getState().issuer.currentIssuer.id;
    dispatch({ type: LOAD_FULL_SUMMARY.RESET });
    dispatch({
      type: LOAD_SHORT_SUMMARY,
      promise: ({ issuerService }) => issuerService.loadShortSummary(issuerId)
    });
  };
}

export function loadFullSummary() {
  return (dispatch, getState) => {
    const issuerId = getState().issuer.currentIssuer.id;
    dispatch({
      type: LOAD_FULL_SUMMARY,
      promise: ({ issuerService }) => issuerService.loadFullSummary(issuerId)
    });
  };
}
