import { ActionsNamespaceFactory } from 'react-techstack/redux';

const actionsNamespace = ActionsNamespaceFactory('ISSUER_STATEMENTS_SEARCH');

export const LOAD_STATEMENTS_SEARCH_DATA = actionsNamespace.createAsyncAction('LOAD_STATEMENTS_SEARCH_DATA');
export const LOAD_STATEMENTS_LIST = actionsNamespace.createAsyncAction('LOAD_STATEMENTS_LIST');
export const RESET_STATEMENTS_FILTER = actionsNamespace.createAction('RESET_STATEMENTS_FILTER');
export const APPLY_STATEMENTS_SEARCH = actionsNamespace.createAction('APPLY_STATEMENTS_SEARCH');
export const CANCEL_STATEMENTS_SEARCH = actionsNamespace.createAction('CANCEL_STATEMENTS_SEARCH');
export const SAVE_STATEMENTS_SEARCH = actionsNamespace.createAsyncAction('SAVE_STATEMENTS_SEARCH');

export function loadStatementsSearchData(issuer) {
  return {
    type: LOAD_STATEMENTS_SEARCH_DATA,
    promise: ({issuerStatementsService}) => issuerStatementsService.loadStatementsSearchData(issuer)
  };
}

export function loadStatementsList(issuer, filtersValues) {
  // ToDo: validate issuer ?
  return (dispatch, getStorage) => {
    const {filters: previousFilters, dictionaries} = getStorage().issuerStatementsSearch;
    const filters = previousFilters.clone().setControlsValues(filtersValues);

    dispatch({
      type: LOAD_STATEMENTS_LIST,
      meta: {
        filters
      },
      promise: ({issuerStatementsService}) => issuerStatementsService.loadStatementsList(issuer, filters, dictionaries)
    });
  };
}

export function resetStatementsFilter(issuer) {
  return (dispatch, getStorage) => {
    const {filters} = getStorage().issuerStatementsSearch;

    dispatch({
      type: RESET_STATEMENTS_FILTER
    });

    dispatch(loadStatementsList(issuer, filters.getControlsDefaultValues()));
  };
}

export function saveStatementsSearch(issuer, filters) {
  return {
    type: SAVE_STATEMENTS_SEARCH,
    promise: ({issuerStatementsService}) => issuerStatementsService.saveStatementsSearch(issuer, filters)
  };
}

export function applyStatementsSearch(issuer) {
  return (dispatch, getStorage) => {
    const {filters, statements} = getStorage().issuerStatementsSearch;

    dispatch({
      type: APPLY_STATEMENTS_SEARCH,
      meta: {
        issuer
      },
      payload: {
        filters,
        statements
      }
    });
    dispatch(saveStatementsSearch(issuer, filters));
  };
}

export function cancelStatementsSearch(issuer) {
  return {
    type: CANCEL_STATEMENTS_SEARCH,
    meta: {
      issuer
    }
  };
}
