import { ActionsNamespaceFactory } from 'react-techstack/redux';

const actionsNamespace = ActionsNamespaceFactory('ISSUER_SELECTOR');

export const LOAD_INITIAL_DATA = actionsNamespace.createAsyncAction('LOAD_INITIAL_DATA');
export const LOAD_ISSUERS_LIST = actionsNamespace.createAsyncAction('LOAD_ISSUERS_LIST');
export const LOAD_ISSUERS_LIST_PURE = actionsNamespace.createAsyncAction('LOAD_ISSUERS_LIST_PURE');
export const LOAD_ISSUER_SUMMARY = actionsNamespace.createAsyncAction('LOAD_ISSUER_SUMMARY');
export const CHANGE_CURRENT_ISSUER = actionsNamespace.createAction('CHANGE_CURRENT_ISSUER');
export const TOGGLE_SHOW_INACTIVE_ISSUERS = actionsNamespace.createAction('TOGGLE_SHOW_INACTIVE_ISSUERS');
export const LOAD_FULL_SUMMARY = actionsNamespace.createAsyncAction('LOAD_FULL_SUMMARY');
export const LOAD_ALL_ISSUERS = actionsNamespace.createAsyncAction('LOAD_ALL_ISSUERS');

export function loadInitialData(issuerId, lobId, showInactive) {
  return {
    type: LOAD_INITIAL_DATA,
    promise: ({issuerService}) => issuerService.loadInitialData(issuerId, lobId, showInactive)
  };
}

export function loadIssuersList(lob) {
  return {
    type: LOAD_ISSUERS_LIST,
    meta: {lob},
    promise: ({issuerService}) => issuerService.loadIssuersList(lob)
  };
}

export function loadIssuersListPure(lob) {
  return {
    type: LOAD_ISSUERS_LIST_PURE,
    promise: ({issuerService}) => issuerService.loadIssuersList(lob, false, true)
  };
}

export function loadIssuerSummary(id, listLob) {
  return {
    type: LOAD_ISSUER_SUMMARY,
    promise: ({ issuerService }) => issuerService.loadIssuerSummaryAndLobs(id, listLob)
  };
}

export function changeCurrentIssuer(issuer) {
  return {
    type: CHANGE_CURRENT_ISSUER,
    payload: { id: issuer.id, lobId: issuer.lobId },
    promise: ({issuerService}) => issuerService.saveDefaultIssuer(issuer)
  };
}

export function toggleShowInactiveIssuers(showInactive) {
  return (dispatch, getState) => {
    const {currentIssuer, currentLOB} = getState().issuer;
    dispatch(loadInitialData(currentIssuer.id, currentLOB.id, showInactive));
    dispatch({ type: LOAD_FULL_SUMMARY.RESET });
    dispatch({
      type: TOGGLE_SHOW_INACTIVE_ISSUERS,
      payload: showInactive
    });
  };
}

export function loadFullSummary() {
  return (dispatch, getState) => {
    const issuerId = getState().issuer.currentIssuer.id;
    dispatch({
      type: LOAD_FULL_SUMMARY,
      promise: ({ issuerService }) => issuerService.loadFullSummary(issuerId)
    });
  };
}
