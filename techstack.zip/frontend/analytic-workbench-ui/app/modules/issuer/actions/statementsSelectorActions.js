import {ActionsNamespaceFactory} from 'react-techstack/redux';

const actionsNamespace = ActionsNamespaceFactory('ISSUER_STATEMENTS_SELECTOR');

export const TOGGLE_SELECTED_STATEMENTS = actionsNamespace.createAction('TOGGLE_SELECTED_STATEMENTS');
export const DESELECT_ALL_STATEMENTS = actionsNamespace.createAction('DESELECT_ALL_STATEMENTS');

export function toggleSelectedStatements(statement) {
  return {
    type: TOGGLE_SELECTED_STATEMENTS,
    payload: statement
  };
}

export function deselectAllStatements() {
  return {
    type: DESELECT_ALL_STATEMENTS
  };
}
