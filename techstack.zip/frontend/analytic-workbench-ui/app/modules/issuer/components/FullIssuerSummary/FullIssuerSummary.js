import PropTypes from 'prop-types';
import React from 'react';
import { LoadingContainer, Alert } from 'react-techstack';
import { get } from 'lodash';
import {ModalDialog} from 'modules/shared/components';
import KeyValueList from 'modules/shared/components/KeyValueList';
import { issuerType } from 'modules/issuer/types';
import { getMessage } from 'modules/common/utils/messagesUtils';
import { isNotEmptyArray } from 'react-techstack/utils/array';

import theme from './FullIssuerSummary.css';

const itemTheme = {
  title: theme.itemHeader,
  label: theme.itemLabel,
  content: theme.itemContent,
  pair: theme.pair
};

class FullIssuerSummary extends React.Component {
  static propTypes = {
    opened: PropTypes.bool,
    onClose: PropTypes.func.isRequired,
    currentIssuer: issuerType,

    summary: PropTypes.arrayOf(PropTypes.object).isRequired,
    isNotStarted: PropTypes.bool,
    isFailed: PropTypes.bool,
    isLoading: PropTypes.bool,
    loadFullSummary: PropTypes.func.isRequired
  };

  UNSAFE_componentWillReceiveProps(props) {
    if (props.opened && props.isNotStarted) {
      props.loadFullSummary();
    }
  }

  renderItem = (item, index) => {
    return (
      <div key={`item-${index}`}>
        {index > 0 ? <hr className={theme.hr}/> : null}
        <KeyValueList {...item} theme={itemTheme} />
      </div>
    );
  }

  renderErrorMessage() {
    return <Alert bsStyle="danger" className={theme.error}>{getMessage('issuerSummary.full.error')}</Alert>;
  }

  render() {
    const ModalDialogProps = {
      show: this.props.opened,
      onHide: this.props.onClose,
      header: getMessage('issuerSummary.full.title', get(this.props, 'currentIssuer.name')),
      theme: {
        root: theme.modalDialog,
        modal: theme.modal
      }
    };

    return (
      <ModalDialog {...ModalDialogProps}>
        <LoadingContainer isLoading={this.props.isLoading}>
          {this.props.isFailed && this.renderErrorMessage()}
          {isNotEmptyArray(this.props.summary) && this.props.summary.map(this.renderItem)}
        </LoadingContainer>
      </ModalDialog>
    );
  }
}

export default FullIssuerSummary;
