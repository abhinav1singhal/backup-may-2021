import { connect } from 'react-redux';
import { asyncStatusUtils } from 'react-techstack/utils';
import { loadFullSummary } from 'modules/issuer/actions/issuerSummaryActions';
const { isFailed, isPending, isNotStarted } = asyncStatusUtils;
import FullIssuerSummary from './FullIssuerSummary';

function mapStateToProps(state) {
  return {
    currentIssuer: state.issuer.currentIssuer,
    summary: state.issuerSummary.fullSummary,
    isNotStarted: isNotStarted(state.requests.loadFullSummary.status),
    isFailed: isFailed(state.requests.loadFullSummary.status),
    isLoading: isPending(state.requests.loadFullSummary.status)
  };
}

const mapDispatchToProps = {
  loadFullSummary
};

export default connect(mapStateToProps, mapDispatchToProps)(FullIssuerSummary);
