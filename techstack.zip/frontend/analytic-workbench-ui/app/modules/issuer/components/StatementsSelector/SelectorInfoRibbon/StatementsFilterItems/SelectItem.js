import PropTypes from 'prop-types';
import {isPlainObject} from 'lodash';

import BaseItem from './BaseItem';

class SelectItem extends BaseItem {
  static propTypes = {
    ...BaseItem.propTypes,

    value: PropTypes.object.isRequired
  };

  prepareValue() {
    return super.renderValue(
      isPlainObject(this.props.value) ? this.props.value.name : ''
    );
  }
}

export default SelectItem;
