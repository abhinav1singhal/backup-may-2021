import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { asyncStatusTypes, formBuilderTypes } from 'react-techstack/utils';

import FilterForm from './FiltersForm';
import StatementsTable from './StatementsTable';
import {shouldLoadStatementsSearchData} from 'modules/issuer/utils/statementsSelectorUtils';
import {issuerType} from 'modules/issuer/types/issuerTypes';

import theme from './StatementsSelector.css';

const { asyncRequestType } = asyncStatusTypes;
const { formConfigDTOType } = formBuilderTypes;

class StatementsSelector extends React.Component {
  static propTypes = {
    currentIssuer: issuerType.isRequired,
    config: formConfigDTOType.isRequired,
    columns: PropTypes.array.isRequired,
    statements: PropTypes.array.isRequired,

    shouldLoadStatementsSearchData: PropTypes.bool.isRequired,
    loadStatementsSearchData: PropTypes.func.isRequired,
    loadStatementsList: PropTypes.func.isRequired,
    resetStatementsFilter: PropTypes.func.isRequired,
    toggleSelectedStatements: PropTypes.func.isRequired,
    deselectAllStatements: PropTypes.func.isRequired,

    statementsSearchDataRequest: asyncRequestType.isRequired,
    statementsListRequest: asyncRequestType.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string,
      filterForm: PropTypes.string,
      filterFormFilters: PropTypes.string,
      filterControlGroup: PropTypes.string,
      filterControlLabel: PropTypes.string,
      filterFormActions: PropTypes.string,
      filterFormResetButton: PropTypes.string,
      filterFormApplyButton: PropTypes.string,
      statementsTable: PropTypes.string
    }).isRequired
  };

  UNSAFE_componentWillReceiveProps(props) {
    if (shouldLoadStatementsSearchData(props, this.props)) {
      props.loadStatementsSearchData(props.currentIssuer);
    }
  }

  render() {
    const {
      config, columns, statements, currentIssuer,
      loadStatementsList, resetStatementsFilter,
      statementsListRequest,
      toggleSelectedStatements, deselectAllStatements,
      theme: customTheme
    } = this.props;

    const FiltersFormProps = {
      controls: config.getControlsList(),
      options: config.getDictionaries(),
      data: config.getControlsValues(),
      onSubmit: (filtersValues) => loadStatementsList(currentIssuer, filtersValues),
      onReset: () => resetStatementsFilter(currentIssuer),
      // ref: (ref) => {
      //   this.filtersForm = ref;
      // },
      theme: {
        root: customTheme.filterForm,
        filters: customTheme.filterFormFilters,
        controlGroup: customTheme.filterControlGroup,
        controlLabel: customTheme.filterControlLabel,
        actions: customTheme.filterFormActions,
        resetButton: customTheme.filterFormResetButton,
        applyButton: customTheme.filterFormApplyButton
      }
    };

    const StatementsTableProps = {
      columns,
      statements,
      statementsListRequest,
      toggleSelectedStatements,
      deselectAllStatements,
      theme: {
        root: classNames(theme.table, customTheme.statementsTable)
      }
    };

    return (
      <div className={classNames(theme.root, customTheme.root)}>
        <FilterForm {...FiltersFormProps} />
        <StatementsTable {...StatementsTableProps} />
      </div>
    );
  }
}

StatementsSelector.defaultProps = {
  shouldLoadStatementsSearchData: true,

  theme: {}
};

export default StatementsSelector;
