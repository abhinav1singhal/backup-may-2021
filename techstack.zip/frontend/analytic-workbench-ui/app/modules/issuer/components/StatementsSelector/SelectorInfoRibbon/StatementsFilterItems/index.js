import isUndefined from 'lodash/isUndefined';
import { FORM_CONTROL_TYPES } from 'react-techstack/FormBuilder';

import BaseItem from './BaseItem';
import SelectItem from './SelectItem';
import MultiSelectItem from './MultiSelectItem';
import CheckboxItem from './CheckboxItem';
import SelectRangeItem from './SelectRangeItem';

export const FilterItemComponents = {
  DefaultItem: BaseItem,
  [FORM_CONTROL_TYPES.SELECT]: SelectItem,
  [FORM_CONTROL_TYPES.MULTISELECT]: MultiSelectItem,
  [FORM_CONTROL_TYPES.CHECKBOX]: CheckboxItem,
  [FORM_CONTROL_TYPES.SELECT_RANGE]: SelectRangeItem
};

export function getFilterItemComponent(type) {
  if (isUndefined(FilterItemComponents[type])) {
    return FilterItemComponents.DefaultItem;
  }

  return FilterItemComponents[type];
}

