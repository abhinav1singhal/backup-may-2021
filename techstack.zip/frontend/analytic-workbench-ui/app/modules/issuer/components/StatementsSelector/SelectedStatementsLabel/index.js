export default from './SelectedStatementsLabel';
