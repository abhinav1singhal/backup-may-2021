import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import {Button} from 'react-techstack';

import {ModalDialog, MODAL_DIALOG_FULL_WIDTH_MODAL_STYLE} from 'modules/shared/components';
import StatementsSelector from '../StatementsSelectorContainer';

import theme from './SelectorModal.css';

class SelectorModal extends React.Component {
  static propTypes = {
    show: PropTypes.bool.isRequired,

    onHide: PropTypes.func.isRequired,
    onApply: PropTypes.func.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string,
      modal: PropTypes.string,
      content: PropTypes.string,
      closeIcon: PropTypes.string,
      filterForm: PropTypes.string,
      filterFormFilters: PropTypes.string,
      filterControlGroup: PropTypes.string,
      filterControlLabel: PropTypes.string,
      filterFormActions: PropTypes.string,
      filterFormResetButton: PropTypes.string,
      filterFormApplyButton: PropTypes.string,
      statementsTable: PropTypes.string
    }).isRequired
  };

  renderModalFooter() {
    const {onHide, onApply} = this.props;

    const cancelButtonProps = {
      onClick: onHide,
      bsStyle: 'link',
      className: theme.cancelButton
    };

    const applyButtonProps = {
      onClick: onApply,
      bsStyle: 'primary',
      className: theme.applyButton
    };

    return (
      <div>
        <Button {...cancelButtonProps}>Cancel</Button>
        <Button {...applyButtonProps}>Show Results</Button>
      </div>
    );
  }

  renderStatementsSelector() {
    const customTheme = this.props.theme;

    const StatementsSelectorTheme = {
      root: theme.selector,
      filterForm: customTheme.filterForm,
      filterFormFilters: customTheme.filterFormFilters,
      filterControlGroup: customTheme.filterControlGroup,
      filterControlLabel: customTheme.filterControlLabel,
      filterFormActions: customTheme.filterFormActions,
      filterFormResetButton: customTheme.filterFormResetButton,
      filterFormApplyButton: customTheme.filterFormApplyButton,
      statementsTable: theme.selectorTable
    };

    return <StatementsSelector theme={StatementsSelectorTheme} shouldLoadStatementsSearchData={false} />;
  }

  render() {
    const {show, onHide, theme: customTheme} = this.props;

    const ModalDialogProps = {
      show,
      onHide,
      footer: this.renderModalFooter(),
      theme: {
        root: classNames(customTheme.root, MODAL_DIALOG_FULL_WIDTH_MODAL_STYLE),
        modal: customTheme.modal,
        content: classNames(theme.content, customTheme.content),
        closeIcon: customTheme.closeIcon
      }
    };

    return (
      <ModalDialog {...ModalDialogProps}>
        {this.renderStatementsSelector()}
      </ModalDialog>
    );
  }
}

SelectorModal.defaultProps = {
  theme: {}
};

export default SelectorModal;
