import PropTypes from 'prop-types';
import React from 'react';
import {isNotEmptyArray} from 'modules/common/utils/arrayUtils';

import BaseItem from './BaseItem';

class MultiSelectItem extends BaseItem {
  static propTypes = {
    ...BaseItem.propTypes,

    value: PropTypes.arrayOf(PropTypes.object).isRequired,
    dictionary: PropTypes.object.isRequired
  };

  renderValueWithHint(label) {
    return super.renderValueWithHint(label, (
      <div>
        {this.props.value.map((item) => item.name).join(', ')}
      </div>
    ));
  }

  prepareValue() {
    const {value, dictionary} = this.props;

    if (!isNotEmptyArray(value) || !isNotEmptyArray(dictionary.list)) {
      return this.renderValue('None');
    } else if (value.length === dictionary.list.length) {
      return this.renderValueWithHint('All selected');
    } else if (value.length > 1) {
      return this.renderValueWithHint(`${value.length} selected`);
    }

    return this.renderValue(value[0].name);
  }
}

export default MultiSelectItem;
