import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { Button } from 'react-techstack';
import FormBuilder, { FormComponent, FORM_CONTROL_TYPES } from 'react-techstack/FormBuilder';
import { find, some } from 'lodash';

import {isNotEmptyString} from 'modules/common/utils/stringUtils';
import { getMessage } from 'modules/common/utils/messagesUtils';

import theme from './FiltersForm.css';

class FiltersForm extends FormComponent {
  static propTypes = {
    ...FormComponent.propTypes,

    onReset: PropTypes.func.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string,
      filters: PropTypes.string,
      controlGroup: PropTypes.string,
      controlLabel: PropTypes.string,
      actions: PropTypes.string,
      resetButton: PropTypes.string,
      applyButton: PropTypes.string
    }).isRequired
  };

  prepareControlLabel(control) {
    if (isNotEmptyString(control.label)) {
      return control.type === FORM_CONTROL_TYPES.CHECKBOX ? control.label : `${control.label}:`;
    }

    return undefined;
  }

  componentDidUpdate() {
    const { controls } = this.props;
    const { idv_periods: periods } = this.state.data;
    const latestYTD = find(controls, {key: 'interim_only'});
    if (periods && latestYTD && latestYTD.disabled) {
      if (latestYTD.disabled) {
        this.setState({data: {
          ...this.state.data,
          interim_only: false
        }});
      }
    }
  }

  prepareControls(controls) {
    const { idv_periods: periods } = this.state.data;
    const latestYTD = find(controls, {key: 'interim_only'});
    if (periods && latestYTD) {
      latestYTD.disabled = !some(periods, ['id', 1]);
    }
    return controls;
  }

  render() {
    const {controls: initialControls, onReset, theme: customTheme} = this.props;
    const controls = this.prepareControls(initialControls);

    const FormBuilderProps = {
      ...this.prepareFormConstructorProps('StatementsFilters'),
      controls,
      customFieldLabel: this.prepareControlLabel,
      theme: {
        root: classNames(theme.filters, customTheme.filters),
        controlGroup: classNames(theme.controlGroup, customTheme.controlGroup),
        controlLabel: classNames(theme.controlLabel, customTheme.controlLabel)
      }
    };

    const resetButtonProps = {
      onClick: () => {
        this.reset();
        onReset();
      },
      bsStyle: 'link',
      className: classNames(theme.resetButton, customTheme.resetButton)
    };

    const applyButtonProps = {
      onClick: this.onSubmit.bind(this),
      bsStyle: 'primary',
      className: classNames(theme.applyButton, customTheme.applyButton)
    };

    return (
      <div className={classNames(theme.root, customTheme.root)}>
        <FormBuilder {...FormBuilderProps} />
        <div className={classNames(theme.actions, customTheme.actions)}>
          <Button {...resetButtonProps}>{getMessage('issuer.statementsSelector.resetFiltersButton')}</Button>
          <Button {...applyButtonProps}>{getMessage('issuer.statementsSelector.applyFiltersButton')}</Button>
        </div>
      </div>
    );
  }
}

FiltersForm.defaultProps = {
  ...FormComponent.defaultProps,

  theme: {}
};

export default FiltersForm;
