import { connect } from 'react-redux';

import {
  loadStatementsSearchData, loadStatementsList, resetStatementsFilter
} from 'modules/issuer/actions/statementsSearchActions';
import {
  toggleSelectedStatements, deselectAllStatements
} from 'modules/issuer/actions/statementsSelectorActions';

import StatementsSelector from './StatementsSelector';

function mapStateToProps(state) {
  return {
    currentIssuer: state.issuer.currentIssuer,
    config: state.issuerStatementsSearch.filters,
    columns: state.issuerStatementsSearch.columns,
    statements: state.issuerStatementsSearch.statements,
    statementsSearchDataRequest: state.requests.issuerStatementsSearchData,
    statementsListRequest: state.requests.issuerStatementsSearchList
  };
}

const mapDispatchToProps = {
  loadStatementsSearchData,
  loadStatementsList,
  resetStatementsFilter,
  toggleSelectedStatements,
  deselectAllStatements
};

export default connect(mapStateToProps, mapDispatchToProps)(StatementsSelector);
