import PropTypes from 'prop-types';
import React from 'react';
import { Tooltip, OverlayTrigger } from 'react-techstack';

import {isNotEmptyString} from 'modules/common/utils/stringUtils';

class BaseItem extends React.Component {
  static propTypes = {
    label: PropTypes.string.isRequired,
    value: PropTypes.string.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string,
      label: PropTypes.string,
      value: PropTypes.value,
      hint: PropTypes.hint
    }).isRequired
  };

  prepareValue() {
    return this.renderValue(this.props.value);
  }

  renderValueWithHint(value, hint) {
    // const tooltipId = `DetailsTooltip_${this.props.title}_${index}`;

    const tooltip = <Tooltip className={this.props.theme.hint} id={this.props.label}>{hint}</Tooltip>;

    return (
      <OverlayTrigger placement="bottom" overlay={tooltip}>
        {this.renderValue(value)}
      </OverlayTrigger>
    );
  }

  renderValue(value) {
    return (
      <div className={this.props.theme.value}>
        {isNotEmptyString(value) ? value : ''}
      </div>
    );
  }

  render() {
    const {label, theme} = this.props;

    return (
      <div className={theme.root}>
        <div className={theme.label}>{label}</div>
        {this.prepareValue()}
      </div>
    );
  }
}

BaseItem.defaultProps = {
  theme: {}
};

export default BaseItem;
