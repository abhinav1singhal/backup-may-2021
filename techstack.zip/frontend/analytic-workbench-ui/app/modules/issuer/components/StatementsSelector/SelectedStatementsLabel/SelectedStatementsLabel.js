import PropTypes from 'prop-types';
import React from 'react';

import { getMessage } from 'modules/common/utils/messagesUtils';

class SelectedStatementsLabel extends React.Component {
  static propTypes = {
    totalCount: PropTypes.number.isRequired,
    selectedCount: PropTypes.number.isRequired,

    noneSelectedMessageKey: PropTypes.string.isRequired,
    someSelectedMessageKey: PropTypes.string.isRequired,
    allSelectedMessageKey: PropTypes.string.isRequired,

    className: PropTypes.string
  };

  getMessage() {
    const {
      totalCount, selectedCount, noneSelectedMessageKey, someSelectedMessageKey, allSelectedMessageKey
    } = this.props;

    if (selectedCount === 0) {
      return getMessage(noneSelectedMessageKey);
    }

    if (selectedCount < totalCount) {
      return getMessage(someSelectedMessageKey, selectedCount, totalCount);
    }

    return getMessage(allSelectedMessageKey, selectedCount);
  }

  render() {
    return (
      <span className={this.props.className}>
        {this.getMessage()}
      </span>
    );
  }
}

SelectedStatementsLabel.defaultProps = {
  noneSelectedMessageKey: 'issuer.statementsSelector.selectedStatements.none',
  someSelectedMessageKey: 'issuer.statementsSelector.selectedStatements.some',
  allSelectedMessageKey: 'issuer.statementsSelector.selectedStatements.all'
};

export default SelectedStatementsLabel;
