import PropTypes from 'prop-types';
import {isPlainObject} from 'lodash';

import BaseItem from './BaseItem';
import {isNotEmptyString} from 'modules/common/utils/stringUtils';

class SelectRangeItem extends BaseItem {
  static propTypes = {
    ...BaseItem.propTypes,

    value: PropTypes.shape({
      from: PropTypes.any,
      to: PropTypes.any
    }).isRequired
  };

  prepareValue() {
    const value = this.props.value;

    const from = isPlainObject(value.from) && value.from.name && `${value.from.name}`;
    const to = isPlainObject(value.to) && value.to.name && `${value.to.name}`;

    let result;
    if (isNotEmptyString(from) && isNotEmptyString(to)) {
      result = from === to ? from : `${from} - ${to}`;
    } else if (isNotEmptyString(from) && !isNotEmptyString(to)) {
      result = from;
    } else if (isNotEmptyString(to) && !isNotEmptyString(from)) {
      result = to;
    }

    return super.renderValue(result);
  }
}

export default SelectRangeItem;
