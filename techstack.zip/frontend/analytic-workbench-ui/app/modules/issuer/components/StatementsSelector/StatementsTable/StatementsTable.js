import PropTypes from 'prop-types';
import React from 'react';
import {isEmpty, isPlainObject} from 'lodash';
import classNames from 'classnames';
import { Checkbox, Button, DataTableBare as DataTable, DataTableCell } from 'react-techstack';
// import { Checkbox, Button, DataTableCell } from 'react-techstack';
// import { asyncStatusUtils, asyncStatusTypes } from 'react-techstack/utils';
import { asyncStatusTypes } from 'react-techstack/utils';

import {AutoSizer} from 'modules/shared/components';
// import {DataTable} from 'modules/shared/components';
import {LoadingContainer} from 'modules/common/components';
import SelectedStatementsLabel from '../SelectedStatementsLabel';
import {getMessage} from 'modules/common/utils/messagesUtils';
import {
  HEADER_HEIGHT, ROW_HEIGHT, isMaximumNumberOfStatements
} from 'modules/issuer/utils/statementsSearchUtils';
import {shouldUpdateStatementsState, prepareSelectedStatements} from 'modules/issuer/utils/statementsSelectorUtils';

import theme from './StatementsTable.css';
// const { combineStatuses, isPending, isNotStarted } = asyncStatusUtils;

class StatementsTable extends React.Component {
  static propTypes = {
    columns: PropTypes.array.isRequired,
    statements: PropTypes.array.isRequired,

    statementsListRequest: asyncStatusTypes.asyncRequestType.isRequired,

    toggleSelectedStatements: PropTypes.func.isRequired,
    deselectAllStatements: PropTypes.func.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string
    }).isRequired
  };

  constructor(props) {
    super(props);

    const selectedStatements = prepareSelectedStatements(props.statements);

    this.state = {
      data: props.statements,
      selectedStatements,
      showSelectedOnly: false,
      isAllSelected: isMaximumNumberOfStatements(selectedStatements, props.statements)
    };

    // ToDo: we need global solution for this
    this.headerCell = this.headerCell.bind(this);
    this.cell = this.cell.bind(this);
  }

  UNSAFE_componentWillReceiveProps(props) {
    const newState = {};

    if (shouldUpdateStatementsState(props, this.props)) {
      newState.selectedStatements = prepareSelectedStatements(props.statements);
      newState.isAllSelected = isMaximumNumberOfStatements(newState.selectedStatements, props.statements);
      newState.data = this.state.showSelectedOnly ? newState.selectedStatements : props.statements;
    }

    if (!isEmpty(newState)) {
      this.setState(newState);
    }
  }

  toggleShowSelectedOnly() {
    const showSelectedOnly = !this.state.showSelectedOnly;
    this.setState({
      data: showSelectedOnly ? this.state.selectedStatements : this.props.statements,
      showSelectedOnly
    });
  }

  headerCell(cellProps, label) {
    const {toggleSelectedStatements} = this.props;
    const {data, showSelectedOnly, isAllSelected} = this.state;

    let content;
    switch (cellProps.columnKey) {
      case '$selected':
        const CheckboxProps = {
          checked: showSelectedOnly ? data.length > 0 : isAllSelected,
          disabled: data.length === 0 || showSelectedOnly,
          className: theme.selectCheckbox
        };

        cellProps.onClick = () => {
          toggleSelectedStatements();
        };

        content = <Checkbox {...CheckboxProps} />;
        break;
      default:
        content = label;
    }

    return content || '';
  }

  cell(data, key, statement, cellProps) {
    const {toggleSelectedStatements} = this.props;
    const {showSelectedOnly, isAllSelected} = this.state;

    let content;
    switch (key) {
      case '$selected':
        const CheckboxProps = {
          checked: showSelectedOnly || statement.$selected,
          disabled: !showSelectedOnly && !statement.$selected && isAllSelected,
          className: theme.selectCheckbox
        };

        content = <Checkbox {...CheckboxProps} />;
        break;
      default:
        content = isPlainObject(data) ? data.name : data;
    }

    cellProps.onClick = () => {
      toggleSelectedStatements(statement);
    };

    return <DataTableCell {...cellProps}>{content || ''}</DataTableCell>;
  }

  renderHeader() {
    const {statements, deselectAllStatements} = this.props;
    const {selectedStatements, showSelectedOnly} = this.state;

    const SelectedStatementsLabelProps = {
      totalCount: statements.length,
      selectedCount: selectedStatements.length,
      className: theme.selectedStatementsLabel
    };

    const CheckboxProps = {
      onClick: () => this.toggleShowSelectedOnly(),
      checked: showSelectedOnly,
      disabled: !showSelectedOnly && selectedStatements.length === 0,
      label: getMessage('issuer.statementsSelector.table.showSelectedOnlyButton'),
      className: theme.showSelectedOnlyButton
    };

    const ButtonProps = {
      onClick: () => deselectAllStatements(),
      disabled: selectedStatements.length === 0,
      className: theme.deselectAllButton,
      bsStyle: 'link'
    };

    return (
      <div className={classNames(theme.header)}>
        <SelectedStatementsLabel {...SelectedStatementsLabelProps} />
        <Checkbox {...CheckboxProps} />
        <Button {...ButtonProps}>{getMessage('issuer.statementsSelector.table.deselectAllButton')}</Button>
      </div>
    );
  }

  renderTable() {
    const data = this.state.data;

    const DataTableProps = {
      columns: this.props.columns,
      data,
      headerCell: this.headerCell,
      cell: this.cell,
      headerHeight: HEADER_HEIGHT,
      rowHeight: ROW_HEIGHT,
      theme: {
        root: theme.table
      }
    };

    // return <DataTable {...DataTableProps} />;

    return (
      <AutoSizer height="auto" width="auto" className={theme.table}>
        <DataTable {...DataTableProps} />
      </AutoSizer>
    );
  }

  render() {
    const {statementsListRequest, theme: customTheme} = this.props;

    const LoadingContainerProps = {
      isPendingRequest: statementsListRequest,
      message: 'issuer.statementsSelector.table.loadingStatements',
      theme: {
        root: theme.loadingSpinner,
        wrapper: classNames(theme.root, customTheme.root)
      }
    };

    return (
      <LoadingContainer {...LoadingContainerProps}>
        <div className={classNames(theme.root, customTheme.root)}>
          {this.renderHeader()}
          {this.renderTable()}
        </div>
      </LoadingContainer>
    );
  }
}

StatementsTable.defaultProps = {
  theme: {}
};

export default StatementsTable;
