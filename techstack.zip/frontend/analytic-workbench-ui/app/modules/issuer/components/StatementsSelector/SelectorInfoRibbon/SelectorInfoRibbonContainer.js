import { connect } from 'react-redux';

import {
  loadStatementsSearchData, applyStatementsSearch, cancelStatementsSearch
} from 'modules/issuer/actions/statementsSearchActions';

import SelectorInfoRibbon from './SelectorInfoRibbon';

function mapStateToProps(state) {
  return {
    currentIssuer: state.issuer.currentIssuer,
    config: state.issuerStatementsSearch.currentFilters,
    statements: state.issuerStatementsSearch.currentStatements
  };
}

const mapDispatchToProps = {
  loadStatementsSearchData,
  applyStatementsSearch,
  cancelStatementsSearch
};

export default connect(mapStateToProps, mapDispatchToProps)(SelectorInfoRibbon);
