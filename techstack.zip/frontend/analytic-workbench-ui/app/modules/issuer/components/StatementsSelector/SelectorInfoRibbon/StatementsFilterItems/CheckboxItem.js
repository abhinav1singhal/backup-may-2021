import PropTypes from 'prop-types';

import BaseItem from './BaseItem';

class CheckboxItem extends BaseItem {
  static propTypes = {
    ...BaseItem.propTypes,

    value: PropTypes.bool.isRequired
  };

  prepareValue() {
    return super.renderValue(this.props.value ? 'Yes' : 'No');
  }
}

export default CheckboxItem;
