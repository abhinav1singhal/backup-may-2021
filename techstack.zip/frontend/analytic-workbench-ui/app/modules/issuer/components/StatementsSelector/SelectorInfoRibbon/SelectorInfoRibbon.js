import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import InlineSVG from 'svg-inline-react';

import {getFilterItemComponent} from './StatementsFilterItems';
import SelectedStatementsLabel from '../SelectedStatementsLabel';
import SelectorModal from '../SelectorModal';
import {
  shouldLoadStatementsSearchData, shouldUpdateStatementsState, prepareSelectedStatements
} from 'modules/issuer/utils/statementsSelectorUtils';

import theme from './SelectorInfoRibbon.css';
import {issuerType} from 'modules/issuer/types/issuerTypes';
const openIcon = require('!!svg-inline-loader!./open.svg');

class SelectorInfoRibbon extends React.Component {
  static propTypes = {
    currentIssuer: issuerType,
    config: PropTypes.object, // ToDo: improve this
    statements: PropTypes.array.isRequired,

    loadStatementsSearchData: PropTypes.func.isRequired,
    applyStatementsSearch: PropTypes.func.isRequired,
    cancelStatementsSearch: PropTypes.func.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string
    }).isRequired
  };

  constructor(props) {
    super(props);

    this.state = {
      showModal: false,
      selectedStatements: prepareSelectedStatements(props.statements)
    };
  }

  UNSAFE_componentWillReceiveProps(props) {
    if (shouldLoadStatementsSearchData(props, this.props)) {
      props.loadStatementsSearchData(props.currentIssuer);
    }

    if (shouldUpdateStatementsState(props, this.props)) {
      this.setState({
        selectedStatements: prepareSelectedStatements(props.statements)
      });
    }
  }

  showModal(showModal) {
    this.setState({showModal});
  }

  renderFiltersList() {
    const controls = this.props.config.getControlsList();

    return controls.map((control) => {
      const FilterItemComponent = getFilterItemComponent(control.type);
      const filterItemProps = {
        label: control.label,
        value: control.value,
        dictionary: control.dictionary,
        theme: {
          root: theme.filterItem,
          label: theme.label,
          value: theme.value
        },
        key: `StatementsFilterItem-${control.key}`
      };

      return <FilterItemComponent {...filterItemProps} />;
    });
  }

  renderSelectedStatementsInfo() {
    const SelectedStatementsLabelProps = {
      totalCount: this.props.statements.length,
      selectedCount: this.state.selectedStatements.length,
      noneSelectedMessageKey: 'issuer.statementsSelector.selected.none',
      someSelectedMessageKey: 'issuer.statementsSelector.selected.some',
      allSelectedMessageKey: 'issuer.statementsSelector.selected.all',
      className: theme.value
    };

    return (
      <div className={theme.selectedStatements}>
        <div className={theme.label}>Statements</div>
        <SelectedStatementsLabel {...SelectedStatementsLabelProps} />
      </div>
    );
  }


  render() {
    const {currentIssuer, applyStatementsSearch, cancelStatementsSearch, theme: customTheme} = this.props;

    const rootClassName = classNames(theme.root, customTheme.root, {
      [theme.showModal]: this.state.showModal
    });

    const SelectorModalProps = {
      show: this.state.showModal,
      onHide: () => {
        cancelStatementsSearch(currentIssuer);
        this.showModal(false);
      },
      onApply: () => {
        applyStatementsSearch(currentIssuer);
        this.showModal(false);
      },
      theme: {
        root: theme.modalDialog,
        modal: theme.modalDialogModal,
        content: theme.modalDialogContent,
        closeIcon: theme.modalCloseIcon,
        filterForm: theme.filterForm,
        filterFormFilters: theme.filterFormFilters,
        filterControlGroup: theme.controlGroup,
        filterControlLabel: theme.controlLabel,
        filterFormActions: theme.filterFormActions,
        filterFormResetButton: theme.filterFormResetButton,
        filterFormApplyButton: theme.filterFormApplyButton,
        statementsTable: theme.statementsTable
      }
    };

    return (
      <div className={rootClassName}>
        <div className={theme.ribbon} onClick={() => this.showModal(true)}>
          {this.renderFiltersList()}
          {this.renderSelectedStatementsInfo()}
          <InlineSVG src={openIcon} className={theme.openIcon} />
        </div>
        <SelectorModal {...SelectorModalProps} />
      </div>
    );
  }
}

export default SelectorInfoRibbon;
