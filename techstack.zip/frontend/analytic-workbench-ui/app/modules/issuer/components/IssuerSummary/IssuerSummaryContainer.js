import { connect } from 'react-redux';
import { asyncStatusUtils } from 'react-techstack/utils';
import { loadShortSummary } from 'modules/issuer/actions/issuerSummaryActions';
const { isSuccessful } = asyncStatusUtils;
import IssuerSummary from './IssuerSummary';

function mapStateToProps(state) {
  return {
    summary: state.issuerSummary.shortSummary,
    currentIssuer: state.issuer.currentIssuer,
    isLoaded: isSuccessful(state.requests.loadShortSummary.status)
  };
}

const mapDispatchToProps = {
  loadShortSummary
};

export default connect(mapStateToProps, mapDispatchToProps)(IssuerSummary);
