import PropTypes from 'prop-types';
import React from 'react';
import isPlainObject from 'lodash/isPlainObject';
import classNames from 'classnames';
import CSSTransitionGroup from 'react-transition-group/CSSTransitionGroup';
import { Tooltip, OverlayTrigger } from 'react-techstack';
import { Icon } from 'modules/shared/components';
import { shouldLoadShortSummary } from 'modules/issuer/utils/summaryUtils';
import { issuerType } from 'modules/issuer/types';
import { getMessage } from 'modules/common/utils/messagesUtils';
import FullIssuerSummary from '../FullIssuerSummary';

import theme from './IssuerSummary.css';

class IssuerSummary extends React.Component {
  static propTypes = {
    summary: PropTypes.arrayOf(PropTypes.shape({
      label: PropTypes.string.isRequired,
      value: PropTypes.any,
      extra: PropTypes.shape({
        hint: PropTypes.string,
        link: PropTypes.string,
        ratingForLeadRatedEntity: PropTypes.bool
      })
    })).isRequired,
    loadShortSummary: PropTypes.func.isRequired,
    isLoaded: PropTypes.bool,

    currentIssuer: issuerType,
    theme: PropTypes.object.isRequired
  };

  constructor(props) {
    super(props);

    this.state = {
      opened: false
    };
  }

  UNSAFE_componentWillMount() {
    if (this.props.currentIssuer) {
      this.props.loadShortSummary();
    }
  }

  UNSAFE_componentWillReceiveProps(props) {
    if (shouldLoadShortSummary(this.props, props)) {
      this.props.loadShortSummary();
    }
  }

  openModal = () => {
    this.setState({ opened: true });
  };

  closeModal = () => {
    this.setState({ opened: false });
  };

  renderLeadBankLabel(extra) {
    return (isPlainObject(extra) && extra.ratingForLeadRatedEntity) ? ' Lead/Rated Entity' : '';
  }

  renderItem = ({ label, value, extra }, index) => {
    if (isPlainObject(extra) && extra.hint) {
      const tooltipId = `ShortSummary_${index}`;

      const tooltip = (
        <Tooltip id={tooltipId}>
          {extra.hint}
        </Tooltip>
      );

      return (
        <div className={classNames(theme.item, theme.hinted)} key={`item-${index}`}>
          <div className={theme.label}>{label}:</div>
          <OverlayTrigger placement="bottom" overlay={tooltip}>
            <div className={theme.innerValue}>
              {value}{this.renderLeadBankLabel(extra)}
            </div>
          </OverlayTrigger>
        </div>
      );
    }

    return (
      <div key={`item-${index}`} className={theme.item}>
        {label}: {value}{this.renderLeadBankLabel(extra)}
      </div>
    );
  };

  renderContent() {
    const rootClassName = classNames(theme.root, this.props.theme.root);
    const { summary } = this.props;
    return (
      <div>
        <div className={rootClassName} onClick={this.openModal}>
          <div className={theme.info}>
            <div className={theme.title}>{getMessage('issuerSummary.short.title')}</div>
            <div className={theme.list}>{summary.map(this.renderItem)}</div>
          </div>
          <div className={theme.expandIcon}>
            <Icon type="expand" />
          </div>
        </div>
        <FullIssuerSummary opened={this.state.opened} onClose={this.closeModal}/>
      </div>
    );
  }

  render() {
    const transitionProps = {
      transitionName: theme.stretchTransition,
      transitionEnterTimeout: 400,
      transitionLeaveTimeout: 300
    };

    return (
      <CSSTransitionGroup {...transitionProps}>
        {this.props.isLoaded && this.renderContent()}
      </CSSTransitionGroup>
    );
  }
}

IssuerSummary.defaultProps = {
  theme: {}
};

export default IssuerSummary;
