import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { noop, toLower, filter, isEqual, isEmpty } from 'lodash';
import { Spinner } from 'react-techstack';
import { asyncStatusUtils, asyncStatusTypes } from 'react-techstack/utils';

import LOBSelect from './LOBSelect';
import IssuerSelect from './IssuerSelect';
import ShowInactiveCheckbox from './ShowInactiveCheckbox';

import theme from './IssuerSelector.css';
import { lobListType, lobType, issuerListType, issuerType } from 'modules/issuer/types';
const { combineStatuses, isPending, isNotStarted } = asyncStatusUtils;
const { asyncRequestType } = asyncStatusTypes;

class IssuerSelector extends React.Component {
  static propTypes = {
    lobList: lobListType,
    currentLOB: lobType,
    defaultLOBId: PropTypes.number,
    issuersList: issuerListType,
    allIssuers: issuerListType,
    currentIssuer: issuerType,
    defaultIssuerId: PropTypes.number,
    showInactiveIssuers: PropTypes.bool.isRequired,

    loadInitialData: PropTypes.func.isRequired,
    loadIssuersList: PropTypes.func.isRequired,
    toggleShowInactiveIssuers: PropTypes.func.isRequired,
    changeCurrentIssuer: PropTypes.func.isRequired,

    lobLabel: PropTypes.string,
    lobPlaceholder: PropTypes.string,
    lobLoadingMessage: PropTypes.string,
    issuerLabel: PropTypes.string,
    issuerPlaceholder: PropTypes.string,
    issuerLoadingMessage: PropTypes.string,
    showInactiveLabel: PropTypes.string,
    showInactiveCheckbox: PropTypes.bool.isRequired,
    controlSize: PropTypes.string, // ToDo: improve this

    initialDataRequest: asyncRequestType.isRequired,
    issuersListRequest: asyncRequestType.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string,
      lob: PropTypes.string,
      issuer: PropTypes.string,
      control: PropTypes.string,
      showInactive: PropTypes.string,
      lobControl: PropTypes.string,
      issuerControl: PropTypes.string,
      label: PropTypes.string,
      lobLabel: PropTypes.string,
      issuerLabel: PropTypes.string,
      spinner: PropTypes.string
    }).isRequired
  };

  constructor(props) {
    super(props);

    this.state = { issuersList: [], searching: false };
  }

  componentDidMount() {
    const { loadInitialData, defaultIssuerId, defaultLOBId, initialDataRequest } = this.props;

    // ToDo: improve this
    if (isNotStarted(initialDataRequest.status)) {
      loadInitialData(defaultIssuerId, defaultLOBId);
    }
  }

  UNSAFE_componentWillReceiveProps(newProps) {
    if (!isEqual(newProps.issuersList, this.props.issuersList)) {
      this.setState({ issuersList: newProps.issuersList });
    }
  }

  onChange = (issuer) => {
    this.props.changeCurrentIssuer(issuer);
  }

  onBlur = () => {
    const { issuersList } = this.props;
    this.setState({ issuersList, searching: false });
  }

  onInputChange = (value) => {
    if (!value) {
      this.onBlur();
    }
  }

  search = (opts, value) => {
    const { issuersList: currentList, allIssuers } = this.props;
    const options = value.length > 2 && !isEmpty(allIssuers) ? allIssuers : currentList;

    const issuersList = filter(options, (option) => {
      return ~toLower(option.label).indexOf(toLower(value));
    });
    this.setState({ issuersList, searching: true });
  }

  render() {
    const {
      lobList, currentLOB, loadIssuersList, currentIssuer,
      lobLabel, lobPlaceholder, lobLoadingMessage, issuerLabel, issuerPlaceholder, issuerLoadingMessage,
      showInactiveIssuers, toggleShowInactiveIssuers, showInactiveCheckbox, showInactiveLabel, controlSize,
      initialDataRequest, issuersListRequest, theme: customTheme
    } = this.props;

    const LOBSelectProps = {
      options: lobList,
      value: currentLOB,
      onChange: loadIssuersList,
      isLoading: isPending(initialDataRequest.status),
      label: lobLabel,
      placeholder: lobPlaceholder,
      loadingMessage: lobLoadingMessage,
      controlSize,
      theme: {
        root: classNames(theme.lob, customTheme.lob),
        control: classNames(theme.control, customTheme.control, customTheme.lobControl),
        label: classNames(theme.label, customTheme.label, customTheme.lobLabel)
      }
    };

    const isLoading = isPending(combineStatuses(initialDataRequest.status, issuersListRequest.status));

    const IssuerSelectProps = {
      options: this.state.issuersList,
      value: currentIssuer,
      onChange: this.onChange,
      filter: this.search,
      onBlur: this.onBlur,
      onInputChange: this.onInputChange,
      isLoading,
      searching: this.state.searching,
      label: issuerLabel,
      placeholder: issuerPlaceholder,
      loadingMessage: issuerLoadingMessage,
      controlSize,
      theme: {
        root: classNames(theme.issuer, customTheme.issuer),
        control: classNames(theme.control, customTheme.control, customTheme.issuerControl),
        label: classNames(theme.label, customTheme.label, customTheme.issuerLabel)
      }
    };

    const ShowInactiveCheckboxProps = {
      checked: showInactiveIssuers,
      onChange: toggleShowInactiveIssuers,
      disabled: isLoading,
      label: showInactiveLabel,
      theme: {
        root: classNames(theme.showInactive, customTheme.showInactive)
      }
    };

    return (
      <div className={classNames(theme.root, customTheme.root)}>
        <LOBSelect {...LOBSelectProps} />
        <IssuerSelect {...IssuerSelectProps} />
        {showInactiveCheckbox && <ShowInactiveCheckbox {...ShowInactiveCheckboxProps} />}
        <div className={classNames(theme.spinner, customTheme.spinner, {[theme.loading]: isLoading})}>
          <Spinner size={20} type="primary" />
        </div>
      </div>
    );
  }
}

IssuerSelector.defaultProps = {
  showInactiveCheckbox: false,
  showInactiveIssuers: false,
  toggleShowInactiveIssuers: noop,
  theme: {}
};

export default IssuerSelector;
