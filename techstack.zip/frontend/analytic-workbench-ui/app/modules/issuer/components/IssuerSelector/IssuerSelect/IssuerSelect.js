import React from 'react';
import PropTypes from 'prop-types';
import { get } from 'lodash';
import { Select } from 'react-techstack';
import { issuerListType, issuerType } from 'modules/issuer/types';
import { getMessage } from 'modules/common/utils/messagesUtils';
import { SelectPropTypes, prepareSelectProps } from 'modules/issuer/utils/issuerSelectorUtils';


class IssuerSelect extends React.Component {
  static propTypes = {
    ...SelectPropTypes,
    options: issuerListType.isRequired,
    value: issuerType,
    searching: PropTypes.bool,
    filter: PropTypes.func,
    onBlur: PropTypes.func
  };

  onChange = (issuer) => {
    const { value, onChange } = this.props;
    if (get(issuer, 'id', null) !== get(value, 'id', null)) {
      onChange(issuer);
    }
  }

  render() {
    const { filter, onBlur, onInputChange } = this.props;
    const SelectProps = {
      ...prepareSelectProps(this.props),
      onChange: this.onChange,
      valueKey: 'label',
      labelKey: 'label',
      filter,
      onBlur,
      onInputChange
    };

    return (
      <div className={this.props.theme.root}>
        <Select {...SelectProps} />
      </div>
    );
  }
}

IssuerSelect.defaultProps = {
  label: getMessage('issuerSelector.issuer.label'),
  placeholder: getMessage('issuerSelector.issuer.placeholder'),
  loadingMessage: getMessage('issuerSelector.issuer.loadingMessage'),
  theme: {}
};

export default IssuerSelect;
