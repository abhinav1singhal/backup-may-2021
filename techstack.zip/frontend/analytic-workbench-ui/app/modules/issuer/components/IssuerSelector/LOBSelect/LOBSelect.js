import React from 'react';
import { Select } from 'react-techstack';

import { getMessage } from 'modules/common/utils/messagesUtils';
import { SelectPropTypes, prepareSelectProps } from 'modules/issuer/utils/issuerSelectorUtils';

import { lobListType, lobType } from 'modules/issuer/types';

class LOBSelect extends React.Component {
  static propTypes = {
    ...SelectPropTypes,
    options: lobListType.isRequired,
    value: lobType
  };

  onChange(lob) {
    const {value = {}, onChange} = this.props;
    if (lob.id !== value.id) {
      onChange(lob);
    }
  }

  render() {
    const SelectProps = {
      ...prepareSelectProps(this.props),
      onChange: this.onChange.bind(this),
      valueKey: 'name',
      labelKey: 'name'
    };

    return (
      <div className={this.props.theme.root}>
        <Select {...SelectProps} />
      </div>
    );
  }
}

LOBSelect.defaultProps = {
  label: getMessage('issuerSelector.lob.label'),
  placeholder: getMessage('issuerSelector.lob.placeholder'),
  loadingMessage: getMessage('issuerSelector.lob.loadingMessage'),
  theme: {}
};

export default LOBSelect;
