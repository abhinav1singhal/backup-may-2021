import {connect} from 'react-redux';
import IssuerSelector from './IssuerSelector';
import {
  loadInitialData,
  loadIssuersList,
  changeCurrentIssuer,
  toggleShowInactiveIssuers
} from 'modules/issuer/actions/issuerActions';

function mapStateToProps(storage) {
  const { lobList, currentLOB, issuersList, currentIssuer, showInactiveIssuers, allIssuers } = storage.issuer;

  return {
    lobList,
    currentLOB,
    issuersList,
    allIssuers,
    currentIssuer,
    showInactiveIssuers,
    initialDataRequest: storage.requests.issuerSelectInitialData,
    issuersListRequest: storage.requests.issuerSelectIssuersList
  };
}

const mapDispatchToProps = {
  loadInitialData,
  loadIssuersList,
  changeCurrentIssuer,
  toggleShowInactiveIssuers
};

export default connect(mapStateToProps, mapDispatchToProps)(IssuerSelector);
