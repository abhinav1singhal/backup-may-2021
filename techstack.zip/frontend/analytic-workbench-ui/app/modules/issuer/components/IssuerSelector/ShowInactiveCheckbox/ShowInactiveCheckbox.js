import PropTypes from 'prop-types';
import React from 'react';
import {Checkbox} from 'react-techstack';

import { getMessage } from 'modules/common/utils/messagesUtils';

class ShowInactiveCheckbox extends React.Component {
  static propTypes = {
    checked: PropTypes.bool.isRequired,
    label: PropTypes.string.isRequired,
    disabled: PropTypes.bool.isRequired,

    onChange: PropTypes.func.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string
    }).isRequired
  };

  render() {
    const {checked, label, disabled, onChange, theme} = this.props;
    const CheckboxProps = {
      checked,
      onChange: () => onChange(!checked),
      label,
      disabled
    };

    return (
      <div className={theme.root}>
        <Checkbox {...CheckboxProps} />
      </div>
    );
  }
}

ShowInactiveCheckbox.defaultProps = {
  label: getMessage('issuerSelector.showInactive.label'),
  theme: {}
};

export default ShowInactiveCheckbox;
