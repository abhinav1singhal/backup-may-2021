const MESSAGES = {
  pageTitle: 'Issuer Data View'
};

export default MESSAGES;
