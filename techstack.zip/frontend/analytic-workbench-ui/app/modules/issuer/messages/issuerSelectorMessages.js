const MESSAGES = {
  lob: {
    label: 'Analytic Sector 2',
    placeholder: 'Select Analytic Sector 2...',
    loadingMessage: 'Loading Analytic Sector 2 list...'
  },
  issuer: {
    label: 'Issuer',
    placeholder: 'Select issuer...',
    loadingMessage: 'Loading issuers list...'
  },
  showInactive: {
    label: 'Show inactive'
  },
  messages: {
    errorLoadingLOBList: {
      message: 'while loading Analytic Sector 2 list.'
    },
    errorLoadingIssuersList: {
      title: 'Failed to load issuers list',
      message: 'while loading issuers list.'
    }
  }
};

export default MESSAGES;
