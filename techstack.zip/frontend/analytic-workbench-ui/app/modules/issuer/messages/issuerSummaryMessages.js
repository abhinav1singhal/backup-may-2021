const MESSAGES = {
  short: {
    title: 'SUMMARY: '
  },
  full: {
    title: '%s (Issuer Summary)',
    error: 'Unexpected error occured.'
  }
};

export default MESSAGES;
