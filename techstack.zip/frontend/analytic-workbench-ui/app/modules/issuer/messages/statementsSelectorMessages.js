const MESSAGES = {
  selectedStatements: {
    none: 'No Statements Selected',
    some: '%1i of %2i Statements Selected',
    all: '%1i Statements Selected'
  },
  selected: {
    none: 'Not selected',
    some: '%1i of %2i selected',
    all: '%1i selected'
  },
  applyFiltersButton: 'Apply filter',
  resetFiltersButton: 'Reset filter',
  table: {
    loadingStatements: 'Loading statements list..',
    showSelectedOnlyButton: 'Show selected only',
    deselectAllButton: 'Deselect all'
  },

  messages: {
    loadingConfiguration: 'Loading search configuration...',
    statementsNotFound: 'No statements found'
  },

  modal: {
    title: 'Select Statements',
    cancelButton: 'Cancel',
    applyButton: 'Show Results'
  }
};

export default MESSAGES;
