import { handleActions } from 'react-techstack/redux';

import { LOAD_SHORT_SUMMARY, LOAD_FULL_SUMMARY  } from 'modules/issuer/actions/issuerSummaryActions';


export const INITIAL_STATE = {
  shortSummary: [],
  fullSummary: []
};

export function getInitialState() {
  return INITIAL_STATE;
}

export default handleActions({
  [LOAD_SHORT_SUMMARY.REQUEST](store) {
    return {
      ...store,
      shortSummary: []
    };
  },

  [LOAD_FULL_SUMMARY.REQUEST](store) {
    return {
      ...store,
      fullSummary: []
    };
  },

  [LOAD_SHORT_SUMMARY.SUCCESS](storage, { payload }) {
    return {
      ...storage,
      shortSummary: payload,
      fullSummary: []
    };
  },

  [LOAD_FULL_SUMMARY.SUCCESS](storage, { payload }) {
    return {
      ...storage,
      fullSummary: payload
    };
  }
}, getInitialState());
