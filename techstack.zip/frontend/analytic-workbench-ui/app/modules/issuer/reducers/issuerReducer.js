import { handleActions } from 'react-techstack/redux';

// import {LOAD_APP_INIT_DATA} from 'modules/common/actions/configActions';
import {
  LOAD_INITIAL_DATA, LOAD_ISSUERS_LIST, LOAD_ISSUER_SUMMARY, LOAD_ISSUERS_LIST_PURE,
  CHANGE_CURRENT_ISSUER, TOGGLE_SHOW_INACTIVE_ISSUERS, LOAD_ALL_ISSUERS
} from 'modules/issuer/actions/issuerActions';


export const INITIAL_STATE = {
  currentLOB: undefined,
  currentIssuer: undefined,
  lobList: [],
  issuersList: [],
  issuersListPure: [],
  allIssuers: [],
  showInactiveIssuers: false
};

// ToDo: improve this
export function getInitialState() {
  return INITIAL_STATE;
}

export default handleActions({
  [LOAD_INITIAL_DATA.SUCCESS](storage, {payload}) {
    return {
      ...storage,
      currentLOB: payload.currentLOB,
      currentIssuer: payload.currentIssuer,
      lobList: payload.lobList,
      issuersList: payload.issuersList,
      issuersListPure: payload.issuersList,
      showInactiveIssuers: payload.showInactive
    };
  },

  [LOAD_ISSUERS_LIST.REQUEST](storage, { meta }) {
    return {
      ...storage,
      currentLOB: meta.lob,
    };
  },

  [LOAD_ISSUERS_LIST.SUCCESS](storage, {payload}) {
    return {
      ...storage,
      issuersList: payload.issuersList,
      issuersListPure: payload.issuersList,
      currentIssuer: payload.defaultIssuer
    };
  },

  [LOAD_ISSUERS_LIST_PURE.SUCCESS](storage, {payload}) {
    return {
      ...storage,
      issuersListPure: payload
    };
  },

  [LOAD_ISSUER_SUMMARY.SUCCESS](storage, {payload}) {
    return {
      ...storage,
      issuersListPure: payload
    };
  },

  [LOAD_ALL_ISSUERS.SUCCESS](storage, {payload}) {
    return {
      ...storage,
      allIssuers: payload
    };
  },

  [CHANGE_CURRENT_ISSUER](storage, {payload}) {
    let { currentLOB, issuersList } = storage;
    const { lobId, id } = payload;
    if (currentLOB.id !== lobId ) {
      currentLOB = storage.lobList.find((lob) => lob.id === lobId);
      issuersList = storage.allIssuers.filter((issuer) => issuer.lobId === lobId);
    }
    const currentIssuer = issuersList.find((issuer) => issuer.id === id);
    return {
      ...storage,
      currentLOB,
      issuersList,
      currentIssuer,
    };
  },

  [TOGGLE_SHOW_INACTIVE_ISSUERS](storage, {payload}) {
    return {
      ...storage,
      showInactiveIssuers: payload
    };
  }
}, getInitialState());
