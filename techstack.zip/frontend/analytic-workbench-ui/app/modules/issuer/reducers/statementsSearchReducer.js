import cloneDeep from 'lodash/cloneDeep';
import {handleActions} from 'react-techstack/redux';

import {
  LOAD_STATEMENTS_SEARCH_DATA, LOAD_STATEMENTS_LIST,
  APPLY_STATEMENTS_SEARCH, CANCEL_STATEMENTS_SEARCH
} from 'modules/issuer/actions/statementsSearchActions';
import {
  TOGGLE_SELECTED_STATEMENTS, DESELECT_ALL_STATEMENTS
} from 'modules/issuer/actions/statementsSelectorActions';

import { FormBuilderConfigDTO } from 'react-techstack/utils';
import {toggleSelectedStatements, deselectAllStatements} from 'modules/issuer/utils/statementsSelectorUtils';

export const INITIAL_STATE = {
  currentFilters: new FormBuilderConfigDTO(),
  currentStatements: [],
  filters: new FormBuilderConfigDTO(),
  columns: [],
  statements: [],
  dictionaries: {}
};

function getInitialState() {
  return INITIAL_STATE;
}

export default handleActions({
  [LOAD_STATEMENTS_SEARCH_DATA.REQUEST]() {
    return getInitialState();
  },

  [LOAD_STATEMENTS_SEARCH_DATA.SUCCESS](storage, {payload}) {
    return {
      currentFilters: payload.filters,
      currentStatements: payload.statements,
      filters: payload.filters.clone(),
      columns: payload.columns,
      statements: cloneDeep(payload.statements),
      dictionaries: payload.dictionaries
    };
  },

  [LOAD_STATEMENTS_LIST.REQUEST](storage, {meta}) {
    const initialState = getInitialState();

    // ToDo: improve this
    return {
      ...storage,
      filters: meta.filters,
      statements: initialState.statements
    };
  },

  [LOAD_STATEMENTS_LIST.SUCCESS](storage, {payload}) {
    return {
      ...storage,
      statements: payload.statements
    };
  },

  [APPLY_STATEMENTS_SEARCH](storage, {payload}) {
    return {
      ...storage,
      currentFilters: payload.filters,
      currentStatements: payload.statements,
      filters: payload.filters.clone(),
      statements: cloneDeep(payload.statements)
    };
  },

  [CANCEL_STATEMENTS_SEARCH](storage) {
    return {
      ...storage,
      filters: storage.currentFilters.clone(),
      statements: cloneDeep(storage.currentStatements)
    };
  },

  [TOGGLE_SELECTED_STATEMENTS](storage, {payload}) {
    const statements = toggleSelectedStatements(cloneDeep(storage.statements), payload);

    return {
      ...storage,
      statements
    };
  },

  [DESELECT_ALL_STATEMENTS](storage) {
    return {
      ...storage,
      statements: deselectAllStatements(cloneDeep(storage.statements))
    };
  }

}, getInitialState());
