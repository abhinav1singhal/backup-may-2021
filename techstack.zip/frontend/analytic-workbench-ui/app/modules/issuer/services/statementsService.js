import { BASE_API_URL } from 'config/index';

import {
  prepareFiltersConfig, prepareColumnsConfig, prepareDictionariesRequestConfig,
  prepareStatements, prepareStatementsDictionaries,
  prepareFiltersRequest, isValidSearch, prepareSearchParams
} from 'modules/issuer/utils/statementsSearchUtils';
import {loadDictionaries} from 'modules/common/services/dictionariesService';

function loadStatementsSearchConfig(client, issuer) {
  return client.get(`${BASE_API_URL}/v2/statement-view/filter-set/${issuer.lobId}/${issuer.id}`)
    .then(({data}) => {
      return {
        columns: prepareColumnsConfig(data.columns),
        filters: prepareFiltersConfig(data.filters)
      };
    });
}

function loadStatementsList(client, issuer, filtersRequest) {
  return client.get(`${BASE_API_URL}/v2/statement-view/grid/${issuer.lobId}/${issuer.id}`, {
    params: prepareSearchParams(filtersRequest)
  }).then(({data}) => data.data);
}

export default (client) => {
  const Service = {
    loadStatementsSearchData: (issuer) => {
      return loadStatementsSearchConfig(client, issuer).then((config) => {
        let statementsListRequest = Promise.resolve([]);
        const filtersRequest = prepareFiltersRequest(config.filters, issuer);
        if (isValidSearch(config.filters.getControlsList())) {
          statementsListRequest = loadStatementsList(client, issuer, filtersRequest);
        }

        return Promise.all([
          loadDictionaries(client, prepareDictionariesRequestConfig(config)),
          statementsListRequest
        ]).then(([dictionaries, statementsList]) => {
          config.filters.setDictionariesValues(dictionaries);
          const statementsDictionaries = prepareStatementsDictionaries(config, dictionaries);
          const statements = prepareStatements(statementsList, statementsDictionaries);

          return {
            filters: config.filters,
            columns: config.columns,
            statements,
            dictionaries: statementsDictionaries
          };
        });

      });
    },
    loadStatementsList: (issuer, filters, dictionaries) => {
      const filtersRequest = prepareFiltersRequest(filters, issuer, true);
      return loadStatementsList(client, issuer, filtersRequest).then((statementsList) => {
        const statements = prepareStatements(statementsList, dictionaries);

        return {
          statements
        };
      });
    },
    saveStatementsSearch: (issuer, filters) => {
      const filtersRequest = prepareFiltersRequest(filters, issuer, true);
      return client.post(`${BASE_API_URL}/v2/statement-view/user-filters/${issuer.lobId}/${issuer.id}`, filtersRequest);
    }
  };

  return Service;
};
