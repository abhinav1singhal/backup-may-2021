import { BASE_API_URL } from 'config/index';

import {
  prepareCurrentLOB, prepareCurrentIssuer, prepareIssuer, prepareIssuersList, findIssuerById, ERROR_CODES
} from 'modules/issuer/utils/issuerUtils';

export function loadDefaultIssuer(client, issuerId) {
  // ToDo: implement invalid issuerId handling
  return client.get(`${BASE_API_URL}/dictionary/organization-data`, {
    params: {
      id: issuerId
    }
  }).then(({data}) => data && data.id ? prepareIssuer(data) : undefined).catch((response) => {
    return Promise.reject({
      ...response,
      $errorCode: ERROR_CODES.ERROR_LOADING_DEFAULT_ISSUER
    });
  });
}

export default (client) => {
  const Service = {
    loadInitialData: (issuerId, lobId, showInactive = false) => {
      return Promise.all([
        Service.loadLOBList(showInactive), Service.loadDefaultIssuer(issuerId)
      ]).then(([lobList, defaultIssuer]) => {
        const result = {
          currentIssuer: undefined,
          currentLOB: prepareCurrentLOB(lobList, issuerId, lobId, defaultIssuer),
          issuersList: [],
          lobList,
          showInactive
        };

        if (result.currentLOB) {
          return Service.loadIssuersList(result.currentLOB, showInactive)
            .then(({issuersList, defaultIssuer: defaultLOBIssuer}) => {
              return {
                ...result,
                currentIssuer: prepareCurrentIssuer(result.currentLOB, defaultIssuer, defaultLOBIssuer),
                issuersList
              };
            }).catch(({$errorCode}) => {
              return {
                ...result,
                $errorCode
              };
            });
        }

        return result;
      });
    },

    loadDefaultIssuer: (issuerId) => loadDefaultIssuer(client, issuerId),

    saveDefaultIssuer: (issuer) => {
      // ToDo: check if issuer is valid
      return client.post(`${BASE_API_URL}/dictionary/organization-data`, {}, {
        params: {
          issuerId: issuer.id,
          lobId: issuer.lobId
        }
      });
    },

    loadLOBList: (showInactive = false) => {
      return client.get(`${BASE_API_URL}/lob-filter/lobs`, {
        params: {
          showInactive
        }
      }).then(({data}) => data).catch((response) => {
        return Promise.reject({
          ...response,
          $errorCode: ERROR_CODES.ERROR_LOADING_LOB_LIST
        });
      });
    },

    loadIssuersList: (lob, showInactive = false, pure = false) => {
      return client.get(`${BASE_API_URL}/lob-filter/organizations-by-lob`, {
        params: {
          lobId: lob.id,
          showInactive,
          save: !pure
        }
      }).then(({data}) => {
        const issuersList = prepareIssuersList(data.issuers);

        if (pure) {
          return issuersList;
        }

        return {
          issuersList,
          defaultIssuer: findIssuerById(issuersList, data.defaultIssuerId)
        };
      }).catch((response) => {
        return Promise.reject({
          ...response,
          $errorCode: ERROR_CODES.ERROR_LOADING_ISSUERS_LIST
        });
      });
    },
    loadShortSummary: (issuerId) => {
      return client.get(`${BASE_API_URL}/issuer-summary/short/${issuerId}`)
        .then(({data}) => data);
    },

    loadFullSummary: (issuerId) => {
      return client.get(`${BASE_API_URL}/issuer-summary/full/${issuerId}`)
        .then(({data}) => data);
    },

    loadIssuerSummaryAndLobs: (issuerId, listLob) => {
      return client.get(`${BASE_API_URL}/issuer-summary/full/${issuerId}`)
        .then(({data}) => {
          const lobName = data[0].content.find((item) => item.label === 'Analytic Sector 2');
          const lob = listLob.find((item) => item.name === lobName.value);
          return Service.loadIssuersList(lob, false, true);
        });
    }
  };

  return Service;
};
