/* global expect */

import frisby from 'frisby';
import joi from 'joi';
import { buildURL } from 'react-techstack/utils';
import { ErrorSchema } from '../../../../utils/apiTestUtils'; // TODO: improve

const IssuerSchema = joi.object().keys({
  id: joi.number(),
  lobId: joi.number(),
  name: joi.string().allow(''), // ToDo: why empty issuers in DB ???
  description: joi.string()
});

const UNEXPECTED_SERVER_ERROR_CODE = 'UNEXPECTED_SEVER_ERROR';

export default function(BASE_URL) {
  frisby.create('issuerService.loadDefaultIssuer() load last saved issuer response')
    .get(`${BASE_URL}/api/dictionary/organization-data`)
    .expectStatus(200)
    .afterJSON((data) => {
      expect(data).toHaveJoiSchema(IssuerSchema);
    })
    .toss();

  frisby.create('issuerService.loadDefaultIssuer() load data response for custom issuer id (example: 600020131 - Aetna Inc.)')
    .get(buildURL(`${BASE_URL}/api/dictionary/organization-data`, {
      id: 600020131
    }))
    .expectStatus(200)
    .afterJSON((data) => {
      expect(data).toHaveJoiSchema(IssuerSchema);
    })
    .toss();

  frisby.create('issuerService.loadDefaultIssuer() load data response for invalid issuer id')
    .get(buildURL(`${BASE_URL}/api/dictionary/organization-data`, {
      id: 424242
    }))
    .expectStatus(200)
    .after((error, response, data) => {
      expect(data).toBeUndefined();
    })
    .toss();

  frisby.create('issuerService.loadLOBList() load available Line of Business list response')
    .get(`${BASE_URL}/api/lob-filter/lobs`)
    .expectStatus(200)
    .afterJSON((data) => {
      expect(data).toHaveJoiSchema(joi.array().items(
        joi.object().keys({
          id: joi.number(),
          name: joi.string(),
          description: joi.string()
        })
      ));
    })
    .toss();

  frisby.create('issuerService.loadIssuersList() load issuers list response for specific existing Line of Business id')
    .get(buildURL(`${BASE_URL}/api/lob-filter/organizations-by-lob`, {
      lobId: 6000
    }))
    .expectStatus(200)
    .afterJSON((data) => {
      expect(data).toHaveJoiSchema(joi.object().keys({
        defaultIssuerId: joi.number(),
        issuers: joi.array().items(IssuerSchema)
      }));
    })
    .toss();

  frisby.create('issuerService.loadIssuersList() load issuers list response without required Line of Business id')
    .get(buildURL(`${BASE_URL}/api/lob-filter/organizations-by-lob`))
    .expectStatus(500)
    .afterJSON((data) => {
      expect(data).toHaveJoiSchema(ErrorSchema);

      expect(data.code).toBe(UNEXPECTED_SERVER_ERROR_CODE);
      expect(data.message).toBe('Required Long parameter \'lobId\' is not present');
    })
    .toss();

  frisby.create('issuerService.loadIssuersList() load issuers list response for invalid Line of Business id')
    .get(buildURL(`${BASE_URL}/api/lob-filter/organizations-by-lob`, {
      lobId: 424242
    }))
    .expectStatus(200)
    .afterJSON((data) => {
      expect(data).toHaveJoiSchema(joi.object().keys({
        defaultIssuerId: joi.valid(null),
        issuers: joi.array().length(0)
      }));
    })
    .toss();
}
