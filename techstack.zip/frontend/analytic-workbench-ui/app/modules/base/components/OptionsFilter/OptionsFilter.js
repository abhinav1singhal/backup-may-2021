import PropTypes from 'prop-types';
import React from 'react';
import { Button } from 'react-techstack';
import _ from 'lodash';

import OptionItem from './components/OptionItem';

import theme from './OptionsFilter.css';

class OpitonsFilter extends React.Component {

  static propTypes = {
    onChange: PropTypes.func,
    options: PropTypes.arrayOf(
      PropTypes.object.isRequired
    ).isRequired,
    selectedOptions: PropTypes.arrayOf(
      PropTypes.string.isRequired
    ).isRequired,
    labelParam: PropTypes.string.isRequired,
    valueParam: PropTypes.string.isRequired,
    maxItems: PropTypes.number.isRequired
  };

  constructor(props) {
    super(arguments);
    this.state = {
      options: props.selectedOptions
    };
  }

  onClearClickHandler = (e) => {
    e.preventDefault();
    this.setState({ options: [] });
  };

  onApplyClickHandler = (e) => {
    e.preventDefault();
    this.props.onChange(this.state.options);
  };

  onChangeOption = (option) => {
    return (checked) => {
      if (checked) {
        this.setState({
          options: [ ...this.state.options, option[this.props.valueParam] ]
        });
      } else {
        this.setState({
          options: this.state.options.filter((item) => {
            return item !== option[this.props.valueParam];
          })
        });
      }
    };
  };

  renderClearFilterButton() {
    return (
      <a className={theme.clearFilterButton} href="#"
         onClick={this.onClearClickHandler}>
        Clear Filter
      </a>
    );
  }

  renderApplyButton() {
    return (
      <Button href="#" bsStyle="primary"
              className={theme.applyButton}
              onClick={this.onApplyClickHandler}>
        Apply
      </Button>
    );
  }

  renderItems() {
    return this.props.options.map((option) => {
      const checked = this.state.options.indexOf(option[this.props.valueParam]) !== -1;
      return (
        <OptionItem label={option[this.props.labelParam]} key={option[this.props.valueParam]}
                    checked={checked}
                    onChange={this.onChangeOption(option)} />
      );
    });
  }

  render() {
    return (
      <div className={theme.root} data-test="OptionsFilter__root">
        <div className={theme.topPanel}>
          { this.renderClearFilterButton() }
        </div>
        <div className={theme.optionsPanel} style={{ maxHeight: `${ this.props.maxItems * 30 }px`}}>
          { this.renderItems() }
        </div>
        <div className={theme.bottomPanel}>
          { this.renderApplyButton() }
        </div>
      </div>
    );
  }

}

OpitonsFilter.defaultProps = {
  onChange: _.noop,
  options: [],
  selectedOptions: [],
  labelParam: 'label',
  valueParam: 'value',
  maxItems: 7
};

export default OpitonsFilter;
