import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';

import { Input } from 'react-techstack';

import theme from './OptionItem.css';

class OptionItem extends React.Component {

  static propTypes = {
    label: PropTypes.string.isRequired,
    onChange: PropTypes.func.isRequired,
    checked: PropTypes.bool.isRequired
  };

  handleChange = () => {
    this.props.onChange(!this.props.checked);
  };

  render() {
    return (
      <div className={theme.root} data-test="OptionsItem__root">
        <Input type="checkbox"
               checked={this.props.checked}
               onChange={this.handleChange}
               label={this.props.label} />
      </div>
    );
  }

}

OptionItem.defaultProps = {
  onChange: _.noop,
  checked: false
};

export default OptionItem;
