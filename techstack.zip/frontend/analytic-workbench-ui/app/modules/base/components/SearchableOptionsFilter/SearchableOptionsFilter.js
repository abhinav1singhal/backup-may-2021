import PropTypes from 'prop-types';
import React from 'react';
import { Button, Input } from 'react-techstack';
import _ from 'lodash';

import OptionItem from './components/OptionItem';

class SearchableOptionsFilter extends React.Component {

  static propTypes = {
    onChange: PropTypes.func,
    options: PropTypes.arrayOf(
      PropTypes.object.isRequired
    ).isRequired,
    selectedOptions: PropTypes.arrayOf(
      PropTypes.string.isRequired
    ).isRequired,
    labelParam: PropTypes.string.isRequired,
    valueParam: PropTypes.string.isRequired,
    maxItems: PropTypes.number.isRequired,

    theme: PropTypes.object.isRequired
  };

  constructor(props) {
    super(arguments);
    this.state = {
      options: props.selectedOptions,
      searchText: null
    };
  }

  onClearClickHandler = (e) => {
    e.preventDefault();
    this.setState({options: []});
  };

  onApplyClickHandler = (e) => {
    e.preventDefault();
    this.props.onChange(this.state.options);
  };

  onChangeOption = (option) => {
    return (checked) => {
      if (checked) {
        this.setState({
          options: [...this.state.options, option[this.props.valueParam]]
        });
      } else {
        this.setState({
          options: this.state.options.filter((item) => {
            return item !== option[this.props.valueParam];
          })
        });
      }
    };
  };

  onSearchInputChange = (e) => {
    this.setState({
      searchText: e.target.value
    });
  };

  renderClearFilterButton() {
    return (
      <a className={this.props.theme.clearFilterButton} href="#"
         onClick={this.onClearClickHandler}>
        Clear Filter
      </a>
    );
  }

  renderApplyButton() {
    return (
      <Button href="#" bsStyle="primary"
              className={this.props.theme.applyButton}
              onClick={this.onApplyClickHandler}>
        Apply
      </Button>
    );
  }

  renderItems() {
    const {searchText} = this.state;
    let options = this.props.options;

    if (searchText && !_.isEqual(searchText, '')) {
      options = options.filter(({label}) => `${label}`.toLowerCase().indexOf(searchText.toLowerCase()) > -1);
    }

    return options.map((option) => {
      const checked = this.state.options.indexOf(option[this.props.valueParam]) !== -1;
      return (
        <OptionItem label={`${option[this.props.labelParam]}`} key={option[this.props.valueParam]}
                    checked={checked}
                    onChange={this.onChangeOption(option)}/>
      );
    });
  }

  render() {
    const {theme} = this.props;

    return (
      <div className={theme.root} data-test="OptionsFilter__root">
        <Input type="text" ref="searchInput" placeholder="Search..."
               onChange={this.onSearchInputChange}/>
        <div className={theme.topPanel}>
          { this.renderClearFilterButton() }
        </div>
        <div className={theme.optionsPanel} style={{ maxHeight: `${ this.props.maxItems * 30 }px`}}>
          { this.renderItems() }
        </div>
        <div className={theme.bottomPanel}>
          { this.renderApplyButton() }
        </div>
      </div>
    );
  }
}

SearchableOptionsFilter.defaultProps = {
  onChange: _.noop,
  options: [],
  selectedOptions: [],
  labelParam: 'label',
  valueParam: 'value',
  maxItems: 7,
  theme: require('./SearchableOptionsFilter.css')
};

export default SearchableOptionsFilter;
