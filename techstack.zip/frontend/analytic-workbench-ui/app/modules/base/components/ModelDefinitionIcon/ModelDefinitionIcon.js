import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { Icon } from 'modules/shared/components';

import theme from './ModelDefinitionIcon.css';

export default class ModelDefinitionIcon extends React.Component {
  static propTypes = {
    className: PropTypes.string
  };

  render() {
    const {className, ...props} = this.props;

    return <Icon {...props} className={classNames(theme.root, className)} type="link" />;
  }
}
