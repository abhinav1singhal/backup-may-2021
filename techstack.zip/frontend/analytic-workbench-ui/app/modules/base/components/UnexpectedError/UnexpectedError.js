import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { Alert } from 'react-techstack';

class UnexpectedError extends React.Component {
  static propTypes = {
    className: PropTypes.string
  };

  render() {
    return (
      <div className={classNames(this.props.className)}>
        <Alert bsStyle="danger">
          An unexpected error occurred.
        </Alert>
      </div>
    );
  }
}

export default UnexpectedError;
