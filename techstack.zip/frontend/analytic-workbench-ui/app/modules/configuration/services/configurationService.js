import { isEmpty, isArray, pick, mapKeys, mapValues, omit, some } from 'lodash';
import { BASE_API_URL } from 'config/index';
import { loadDictionaries } from 'react-techstack/redux/services';
import  surveillanceGroupServices  from 'modules/surveillance/services/surveillanceGroupServices';
import { prepareIssuer, prepareIssuersList } from 'modules/issuer/utils/issuerUtils';

import { n8mareContractConverter } from 'utils/FormBuilderContractUtils';
import { prepareTableDictionary } from 'modules/configuration/utils';

const consolidatedFilterDictionaryQuery = [
  { dataEntityId: 'cons_status_category' },
  { dataEntityId: 'cons_status_rationale' }
];

const categoryData = {
  1: { backgroundColor: '#eaf6fc', color: '#000' },
  2: { backgroundColor: '#b2e1f6', color: '#000' },
  3: { backgroundColor: '#009be1', color: '#fff' },
  4: { backgroundColor: '#0028a0', color: '#fff' }
};

function loadGroupFiltersDictionary(filtersKeys) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(pick({}, filtersKeys));
    }, 1000);
  });
}

function prepareFilter(filter) {
  if (isEmpty(filter)) {
    return undefined;
  }
  return isArray(filter) ? filter : [filter];
}

function prepareFormData(formData) {
  const result = {
    groupDefinitionId: formData.groupDefinitionId,
    groupDescription: formData.groupDescription,
    groupLeadIssuerId: formData.groupLeadIssuerId,
    groupName: formData.name,
    groupTypeId: formData.type,
    issuerIds: formData.members,
    static: formData.isSelectingManually,
    userSelectParams: mapValues(formData.filters, (filter) => prepareFilter(filter)),
    groupTierId: formData.tier,
    groupStatus: formData.groupStatus
  };
  return result;
}

export default (client) => {
  return {
    loadGroupDefinitionDictionary() {
      return client.get(`${BASE_API_URL}/group/definition-data`)
        .then(({ data }) => data);
    },

    loadGroupFilters(groupDefinitionId) {
      return client.get(`${BASE_API_URL}/group/meta?groupDefinitionId=${groupDefinitionId}`)
        .then(({ data }) => data)
        .then((filters) => {
          const newFilters = filters.map((item) => {
            // if (index === 1) {
            //   item.valueList.map((val) => {
            //     val.parentIds =  ['7001'];
            //     return val;
            //   });
            // } else {
            //   item.valueList.map((val, i) => {
            //     val.parentIds = i % 2 ? ['3', '4'] : ['2', '3'];
            //     return val;
            //   });
            // }
            return item;
          });
          // newFilters[3].parentName = 'rating_type_id';
          // newFilters[1].multiple = false;
          // newFilters[0].multiple = false;
          // newFilters[1].parentName = 'lob_id';
          const config = n8mareContractConverter(newFilters);
          const filterQueryIds = filters.filter(({ queryId }) => !!queryId).map(({ queryId }) => queryId);
          config.controls.forEach(({ key, dictionaryKey }) => {
            if (dictionaryKey === 'organizations-all.id') {
              config.dictionaries[key] = config.dictionaries[key].map(prepareIssuer);
            }
          });
          if (config.dictionariesKeys.length === 0) {
            return { ...config, filterQueryIds };
          }

          return loadGroupFiltersDictionary(config.dictionariesKeys).then((filtersDictionary) => {
            const mappedDictionary = mapKeys(filtersDictionary, (val, key) => config.dictionariesKeyMap[key]);
            return {
              ...config,
              dictionaries: {
                ...config.dictionaries,
                ...mappedDictionary
              },
              filterQueryIds
            };
          });
        });
    },

    loadGroupFiltersDictionary,

    loadGroupMembers(groupDefinitionId, filters) {
      const nonEmptyFilters = mapValues(filters, (filter) => prepareFilter(filter));
      return client.post(`${BASE_API_URL}/group/matching-results?groupDefinitionId=${groupDefinitionId}`, nonEmptyFilters)
        .then(({ data }) => ({
          columns: data.columns,
          records: data.records.map((record) => {
            const issuer = prepareIssuer(record.issuer);

            return {
              ...record,
              issuer,
              searchKey: issuer.label.toLowerCase()
            };
          })
        }));
    },

    loadManualIssuers(groupDefinitionId, ids ) {
      return client.post(`${BASE_API_URL}/group/resolve-records?groupDefinitionId=${groupDefinitionId}`, {ids})
        .then(({ data }) => ({
          columns: data.columns,
          records: data.records.map((record) => {
            const issuer = prepareIssuer(record.issuer);

            return {
              ...record,
              issuer,
              searchKey: issuer.label.toLowerCase()
            };
          })
        }));
    },

    loadTableFiltersDictionary(dictionariesColumns) {
      return loadDictionaries(client, dictionariesColumns.map(({ queryId }) => ({ queryId })), BASE_API_URL)
        .then((data) => prepareTableDictionary(data, dictionariesColumns));
    },

    saveGroup(groupId, formData) {
      return client.put(`${BASE_API_URL}/group/data/${groupId}`, prepareFormData(formData))
        .then(({ data }) => data);
    },

    createGroup(formData) {
      return client.post(`${BASE_API_URL}/group/data`, prepareFormData(formData))
        .then(({ data }) => data);
    },

    loadGroupData(groupId) {
      return client.get(`${BASE_API_URL}/group/data/${groupId}`)
        .then(({ data }) => {
          return {
            ...omit(data, ['groupTypeId']),
            type: data.groupTypeId
          };
        }).then((data) => {
          return Promise.all([
            this.loadGroupFilters(data.groupDefinitionId),
            surveillanceGroupServices(client).loadGroupAttributesDictionary(),
            this.loadGroupDefinitionDictionary(),
            this.loadGroupMembers(data.groupDefinitionId, data.userSelectParams)
          ]).then(([filtersData, attributes, definition, members]) => {
            const userSelectParams = {};
            filtersData.controls.forEach((control) => {
              if (data.userSelectParams[control.key]) {
                const { key } = control;
                userSelectParams[key] = control.multiple ? data.userSelectParams[key] : data.userSelectParams[key][0];
              }
            });
            const result = {
              data: {
                ...data,
                userSelectParams
              },
              filtersData,
              attributes,
              definition,
              members
            };
            if (data.static) {
              const missedIds = data.issuerIds.filter((id) => !some(members.records, { id }) );
              if (missedIds.length) {
                return this.loadManualIssuers(data.groupDefinitionId, missedIds).then((issuers) => {
                  if (!result.members.columns.length) {
                    result.members.columns.unshift(...issuers.columns);
                  }
                  result.members.records.unshift(...issuers.records);
                  return result;
                });
              }
            }

            return result;
          });
        });
    },

    loadConsolidatedFilterDictionary() {
      return loadDictionaries(client, consolidatedFilterDictionaryQuery, BASE_API_URL)
        .then((data) => {
          const { cons_status_category, cons_status_rationale } = data;
          return {
            category: cons_status_category.map((category) => ({ ...category, ...categoryData[category.id]})),
            rationale: cons_status_rationale
          };
        });
    },

    loadConsolidatedFilterData(issuerId) {
      return client.get(`${BASE_API_URL}/organizations/${issuerId}/consolidated-status`)
        .then(({data}) => ({
          categoryId: data.flagId,
          rationaleId: data.rationaleId
        }));
    },

    saveConsolidatedFilterData(issuerId, formData) {
      const requestData = {
        flagId: formData.categoryId,
        rationaleId: formData.rationaleId,
        organizationId: issuerId
      };

      return client.post(`${BASE_API_URL}/organizations/${issuerId}/consolidated-status`, requestData)
        .then(({ data }) => data);
    },

    loadEventScenarioDictionary() {
      return client.get(`${BASE_API_URL}/group/dictionary/assignment`)
        .then(({ data }) => {
          return {
            groups: data.groups,
            issuers: prepareIssuersList(data.issuers)
          };
        });
    },

    loadIssuerGroups(issuerId) {
      return client.get(`${BASE_API_URL}/group/issuer/${issuerId}`)
        .then(({ data }) => data);
    },

    saveIssuerGroups(issuerId, formData) {
      return client.post(`${BASE_API_URL}/group/issuer/${issuerId}`, (formData || []) );
    },

    loadShareableLobs() {
      return client
        .get(`${BASE_API_URL}/analyticssharing/get-shareable-lobs`)
        .then(({data}) => data);
    },

    saveSelectedLobs(lobs) {
      return client
        .post(`${BASE_API_URL}/analyticssharing/save-shareable-lobs`, lobs);
    },

    shareSelectedLobsWithMA() {
      return client
        .get(`${BASE_API_URL}/analyticssharing/trigger-bulk-sharing`);
    },

    getGeneratedGroupName(issuerId) {
      return client
        .get(`${BASE_API_URL}/group/generate-name/${issuerId}`)
        .then(({ data }) => ({ data, issuerId }));
    }
  };
};
