/* global expect */

import frisby from 'frisby';
import joi from 'joi';
import { buildURL } from 'react-techstack/utils';
import { ErrorSchema } from '../../../../utils/apiTestUtils';

const NOT_FOUND_ERROR_CODE = 'CODE_NOT_FOUND';
const TEST_GROUP_ID = '1b9c0bda-00d0-46a2-8179-6abfd024fa5d';
const DUPLICATE_NAME_ERROR_CODE = 'DUPLICATE_NAME';
const EXISTING_NAME = 'aaaa';

const GroupResponseSchema = joi.object().keys({
  id: joi.string().guid(),
  timestamp: joi.number()
});

export default function(apiBaseUrl) {
  frisby.create('group-attributes-dictionary')
    .get(`${apiBaseUrl}/api/group/dictionary?dictionaryId=all`)
    .expectStatus(200)
    .afterJSON((responseBody) => {
      expect(responseBody).toHaveJoiSchema(joi.object().keys({
        groupLeadIssuerId: joi.array().items(joi.object().keys({
          id: joi.number(),
          name: joi.string(),
          lobId: joi.number().allow(null),
          description: joi.string().allow(null)
        })),
        groupTypeId: joi.array().items(joi.object().keys({
          id: joi.string(),
          name: joi.string(),
          description: joi.string()
        }))
      }));
    })
    .toss();

  frisby.create('group-members')
    .post(`${apiBaseUrl}/api/group/matching-results?groupDefinitionId=issuer-by-sectors`, {
      lob_id: ['6000'],
      subsector_id: ['6160']
    })
    .expectStatus(200)
    .afterJSON((responseBody) => {
      expect(responseBody).toHaveJoiSchema(joi.object().keys({
        columns: joi.array().items(joi.object().keys({
          key: joi.string(),
          label: joi.string()
        })),
        records: joi.array().items(joi.object().keys({
          id: joi.number(),
          country: joi.string(),
          lob: joi.string(),
          name: joi.string(),
          region: joi.string(),
          subsector: joi.string()
        }))
      }));
    })
    .toss();

  frisby.create('configurationService.loadGroupData() load for existing group id')
    .get(`${apiBaseUrl}/api/group/data/${TEST_GROUP_ID}`)
    .expectStatus(200)
    .afterJSON((data) => {
      expect(data).toHaveJoiSchema(joi.object().keys({
        groupDefinitionId: joi.string(),
        groupName: joi.string(),
        groupDescription: joi.string().allow(null),
        groupTypeId: joi.string(),
        groupLeadIssuerId: joi.number().allow(null),
        userSelectParams: joi.object(),
        issuerIds: joi.array().items(joi.number()),
        static: joi.boolean()
      }));

      frisby.create('configurationService.saveGroup() saves group as is')
        .put(`${apiBaseUrl}/api/group/data/${TEST_GROUP_ID}`, data)
        .expectStatus(200)
        .afterJSON((groupData) => {
          expect(groupData).toHaveJoiSchema(GroupResponseSchema);
          expect(groupData.id).toBe(TEST_GROUP_ID);
        })
        .toss();

      frisby.create('configurationService.saveGroup() saves group with duplicate name')
        .put(`${apiBaseUrl}/api/group/data/${TEST_GROUP_ID}`, { ...data, groupName: EXISTING_NAME })
        .expectStatus(400)
        .afterJSON((groupData) => {
          expect(groupData).toHaveJoiSchema(ErrorSchema);
          expect(groupData.code).toBe(DUPLICATE_NAME_ERROR_CODE);
          expect(groupData.message).toBe(`Group with name ${EXISTING_NAME} already exists`);
        })
        .toss();
    })
    .toss();

  frisby.create('configurationService.loadGroupData() load for invalid group id')
    .get(`${apiBaseUrl}/api/group/data/b9c0bda-00d0-46a2-8179-6abfd024fa5d`)
    .expectStatus(404)
    .afterJSON((data) => {
      expect(data).toHaveJoiSchema(ErrorSchema);
      expect(data.code).toBe(NOT_FOUND_ERROR_CODE);
    })
    .toss();

  frisby.create('configurationService.loadGroupFilters() load filters for valid groupDefinitionId')
  .get(buildURL(`${apiBaseUrl}/api/group/meta`, {
    groupDefinitionId: 'issuer-by-sectors'
  }))
  .expectStatus(200)
  .afterJSON((data) => {
    expect(data).toHaveJoiSchema(joi.array().items(joi.object().keys({
      name: joi.string(),
      type: joi.string(),
      multiple: joi.boolean(),
      displayName: joi.string(),
      maxSize: joi.number().allow(null),
      required: joi.boolean(),
      canEdit: joi.boolean().allow(null),
      canView: joi.boolean().allow(null),
      foreignKey: joi.string(),
      valueMap: joi.object(),
      valueList: joi.array().items(joi.object().keys({
        id: joi.string(),
        name: joi.string(),
        description: joi.string().allow(null)
      }))
    })));
  })
  .toss();

  frisby.create('configurationService.loadGroupDefinitionDictionary() load group definition')
    .get(`${apiBaseUrl}/api/group/definition-data`)
    .expectStatus(200)
    .afterJSON((data) => {
      expect(data).toHaveJoiSchema(joi.array().items(joi.object().keys({
        id: joi.string(),
        name: joi.string(),
        groupDefinitions: joi.array().items(joi.object().keys({
          groupLevelId: joi.string(),
          id: joi.string(),
          name: joi.string(),
          queryId: joi.string()
        }))
      })));
    })
    .toss();
}
