import { Notification } from 'react-techstack';

import { SAVE_GROUP } from 'modules/configuration/actions/groupFormActions';
import { SAVE_CONSOLIDATED_FILTER_DATA } from 'modules/configuration/actions/consolidatedIssuerFilterActions';
import { SAVE_ISSUER_GROUPS } from 'modules/configuration/actions/eventScenarioAssignmentActions';
import { LOAD_SHAREABLE_LOBS, SAVE_SELECTED_LOBS, SHARE_SELECTED_LOBS_WITH_MA } from 'modules/configuration/actions/maSharingActions';

export default {
  [SAVE_GROUP.SUCCESS]: ({ formData }) => {
    return Notification.success(
      '',
      `Group was successfully ${formData.id ? 'updated' : 'created'}.`,
      {
        autoDismiss: 5
      }
    );
  },

  [SAVE_CONSOLIDATED_FILTER_DATA.SUCCESS]: () => {
    return Notification.success(
      '',
      'Surveillance Flag data was successfully saved',
      {
        autoDismiss: 5
      }
    );
  },

  [SAVE_CONSOLIDATED_FILTER_DATA.FAILURE]: () => {
    return Notification.error(
      'Sorry',
      'An unexpected error occurred.',
      {
        autoDismiss: 5
      }
    );
  },

  [SAVE_ISSUER_GROUPS.SUCCESS]: () => {
    return Notification.success(
      '',
      'Event/Scenario was successfully assigned.',
      {
        autoDismiss: 5
      }
    );
  },

  [SAVE_ISSUER_GROUPS.FAILURE]: () => {
    return Notification.error(
      'Sorry',
      'An unexpected error occurred.',
      {
        autoDismiss: 5
      }
    );
  },

  [LOAD_SHAREABLE_LOBS.FAILURE]: () => {
    return Notification.error(
      'Sorry',
      'An unexpected error occurred.',
      {
        autoDismiss: 5
      }
    );
  },

  [SAVE_SELECTED_LOBS.SUCCESS]: () => {
    return Notification.success(
      '',
      'Changes to shareable sectors were successfully saved',
      {
        autoDismiss: 5
      }
    );
  },

  [SAVE_SELECTED_LOBS.FAILURE]: () => {
    return Notification.error(
      'Sorry',
      'An unexpected error occurred.',
      {
        autoDismiss: 5
      }
    );
  },

  [SHARE_SELECTED_LOBS_WITH_MA.SUCCESS]: () => {
    return Notification.success(
      '',
      'Selected Sectors were successfully shared with MA',
      {
        autoDismiss: 5
      }
    );
  },

  [SHARE_SELECTED_LOBS_WITH_MA.FAILURE]: () => {
    return Notification.error(
      'Sorry',
      'An unexpected error occurred.',
      {
        autoDismiss: 5
      }
    );
  }
};
