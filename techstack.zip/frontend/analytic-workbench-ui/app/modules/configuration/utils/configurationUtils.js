import {hasPermission} from 'modules/common/utils/permissionsUtils';

export function hasPermissionToConfigureConsolidatedFilter(userPermissions) {
  return hasPermission(userPermissions, 'edit_consolidated_issuer_filter');
}

export function hasPermissionToAssignEventScenarioFlags(userPermissions) {
  return hasPermission(userPermissions, 'assign_issuer_event_scenario_flags');
}
