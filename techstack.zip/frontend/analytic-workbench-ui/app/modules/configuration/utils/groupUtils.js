import { isEqual, values, isEmpty } from 'lodash';

export const EVENT_SCENARIO_GROUP_ID = '7';
export const PARENT_NAME = 'parentName';
export const PARENT_ID = 'parentIds';

export function isSortColumn(column) {
  return !!column.queryId;
}

export function isFilterColumn(column, alreadyFilters) {
  return isSortColumn(column) && !alreadyFilters.includes(column.queryId);
}

export function prepareDictionariesColumns(columns, alreadyFilters) {
  return columns.filter((column) => isFilterColumn(column, alreadyFilters));
}

export function shouldSearch(props, nextProps) {
  return nextProps.needle !== props.needle;
}

export function shouldSort(props, nextProps) {
  const { sortKey, ascending } = props;
  return nextProps.sortKey && (nextProps.sortKey !== sortKey || ascending !== nextProps.ascending);
}

export function shouldFilter(props, nextProps) {
  return !isEqual(props.tableFilters, nextProps.tableFilters);
}

function makeComparator(key, ascending) {
  const before = ascending ? -1 : 1;

  return (a, b) => {
    const ak = a[key] ? a[key].name : '';
    const bk = b[key] ? b[key].name : '';
    if (ak === bk) {
      return 0;
    }
    return ak < bk ? before : -before;
  };
}

export function sortMembers(items, key, ascending) {
  const list = items.slice();
  return list.sort(makeComparator(key, ascending));
}

export function searchMembers(members, searchNeedle) {
  if (!searchNeedle) {
    return members;
  }
  const needle = searchNeedle.toLowerCase();
  return members.filter(({ searchKey }) => searchKey.includes(needle));
}

function areEmptyFilters(filters) {
  return values(filters).every((filter) => isEmpty(filter));
}

export function filterMembers(members, tableFilters) {
  if (areEmptyFilters(tableFilters)) {
    return members;
  }
  const filterKeys = Object.keys(tableFilters);
  return members.filter((member) => filterKeys.every((key)  =>
    !tableFilters[key].length || member[key] && tableFilters[key].includes(member[key].id)
  ));
}

export function prepareTableDictionary(dictionary, columns) {
  return columns.reduce((res, { queryId, key }) => {
    res[key] = dictionary[queryId];
    return res;
  }, {});
}
