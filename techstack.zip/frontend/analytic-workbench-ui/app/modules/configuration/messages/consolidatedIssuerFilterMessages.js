const MESSAGES = {
  pageTitle: 'Surveillance Flag Assignment', // 'Consolidated Issuer Filter'
  rationale: {
    label: 'Rationale'
  },
  category: {
    label: 'Surveillance Flag' // 'Consolidated Issuer Filter'
  }
};

export default MESSAGES;
