const MESSAGES = {
  error: {
    DUPLICATE_NAME: 'Group with name %1s already  exists',
    NOT_FOUND: 'Group with id %1s not found',
    NO_PERMISSION: '%1s is already defined as a Group Lead for group $2. Please select another issuer as the Group Lead.',
    NO_PERMISSION_PEER_GROUP: 'You are not the lead analyst or permissioned manager for %1s %2s',
    ALREADY_DEFINED_GROUP_LEAD: '%1s %2i is already defined as a Group Lead for group %3s. Please select another issuer as the Group Lead.',
    DEFAULT: 'An unexpected error occurred'
  }
};

export default MESSAGES;
