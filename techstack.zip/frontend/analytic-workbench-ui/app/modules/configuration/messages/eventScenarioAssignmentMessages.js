const MESSAGES = {
  pageTitle: 'Event/Scenario Assignment'
};

export default MESSAGES;
