import { handleActions } from 'react-techstack/redux';
import isPlainObject from 'lodash/isPlainObject';

import {
  LOAD_GROUP_DEFINITION_DICTIONARY,
  LOAD_GROUP_FILTERS,
  APPLY_STATIC_ISSUERS_OVERWRITE,
  LOAD_GROUP_MEMBERS,
  APPLY_GROUP_MEMBERS_FILTER,
  APPLY_GROUP_MEMBERS_NAME_SEARCH,
  APPLY_GROUP_MEMBERS_SORT,
  RESET_GROUP_MEMBERS_TABLE,
  LOAD_TABLE_FILTERS_DICTIONARY,
  SAVE_GROUP, RESET_FILTERS,
  LOAD_GROUP,
  GET_GENERATED_GROUP_NAME
 } from '../actions/groupFormActions';


const initialState = {
  dictionary: {
    groupLevel: []
  },
  tableDictionary: {},
  filtersDictionary: {
    lob: [],
    sector: [],
    region: []
  },
  groupIsDefinedById: null,
  filterFields: [],
  members: {
    records: [],
    columns: []
  },
  needle: '',
  filters: {},
  tableFilters: {},
  sortKey: null,
  ascending: false,
  isTableShown: false,
  areFiltersShown: false,
  groupSaved: false,
  errors: [],
  errorsParams: [],
  defaultValues: {},
  failedValues: {},
  data: {},
  filterQueryIds: [],
  areFiltersLoaded: false,
  overwriteStaticIssuers: false,
  generatedGroupName: {}
};

function getInitialState() {
  return initialState;
}

export default handleActions({

  [LOAD_GROUP_DEFINITION_DICTIONARY.REQUEST](state) {
    return {
      ...state,
      filterFields: [],
      isTableShown: false,
      areFiltersShown: false
    };
  },
  [LOAD_GROUP_DEFINITION_DICTIONARY.SUCCESS](state, action) {
    return {
      ...state,
      dictionary: {
        ...state.dictionary,
        groupLevel: action.payload
      }
    };
  },
  [LOAD_GROUP_FILTERS.REQUEST](state, action) {
    return {
      ...state,
      groupIsDefinedById: action.meta.groupIsDefinedById,
      isTableShown: false,
      areFiltersShown: true,
      areFiltersLoaded: false
    };
  },
  [LOAD_GROUP_FILTERS.SUCCESS](state, action) {
    return {
      ...state,
      filterFields: action.payload.controls,
      filtersDictionary: action.payload.dictionaries,
      filterQueryIds: action.payload.filterQueryIds,
      areFiltersLoaded: true
    };
  },
  [LOAD_GROUP_MEMBERS.REQUEST](state) {
    return {
      ...state,
      isTableShown: true
    };
  },
  [APPLY_STATIC_ISSUERS_OVERWRITE](state) {
    return {
      ...state,
      overwriteStaticIssuers: true
    };
  },
  [LOAD_GROUP_MEMBERS.SUCCESS](state, action) {
    return {
      ...state,
      members: action.payload
    };
  },
  [LOAD_GROUP_MEMBERS.FAILURE](state) {
    return {
      ...state,
      membersErrors: ['UNEXPECTED']
    };
  },
  [APPLY_GROUP_MEMBERS_FILTER](state, action) {
    return {
      ...state,
      tableFilters: {
        ...state.tableFilters,
        [action.attributeName]: action.options
      }
    };
  },
  [APPLY_GROUP_MEMBERS_NAME_SEARCH](state, action) {
    return {
      ...state,
      needle: action.needle
    };
  },
  [APPLY_GROUP_MEMBERS_SORT](state, action) {
    return {
      ...state,
      sortKey: action.sortKey,
      ascending: action.ascending
    };
  },
  [RESET_GROUP_MEMBERS_TABLE](state, action)  {
    return {
      ...state,
      filters: action.filters,
      tableDictionary: null,
      tableFilters: {},
      needle: '',
      sortKey: null,
      members: initialState.members
    };
  },
  [LOAD_TABLE_FILTERS_DICTIONARY.SUCCESS](state, action) {
    return {
      ...state,
      tableDictionary: action.payload
    };
  },
  [SAVE_GROUP.FAILURE](state, action) {
    const error = action.payload.data;
    return {
      ...state,
      errors: [isPlainObject(error) ? error.code : error],
      errorsParams: isPlainObject(error) ? error.params : [],
      failedValues: action.formData
    };
  },
  [SAVE_GROUP.REQUEST](state) {
    return {
      ...state,
      groupSaved: false
    };
  },
  [SAVE_GROUP.SUCCESS](state, action) {
    const isEdit = !!action.formData.id;
    return {
      ...state,
      defaultValues: action.formData,
      areFiltersShown: isEdit,
      groupSaved: true,
      errors: [],
      errorsParams: [],
      isTableShown: isEdit
    };
  },
  [RESET_FILTERS](state) {
    return {
      ...state,
      filters: {},
      areFiltersShown: false,
      isTableShown: false
    };
  },
  [LOAD_GROUP.SUCCESS](state, action) {
    return {
      ...state,
      data: action.payload.data,
      filters: action.payload.data.userSelectParams,
      dictionary: {
        ...state.dictionary,
        ...action.payload.attributes,
        groupLevel: action.payload.definition
      },
      filterFields: action.payload.filtersData.controls,
      filtersDictionary: action.payload.filtersData.dictionaries,
      filterQueryIds: action.payload.filtersData.filterQueryIds,
      areFiltersShown: true,
      areFiltersLoaded: true,
      isTableShown: true,
      members: action.payload.members
    };
  },
  [LOAD_GROUP.FAILURE](state, action) {
    const error = action.payload.data;
    const errors = action.payload.status === 404 ? ['NOT_FOUND'] : null;
    return {
      ...state,
      errors: errors || [isPlainObject(error) ? error.code : error]
    };
  },
  [GET_GENERATED_GROUP_NAME.REQUEST](state) {
    return {
      ...state,
      generatedGroupName: initialState.generatedGroupName
    };
  },
  [GET_GENERATED_GROUP_NAME.SUCCESS](state, action) {
    return {
      ...state,
      generatedGroupName: {
        data: action.payload.data,
        issuerId: action.payload.issuerId
      }
    };
  }
}, getInitialState());
