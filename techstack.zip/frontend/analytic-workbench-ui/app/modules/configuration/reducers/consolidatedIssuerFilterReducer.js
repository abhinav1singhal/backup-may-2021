import { handleActions } from 'react-techstack/redux';

import {
  LOAD_CONSOLIDATED_FILTER_DICTIONARY,
  LOAD_CONSOLIDATED_FILTER_DATA,
  SAVE_CONSOLIDATED_FILTER_DATA
} from '../actions/consolidatedIssuerFilterActions';

const initialState = {
  dictionary: {
    category: [],
    rationale: []
  },
  data: {
    categoryId: null,
    rationaleId: null
  }
};

function getInitialState() {
  return initialState;
}

export default handleActions({
  [LOAD_CONSOLIDATED_FILTER_DICTIONARY.SUCCESS](state, action) {
    return {
      ...state,
      dictionary: {
        ...state.dictionary,
        ...action.payload
      }
    };
  },
  [LOAD_CONSOLIDATED_FILTER_DATA.REQUEST](state) {
    return {
      ...state,
      data: initialState.data
    };
  },
  [LOAD_CONSOLIDATED_FILTER_DATA.SUCCESS](state, action) {
    return {
      ...state,
      data: {
        ...action.payload
      }
    };
  },
  [SAVE_CONSOLIDATED_FILTER_DATA.SUCCESS](state, action) {
    return {
      ...state,
      data: {
        ...action.formData
      }
    };
  }
}, getInitialState());
