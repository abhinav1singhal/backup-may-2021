import { handleActions } from 'react-techstack/redux';
import {
  LOAD_SHAREABLE_LOBS,
  TOGGLE_SHAREABLE_LOB
} from 'modules/configuration/actions/maSharingActions';
import { map, get } from 'lodash';

const initialState = {
  shareableLobs: [],
  loaded: false
};

export default handleActions({

  [LOAD_SHAREABLE_LOBS.REQUEST]() {
    return initialState;
  },

  [LOAD_SHAREABLE_LOBS.SUCCESS](state, { payload }) {
    return {
      ...state,
      shareableLobs: payload,
      loaded: true
    };
  },

  [TOGGLE_SHAREABLE_LOB](state, { lobId }) {
    return {
      ...state,
      shareableLobs: map(state.shareableLobs, (shareableLob) => {
        if (lobId && get(shareableLob, 'id') === lobId) {
          return {
            ...shareableLob,
            shareable: !shareableLob.shareable
          };
        }

        return shareableLob;
      })
    };
  }

}, initialState);
