import { handleActions } from 'react-techstack/redux';
import { isPlainObject } from 'lodash';

import {
  LOAD_EVENT_SCENARIO_DICTIONARY,
  LOAD_ISSUER_GROUPS,
  SAVE_ISSUER_GROUPS,
  LOAD_DEFAULT_ISSUER
} from '../actions/eventScenarioAssignmentActions';

const initialState = {
  dictionary: {
    groups: [],
    issuers: []
  },
  groupList: [],
  responseError: null,
  defaultIssuerId: null
};

function handleFailure(state, action) {
  const { data } = action.payload;
  const responseError = isPlainObject(data) ? data.code : 'UNEXPECTED';

  return {
    ...state,
    responseError
  };
}

export default handleActions({
  [LOAD_EVENT_SCENARIO_DICTIONARY.REQUEST]() {
    return initialState;
  },
  [LOAD_EVENT_SCENARIO_DICTIONARY.SUCCESS](state, action) {
    return {
      ...state,
      dictionary: action.payload,
      responseError: null
    };
  },
  [LOAD_ISSUER_GROUPS.SUCCESS](state, action) {
    return {
      ...state,
      groupList: action.payload,
      responseError: null
    };
  },
  [SAVE_ISSUER_GROUPS.SUCCESS](state, action) {
    return {
      ...state,
      groupList: action.meta.groupList,
      responseError: null
    };
  },
  [LOAD_DEFAULT_ISSUER.SUCCESS](state, action) {
    return {
      ...state,
      defaultIssuerId: action.payload.id
    };
  },
  [LOAD_EVENT_SCENARIO_DICTIONARY.FAILURE]: handleFailure,
  [LOAD_ISSUER_GROUPS.FAILURE]: handleFailure,
  [SAVE_ISSUER_GROUPS.FAILURE]: handleFailure
}, initialState);
