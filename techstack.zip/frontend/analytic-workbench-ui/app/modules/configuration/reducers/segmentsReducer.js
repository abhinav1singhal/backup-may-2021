import { handleActions } from 'react-techstack/redux';
import { orderBy, groupBy } from 'lodash';

import { LOAD_SEGMENTS, SAVE_SEGMENTS, LOAD_PREVIEW } from 'modules/issuerManagement/actions/issuerManagementActions';

function getStateOrgSegments(orgSegments) {
  return groupBy(
    orderBy(orgSegments, 'index'),
    'segment.type.code'
  );
}

const initialState = {
  orgSegments: {},
  segmentTypes: [],
  previewData: [],
  responseError: null
};

export default handleActions({
  [LOAD_SEGMENTS.REQUEST]() {
    return initialState;
  },
  [LOAD_SEGMENTS.SUCCESS](state, { payload: { orgSegments, segmentTypes } }) {
    return {
      ...state,
      orgSegments: getStateOrgSegments(orgSegments),
      segmentTypes
    };
  },
  [LOAD_SEGMENTS.FAILURE](state) {
    return {
      ...state,
      responseError: 'UNEXPECTED'
    };
  },
  [SAVE_SEGMENTS.SUCCESS](state, { payload: { orgSegments } }) {
    return {
      ...state,
      orgSegments: getStateOrgSegments(orgSegments)
    };
  },
  [LOAD_PREVIEW.REQUEST](state) {
    return {
      ...state,
      previewData: initialState.previewData
    };
  },
  [LOAD_PREVIEW.SUCCESS](state, { payload }) {
    return {
      ...state,
      previewData: payload.preview
    };
  }
}, initialState);
