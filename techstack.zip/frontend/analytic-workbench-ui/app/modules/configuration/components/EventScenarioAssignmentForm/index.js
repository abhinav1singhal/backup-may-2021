export default from './EventScenarioAssignmentFormContainer';
