import { connect } from 'react-redux';
import { asyncStatusUtils } from 'react-techstack/utils';
import { prepareIntValue } from 'utils/urlQueryUtils';

import {
  loadEventScenarioDictionary,
  loadIssuerGroups,
  saveIssuerGroups,
  loadDefaultIssuer
} from 'modules/configuration/actions/eventScenarioAssignmentActions';
import EventScenarioAssignmentForm from './EventScenarioAssignmentForm';
import { hasPermissionToAssignEventScenarioFlags } from 'modules/configuration/utils/configurationUtils';

const { isPending } = asyncStatusUtils;

function mapStateToProps(state, { urlQuery }) {
  const { groupList, dictionary, responseError } = state.configuration.eventScenarioAssignment;
  const defaultIssuerId = prepareIntValue(urlQuery.issuerId) || state.configuration.eventScenarioAssignment.defaultIssuerId;

  return {
    isLoading: (
      isPending(state.requests.loadEventScenarioDictionary.status) ||
      isPending(state.requests.loadIssuerGroups.status) ||
      isPending(state.requests.saveIssuerGroups.status)
    ),
    groupList,
    dictionary,
    responseError,
    defaultIssuerId,
    editMode: hasPermissionToAssignEventScenarioFlags(state.user.permissions)
  };
}

const mapDispatchToProps = {
  loadDictionary: loadEventScenarioDictionary,
  loadIssuerGroups,
  saveIssuerGroups,
  loadDefaultIssuer
};

export default connect(mapStateToProps, mapDispatchToProps)(EventScenarioAssignmentForm);
