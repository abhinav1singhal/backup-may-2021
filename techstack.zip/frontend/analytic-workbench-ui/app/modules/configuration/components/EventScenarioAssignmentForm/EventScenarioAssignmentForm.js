/* eslint-disable react/no-set-state */
import PropTypes from 'prop-types';

import React, { Component } from 'react';
import { Button } from 'react-techstack';
import Select from 'modules/configuration/components/Select';
import theme from './EventScenarioAssignmentForm.css';

// TODO: Refactor this form using FormBuilder
class EventScenarioAssignmentForm extends Component {
  static propTypes = {
    defaultIssuerId: PropTypes.number,
    isLoading: PropTypes.bool.isRequired,
    groupList: PropTypes.arrayOf(PropTypes.object).isRequired,
    dictionary: PropTypes.shape({
      issuers: PropTypes.arrayOf(PropTypes.object).isRequired,
      groups: PropTypes.arrayOf(PropTypes.object).isRequired
    }).isRequired,
    editMode: PropTypes.bool.isRequired,
    responseError: PropTypes.string,

    loadDictionary: PropTypes.func.isRequired,
    loadIssuerGroups: PropTypes.func.isRequired,
    saveIssuerGroups: PropTypes.func.isRequired,
    loadDefaultIssuer: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props);

    this.state = {
      issuer: null,
      groupList: [],
      isSubmitted: false
    };
  }

  UNSAFE_componentWillMount() {
    this.props.loadDictionary();
    if (!this.props.defaultIssuerId) {
      this.props.loadDefaultIssuer();
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.dictionary !== nextProps.dictionary || this.props.defaultIssuerId !== nextProps.defaultIssuerId) {
      this.checkDefaultIssuer(nextProps);
    }
    if (this.props.groupList !== nextProps.groupList) {
      const { dictionary } = nextProps;
      const groupList = nextProps.groupList.map(({ id }) => id);
      this.setState({
        groupList: dictionary.groups.filter(({ id }) => groupList.includes(id)),
        isSubmitted: false
      });
    }
  }

  onGroupListChange = (groupList) => {
    this.setState({ groupList });
  };

  onIssuerChange = (issuer) => {
    this.setState({ issuer });
    this.props.loadIssuerGroups(issuer.id);
  };

  checkDefaultIssuer(nextProps) {
    const issuer = nextProps.defaultIssuerId && nextProps.dictionary.issuers.find(({ id }) => id === nextProps.defaultIssuerId);
    this.setState({ issuer });
    if (issuer) {
      nextProps.loadIssuerGroups(issuer.id);
    }
  }

  isFormControlDisabled = () => {
    const { isLoading, editMode } = this.props;
    return isLoading || !editMode || !this.state.issuer;
  };

  isSubmitDisabled() {
    return this.props.isLoading || !this.state.issuer;
  }

  submit = (event) => {
    event.preventDefault();
    if (this.isSubmitDisabled()) {
      return;
    }

    this.setState({ isSubmitted: true });
    const { issuer, groupList } = this.state;
    this.props.saveIssuerGroups(issuer.id, groupList);
  };

  renderIssuerSelect() {
    const SelectProps = {
      options: this.props.dictionary.issuers,
      multiple: false,
      value: this.state.issuer,
      onChange: this.onIssuerChange,
      required: false,
      label: 'Issuer',
      isSubmitted: this.state.isSubmitted,
      disabled: false,
      clearable: true,
      parentClassName: theme.select,
      labelClassName: theme.label,
      wrapperClassName: theme.wrapper,
      labelKey: 'label',
      valueKey: 'label'
    };
    return <Select {...SelectProps} />;
  }

  renderEventScenarioSelect() {
    const SelectProps = {
      options: this.props.dictionary.groups,
      multiple: true,
      value: this.state.groupList,
      onChange: this.onGroupListChange,
      required: false,
      label: 'Event/Scenario',
      isSubmitted: this.state.isSubmitted,
      disabled: this.isFormControlDisabled(),
      clearable: true,
      parentClassName: theme.select,
      labelClassName: theme.label,
      wrapperClassName: theme.wrapper
    };

    return <Select {...SelectProps} />;
  }

  renderButtons() {
    const btnProps = {
      type: 'submit',
      bsStyle: 'primary',
      disabled: this.isSubmitDisabled(),
      className: theme.submitBtn
    };

    return (
      <div className={theme.buttons}>
         <Button {...btnProps}>Save</Button>
      </div>
    );
  }


  render() {
    const { editMode } = this.props;

    return (
      <form noValidate onSubmit={this.submit} className={theme.root}>
        {this.renderIssuerSelect()}
        {this.renderEventScenarioSelect()}
        {editMode && this.renderButtons()}
      </form>
    );
  }
}

export default EventScenarioAssignmentForm;
