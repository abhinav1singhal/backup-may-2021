export default from './MASharingContainer';
