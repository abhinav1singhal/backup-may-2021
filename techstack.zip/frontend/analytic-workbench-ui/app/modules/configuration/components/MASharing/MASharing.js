import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { DataTableBare, DataTableCell, Checkbox, Button } from 'react-techstack';
import { hasPermission } from 'modules/common/utils/permissionsUtils';
import { get } from 'lodash';
import theme from './MASharing.css';

import { asyncStatusUtils, asyncStatusTypes } from 'react-techstack/utils';
const { asyncRequestType } = asyncStatusTypes;
const { isPending } = asyncStatusUtils;

const HEADER_HEIGHT = 50;
const ROW_HEIGHT = 40;
const TABLE_OFFSET = 60;

class MASharing extends Component {

  componentDidMount() {
    this.props.loadShareableLobs();
  }

  save = () => {
    const { shareableLobs, saveSelectedLobs } = this.props;

    saveSelectedLobs(shareableLobs);
  }

  share = () => {
    const { shareSelectedLobsWithMA } = this.props;

    shareSelectedLobsWithMA();
  }

  renderCell = (data, key, row, cellProps) => {

    let content;

    switch (key) {
      case 'shareable':
        const checkboxProps = {
          checked: get(row, 'shareable'),
          className: theme.checkbox,
          onClick: () => {
            this.props.toggleLobSharing(get(row, 'id'));
          }
        };

        content = <Checkbox {...checkboxProps} />;
        break;

      default:
        content = data;
    }

    return (
      <DataTableCell {...cellProps} >
        { content || '' }
      </DataTableCell>
    );
  }

  renderButtons = () => {

    const { saveSelectedLobsRequest, shareSelectedLobsWithMARequest } = this.props;

    const savePending = isPending(saveSelectedLobsRequest.status);
    const sharePending = isPending(shareSelectedLobsWithMARequest.status);

    const savingButtonProps = {
      bsStyle: 'primary',
      onClick: this.save,
      disabled: savePending,
      block: true
    };

    const sharingButtonProps = {
      onClick: this.share,
      disabled: sharePending,
      block: true
    };

    return (
      <div className={theme.buttons}>
        <Button {...savingButtonProps}>
          {savePending
            ? 'Saving...'
            : 'Save'
          }
        </Button>
        <Button {...sharingButtonProps}>
          {sharePending
            ? 'Sharing...'
            : 'Share Selected With MA'
          }
        </Button>
      </div>
    );
  }

  render() {
    const { shareableLobs, userPermissions } = this.props;

    if (!shareableLobs.length) {
      return (
        <div>
          There is no Analityc Sectors 2
        </div>
      );
    }

    const DataTableProps = {
      columns: [
        { key: 'name', label: 'Analytic Sector 2' },
        { key: 'shareable', label: 'Shared With MA', width: 150 }
      ],
      data: shareableLobs,
      cell: this.renderCell,
      type: 'bordered',
      width: 'auto',
      height: shareableLobs.length > 0
        ? ROW_HEIGHT * shareableLobs.length + TABLE_OFFSET
        : ROW_HEIGHT,
      headerHeight: HEADER_HEIGHT,
      rowHeight: ROW_HEIGHT
    };

    const userHasPermissions = hasPermission(userPermissions, 'edit_lob_ma_sharing');

    return (
      <div>
        <DataTableBare {...DataTableProps} />
        { userHasPermissions ? this.renderButtons() : null }
      </div>
    );
  }
}

MASharing.propTypes = {
  loadShareableLobs: PropTypes.func.isRequired,
  toggleLobSharing: PropTypes.func.isRequired,
  saveSelectedLobs: PropTypes.func.isRequired,
  shareSelectedLobsWithMA: PropTypes.func.isRequired,
  shareableLobs: PropTypes.array,
  saveSelectedLobsRequest: asyncRequestType.isRequired,
  shareSelectedLobsWithMARequest: asyncRequestType.isRequired,
  userPermissions: PropTypes.array
};

MASharing.defaultProps = {
  shareableLobs: []
};

export default MASharing;
