import { connect } from 'react-redux';
import { get } from 'lodash';
import MASharing from './MASharing';
import {
  loadShareableLobs,
  toggleLobSharing,
  saveSelectedLobs,
  shareSelectedLobsWithMA
} from 'modules/configuration/actions/maSharingActions';

const mapStateToProps = (state) => ({
  shareableLobs: get(state, 'maSharing.shareableLobs', []),
  saveSelectedLobsRequest: state.requests.saveSelectedLobs,
  shareSelectedLobsWithMARequest: state.requests.shareSelectedLobsWithMA,
  userPermissions: state.user.permissions
});

const mapDispatchToProps = {
  loadShareableLobs,
  toggleLobSharing,
  saveSelectedLobs,
  shareSelectedLobsWithMA
};

export default connect(mapStateToProps, mapDispatchToProps)(MASharing);
