import { connect } from 'react-redux';
import { asyncStatusUtils } from 'react-techstack/utils';
import GroupAttributesForm from './GroupAttributesForm';

const { isPending } = asyncStatusUtils;

function mapStateToProps(state) {
  const { dictionaries } = state.surveillance;
  return {
    options: {
      type: dictionaries.type,
      groupLeadIssuerId: dictionaries.groupLeadIssuerId,
      groupStatus: dictionaries.groupStatus,
      tier: dictionaries.tier
    },
    isGroupNameLoading: isPending(state.requests.groupAttributesNameLoad.status)
  };
}

export default connect(mapStateToProps, null, null, { forwardRef: true })(GroupAttributesForm);
