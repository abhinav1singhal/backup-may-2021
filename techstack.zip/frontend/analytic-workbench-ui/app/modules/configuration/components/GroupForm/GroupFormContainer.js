import { connect } from 'react-redux';
import { asyncStatusUtils } from 'react-techstack/utils';

import {
  loadGroupMembers,
  resetGroupMembersTable,
  saveGroup,
  createGroup,
  loadGroupData,
  getGeneratedGroupName
} from 'modules/configuration/actions/groupFormActions';
import { loadGroupAttributesDictionary } from 'modules/surveillance/actions/surveillanceFormActions';
import GroupForm from './GroupForm';

const { isPending, isFailed } = asyncStatusUtils;

function mapStateToProps(state) {
  return {
    isLoading: isPending(state.requests.groupAttributesDictionary.status) ||
      isPending(state.requests.saveGroup.status) ||
      isPending(state.requests.loadGroup.status),
    isFailed: isFailed(state.requests.groupAttributesDictionary.status) ||
      isFailed(state.requests.loadGroup.status),
    isTableShown: state.configuration.groupForm.isTableShown,
    areFiltersLoaded: state.configuration.groupForm.areFiltersLoaded,
    errors: state.configuration.groupForm.errors,
    errorsParams: state.configuration.groupForm.errorsParams,
    saved: state.configuration.groupForm.groupSaved,
    defaultValues: state.configuration.groupForm.defaultValues,
    failedValues: state.configuration.groupForm.failedValues,
    data: state.configuration.groupForm.data,
    dictionary: state.configuration.groupForm.dictionary,
    filtersDictionary: state.configuration.groupForm.filtersDictionary,
    generatedGroupName: state.configuration.groupForm.generatedGroupName
  };
}

const mapDispatchToProps = {
  loadGroupAttributesDictionary,
  loadGroupMembers,
  resetGroupMembersTable,
  saveGroup,
  createGroup,
  loadGroupData,
  getGeneratedGroupName
};

export default connect(mapStateToProps, mapDispatchToProps)(GroupForm);
