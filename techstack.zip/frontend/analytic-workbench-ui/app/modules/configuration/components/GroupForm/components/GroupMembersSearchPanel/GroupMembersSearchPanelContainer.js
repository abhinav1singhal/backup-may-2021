import { connect } from 'react-redux';

import { applyGroupMembersNameSearch } from 'modules/configuration/actions/groupFormActions';
import GroupMembersSearchPanel from './GroupMembersSearchPanel';

function mapStateToProps(state) {
  return {
    value: state.configuration.groupForm.needle
  };
}

const mapDispatchToProps = {
  applyGroupMembersNameSearch
};

export default connect(mapStateToProps, mapDispatchToProps)(GroupMembersSearchPanel);
