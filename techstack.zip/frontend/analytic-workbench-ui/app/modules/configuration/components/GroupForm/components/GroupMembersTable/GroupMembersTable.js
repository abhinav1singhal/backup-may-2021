/* eslint-disable react/no-set-state */
import PropTypes from 'prop-types';

import React, { Component } from 'react';
import clasNames from 'classnames';
import { isPlainObject, noop } from 'lodash';

import { DataTableBare, DataTableCell, Panel, Checkbox, LoadingContainer, Alert } from 'react-techstack';
import FilterHeaderCell from '../FilterHeaderCell';
import GroupMembersSearchPanel from '../GroupMembersSearchPanel';
import SortCell from '../SortCell';
import { isFilterColumn, isSortColumn, shouldSort, sortMembers, shouldSearch, searchMembers, shouldFilter, filterMembers } from 'modules/configuration/utils';

import theme from './GroupMembersTable.css';

function getSelectedNumber(members, selection) {
  return members.reduce((res, { id }) => res + selection.has(id), 0);
}

function prepareSelectedMembers(members, selection) {
  return members.filter(({ id }) => selection.has(id));
}

class GroupMembersTable extends Component {
  static propTypes = {
    members: PropTypes.arrayOf(PropTypes.object).isRequired,
    columns: PropTypes.arrayOf(PropTypes.object),
    isLoading: PropTypes.bool,
    reloadGroupMembers: PropTypes.func.isRequired,
    resetSearch: PropTypes.func.isRequired,
    onChange: PropTypes.func.isRequired,
    selectedNumber: PropTypes.number.isRequired,
    selection: PropTypes.object.isRequired,
    isSelectingManually: PropTypes.bool,
    shouldUpdateOnToggle: PropTypes.bool,
    removeFromSelection: PropTypes.func.isRequired,
    addToSelection: PropTypes.func.isRequired,
    filterQueryIds: PropTypes.arrayOf(PropTypes.string).isRequired,
    isFailed: PropTypes.bool,
    errors: PropTypes.array
  };

  constructor(props) {
    super(props);

    this.toggleSelectManually = this.toggleSelectManually.bind(this);
    this.toggleSelectedAll = this.toggleSelectedAll.bind(this);
    this.onClick = {};
    this.visibleSelected = 0;
    this.toggleSelectedOnly = this.toggleSelectedOnly.bind(this);
    this.sortableColumns = {};

    this.state = {
      members: props.members,
      isSelectedOnly: false
    };
  }

  componentDidMount() {
    if (this.props.isSelectingManually) {
      this.toggleSelectedOnly();
    }
  }

  UNSAFE_componentWillReceiveProps(props) {
    if (props.members === this.props.members) {
      const needFilter = shouldSearch(this.props, props) || shouldFilter(this.props, props);
      if (needFilter || shouldSort(this.props, props)) {
        let members = this.state.members;
        if (needFilter) {
          const { needle, tableFilters } = props;
          members = filterMembers(searchMembers(props.members, needle), tableFilters);
        }
        if (props.sortKey) {
          members = sortMembers(members, props.sortKey, props.ascending);
        }
        this.setState({ members });
        this.visibleSelected = getSelectedNumber(members, props.selection);
      }
      if (props.selectedNumber === 0 && this.state.isSelectedOnly) {
        this.setState({ isSelectedOnly: false });
      }
    } else {
      this.setState({ members: props.members, isSelectedOnly: false });
      this.visibleSelected = getSelectedNumber(props.members, props.selection);
    }
  }

  getColumns() {
    const columns = this.props.columns.filter(({ key }) => key !== 'id');
    if (this.props.isSelectingManually && this.props.columns.length) {
      return [
        { key: 'selected', width: 40 },
        ...columns
      ];
    }

    return columns;
  }

  getContent(data, key, row, cellProps) {
    if (this.props.isSelectingManually) {
      if (this.onClick[row.id]) {
        cellProps.onClick = this.onClick[row.id];
      } else  {
        this.onClick[row.id] = cellProps.onClick = (e) => this.toggleSelectedRow(e, row.id);
      }
    }

    switch (key) {
      case 'selected':
        return <Checkbox checked={this.props.selection.has(row.id)} />;
      case 'issuer':
        return isPlainObject(data) ? data.label : '';
      default:
        return isPlainObject(data) ? data.name : '';
    }
  }

  getErrorMessage(errorKey) {
    switch (errorKey) {
      default:
        return 'An unexpected error occurred';
    }
  }

  toggleSelectManually() {
    if (!this.props.isSelectingManually && this.props.shouldUpdateOnToggle) {
      this.props.resetSearch();
      this.props.reloadGroupMembers();
    } else if (this.props.isSelectingManually) {
      this.setState({ isSelectedOnly: false });
    }
    this.props.onChange({ isSelectingManually: !this.props.isSelectingManually });
  }

  toggleSelectedOnly() {
    this.setState({ isSelectedOnly: !this.state.isSelectedOnly });
  }

  toggleSelectedRow(e, rowId) {
    e.preventDefault();

    const selected = this.props.selection.has(rowId);
    if (selected) {
      this.props.removeFromSelection(rowId);
      --this.visibleSelected;
    } else {
      this.props.addToSelection(rowId);
      ++this.visibleSelected;
    }
  }

  toggleSelectedAll() {
    const areAllSelected = this.areAllSelected();
    const { members, isSelectedOnly } = this.state;

    const visibleIds = isSelectedOnly ? [...this.props.selection] : members.map(({ id }) => id);
    if (areAllSelected) {
      this.props.removeFromSelection(...visibleIds);
      this.visibleSelected = 0;
    } else {
      this.props.addToSelection(...visibleIds);
      this.visibleSelected = visibleIds.length;
    }
  }

  areAllSelected() {
    return this.visibleSelected > 0 && this.visibleSelected === this.state.members.length || this.state.isSelectedOnly;
  }

  isEmptyListShown() {
    return !this.state.isSelectedOnly && this.state.members.length === 0;
  }

  cell = (data, key, row, cellProps) => {
    return (
      <DataTableCell {...cellProps}>
        {this.getContent(data, key, row, cellProps) || ''}
      </DataTableCell>
    );
  }

  headerCell = (cellProps, cellContent) => {
    if (cellProps.columnKey === 'selected') {
      const checkboxProps = {
        checked: this.areAllSelected(),
        onClick: this.toggleSelectedAll,
        disabled: this.isEmptyListShown()
      };

      return (
        <Checkbox {...checkboxProps} />
      );
    }

    let cell = cellContent;
    const column = this.props.columns.find(({ key }) => key === cellProps.columnKey);
    if (!this.state.isSelectedOnly && isSortColumn(column)) {
      if (!this.sortableColumns[column.key]) {
        this.sortableColumns[column.key] = cell = (
          <SortCell sortKey={cellProps.columnKey}>
            {cellContent}
          </SortCell>
        );
      } else {
        cell = this.sortableColumns[column.key];
      }
    }

    if (!this.state.isSelectedOnly && isFilterColumn(column, this.props.filterQueryIds)) {
      const filterCellProps = {
        title: cellProps.title,
        attributeType: cellProps.columnKey,
        onApply: noop
      };

      return (
        <FilterHeaderCell {...filterCellProps}>
          {cell}
        </FilterHeaderCell>
      );
    }
    return cell;
  }

  renderSelectManuallyCheckbox() {
    const { isSelectingManually } = this.props;
    const checkboxProps = {
      label: 'Select Objects manually',
      className: clasNames(theme.checkbox, { [theme.checked]: isSelectingManually }),
      checked: isSelectingManually,
      onClick: this.toggleSelectManually
    };

    return (
      <Checkbox  {...checkboxProps} />
    );
  }

  renderSelectedOnly() {
    if (!this.props.isSelectingManually) {
      return null;
    }

    const checkboxProps = {
      label: 'Show Selected Only',
      className: clasNames(theme.checkbox, { [theme.checked]: this.state.isSelectedOnly }),
      checked: this.state.isSelectedOnly,
      onClick: this.toggleSelectedOnly,
      disabled: this.props.selectedNumber === 0
    };

    return <Checkbox {...checkboxProps} />;
  }

  renderSelectedNumber() {
    if (!this.props.isSelectingManually) {
      return null;
    }

    return <div className={theme.selectedNumber}>{this.props.selectedNumber} objects selected</div>;
  }

  renderHeader() {
    return (
      <div className={theme.header}>
        {this.renderSelectManuallyCheckbox()}
        {this.renderSelectedOnly()}
        {this.renderSelectedNumber()}
      </div>
    );
  }

  renderSearchPanel() {
    return <GroupMembersSearchPanel disabled={this.state.isSelectedOnly} />;
  }

  renderNoItemsAlert() {
    return (
      <Alert bsStyle="warning">
        No matching results
      </Alert>
    );
  }

  renderErrors() {
    if (this.props.isFailed) {
      const errorList = this.props.errors.map(this.getErrorMessage);
      if (errorList.length) {
        return (
          <Alert bsStyle="danger">
            {errorList.map((error, index) => <div key={index}>{error}</div>)}
          </Alert>
        );
      }
    }
    return null;
  }

  renderItems() {
    const { members, selection } = this.props;
    if (members.length === 0) {
      return this.renderNoItemsAlert();
    }

    const data = this.state.isSelectedOnly ? prepareSelectedMembers(members, selection) : this.state.members;
    const dataTableProps = {
      data,
      width: 'auto',
      height: data.length > 5 ? 335 : 60 + data.length * 40,
      cell: this.cell,
      headerCell: this.headerCell,
      columns: this.getColumns(),
      rowHeight: 40
    };

    return (
      <div className={theme.root}>
        {this.renderHeader()}
        <Panel header={this.renderSearchPanel()} className={theme.panel}>
          <DataTableBare {...dataTableProps} />
          {this.isEmptyListShown() && this.renderNoItemsAlert()}
        </Panel>
      </div>
    );
  }

  render() {
    return (
      <LoadingContainer isLoading={this.props.isLoading}>
        {this.renderErrors()}
        {!this.props.isFailed && this.renderItems()}
      </LoadingContainer>
    );
  }
}

export default GroupMembersTable;
