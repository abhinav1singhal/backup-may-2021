import { connect } from 'react-redux';
import { asyncStatusUtils } from 'react-techstack/utils';

import { loadTableFiltersDictionary, applyGroupMembersFilter } from 'modules/configuration/actions/groupFormActions';

import FilterHeaderCell from 'modules/analytic/components/FilterHeaderCell/FilterHeaderCell';
const { isPending, isSuccessful } = asyncStatusUtils;

function mapStateToProps(state, ownProps) {
  const { status } = state.requests.groupTableDictionary;
  const isLoading = isPending(status);
  const selectedOptions = state.configuration.groupForm.tableFilters[ownProps.attributeType] || [];
  const { tableDictionary } = state.configuration.groupForm;

  return {
    isLoading,
    needToLoad: !tableDictionary || !isSuccessful(status),
    options: tableDictionary ? tableDictionary[ownProps.attributeType] || [] : [],
    selectedOptions,
    activeFilter: isSuccessful(status) && selectedOptions.length > 0
  };
}

function mapDispatchToProps(dispatch, ownProps) {
  return {
    loadAttributes: () => dispatch(loadTableFiltersDictionary()),
    applyAttributeFilter: (options) => dispatch(applyGroupMembersFilter(ownProps.attributeType, options))
  };
}
export default connect(mapStateToProps, mapDispatchToProps)(FilterHeaderCell);
