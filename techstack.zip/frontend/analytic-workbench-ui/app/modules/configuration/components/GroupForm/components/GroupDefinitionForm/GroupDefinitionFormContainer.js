import { connect } from 'react-redux';
import { asyncStatusUtils } from 'react-techstack/utils';

import { loadGroupDefinitionDictionary, loadGroupFilters, resetFilters } from 'modules/configuration/actions/groupFormActions';
import GroupDefinitionForm from './GroupDefinitionForm';

const { isPending } = asyncStatusUtils;

function mapStateToProps(state) {
  const { dictionary } = state.configuration.groupForm;

  return {
    groupLevelOptions: dictionary.groupLevel,
    isLoading: isPending(state.requests.groupDefinitionData.status),
    areFiltersLoading: isPending(state.requests.groupFilters.status)
  };
}

const mapDispatchToProps = {
  loadGroupDefinitionDictionary,
  loadGroupFilters,
  resetFilters
};

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(GroupDefinitionForm);
