import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { isEqual, isEmpty, isArray, isPlainObject, find, filter, forEach, get, indexOf, map, pick } from 'lodash';
import { mapValues, transform } from 'lodash/object';
import { Button, LoadingContainer, Modal } from 'react-techstack';
import { ConfirmationDialog } from 'modules/issuerManagement/components';
import Select from 'modules/configuration/components/Select';
import { EVENT_SCENARIO_GROUP_ID, PARENT_NAME, PARENT_ID } from 'modules/configuration/utils/groupUtils';
import theme from './GroupFiltersForm.css';

function isEqualFilter(filterA, filterB) {
  if (isEmpty(filterA) && isEmpty(filterB)) {
    return true;
  }
  return isEqual(filterA, filterB);
}

function areEqualFilters(filtersA, filtersB) {
  if (isEmpty(filtersA) && isEmpty(filtersB)) {
    return true;
  }
  return Object.keys(filtersA).every((name) => isEqualFilter(filtersA[name], filtersB[name])) &&
    Object.keys(filtersB).every((name) => isEqualFilter(filtersA[name], filtersB[name]));
}

function isNotUpdated(field, value) {
  return field.multiple && isPlainObject(value) || !field.multiple && isArray(value);
}

// ToDo: change this
function toOptionsIds(filters) {
  return mapValues(filters, (value) => {
    if (isArray(value)) {
      return transform(value, (result, item) => {
        if (isPlainObject(item)) {
          result.push(item.id);
        }
      });
    } else if (isPlainObject(value)) {
      return value.id;
    }

    return undefined;
  });
}

class GroupFiltersForm extends Component {
  static propTypes = {
    options: PropTypes.object.isRequired,
    field: PropTypes.object.isRequired,
    filterFields: PropTypes.arrayOf(PropTypes.object).isRequired,
    resetTable: PropTypes.func.isRequired,
    isLoadingGroupMembers: PropTypes.bool.isRequired,
    isLoading: PropTypes.bool.isRequired,
    areFiltersShown: PropTypes.bool.isRequired,
    onChange: PropTypes.func.isRequired,
    filters: PropTypes.object.isRequired,
    needUpdate: PropTypes.bool,
    validate: PropTypes.func.isRequired,
    clearValidation: PropTypes.func.isRequired,
    overwriteStaticIssuers: PropTypes.bool,
    applyStaticIssuersOverwrite: PropTypes.func.isRequired,
    isStaticGroup: PropTypes.bool,
    groupTypeId: PropTypes.string
  };

  constructor(props) {
    super(props);

    this.state = {
      lastApplied: {},
      isShownConfirmation: false
    };

    this.updateOnChange(props);
    this.showResults = this.showResults.bind(this);
    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.isValid = {};
    props.filterFields.forEach((field) => {
      this.validateField(field, props.filters[field.key]);
    });
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!isEqual(this.props.filterFields, nextProps.filterFields)) {
      nextProps.onChange({ filters: nextProps.filters, needUpdate: !areEqualFilters(this.state.lastApplied, {}) });
      this.updateOnChange(nextProps);
      this.isValid = {};
      nextProps.clearValidation(this.props.filterFields.map(({ key }) => key));
      nextProps.filterFields.forEach((field) => {
        const value = get(nextProps.filters, field.key);
        nextProps.validate(field.key, this.validateField(field, value));
      });
    } else {
      nextProps.filterFields.forEach((field) => {
        const { key } = field;
        if (nextProps.filters[key] !== this.props.filters[key]) {
          nextProps.validate(key, this.validateField(field, nextProps.filters[key]));
        }
      });
    }
    if (!isEqual(this.props.options, nextProps.options)) {
      this.setState({filteredOptions: this.filterOptions(nextProps)});
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    return !isEqual(nextProps, this.props) || !isEqual(nextState.isShownConfirmation, this.state.isShownConfirmation);
  }

  getFieldsProps({ key, ...field }) {
    const value = isNotUpdated(field, this.props.filters[key]) ? null : this.props.filters[key];
    const options = this.state.filteredOptions[key];
    return {
      ...this.props.field,
      ...field,
      disabled: field.disabled || isEmpty(options),
      key,
      labelKey: field.dictionaryKey === 'organizations-all.id' ? 'label' : 'name',
      valid: this.isValid[key],
      options,
      value,
      onChange: this.onChange[key]
    };
  }

  validateField(field, value) {
    if (field.required && isEmpty(value)) {
      this.isValid[field.key] = false;
      return { required: true };
    }
    this.isValid[field.key] = true;
    return { required: false };
  }

  reset = () => {
    this.setState({ lastApplied: {} }); // eslint-disable-line react/no-set-state
    this.props.onChange({ filters: {}, needUpdate: false });
  }

  updateOnChange({ filterFields }) {
    this.onChange = {};
    filterFields.forEach(({ key }) => {
      this.onChange[key] = (value) => this.updateField(value, key);
    });
  }

  filterOptions(props) {
    const { filters, filterFields, options } = props;
    const filteredOptions = { ...options };
    forEach(filterFields, (field) => {
      if (field[PARENT_NAME]) {
        const parentValue = filters[field[PARENT_NAME]];
        this.filterChildOptions(filteredOptions, parentValue, options, field.key);
      }
    });
    return filteredOptions;
  }

  filterChildOptions(options, parentValue, sourceOptions, key) {
    const id = get(parentValue, 'id');
    options[key] = filter(sourceOptions[key], (option) => ~indexOf(option[PARENT_ID], id));
  }

  clearChildsRecursively(fields, key, filters, options, value) {
    const child = find(fields, [PARENT_NAME, key]);
    if (child && child.key) {
      if (filters[child.key]) {
        filters[child.key] = null;
      }
      this.filterChildOptions(options, value, this.props.options, child.key);

      this.clearChildsRecursively(fields, child.key, filters, options);
    }
  }

  checkChilds(value, key) {
    const { filters, filterFields } = this.props;
    const newFilters = pick(filters, map(filterFields, 'key'));
    const filteredOptions = {...this.state.filteredOptions};
    this.clearChildsRecursively(filterFields, key, newFilters, filteredOptions, value);
    this.setState({filteredOptions});

    return {
      ...newFilters,
      [key]: value
    };
  }

  updateField(value, key) {
    const newFilters = this.checkChilds(value, key);


    this.props.onChange({
      filters: newFilters,
      needUpdate: !areEqualFilters(this.state.lastApplied, toOptionsIds(newFilters))
    });
  }

  closeModal() {
    this.setState({ // eslint-disable-line react/no-set-state
      isShownConfirmation: false
    });
  }

  openModal() {
    this.setState({ // eslint-disable-line react/no-set-state
      isShownConfirmation: true
    });
  }

  showResults() {
    const filters = toOptionsIds(this.props.filters);

    this.props.resetTable(filters);
    this.props.onChange({ needUpdate: false });
    this.setState({ lastApplied: filters }); // eslint-disable-line react/no-set-state
  }

  hasErrors() {
    return Object.keys(this.isValid).some((key) => !this.isValid[key]);
  }

  doShowConfirmation() {
    return (this.props.groupTypeId === EVENT_SCENARIO_GROUP_ID && this.props.isStaticGroup && !this.props.overwriteStaticIssuers);
  }

  renderConfirmationModal() {
    const dialogProps = {
      onHide: this.closeModal,
      onProceed: () => {
        this.closeModal();
        this.props.applyStaticIssuersOverwrite();
        this.showResults();
      },
      text: 'List of issuers assigned to this issuer group was manually amended. ' +
      'If you proceed with a search by query, these manual changes will be lost.',
      okButtonLabel: 'Proceed',
    };
    const modalProps = {
      show: this.state.isShownConfirmation,
      backdrop: 'static',
      dialogComponentClass: () => <ConfirmationDialog {...dialogProps} />
    };

    return <Modal {...modalProps} />;
  }

  renderFilterFields() {
    return this.props.filterFields.map((field) => {
      return <Select {...this.getFieldsProps(field)} />;
    });
  }

  renderShowResultsButton() {
    const buttonProps = {
      bsStyle: this.props.needUpdate ? 'primary' : 'default',
      onClick: this.doShowConfirmation() ? this.openModal : this.showResults,
      disabled: this.props.isLoadingGroupMembers || this.hasErrors()
    };

    return (
      <Button {...buttonProps}>Show results</Button>
    );
  }

  renderForm() {
    const isEmptyList = this.props.filterFields.length === 0;
    if (isEmptyList) {
      return null;
    }

    return (
      <div>
        {this.renderConfirmationModal()}
        <div className={theme.header}>Group filters</div>
        {this.renderFilterFields()}
        <div className={theme.buttons}>
          {this.renderShowResultsButton()}
        </div>
      </div>
    );
  }

  render() {
    if (this.props.areFiltersShown) {
      return (
        <LoadingContainer isLoading={this.props.isLoading}>
          {this.renderForm()}
        </LoadingContainer>
      );
    }
    return null;
  }
}

export default GroupFiltersForm;
