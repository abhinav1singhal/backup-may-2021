import PropTypes from 'prop-types';
import React, { Component } from 'react';
import debounce from 'lodash/debounce';
import { Icon } from 'react-techstack';
import Input from '../Input';

import theme from './GroupMembersSearchPanel.css';

class GroupMembersSearchPanel extends Component {
  static propTypes = {
    applyGroupMembersNameSearch: PropTypes.func.isRequired,
    value: PropTypes.string,
    disabled: PropTypes.bool
  };

  constructor(props) {
    super(props);

    this.state = {
      value: props.value
    };

    this.onChange = this.onChange.bind(this);
    this.applyNameSearch = debounce(this.props.applyGroupMembersNameSearch, 300);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    this.setState({ value: nextProps.value }); // eslint-disable-line react/no-set-state
  }

  onChange(value) {
    this.setState({ value }); // eslint-disable-line react/no-set-state
    this.applyNameSearch(value);
  }

  render() {
    const { disabled } = this.props;
    const inputProps = {
      value: disabled ? null : this.state.value,
      onChange: this.onChange,
      type: 'text',
      hasFeedback: true,
      className: theme.search,
      placeholder: 'Type to search',
      feedbackIcon: <Icon type="search" className={theme.searchIcon} color="#9d9f9e" />,
      disabled
    };

    return <Input {...inputProps}/>;
  }
}

export default GroupMembersSearchPanel;
