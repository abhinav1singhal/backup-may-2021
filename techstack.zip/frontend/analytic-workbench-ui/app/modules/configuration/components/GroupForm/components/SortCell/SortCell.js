import PropTypes from 'prop-types';
import React from 'react';
import SortIcon from '../SortIcon';
import { noop } from 'lodash';

import theme from './SortCell.css';

class SortCell extends React.Component {
  static propTypes = {
    children: PropTypes.node,
    sortKey: PropTypes.string.isRequired,
    applySort: PropTypes.func.isRequired,
    ascending: PropTypes.bool,
    onSort: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props);
    this.sort = this.sort.bind(this);
  }

  sort() {
    this.props.applySort(this.props.sortKey, !this.props.ascending);
    this.props.onSort();
  }

  render() {
    return (
      <div className={theme.sortableCell} onClick={this.sort}>
        {this.props.children}
        <SortIcon sortKey={this.props.sortKey} />
      </div>
    );
  }
}

SortCell.defaultProps = {
  onSort: noop
};

export default SortCell;
