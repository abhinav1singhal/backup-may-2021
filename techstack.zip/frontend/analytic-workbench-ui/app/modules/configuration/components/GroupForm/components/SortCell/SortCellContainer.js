import { connect } from 'react-redux';
import { applyGroupMembersSort } from 'modules/configuration/actions/groupFormActions';

import SortCell from './SortCell';

function mapStateToProps(state, ownProps) {
  const { sortKey, ascending } = state.configuration.groupForm;
  const sorted = sortKey === ownProps.sortKey;
  return {
    sorted,
    ascending: ascending && sorted
  };
}

export default connect(mapStateToProps, { applySort: applyGroupMembersSort })(SortCell);
