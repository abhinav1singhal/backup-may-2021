import { connect } from 'react-redux';
import { asyncStatusUtils } from 'react-techstack/utils';
import GroupFiltersForm from './GroupFiltersForm';

const { isPending } = asyncStatusUtils;
import { applyStaticIssuersOverwrite } from 'modules/configuration/actions/groupFormActions';
function mapStateToProps(state) {
  const { filtersDictionary, filterFields } = state.configuration.groupForm;

  return {
    options: filtersDictionary,
    filterFields,
    isLoadingGroupMembers: isPending(state.requests.groupMembers.status),
    isLoading: isPending(state.requests.groupFilters.status),
    areFiltersShown: state.configuration.groupForm.areFiltersShown,
    overwriteStaticIssuers: state.configuration.groupForm.overwriteStaticIssuers,
    isStaticGroup: state.configuration.groupForm.data.static,
    groupTypeId: state.configuration.groupForm.data.type
  };
}

const mapDispatchToProps = {
  applyStaticIssuersOverwrite
};

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(GroupFiltersForm);
