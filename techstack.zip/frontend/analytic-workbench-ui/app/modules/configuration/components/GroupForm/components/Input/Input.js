import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { Input } from 'react-techstack';

class CustomInput extends Component {
  static propTypes = {
    onChange: PropTypes.func.isRequired,
    label: PropTypes.string,
    required: PropTypes.bool,
    valid: PropTypes.bool,
    isSubmitted: PropTypes.bool
  };

  constructor(props) {
    super(props);

    this.onChange = this.onChange.bind(this);
  }

  onChange(event) {
    this.props.onChange(event.target.value);
  }

  render() {
    const { required, valid, label, isSubmitted } = this.props;
    const inputProps = {
      ...this.props,
      onChange: this.onChange,
      label: required && label ? `${label} *` : label,
      bsStyle: isSubmitted && !valid ? 'error' : null
    };

    return (
      <Input {...inputProps} />
    );
  }
}

CustomInput.defaultProps = {
  valid: true
};

export default CustomInput;
