import PropTypes from 'prop-types';
import React, { Component } from 'react';
import isEqual from 'lodash/isEqual';
import { LoadingContainer } from 'react-techstack';
import Select from 'modules/configuration/components/Select';

const fields = {
  groupLevel: {
    label: 'Group Level',
    clearable: false
  },
  groupDefinitionId: {
    label: 'Group is defined by',
    clearable: false
  }
};

class GroupDefinitionForm extends Component {
  static propTypes = {
    groupLevelOptions: PropTypes.arrayOf(PropTypes.object).isRequired,
    isLoading: PropTypes.bool,
    areFiltersLoading: PropTypes.bool,

    values: PropTypes.object.isRequired,
    field: PropTypes.object.isRequired,
    onChange: PropTypes.func.isRequired,

    loadGroupDefinitionDictionary: PropTypes.func.isRequired,
    loadGroupFilters: PropTypes.func.isRequired,
    resetFilters: PropTypes.func.isRequired,

    isEditMode: PropTypes.bool
  };

  constructor(props) {
    super(props);

    this.onChange = {
      groupLevel: (value) => {
        this.props.onChange({ groupLevel: value, groupDefinitionId: null });
        this.props.resetFilters();
      },
      groupDefinitionId: (value) => {
        this.props.onChange({ groupDefinitionId: value });
        this.props.loadGroupFilters(value.id);
      }
    };
  }

  UNSAFE_componentWillMount() {
    this.props.loadGroupDefinitionDictionary();
  }

  shouldComponentUpdate(nextProps) {
    return !isEqual(nextProps, this.props);
  }

  getFieldsProps(key) {
    const { values, groupLevelOptions, isEditMode, areFiltersLoading } = this.props;
    return {
      ...this.props.field,
      ...fields[key],
      onChange: this.onChange[key],
      options: key === 'groupLevel' ? groupLevelOptions : (values.groupLevel || {}).groupDefinitions || [],
      disabled: key === 'groupDefinitionId' && (!values.groupLevel || areFiltersLoading) || key === 'groupLevel' && isEditMode,
      value: values[key]
    };
  }

  reset = () => {
    this.props.onChange({ groupLevel: null, groupDefinitionId: null});
  }

  render() {
    const { isLoading } = this.props;
    return (
      <LoadingContainer isLoading={isLoading}>
        <Select {...this.getFieldsProps('groupLevel')} />
        <Select {...this.getFieldsProps('groupDefinitionId')} />
      </LoadingContainer>
    );
  }
}

export default GroupDefinitionForm;
