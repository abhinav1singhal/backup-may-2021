import { connect } from 'react-redux';

import SortIcon from './SortIcon';

function mapStateToProps(state, ownProps) {
  const { sortKey, ascending } = state.configuration.groupForm;
  const sorted = sortKey === ownProps.sortKey;
  return {
    sorted,
    ascending: ascending && sorted,
    descending: !ascending && sorted
  };
}

export default connect(mapStateToProps)(SortIcon);
