import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { asyncStatusUtils } from 'react-techstack/utils';

import { toggleSelectManually, applyGroupMembersNameSearch } from 'modules/configuration/actions/groupFormActions';
import GroupMembersTable from './GroupMembersTable';

const { isPending, isNotStarted, isFailed } = asyncStatusUtils;

function mapStateToProps(state) {
  const { groupForm } = state.configuration;

  return {
    sortKey: groupForm.sortKey,
    ascending: groupForm.ascending,
    needle: groupForm.needle,
    tableFilters: groupForm.tableFilters,
    members: groupForm.members.records,
    columns: groupForm.members.columns,
    errors: groupForm.membersErrors,
    isLoading: isPending(state.requests.groupMembers.status),
    isNotStarted: isNotStarted(state.requests.groupMembers.status),
    isFailed: isFailed(state.requests.groupMembers.status),
    filterQueryIds: groupForm.filterQueryIds
  };
}

function mapDispatchToProps(dispatch) {
  return {
    ...bindActionCreators({
      toggleSelectManually
    }, dispatch),
    resetSearch: () => dispatch(applyGroupMembersNameSearch(null))
  };
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(GroupMembersTable);
