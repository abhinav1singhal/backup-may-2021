/* eslint-disable react/no-set-state */
import PropTypes from 'prop-types';

import React, { Component } from 'react';
import { Button, LoadingContainer, Alert } from 'react-techstack';
import { isEqual, isPlainObject, isArray, mapValues, get } from 'lodash';

import {
  GroupDefinitionForm,
  GroupFiltersForm,
  GroupAttributesForm,
  GroupMembersTable
 } from './components';

import { getMessage } from 'modules/common/utils/messagesUtils';

import theme from './GroupForm.css';

const errorMessages = {
  'required': 'Please fill all required fields',
  'noItems': 'Please specify group members for the group',
  'groupName': 'Group Name can contain only letters (a-z, A-Z), numbers (0-9), underscores (_). Max length 50 symbols.',
  'groupDescription': 'Group description can not exceed 255 symbols.'
};

const PEER_GROUP_ID = '2';

function selectValue(props, key) {
  const val = props.data[key];
  const dictionary = props.dictionary[key] ? props.dictionary[key] : props.filtersDictionary[key];
  if (!val) {
    return val;
  }
  if (isArray(val)) {
    return val.map((id) => dictionary.find((option) => option.id === id));
  }
  return dictionary.find((option) => option.id === val);
}

function convert(formData) {
  const result = {};
  Object.keys(formData).forEach((key) => {
    if (isPlainObject(formData[key])) {
      result[key] = formData[key].id;
    } else if (isArray(formData[key])) {
      result[key] = formData[key].map(({ id }) => id);
    } else {
      result[key] = formData[key];
    }
  });
  return result;
}

function prepareFilters(filters, props) {
  return mapValues(filters, (val, key) => {
    if (!val) {
      return val;
    }

    const dictionary = props.filtersDictionary[key];

    if (isArray(val)) {
      return val.reduce((filtered, id) => {
        const curOption = dictionary.find((option) => option.id === id);
        if (curOption) {
          filtered.push(curOption);
        } else {
          console.warn('Cannot find option with id ', id, ' in dictionary ', key); // eslint-disable-line no-console
        }
        return filtered;
      }, []);
    }
    return props.filtersDictionary[key].find((option) => option.id === val);
  });
}

const field = {
  wrapperClassName: theme.fieldWrapper,
  labelClassName: theme.label
};
const parts = ['definitionForm', 'attributesForm', 'filtersForm'];

class GroupForm extends Component {
  static propTypes = {
    loadGroupAttributesDictionary: PropTypes.func.isRequired,
    isLoading: PropTypes.bool,
    resetGroupMembersTable: PropTypes.func.isRequired,
    loadGroupMembers: PropTypes.func.isRequired,
    isTableShown: PropTypes.bool,
    areFiltersLoaded: PropTypes.bool,
    saveGroup: PropTypes.func.isRequired,
    createGroup: PropTypes.func.isRequired,
    errors: PropTypes.array.isRequired,
    errorsParams: PropTypes.array.isRequired,
    defaultValues: PropTypes.object.isRequired,
    saved: PropTypes.bool,
    failedValues: PropTypes.object.isRequired,
    params: PropTypes.object.isRequired,
    loadGroupData: PropTypes.func.isRequired,
    data: PropTypes.object.isRequired,
    dictionary: PropTypes.object.isRequired,
    filtersDictionary: PropTypes.object.isRequired,
    isFailed: PropTypes.bool,
    getGeneratedGroupName: PropTypes.func.isRequired,
    generatedGroupName: PropTypes.object.isRequired
  };

  constructor(props) {
    super(props);

    this.selection = new Set();
    this.state = {
      definitionForm: {},
      filtersForm: {
        filters: {},
        needUpdate: false
      },
      attributesForm: {
        isNameDisabled: false
      },
      table: {
        selectedNumber: 0,
        isSelectingManually: false
      },
      errors: [],
      isSubmitted: false,
      fieldsErrors: []
    };
    this.fields = {};
    parts.forEach((part) => {
      this.fields[part] = {
        field,
        onChange: this.onChange.bind(this, part)
      };
    });
    this.errors = { required: new Set([ 'type', 'name', 'groupDescription' ]) };
    this.onTableChange = this.onChange.bind(this, 'table');

    this.resetTable = this.resetTable.bind(this);
    this.validateField = this.validateField.bind(this);
    this.clearValidation = this.clearValidation.bind(this);
    this.submit = this.submit.bind(this);
    this.getErrorMessage = this.getErrorMessage.bind(this);
    this.reloadGroupMembers = this.reloadGroupMembers.bind(this);
    this.addToSelection = this.addToSelection.bind(this);
    this.removeFromSelection = this.removeFromSelection.bind(this);
  }

  UNSAFE_componentWillMount() {
    const { groupId } = this.props.params;
    if (groupId) {
      this.props.loadGroupData(groupId);
    }
    this.props.loadGroupAttributesDictionary();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.defaultValues !== this.props.defaultValues) {
      if  (!nextProps.params.groupId) {
        this.definitionForm.reset();
        this.attributesForm.reset();
        this.filtersForm.reset();
      }
      this.setState({ isSubmitted: false });
    } else if (nextProps.data !== this.props.data) {
      const { data } = nextProps;
      const groupLevel = nextProps.dictionary.groupLevel[0];
      this.selection = new Set(data.issuerIds);

      this.setState({
        definitionForm: {
          groupLevel,
          groupDefinitionId: groupLevel.groupDefinitions.find((option) => option.id === data.groupDefinitionId)
        },
        filtersForm: {
          filters: prepareFilters(data.userSelectParams, nextProps),
          needUpdate: false
        },
        attributesForm: {
          type: selectValue(nextProps, 'type'),
          groupLeadIssuerId: selectValue(nextProps, 'groupLeadIssuerId'),
          name: data.groupName,
          groupStatus: selectValue(nextProps, 'groupStatus'),
          groupDescription: data.groupDescription,
          tier: selectValue(nextProps, 'tier')
        },
        table: {
          selectedNumber: this.selection.size,
          isSelectingManually: data.static
        },
        errors: [],
        isSubmitted: false
      });
    } else if (this.props.params.groupId !== nextProps.params.groupId) {
      nextProps.loadGroupData(nextProps.params.groupId);
    }
    this.submitText = nextProps.params.groupId ? 'Save Group' : 'Create Group';

    const generatedGroupName = nextProps.generatedGroupName.data;
    if (generatedGroupName) {
      const typeId = get(this.state, 'attributesForm.type.id');
      const issuerId = get(this.state, 'attributesForm.groupLeadIssuerId.id');

      if (this.isPeerGroup(typeId) && issuerId === nextProps.generatedGroupName.issuerId) {
        this.setAttributesGroupName(generatedGroupName);
      }
    }
    if (nextProps.saved !== this.props.saved && nextProps.saved) {
      this.setState({ attributesForm: { isNameDisabled: false, groupDescription: '' } });
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    return !isEqual(nextProps, this.props) || !isEqual(this.state, nextState);
  }

  componentDidUpdate(prevProps, prevState) {
    const curTypeId = get(this.state, 'attributesForm.type.id');
    const prevTypeId = get(prevState, 'attributesForm.type.id');
    const curIssuerId = get(this.state, 'attributesForm.groupLeadIssuerId.id');
    const prevIssuerId = get(prevState, 'attributesForm.groupLeadIssuerId.id');

    if (curTypeId !== prevTypeId || curIssuerId !== prevIssuerId) {
      if (this.isPeerGroup(curTypeId) &&  curIssuerId) {
        this.setAttributesGroupName();
        this.props.getGeneratedGroupName(curIssuerId);
      }

      if (this.isPeerGroup(curTypeId) || this.isPeerGroup(prevTypeId)) {
        this.setAttributesGroupName();
      }
    }
  }

  onChange(key, val) {
    let value = val;

    if (isEqual(key, 'attributesForm') && value.type) {
      const isNameDisabled = isEqual(get(value, 'type.id'), '2');

      value = { ...val, isNameDisabled };
    }

    this.setState({
      [key]: {
        ...this.state[key],
        ...value
      }
    });
  }

  getPartialProps(key) {
    return {
      ...this.fields[key],
      field: {
        ...this.fields[key].field,
        isSubmitted: this.state.isSubmitted
      },
      isEditMode: !!this.props.params.groupId,
      ref: (form) => { this[key] = form; }
    };
  }

  getErrorMessage(errorKey) {
    switch (errorKey) {
      case 'DUPLICATE_NAME':
        return getMessage('groupForm.error.DUPLICATE_NAME', this.props.failedValues.name);
      case 'NOT_FOUND':
        return getMessage('groupForm.error.NOT_FOUND', this.props.params.groupId);
      case 'NO_PERMISSION':
        return getMessage('groupForm.error.NO_PERMISSION', this.props.errorsParams[0]);
      case 'NO_PERMISSION_PEER_GROUP':
        return  getMessage('groupForm.error.NO_PERMISSION_PEER_GROUP', this.props.errorsParams[0], this.props.errorsParams[1]);
      case 'ALREADY_DEFINED_GROUP_LEAD':
        return getMessage('groupForm.error.ALREADY_DEFINED_GROUP_LEAD', this.props.errorsParams[0], this.props.errorsParams[1], this.props.errorsParams[2]);
      default:
        return  getMessage('groupForm.error.DEFAULT');
    }
  }

  getErrorList() {
    const errors = new Set();
    Object.keys(this.errors).forEach((errorKey) => {
      if (this.errors[errorKey].size === 0) {
        return;
      }
      if (errorMessages[errorKey]) {
        errors.add(errorMessages[errorKey]);
      } else {
        for (const fieldKey of this.errors[errorKey]) {
          errors.add(this.getErrorMessage(errorKey, fieldKey));
        }
      }
    });
    return Array.from(errors.values());
  }

  isPeerGroup(id) {
    return id && id === PEER_GROUP_ID;
  }

  setAttributesGroupName = (name = '') => {
    this.setState({
      attributesForm: {
        ...this.state.attributesForm,
        name
      }
    });
  }

  isSubmitDisabled() {
    const { definitionForm, filtersForm, table } = this.state;
    const { areFiltersLoaded, isTableShown } = this.props;

    return !(definitionForm.groupLevel && definitionForm.groupDefinitionId && areFiltersLoaded) ||
      filtersForm.needUpdate && table.isSelectingManually && isTableShown;
  }

  reloadGroupMembers() {
    this.props.loadGroupMembers(this.state.definitionForm.groupDefinitionId.id, convert(this.state.filtersForm.filters));
    this.setState({
      filtersForm: { ...this.state.filtersForm, needUpdate: false }
    });
  }

  resetTable(filters) {
    this.props.resetGroupMembersTable(filters);
    this.reloadGroupMembers();
    this.selection = new Set();
    this.setState({
      table: {
        selectedNumber: 0,
        isSelectingManually: false
      }
    });
  }

  validateForm() {
    const errors = [];
    const { table } = this.state;
    if (table.isSelectingManually && this.props.isTableShown && !table.selectedNumber) {
      errors.push(errorMessages.noItems);
    }
    return errors;
  }

  validateField(key, errors) {
    Object.keys(errors).forEach((errorKey) => {
      if (!this.errors[errorKey]) {
        this.errors[errorKey] = new Set();
      }
      if (errors[errorKey]) {
        this.errors[errorKey].add(key);
      } else {
        this.errors[errorKey].delete(key);
      }
    });
    this.setState({ fieldsErrors: this.getErrorList() });
  }

  clearValidation(keys) {
    Object.keys(this.errors).forEach((errorKey) => {
      keys.forEach((key) => {
        this.errors[errorKey].delete(key);
      });
    });
  }

  addToSelection(...items) {
    items.forEach((item) => {
      this.selection.add(item);
    });
    this.setState({
      table: {
        ...this.state.table,
        selectedNumber: this.selection.size
      }
    });
  }

  removeFromSelection(...items) {
    items.forEach((item) => {
      this.selection.delete(item);
    });
    this.setState({
      table: {
        ...this.state.table,
        selectedNumber: this.selection.size
      }
    });
  }

  submit(e) {
    e.preventDefault();
    document.body.scrollTop = document.documentElement.scrollTop = 0;
    this.setState({ isSubmitted: true });
    if (this.isSubmitDisabled() || this.getErrorList().length || this.validateForm().length) {
      return null;
    }

    const { definitionForm, filtersForm, attributesForm, table } = this.state;
    const formData = {
      ...convert(definitionForm),
      filters: convert(filtersForm.filters),
      ...convert(attributesForm)
    };
    const isEdit = !!this.props.params.groupId;

    if (isEdit) {
      formData.id = this.props.params.groupId;
    }

    formData.isSelectingManually = table.isSelectingManually;
    if (this.props.isTableShown && table.isSelectingManually) {
      formData.members = [...this.selection];
    }

    if (isEdit) {
      this.props.saveGroup(formData);
    } else {
      this.props.createGroup(formData);
    }

    return null;
  }

  renderErrors() {
    if (this.state.isSubmitted || this.props.isFailed) {
      let errorList = this.props.errors.map(this.getErrorMessage);
      if (!this.props.isFailed) {
        errorList = errorList.concat(this.state.fieldsErrors).concat(this.validateForm());
      }

      if (errorList.length) {
        return (
          <Alert bsStyle="danger">
            {errorList.map((error, index) => <div key={index}>{error}</div>)}
          </Alert>
        );
      }
    }
    return null;
  }

  renderForm() {
    const { state, props: { isTableShown } } = this;
    const groupFiltersFormProps = {
      ...this.getPartialProps('filtersForm'),
      ...this.state.filtersForm,
      resetTable: this.resetTable,
      validate: this.validateField,
      clearValidation: this.clearValidation
    };
    const groupMembersTableProps = {
      ...state.table,
      selection: this.selection,
      addToSelection: this.addToSelection,
      removeFromSelection: this.removeFromSelection,
      onChange: this.onTableChange,
      reloadGroupMembers: this.reloadGroupMembers,
      shouldUpdateOnToggle: this.state.filtersForm.needUpdate
    };

    return (
      <form noValidate onSubmit={this.submit}>
        <div className={theme.main}>
          <div>
            <GroupDefinitionForm {...this.getPartialProps('definitionForm')} values={state.definitionForm} />
            <div className={theme.groupFilters}>
              <GroupFiltersForm {...groupFiltersFormProps} />
            </div>
          </div>
          <div>
            <GroupAttributesForm {...this.getPartialProps('attributesForm')} values={state.attributesForm} validate={this.validateField} />
          </div>
        </div>
        <div className={theme.table}>
          {isTableShown && <GroupMembersTable {...groupMembersTableProps} />}
        </div>
        <div className={theme.buttons}>
          <Button type="submit" bsStyle="primary" disabled={this.isSubmitDisabled()}>{this.submitText}</Button>
        </div>
      </form>
    );
  }

  render() {
    const { isFailed, params: { groupId } } = this.props;
    const mainHeader = groupId ? 'Edit Group' : 'Create New Group';

    return (
      <div>
        <div className={theme.header}>
          <span className={theme.mainHeader}>{mainHeader}</span>
          <span className={theme.subHeader}>Based on selected parameters</span>
        </div>

        <LoadingContainer isLoading={this.props.isLoading}>
          {this.renderErrors()}
          {!isFailed && this.renderForm()}
        </LoadingContainer>
      </div>
    );
  }
}

export default GroupForm;
