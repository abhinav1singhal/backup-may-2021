import PropTypes from 'prop-types';
import React, { Component } from 'react';
import classNames from 'classnames';
import { isEqual, isEmpty } from 'lodash/lang';
import Select from 'modules/configuration/components/Select';
import Input from '../Input';
import {ANALYTIC_UNIT_GROUP_ID, PEER_GROUP_ID, BENCHMARK_MEDIAN_GROUP_ID} from 'modules/surveillance/utils/surveillanceUtils';
import theme from './GroupAttributesForm.css';

const validators = {
  groupName(name) {
    return name && name.match(/^[\x20-\x7E]{1,100}$/);
  },
  groupDescription(groupDescription) {
    return !groupDescription || groupDescription.length <= 255;
  }
};

function isGroupLeadRequired(type) {
  return type && (type.id === ANALYTIC_UNIT_GROUP_ID || type.id === PEER_GROUP_ID);
}

function isGroupStatusShown(type) {
  return type && (type.id === PEER_GROUP_ID || type.id === BENCHMARK_MEDIAN_GROUP_ID);
}

const fields = {
  type: {
    label: 'Group Type',
    placeholder: 'Select Type',
    clearable: false,
    required: true,
    valid: false
  },
  name: {
    label: 'Group Name',
    type: 'text',
    placeholder: 'Type Name here',
    required: true,
    validators: ['groupName'],
    valid: false
  },
  groupLeadIssuerId: {
    label: 'Group Lead',
    placeholder: 'Start typing Issuer ID or Name',
    clearable: true,
    required: false,
    valid: true,
    labelKey: 'label',
    valueKey: 'label'
  },
  groupStatus: {
    label: 'Status',
    clearable: false,
    required: true
  },
  groupDescription: {
    label: 'Group Description',
    type: 'textarea',
    placeholder: 'Type here Description',
    required: true,
    validators: ['groupDescription'],
    valid: false
  }
  // tier: {
  //   label: 'Tier',
  //   required: false,
  //   clearable: false
  // }
};

function validateField(key, value) {
  if (fields[key].required && isEmpty(value)) {
    fields[key].valid = false;
    return { required: true };
  }
  const errors = { required: false };
  fields[key].valid = true;

  if (fields[key].validators) {
    fields[key].validators.forEach((name) => {
      if (!validators[name](value, key)) {
        errors[name] = true;
        fields[key].valid = false;
      } else {
        errors[name] = false;
      }
    });
  }

  return errors;
}

class GroupAttributesForm extends Component {
  static propTypes = {
    options: PropTypes.object.isRequired,
    field: PropTypes.object.isRequired,
    onChange: PropTypes.func.isRequired,
    values: PropTypes.object.isRequired,
    validate: PropTypes.func.isRequired,
    isEditMode: PropTypes.bool,
    isGroupNameLoading: PropTypes.bool
  };

  constructor(props) {
    super(props);

    Object.keys(fields).forEach((key) => {
      fields[key].onChange = (value) => {
        if (key === 'type') {
          // const isShown = value && value.id === '1';
          // const requiredError = fields.tier.required && !this.props.values.tier && isShown;
          // this.setState({ isTierShown: isShown }); // eslint-disable-line react/no-set-state
          // this.props.validate('tier', { required: requiredError });

          const isShown = isGroupStatusShown(value);
          fields.groupStatus.required = isGroupStatusShown(value);
          const requiredError = fields.groupStatus.required && !this.props.values.groupStatus && isShown;
          this.setState({ isGroupStatusShown: isShown }); // eslint-disable-line react/no-set-state
          this.props.validate('groupStatus', { required: requiredError });

          fields.groupLeadIssuerId.required = isGroupLeadRequired(value);
          const groupLeadInvalid = fields.groupLeadIssuerId.required && !this.props.values.groupLeadIssuerId;
          this.props.validate('groupLeadIssuerId', { required: groupLeadInvalid });
          fields.groupLeadIssuerId.valid = !groupLeadInvalid;
          // fields.tier.valid = !requiredError;
        }

        this.props.onChange({ [key]: value });
      };
    });

    this.state = {
      isTierShown: props.values.type && props.values.type.id === '1'
    };

    this.reset = this.reset.bind(this);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    Object.keys(fields).forEach((key) => {
      if (nextProps.values[key] !== this.props.values[key]) {
        this.props.validate(key, validateField(key, nextProps.values[key]));
      }
    });
    // if (this.props.options.tier.length !== 0) {
    //   fields.tier.required = true;
    // }
    fields.groupLeadIssuerId.required = isGroupLeadRequired(nextProps.values.type);
    this.setState({ isTierShown: nextProps.values.type && nextProps.values.type.id === '1' }); // eslint-disable-line react/no-set-state

    fields.groupStatus.required = isGroupStatusShown(nextProps.values.type);
    this.setState({ isGroupStatusShown: nextProps.values.type && isGroupStatusShown(nextProps.values.type)}); // eslint-disable-line react/no-set-state

    if (nextProps.options.groupStatus && nextProps.options.groupStatus.length && !this.isStatusSet) {
      fields.groupStatus.valid = true;
      this.props.validate('groupStatus', { required: false });
      this.props.onChange({ groupStatus: nextProps.options.groupStatus.find((option) => option.name === 'Draft')});
      this.isStatusSet = true;
    }
  }

  shouldComponentUpdate(nextProps) {
    return !isEqual(nextProps, this.props);
  }

  getFieldProps(key) {
    const { isEditMode, isGroupNameLoading, field, options, values } = this.props;
    const isDisabledField = (key === 'type' && isEditMode)
      || (key === 'name' && values.isNameDisabled)
      || (isGroupNameLoading && (key === 'type' || key === 'groupLeadIssuerId'));

    return {
      ...this.props.field,
      ...fields[key],
      disabled: isDisabledField,
      valueClassName: theme.valueWrapper,
      wrapperClassName: classNames(field.wrapperClassName, theme.fieldWrapper),
      labelClassName: classNames(
        field.labelClassName,
        fields[key].type === 'textarea' ? theme.textareaLabel : theme.label
      ),
      options: options[key],
      value: key === 'name' && isGroupNameLoading
        ? 'Loading...'
        : values[key]
    };
  }

  validateField(key, props) {
    if (fields[key].required && !props.values[key]) {
      if (key !== 'tier' /* || props.values.type && props.values.type.id === '1' */) {
        props.validate(key, { required: true });
        fields[key].valid = false;
      }
    }
  }

  reset() {
    const newValues = {};
    Object.keys(fields).forEach((key) => { newValues[key] = null; });
    newValues.groupStatus =  this.props.options.groupStatus.find((option) => option.name === 'Draft');
    newValues.groupDescription = '';
    this.props.onChange(newValues);
  }

  render() {
    // const { isTierShown } = this.state;
    return (
      <div className={theme.root}>
        <div className={theme.header}>Group Attributes</div>
        <Select {...this.getFieldProps('type')} />
        <Input {...this.getFieldProps('name')} />
        <Select {...this.getFieldProps('groupLeadIssuerId')} />
        { this.state.isGroupStatusShown && <Select {...this.getFieldProps('groupStatus')} /> }
        {/* {isTierShown && <Select {...this.getFieldProps('tier')} />} */}
        <Input {...this.getFieldProps('groupDescription')} />
      </div>
    );
  }
}

export default GroupAttributesForm;
