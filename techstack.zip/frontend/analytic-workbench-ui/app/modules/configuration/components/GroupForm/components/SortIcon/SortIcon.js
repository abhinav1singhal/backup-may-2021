import PropTypes from 'prop-types';
import React, { Component } from 'react';
import classNames from 'classnames';
import Icon from 'modules/shared/components/Icon';

import theme from './SortIcon.css';

class SortIcon extends Component {
  static propTypes = {
    sortKey: PropTypes.string.isRequired,
    ascending: PropTypes.bool.isRequired,
    descending: PropTypes.bool.isRequired
  };

  render() {
    const sortUpClassNames = classNames(theme.sortButtonUp, { [theme.sortingActive]: this.props.descending });
    const sortDownClassNames = classNames(theme.sortButtonDown, { [theme.sortingActive]: this.props.ascending });

    return (
      <div className={theme.sortButton}>
        <span className={sortUpClassNames}>
          <Icon type="sort-up" />
        </span>
        <span className={sortDownClassNames}>
          <Icon type="sort-down" />
        </span>
      </div>
    );
  }
}

export default SortIcon;
