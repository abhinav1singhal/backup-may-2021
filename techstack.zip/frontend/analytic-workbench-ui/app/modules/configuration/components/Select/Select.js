import PropTypes from 'prop-types';
import React, { Component } from 'react';
import classNames from 'classnames';
import { Select } from 'react-techstack';

import theme from './Select.css';

class CustomSelect extends Component {
  static propTypes = {
    wrapperClassName: PropTypes.string,
    multiple: PropTypes.bool,
    label: PropTypes.string,
    labelKey: PropTypes.string,
    valueKey: PropTypes.string,
    placeholder: PropTypes.string,
    required: PropTypes.bool,
    valid: PropTypes.bool,
    isSubmitted: PropTypes.bool,
    optionLabelConstructor: PropTypes.func
  };

  filter = (options, needle) => {
    const { optionLabelConstructor, labelKey } = this.props;
    return options.filter((option) => {
      const optionLabel = optionLabelConstructor ? optionLabelConstructor(option) : option[labelKey];
      return optionLabel.toLowerCase().includes(needle.toLowerCase());
    });
  };

  valueRenderer = (option) => {
    const { optionLabelConstructor } = this.props;
    return <div className={theme.value}>{optionLabelConstructor ? optionLabelConstructor(option.item) : option.label}</div>;
  };

  optionRenderer = (option) => {
    const { optionLabelConstructor, labelKey } = this.props;
    return optionLabelConstructor ? optionLabelConstructor(option) : option[labelKey];
  };

  render() {
    const { required, valid, label, isSubmitted, multiple } = this.props;
    const selectProps = {
      ...this.props,
      filter: this.filter,
      multi: multiple,
      wrapperClassName: classNames(this.props.wrapperClassName, { [theme.multi]: multiple }),
      valueRenderer: this.valueRenderer,
      optionRenderer: this.optionRenderer,
      label: required && label ? `${label} *` : label,
      bsStyle: isSubmitted && !valid ? 'error' : null
    };

    return (
      <Select {...selectProps} />
    );
  }
}

CustomSelect.defaultProps = {
  placeholder: '',
  valueKey: 'id',
  labelKey: 'name',
  valueClassName: theme.valueWrapper,
  valid: true
};

export default CustomSelect;
