import PropTypes from 'prop-types';
import React, { Component } from 'react';
import classNames from 'classnames';
import { get, compact, isFunction } from 'lodash';
import { IssuerSelector } from 'modules/issuer/components';
import { ChooseIssuerMessage } from 'modules/issuerLibrary/components';
import { Radio, Button, Alert } from 'react-techstack';
import Select from 'modules/configuration/components/Select';
import { issuerType } from 'modules/issuer/types';
import theme from './ConsolidatedIssuerFilterForm.css';

import { getMessage } from 'modules/common/utils/messagesUtils';

const FIELDS = {
  RATIONALE: {
    key: 'rationaleId',
    label: getMessage('consolidatedIssuerFilter.rationale.label'),
    required: (formData) => formData[FIELDS.CATEGORY.key] && formData[FIELDS.CATEGORY.key] !== 1
  },
  CATEGORY: {
    key: 'categoryId',
    label: getMessage('consolidatedIssuerFilter.category.label'),
    required: true
  }
};

// TODO: Refactor this form using FormBuilder
class ConsolidatedIssuerFilterForm extends Component {
  static propTypes = {
    isLoading: PropTypes.bool.isRequired,
    dictionary: PropTypes.shape({
      category: PropTypes.array.isRequired,
      rationale: PropTypes.array.isRequired
    }),
    data: PropTypes.object.isRequired,
    currentIssuer: issuerType,
    defaultIssuerId: PropTypes.number,
    editMode: PropTypes.bool.isRequired,
    loadConsolidatedFilterDictionary: PropTypes.func.isRequired,
    loadConsolidatedFilterData: PropTypes.func.isRequired,
    saveConsolidatedFilterData: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props);

    this.state = {
      issuerId: props.defaultIssuerId,
      formData: props.data,
      isSubmitted: false,
      validationResult: {}
    };
  }

  UNSAFE_componentWillMount() {
    this.props.loadConsolidatedFilterDictionary();

    const { defaultIssuerId } = this.props;
    if (defaultIssuerId) {
      this.props.loadConsolidatedFilterData(defaultIssuerId);
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.currentIssuer !== this.props.currentIssuer) {
      if (nextProps.currentIssuer) {
        this.props.loadConsolidatedFilterData(nextProps.currentIssuer.id);
      } else {
        this.clearFormData();
      }
    }

    if (nextProps.data !== this.props.data) {
      this.setState({ // eslint-disable-line react/no-set-state
        formData: nextProps.data,
        isSubmitted: false,
        validationResult: {}
      });
    }
  }

  onValueChange = (key, value) => { // eslint-disable-line
    this.setState({
      formData: {
        ...this.state.formData,
        [key]: value && value.id
      }
    }, this.validateForm);
  };

  isFormFieldDisabled = () => {
    return this.props.isLoading || !this.props.currentIssuer || !this.props.editMode;
  };

  isFormFieldRequired = (key) => {
    const isRequired = FIELDS[key].required;
    return isFunction(isRequired) ? isRequired(this.state.formData) : isRequired;
  };

  isFormFieldValid = (key) => {
    const { validationResult } = this.state;

    return get(validationResult, `${key}.valid`, true);
  };

  isSubmitDisabled() {
    return this.props.isLoading || !this.props.currentIssuer;
  }

  clearFormData() {
    this.setState({ // eslint-disable-line react/no-set-state
      formData: {},
      isSubmitted: false,
      validationResult: {}
    });
  }

  validateForm() {
    const { formData } = this.state;
    const validationResult = {};


    Object.keys(FIELDS).forEach((key) => {
      const field = FIELDS[key];
      if (this.isFormFieldRequired(key) && !formData[field.key]) {
        validationResult[field.key] = {
          valid: false,
          errorMessage: `${field.label} field is required`
        };
      } else {
        validationResult[field.key] = {};
      }
    });

    this.setState({ // eslint-disable-line react/no-set-state
      validationResult
    });

    return Object.keys(validationResult).every((key) => validationResult[key].valid !== false);
  }

  submit = (event) => {
    event.preventDefault();

    const isFormValid = this.validateForm();
    this.setState({ isSubmitted: true });

    if (isFormValid) {
      this.props.saveConsolidatedFilterData(this.props.currentIssuer.id, this.state.formData);
    }
  };

  renderFormControlLabel(label, required, valid) {
    const className = classNames('control-label', theme.label, {
      [theme.hasError]: !valid
    });

    return (
      <label className={className}>{required && label ? `${label} *` : label}</label>
    );
  }

  renderIssuerSelector() {
    const { defaultIssuerId, currentIssuer, isLoading } = this.props;

    const IssuerSelectorProps = {
      defaultIssuerId,
      theme: {
        root: theme.issuerSelector,
        lob: theme.lob
      }
    };

    return (
      <div>
        <IssuerSelector {...IssuerSelectorProps} />
        {currentIssuer || isLoading ? null : <ChooseIssuerMessage />}
      </div>
    );
  }

  renderCategories() {
    const { dictionary: { category }} = this.props;
    const { formData } = this.state;
    const isDisabled = this.isFormFieldDisabled();
    const categoryFieldKey = FIELDS.CATEGORY.key;
    const isRequired = this.isFormFieldRequired('CATEGORY');

    const options = category.map((option) => {
      const RadioProps = {
        name,
        checked: formData[categoryFieldKey] === option.id,
        label: option.name,
        onChange: () => { this.onValueChange(categoryFieldKey, option); },
        key: `RadioGroup-ConsolidatedIssuerFilter-${option.id}`,
        disabled: isDisabled
      };

      const WrapperProps = {
        disabled: isDisabled,
        className: theme.controlWrapper,
        style: {
          color: option.color,
          backgroundColor: option.backgroundColor
        }
      };

      return (
        <div key={option.id} className={theme.radio}>
          <div {...WrapperProps}>
            <Radio {...RadioProps} />
          </div>
          <div className="clearfix"/>
        </div>
      );
    });

    return (
      <div>
        {this.renderFormControlLabel(FIELDS.CATEGORY.label, isRequired, this.isFormFieldValid(FIELDS.CATEGORY.key))}
        {options}
      </div>
    );
  }

  renderRationale() {
    const { dictionary: { rationale } } = this.props;
    const { formData, isSubmitted } = this.state;
    const rationaleFieldKey = FIELDS.RATIONALE.key;
    const isRequired = this.isFormFieldRequired('RATIONALE');

    const SelectProps = {
      options: rationale,
      value: rationale.find((r) => r.id === formData[rationaleFieldKey]),
      onChange: (value) => { this.onValueChange(rationaleFieldKey, value); },
      required: isRequired,
      valid: this.isFormFieldValid(rationaleFieldKey),
      label: FIELDS.RATIONALE.label,
      labelClassName: theme.label,
      isSubmitted,
      multiple: false,
      disabled: this.isFormFieldDisabled(),
      clearable: !isRequired
    };
    return (
      <Select {...SelectProps} />
    );
  }

  renderErrors() {
    if (this.state.isSubmitted) {
      const { validationResult } =  this.state;
      const errorList = compact(Object.keys(validationResult).map((key) => get(validationResult, `${key}.errorMessage`)));

      if (errorList.length) {
        return (
          <Alert bsStyle="danger">
            {errorList.map((error, index) => <div key={index}>{error}</div>)}
          </Alert>
        );
      }
    }
    return null;
  }

  render() {
    const { currentIssuer, editMode } = this.props;
    const submitText = `Submit Organization${currentIssuer ? ` ID: ${currentIssuer.id}` : ''}`;

    return (
      <div>
        <form noValidate onSubmit={this.submit}>
          {this.renderErrors()}
          {this.renderIssuerSelector()}
          <div className={theme.consolidatedFilterForm}>
            <div>
              {this.renderCategories()}
            </div>
            <div>
              {this.renderRationale()}
            </div>
          </div>
          {editMode ? <Button type="submit" bsStyle="primary" disabled={this.isSubmitDisabled()}>{submitText}</Button> : null}
        </form>
      </div>
    );
  }
}

export default ConsolidatedIssuerFilterForm;
