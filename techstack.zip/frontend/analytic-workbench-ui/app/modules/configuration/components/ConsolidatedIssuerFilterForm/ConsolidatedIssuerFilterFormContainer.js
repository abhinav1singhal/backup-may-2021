import { connect } from 'react-redux';
import { asyncStatusUtils } from 'react-techstack/utils';

import {
  loadConsolidatedFilterDictionary,
  loadConsolidatedFilterData,
  saveConsolidatedFilterData
} from 'modules/configuration/actions/consolidatedIssuerFilterActions';
import ConsolidatedIssuerFilterForm from './ConsolidatedIssuerFilterForm';
import { prepareIntValue } from 'utils/urlQueryUtils';
import { hasPermissionToConfigureConsolidatedFilter } from 'modules/configuration/utils/configurationUtils';

const { isPending } = asyncStatusUtils;

function mapStateToProps(state, { urlQuery }) {
  return {
    isLoading: isPending(state.requests.loadConsolidatedFilterDictionary.status) ||
      isPending(state.requests.loadConsolidatedFilterData.status) ||
      isPending(state.requests.saveConsolidatedFilterData.status) ||
      isPending(state.requests.issuerSelectInitialData.status) ||
      isPending(state.requests.issuerSelectIssuersList.status),
    dictionary: state.configuration.consolidatedIssuerFilter.dictionary,
    data: state.configuration.consolidatedIssuerFilter.data,
    defaultIssuerId: prepareIntValue(urlQuery.issuerId),
    currentIssuer: state.issuer.currentIssuer,
    editMode: hasPermissionToConfigureConsolidatedFilter(state.user.permissions)
  };
}

const mapDispatchToProps = {
  loadConsolidatedFilterDictionary,
  loadConsolidatedFilterData,
  saveConsolidatedFilterData
};

export default connect(mapStateToProps, mapDispatchToProps)(ConsolidatedIssuerFilterForm);
