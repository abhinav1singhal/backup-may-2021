import { ActionsNamespace } from 'react-techstack/redux';

export const actionsNamespace = new ActionsNamespace('MA_SHARING');
export const LOAD_SHAREABLE_LOBS = actionsNamespace.createAsyncAction('LOAD_SHAREABLE_LOBS');
export const SAVE_SELECTED_LOBS = actionsNamespace.createAsyncAction('SAVE_SELECTED_LOBS');
export const SHARE_SELECTED_LOBS_WITH_MA = actionsNamespace.createAsyncAction('SHARE_SELECTED_LOBS_WITH_MA');
export const TOGGLE_SHAREABLE_LOB = actionsNamespace.createAction('TOGGLE_SHAREABLE_LOB');

export function loadShareableLobs() {
  return {
    type: LOAD_SHAREABLE_LOBS,
    promise: ({ configurationService }) => configurationService.loadShareableLobs()
  };
}

export function toggleLobSharing(lobId) {
  return {
    type: TOGGLE_SHAREABLE_LOB,
    lobId
  };
}

export function saveSelectedLobs(shareableLobs) {
  return {
    type: SAVE_SELECTED_LOBS,
    promise: ({ configurationService }) => configurationService.saveSelectedLobs(shareableLobs)
  };
}

export function shareSelectedLobsWithMA() {
  return {
    type: SHARE_SELECTED_LOBS_WITH_MA,
    promise: ({ configurationService }) => configurationService.shareSelectedLobsWithMA()
  };
}
