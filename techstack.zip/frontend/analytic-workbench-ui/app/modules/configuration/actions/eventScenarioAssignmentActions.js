import { ActionsNamespace } from 'react-techstack/redux';

export const actionsNamespace = new ActionsNamespace('EVENT_SCENARIO_ASSIGNMENT');
export const LOAD_EVENT_SCENARIO_DICTIONARY = actionsNamespace.createAsyncAction('LOAD_EVENT_SCENARIO_DICTIONARY');
export const LOAD_ISSUER_GROUPS = actionsNamespace.createAsyncAction('LOAD_ISSUER_GROUPS');
export const SAVE_ISSUER_GROUPS = actionsNamespace.createAsyncAction('SAVE_ISSUER_GROUPS');
export const LOAD_DEFAULT_ISSUER = actionsNamespace.createAsyncAction('LOAD_DEFAULT_ISSUER');

export function loadEventScenarioDictionary() {

  return {
    type: LOAD_EVENT_SCENARIO_DICTIONARY,
    promise: ({ configurationService }) => configurationService.loadEventScenarioDictionary()
  };
}

export function loadIssuerGroups(issuerId) {
  return {
    type: LOAD_ISSUER_GROUPS,
    promise: ({ configurationService }) => configurationService.loadIssuerGroups(issuerId)
  };
}

export function saveIssuerGroups(issuerId, groupList) {
  return {
    type: SAVE_ISSUER_GROUPS,
    meta: { groupList },
    promise: ({ configurationService }) => configurationService.saveIssuerGroups(issuerId, groupList)
  };
}

export function loadDefaultIssuer() {
  return {
    type: LOAD_DEFAULT_ISSUER,
    promise: ({ issuerService }) => issuerService.loadDefaultIssuer()
  };
}
