import { createAsyncAction, createAction } from 'react-techstack/redux';
import { prepareDictionariesColumns } from 'modules/configuration/utils';


export const LOAD_GROUP_DEFINITION_DICTIONARY = createAsyncAction('LOAD_GROUP_DEFINITION_DICTIONARY');
export const LOAD_GROUP_FILTERS = createAsyncAction('LOAD_GROUP_FILTERS');
export const LOAD_GROUP_MEMBERS = createAsyncAction('LOAD_GROUP_MEMBERS');
export const APPLY_GROUP_MEMBERS_FILTER = createAction('APPLY_GROUP_MEMBERS_FILTER');
export const APPLY_GROUP_MEMBERS_NAME_SEARCH = createAction('APPLY_GROUP_MEMBERS_NAME_SEARCH');
export const APPLY_GROUP_MEMBERS_SORT = createAction('APPLY_GROUP_MEMBERS_SORT');
export const RESET_GROUP_MEMBERS_TABLE = createAction('RESET_GROUP_MEMBERS_TABLE');
export const APPLY_STATIC_ISSUERS_OVERWRITE = createAction('APPLY_STATIC_ISSUERS_OVERWRITE');
export const LOAD_TABLE_FILTERS_DICTIONARY = createAsyncAction('LOAD_TABLE_FILTERS_DICTIONARY');
export const SAVE_GROUP = createAsyncAction('SAVE_GROUP');
export const CREATE_GROUP = createAsyncAction('CREATE_GROUP');
export const RESET_FILTERS = createAction('RESET_FILTERS');
export const LOAD_GROUP = createAsyncAction('LOAD_GROUP');
export const GET_GENERATED_GROUP_NAME = createAsyncAction('GET_GENERATED_GROUP_NAME');


export function loadGroupDefinitionDictionary() {

  return {
    type: LOAD_GROUP_DEFINITION_DICTIONARY,
    promise: ({ configurationService }) => configurationService.loadGroupDefinitionDictionary()
  };
}

export function loadGroupFilters(groupIsDefinedById) {

  return {
    type: LOAD_GROUP_FILTERS,
    meta: {
      groupIsDefinedById
    },
    promise: ({ configurationService }) => configurationService.loadGroupFilters(groupIsDefinedById)
  };
}

export function loadGroupMembers(groupDefinitionId, filters) {
  return {
    type: LOAD_GROUP_MEMBERS,
    promise: ({ configurationService }) => configurationService.loadGroupMembers(groupDefinitionId, filters)
  };
}

// export function loadGroupMembers(pageNumber) {
//   return (dispatch, getState) => {
//     const { levelId, filters, tableFilters, needle, sortKey, ascending } = getState().configuration.groupForm;
//     const sortOrder = {
//       property: sortKey,
//       direction: ascending ? 'ASC' : 'DESC'
//     };
//     const searchDto = {
//       filters: merge(filters, tableFilters),
//       needle,
//       sortOrder
//     };
//
//
//     dispatch({
//       type: LOAD_GROUP_MEMBERS,
//       promise: ({ configurationService }) => configurationService.loadGroupMembers(levelId, pageNumber, searchDto)
//     });
//   };
// }

export function applyGroupMembersFilter(attributeName, options) {
  return {
    type: APPLY_GROUP_MEMBERS_FILTER,
    attributeName,
    options
  };
}

export function applyGroupMembersNameSearch(needle) {
  return {
    type: APPLY_GROUP_MEMBERS_NAME_SEARCH,
    needle
  };
}

export function applyGroupMembersSort(sortKey, ascending) {
  return {
    type: APPLY_GROUP_MEMBERS_SORT,
    sortKey,
    ascending
  };
}

export function resetGroupMembersTable(filters) {
  return {
    type: RESET_GROUP_MEMBERS_TABLE,
    filters
  };
}

export function loadTableFiltersDictionary() {
  return (dispatch, getState) => {
    const { columns } = getState().configuration.groupForm.members;
    const { filterQueryIds } = getState().configuration.groupForm;
    const dictionariesColumns = prepareDictionariesColumns(columns, filterQueryIds);

    dispatch({
      type: LOAD_TABLE_FILTERS_DICTIONARY,
      promise: ({ configurationService }) => configurationService.loadTableFiltersDictionary(dictionariesColumns)
    });
  };
}

export function saveGroup(formData) {
  return {
    type: SAVE_GROUP,
    formData,
    promise: ({ configurationService }) => configurationService.saveGroup(formData.id, formData)
  };
}

export function createGroup(formData) {
  return {
    type: SAVE_GROUP,
    formData,
    promise: ({ configurationService }) => configurationService.createGroup(formData)
  };
}

export function resetFilters() {
  return {
    type: RESET_FILTERS
  };
}

export function loadGroupData(groupId) {
  return (dispatch) => {
    dispatch({
      type: LOAD_GROUP,
      promise: ({ configurationService }) => configurationService.loadGroupData(groupId)
    });
  };
}

export function applyStaticIssuersOverwrite() {
  return {
    type: APPLY_STATIC_ISSUERS_OVERWRITE
  };
}

export function getGeneratedGroupName(issuerId) {
  return {
    type: GET_GENERATED_GROUP_NAME,
    promise: ({ configurationService }) => configurationService.getGeneratedGroupName(issuerId)
  };
}
