import { createAsyncAction } from 'react-techstack/redux';

export const LOAD_CONSOLIDATED_FILTER_DICTIONARY = createAsyncAction('LOAD_CONSOLIDATED_FILTER_DICTIONARY');
export const LOAD_CONSOLIDATED_FILTER_DATA = createAsyncAction('LOAD_CONSOLIDATED_FILTER_DATA');
export const SAVE_CONSOLIDATED_FILTER_DATA = createAsyncAction('SAVE_CONSOLIDATED_FILTER_DATA');

export function loadConsolidatedFilterDictionary() {

  return {
    type: LOAD_CONSOLIDATED_FILTER_DICTIONARY,
    promise: ({ configurationService }) => configurationService.loadConsolidatedFilterDictionary()
  };
}

export function loadConsolidatedFilterData(issuerId) {

  return {
    type: LOAD_CONSOLIDATED_FILTER_DATA,
    issuerId,
    promise: ({ configurationService }) => configurationService.loadConsolidatedFilterData(issuerId)
  };
}

export function saveConsolidatedFilterData(issuerId, formData) {
  return {
    type: SAVE_CONSOLIDATED_FILTER_DATA,
    issuerId,
    formData,
    promise: ({ configurationService }) => configurationService.saveConsolidatedFilterData(issuerId, formData)
  };
}
