import { handleActions } from 'react-techstack/redux';

import { LOAD_APP_INIT_DATA } from 'modules/common/actions/configActions';

function getInitialState() {
  return {
    navigation: [],
    externalURIs: {},
    tableauIFrameURIs: {}
  };
}

export default handleActions({
  [LOAD_APP_INIT_DATA.REQUEST]() {
    return getInitialState();
  },

  [LOAD_APP_INIT_DATA.SUCCESS](storage, {payload}) {
    return {
      ...storage,
      navigation: payload.navigation,
      externalURIs: payload.externalURIs,
      tableauIFrameURIs: payload.tableauIFrameURIs
    };
  }

}, getInitialState());
