import { handleActions } from 'react-techstack/redux';

import {LOAD_APP_INIT_DATA} from 'modules/common/actions/configActions';

export const INITIAL_STATE = {
  id: '',
  firstName: '',
  lastName: '',
  fullName: '',
  username: '',
  permissions: []
};

export function getInitialState() {
  return INITIAL_STATE;
}

function setUserData(storage, user) {
  return {
    id: user.id,
    firstName: user.firstName,
    lastName: user.lastName,
    fullName: user.fullName,
    username: user.username,
    permissions: user.permissions
  };
}

export default handleActions({
  [LOAD_APP_INIT_DATA.REQUEST]() {
    return getInitialState();
  },

  [LOAD_APP_INIT_DATA.SUCCESS](storage, {payload}) {
    return setUserData(storage, payload.user);
  }
}, getInitialState());
