import { handleActions } from 'react-techstack/redux';

import {OPEN_EXTERNAL_URL} from 'modules/common/actions/commonActions';
import {FILE_DOWNLOAD} from 'modules/common/actions/downloadFileActions';

function getInitialState() {
  return {};
}

function openURL(url, newTab = false) {
  if (url) {
    if (newTab) {
      window.open(url, '_blank');
    } else {
      window.location = url;
    }
  }
}

function handleOpenURL(storage, {payload, meta = {}}) {
  openURL(payload, meta.newTab);
  return storage;
}

export default handleActions({
  [FILE_DOWNLOAD.SUCCESS]: handleOpenURL,
  [OPEN_EXTERNAL_URL]: handleOpenURL

}, getInitialState());
