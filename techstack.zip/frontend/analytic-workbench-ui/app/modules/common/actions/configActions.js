import { ActionsNamespace } from 'react-techstack/redux';

import {loadDataViewTypesList} from 'modules/issuerData/actions/dataViewTypeFilterActions';
import {loadQuickFiltersDictionary} from 'modules/issuerLibrary/actions/issuerLibraryActions';

import {getDataViewTypeIdFromURLQuery} from 'modules/issuerData/utils/dataViewTypeUtils';

export const actionsNamespace = new ActionsNamespace('CONFIG');

export const LOAD_APP_INIT_DATA = actionsNamespace.createAsyncAction('LOAD_APP_INIT_DATA');

export function loadAppInitData(issuerId) {
  return {
    type: LOAD_APP_INIT_DATA,
    promise: ({configService}) => configService.loadAppInitData(issuerId)
  };
}

export function loadNavigationData(issuer, options) {
  return (dispatch) => {
    dispatch(loadDataViewTypesList(issuer, getDataViewTypeIdFromURLQuery(options.urlQuery)));
    dispatch(loadQuickFiltersDictionary(options));
  };
}
