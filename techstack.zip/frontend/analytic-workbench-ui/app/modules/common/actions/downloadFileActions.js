import { ActionsNamespaceFactory } from 'react-techstack/redux';

const actionsNamespace = ActionsNamespaceFactory('FILE');

export const FILE_DOWNLOAD = actionsNamespace.createAsyncAction('FILE_DOWNLOAD');

export function downloadFile(url, params, options) {
  return {
    type: FILE_DOWNLOAD,
    meta: options,
    promise: ({downloadFileService}) => downloadFileService.downloadFile(url, params, options)
  };
}
