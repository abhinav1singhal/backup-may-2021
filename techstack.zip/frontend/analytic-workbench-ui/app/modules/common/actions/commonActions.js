import { ActionsNamespaceFactory } from 'react-techstack/redux';

const actionsNamespace = ActionsNamespaceFactory('COMMON');

export const OPEN_EXTERNAL_URL = actionsNamespace.createAction('OPEN_EXTERNAL_URL');

export function openExternalURL(url, newTab = true) {
  return {
    type: OPEN_EXTERNAL_URL,
    meta: {
      newTab
    },
    payload: url
  };
}
