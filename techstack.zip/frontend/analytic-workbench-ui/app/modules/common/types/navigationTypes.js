import PropTypes from 'prop-types';

import {requiredPermissionsType, permissionsListType} from './permissionsTypes';

export const navigationConfigItemType = PropTypes.shape({
  label: PropTypes.string,
  provider: PropTypes.string,
  uri: PropTypes.string,
  items: navigationConfigItemsListType, // eslint-disable-line no-use-before-define
  permissions: requiredPermissionsType,
  target: PropTypes.string
});

export const navigationConfigItemsListType = PropTypes.arrayOf(navigationConfigItemType);

export const navigationDataType = PropTypes.shape({
  permissions: permissionsListType.isRequired
  // currentIssuer:
  // currentLOB:
  // ilvQuickFilters:
  // idvViews:
});

export const navigationItemType = PropTypes.shape({
  label: PropTypes.string.isRequired,
  uri: PropTypes.string,
  items: navigationItemsListType, // eslint-disable-line no-use-before-define
  target: PropTypes.string
});

export const navigationItemsListType = PropTypes.arrayOf(navigationItemType);
