import PropTypes from 'prop-types';

export const dictionaryItemType = PropTypes.shape({
  id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  name: PropTypes.string.isRequired
  // description: PropTypes.string.isRequired // ToDo: remove this field ???
});

export const dictionaryType = PropTypes.arrayOf(dictionaryItemType);

export const dictionariesListType = PropTypes.objectOf(dictionaryType);
