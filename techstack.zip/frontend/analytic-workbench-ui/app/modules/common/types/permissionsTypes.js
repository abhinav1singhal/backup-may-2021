import PropTypes from 'prop-types';

export const permissionType = PropTypes.string;

export const permissionsListType = PropTypes.arrayOf(permissionType);

export const requiredPermissionsType = PropTypes.oneOfType([
  permissionType, permissionsListType
]);
