import PropTypes from 'prop-types';

export const tableauURIType = PropTypes.string;

export const tableauURIsListType = PropTypes.objectOf(tableauURIType);
