import PropTypes from 'prop-types';

export const menuItemType = PropTypes.shape({
  label: PropTypes.string.isRequired,
  link: PropTypes.string,
  permission: PropTypes.arrayOf(PropTypes.string)
});

export const menuItemsListType = PropTypes.arrayOf(menuItemType);
