const MESSAGES = {
  basePageTitle: 'Analytic Workbench - techstack\'s',
  pageTitle: '%1s | %2s',
  unexpectedErrorNotification: {
    title: 'An unexpected error occurred.'
  },
  loadingMessage: 'Loading, please wait...',
  region: 'Region',
  lob: 'Analytic Sector 2',
  sector: 'Analytic Sector 3',
  country: 'Country'
};

export default MESSAGES;
