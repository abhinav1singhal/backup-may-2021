const MESSAGES = {
  pageTitle: 'Tableau'
};

export default MESSAGES;
