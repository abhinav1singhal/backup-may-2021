import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';

import {PageHeader} from 'modules/common/components';

import theme from './PageLayout.css';
import {issuerIdType, lobIdType} from 'modules/issuer/types/issuerTypes';

class PageLayout extends React.Component {
  static propTypes = {
    header: PropTypes.node,
    main: PropTypes.node.isRequired,
    menu: PropTypes.node,

    defaultIssuerId: issuerIdType,
    defaultLOBId: lobIdType,
    location: PropTypes.object.isRequired, // ToDo: improve this validation

    theme: PropTypes.shape({
      root: PropTypes.string
    }).isRequired
  };

  render() {
    const {main, defaultIssuerId, defaultLOBId, location, theme: customTheme} = this.props;

    const PageHeaderProps = {
      defaultIssuerId,
      defaultLOBId,
      location
    };

    return (
      <div className={classNames(theme.root, customTheme.root)}>
        <PageHeader {...PageHeaderProps} />
        {main}
      </div>
    );
  }
}

PageLayout.defaultProps = {
  theme: {}
};

export default PageLayout;
