import { connect } from 'react-redux';

import PageHeader from './PageHeader';

function mapStateToProps(state) {
  return {
    userName: state.user.fullName
  };
}

const mapDispatchToProps = {

};

export default connect(mapStateToProps, mapDispatchToProps)(PageHeader);
