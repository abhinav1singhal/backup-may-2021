import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';

import {Navigation} from 'modules/common/components';
import {PageHeader as PageHeaderBase} from 'modules/shared/components';
import {IssuerSelector, IssuerSummary, ISSUER_SELECTOR_INLINE_STYLE} from 'modules/issuer/components';

import theme from './PageHeader.css';
import {issuerIdType, lobIdType} from 'modules/issuer/types/issuerTypes';

class PageHeader extends React.Component {
  static propTypes = {
    defaultIssuerId: issuerIdType,
    defaultLOBId: lobIdType,
    location: PropTypes.object.isRequired,

    userName: PropTypes.string
  };

  render() {
    const {defaultIssuerId, defaultLOBId, location, userName} = this.props;

    const IssuerSelectorProps = {
      defaultIssuerId,
      defaultLOBId,
      lobLabel: null,
      issuerLabel: null,
      theme: {
        root: classNames(ISSUER_SELECTOR_INLINE_STYLE, theme.issuerSelector),
        lob: theme.lob
      }
    };

    const PageHeaderBaseProps = {
      header: <IssuerSelector {...IssuerSelectorProps} />,
      sidebar: <Navigation location={location} />,
      userName,
      theme: {
        sidebar: theme.sidebar
      }
    };

    return (
      <PageHeaderBase {...PageHeaderBaseProps}>
        <IssuerSummary />
      </PageHeaderBase>
    );
  }
}

PageHeader.defaultProps = {
  theme: {}
};

export default PageHeader;
