import PropTypes from 'prop-types';

import {LoadingContainer as LoadingContainerBase} from 'modules/shared/components';
import {isNotEmptyString} from 'modules/common/utils/stringUtils';
import {getMessage} from 'modules/common/utils/messagesUtils';

class LoadingContainer extends LoadingContainerBase {
  renderMessage() {
    const {message, rawMessage} = this.props;
    super.renderMessage(isNotEmptyString(message) ? getMessage(message) : rawMessage);
  }
}

LoadingContainer.propTypes = {
  ...LoadingContainerBase.propTypes,

  message: PropTypes.string,
  rawMessage: PropTypes.string
};

LoadingContainer.defaultProps = {
  ...LoadingContainerBase.defaultProps,

  spinnerType: 'primary'
};

export default LoadingContainer;
