import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import {LoadingContainer} from 'react-techstack';
import {asyncStatusTypes, asyncStatusUtils} from 'react-techstack/utils';
import { history } from 'main';
import NavigationItem from './NavigationItem';
import { isNotEmptyArray } from 'react-techstack/utils/array';
import {
  shouldUpdateNavigationItemsList, prepareNavigationItemsList
} from 'modules/common/utils/navigation/listUtils';
import {shouldLoadNavigationData} from 'modules/common/utils/navigation/dataUtils';
const {isPending} = asyncStatusUtils;

import theme from './Navigation.css';
import {navigationConfigItemsListType, navigationDataType} from 'modules/common/types/navigationTypes';
const {asyncStatusType} = asyncStatusTypes;

class Navigation extends React.Component {
  static propTypes = {
    config: navigationConfigItemsListType.isRequired,
    data: navigationDataType.isRequired,
    location: PropTypes.object.isRequired,

    loadNavigationData: PropTypes.func.isRequired,

    dataRequestStatus: asyncStatusType.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string
    }).isRequired
  };

  constructor(props) {
    super(props);

    this.state = {
      items: prepareNavigationItemsList(props.config, props.data)
    };
  }

  UNSAFE_componentWillReceiveProps(props) {
    if (shouldLoadNavigationData(props, this.props)) {
      props.loadNavigationData(props.data.currentIssuer, {
        urlQuery: props.location.query,
        pathname: props.location.pathname
      });

      if (props.location.query.dataViewTypeId) {
        history.replace(props.location.pathname);
      }
    }

    if (shouldUpdateNavigationItemsList(props, this.props)) {
      this.setState({items: prepareNavigationItemsList(props.config, props.data)});
    }
  }

  renderItems(items) {
    if (!isNotEmptyArray(items)) {
      return null;
    }

    return (
      <ul>
        {items.map((item, index) => {
          const NavigationItemProps = {
            config: item,
            key: `NavigationItem-${index}`
          };

          return <NavigationItem {...NavigationItemProps} />;
        })}
      </ul>
    );
  }

  render() {
    const {dataRequestStatus, theme: customTheme} = this.props;

    const LoadingContainerProps = {
      isLoading: isPending(dataRequestStatus),
      title: 'Loading, please wait...',
      offset: 50,
      spinner: 'white',
      circleColor: '#335d86'
    };

    return (
      <nav role="navigation" className={classNames(theme.root, customTheme.root)}>
        <LoadingContainer {...LoadingContainerProps}>
          {this.renderItems(this.state.items)}
        </LoadingContainer>
      </nav>
    );
  }
}

Navigation.defaultProps = {
  theme: {}
};

export default Navigation;
