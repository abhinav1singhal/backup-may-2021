import { connect } from 'react-redux';
import {loadNavigationData} from 'modules/common/actions/configActions';
import Navigation from './Navigation';

import {
  prepareNavigationData, prepareNavigationDataRequestStatus
} from 'modules/common/utils/navigation/dataUtils';

function mapStateToProps(state) {
  return {
    config: state.config.navigation,
    data: prepareNavigationData(state),
    dataRequestStatus: prepareNavigationDataRequestStatus(state)
  };
}

const mapDispatchToProps = {
  loadNavigationData
};

export default connect(mapStateToProps, mapDispatchToProps)(Navigation);
