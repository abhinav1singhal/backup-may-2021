import React from 'react';
import classNames from 'classnames';
import InlineSVG from 'svg-inline-react';
import {Collapse} from 'react-techstack';

import { isNotEmptyArray } from 'react-techstack/utils/array';

import theme from './NavigationItem.css';
import {navigationItemType} from 'modules/common/types/navigationTypes';
const expandIcon = require('!!svg-inline-loader!./expand.svg');
const collapseIcon = require('!!svg-inline-loader!./collapse.svg');

class NavigationItem extends React.Component {
  static propTypes = {
    config: navigationItemType.isRequired
  };

  constructor(props) {
    super(props);

    this.state = {
      showSubItems: false
    };
  }

  toggleShowSubItems(event) {
    if (isNotEmptyArray(this.props.config.items)) {
      event.preventDefault();
      this.setState({showSubItems: !this.state.showSubItems});
    }
  }

  renderItems(items) {
    if (!isNotEmptyArray(items)) {
      return null;
    }

    return (
      <Collapse in={this.state.showSubItems}>
        <ul className={theme.subItemsList}>
          {items.map((item, index) => {
            return (
              <li key={`NavigationSubItem-${index}`}>
                <a href={item.link} target={item.target}>{item.label}</a>
              </li>
            );
          })}
        </ul>
      </Collapse>
    );
  }

  renderSubItemsIcon(items) {
    if (!isNotEmptyArray(items)) {
      return null;
    }

    const iconProps = {
      src: this.state.showSubItems ? expandIcon : collapseIcon,
      className: theme.subItemsIcon
    };

    return <InlineSVG {...iconProps} />;
  }

  render() {
    const {config} = this.props;

    const itemProps = {
      className: classNames(theme.root, {
        [theme.showSubItems]: this.state.showSubItems
      })
    };

    const linkProps = {
      onClick: this.toggleShowSubItems.bind(this),
      href: config.link,
      target: config.target
    };

    return (
      <li {...itemProps}>
        <a {...linkProps}>
          {this.renderSubItemsIcon(config.items)}
          {config.label}
        </a>
        {this.renderItems(config.items)}
      </li>
    );
  }
}

export default NavigationItem;
