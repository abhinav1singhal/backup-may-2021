import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { LoadingContainer } from 'react-techstack';

import {getMessage} from 'modules/common/utils/messagesUtils';

import theme from './PageContent.css';

class PageContent extends React.Component {
  static propTypes = {
    isLoading: PropTypes.bool,

    children: PropTypes.node.isRequired,

    loadingMessage: PropTypes.string.isRequired,
    className: PropTypes.string
  };

  render() {
    const {isLoading, loadingMessage, className} = this.props;

    const LoadingContainerProps = {
      isLoading,
      title: getMessage(loadingMessage),
      offset: 250,
      spinner: 'primary'
    };

    return (
      <LoadingContainer {...LoadingContainerProps}>
        <section className={classNames(theme.root, className)}>
          {this.props.children}
        </section>
      </LoadingContainer>
    );
  }
}

PageContent.defaultProps = {
  loadingMessage: 'common.loadingMessage'
};

export default PageContent;
