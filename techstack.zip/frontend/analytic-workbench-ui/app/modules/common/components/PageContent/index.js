export default from './PageContent';
