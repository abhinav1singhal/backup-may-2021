import { connect } from 'react-redux';

import TableauIFrame from './TableauIFrame';

function mapStateToProps(state) {
  return {
    config: state.config.tableauIFrameURIs,
    currentIssuer: state.issuer.currentIssuer
  };
}

export default connect(mapStateToProps)(TableauIFrame);
