import PropTypes from 'prop-types';
import React from 'react';
import {Page404} from 'react-techstack';
import { get, replace } from 'lodash';
import {prepareLink} from 'modules/common/utils/navigation/linkUtils';

import theme from './TableauIFrame.css';
import {tableauURIsListType} from 'modules/common/types/tableauTypes';
import {issuerType} from 'modules/issuer/types/issuerTypes';

class TableauIFrame extends React.Component {
  static propTypes = {
    config: tableauURIsListType.isRequired,
    reportKey: PropTypes.string,
    currentIssuer: issuerType,

    theme: PropTypes.shape({
      root: PropTypes.string,
      iframe: PropTypes.string
    }).isRequired
  };

  prepareReportURI = () => {
    const { config, currentIssuer, reportKey } = this.props;
    const orgNum = get(currentIssuer, 'id');
    const orgName = get(currentIssuer, 'name');
    const dashboardParam = `${encodeURI(orgName)} - ${orgNum}`;

    // Get URLs from config
    const dashboardsAndReports = get(config, 'dashboardsAndReports');
    const issuerSupplementalDataView = get(config, 'issuerSupplementalDataView');
    const homePage = get(config, 'homePage');
    const issuerDashboard = get(config, 'issuerDashboard');

    // Populate orgNum/Issuer
    const darURLWithIssuer = replace(dashboardsAndReports, '${tableauIssuerParam()}', dashboardParam);
    const isdvURLWithIssuer = replace(issuerSupplementalDataView, '${tableauIssuerParam()}', dashboardParam);
    const idWithIssuer = replace(issuerDashboard, '${tableauIssuerParam()}', dashboardParam);
    const urlArray = [darURLWithIssuer, homePage, idWithIssuer, isdvURLWithIssuer];

    return prepareLink(urlArray[reportKey], currentIssuer);
  }

  render() {
    const url = this.prepareReportURI();

    return (
      <div className={theme.root}>
        {url ? <iframe ref="iframe" src={url} className={theme.iframe} /> : <Page404 /> }
      </div>
    );
  }
}

TableauIFrame.defaultProps = {
  theme: {}
};

export default TableauIFrame;
