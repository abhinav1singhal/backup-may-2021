import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { notificationActions } from 'react-techstack/redux/actions';
import { NotificationCenter } from 'modules/shared/components';

export function mapStateToProps(state) {
  return {
    notifications: state.notifications
  };
}

export function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    onHide: notificationActions.hideNotification
  }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(NotificationCenter);
