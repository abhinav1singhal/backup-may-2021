import { get, memoize } from 'lodash';
import { vsprintf } from 'sprintf-js';

import MESSAGES from 'config/messages';
import { isNotEmptyString } from 'react-techstack/utils/string';
import { isNotEmptyArray} from 'react-techstack/utils/array';

const findMessage = memoize((key) => {
  const message = get(MESSAGES, key);

  if (isNotEmptyString(message) && message.startsWith('$message:')) {
    return findMessage(message.replace('$message:', ''));
  }

  return message;
});

const formatMessage = memoize(([message, ...args]) => {
  return vsprintf(message, args);
});

/**
 * Get cached message be key (object path) from messages store
 * if optional args are specified than message will be interpolated as a template using 'sprintf-js' library
 *
 * @param {string} key - message key
 * @param {...*} [args] - data that will be passed to 'sprintf-js/vsprintf' for inserting into message template
 * @returns {string}
 */
export function getMessage(key, ...args) {
  const message = findMessage(key);

  if (!isNotEmptyString(message)) {
    return `MESSAGE_NOT_FOUND: '${key}'`;
  }

  if (isNotEmptyArray(args)) {
    return formatMessage([message, ...args]);
  }

  return message;
}
