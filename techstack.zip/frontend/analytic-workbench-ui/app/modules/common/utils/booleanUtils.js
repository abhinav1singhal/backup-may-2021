import { isString, isBoolean } from 'lodash/lang';

import {isNotEmptyString} from 'modules/common/utils/stringUtils';
import { logger } from 'react-techstack/utils';

const TRUTHY_FLAG = 'Y';
const TRUTHY_VALUES = [TRUTHY_FLAG, 'YES', 'TRUE'];
const FALSY_FLAG = 'N';
const FALSY_VALUES = [FALSY_FLAG, 'NO', 'FALSE'];

export function parseBooleanStringValue(value) {
  if (isNotEmptyString(value)) {
    const needle = value.toUpperCase();

    if (TRUTHY_VALUES.indexOf(needle) !== -1) {
      return true;
    } else if (FALSY_VALUES.indexOf(needle) !== -1) {
      return false;
    }

    logger.debug(`'${value}' - is not a valid boolean string value`);
  }

  return undefined;
}

export function prepareBooleanStringFlag(value) {
  if (isBoolean(value)) {
    return value ? TRUTHY_FLAG : FALSY_FLAG;
  }

  return undefined;
}

// ToDo: replace all usages in favor of parseBooleanStringValue()
export function toBoolean(value) {
  const trulyValues = ['Y', 'YES', 'TRUE'];

  return isString(value) && trulyValues.indexOf(value.toUpperCase()) !== -1;
}

export function prepareFlag(value, fullValue = false) {
  if (value) {
    return fullValue ? 'YES' : 'Y';
  }
  return fullValue ? 'NO' : 'N';
}
