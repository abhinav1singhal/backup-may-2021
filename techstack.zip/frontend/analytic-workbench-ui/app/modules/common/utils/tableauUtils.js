import { isEqual, isArray } from 'lodash';
import { isNotEmptyString } from 'react-techstack/utils/string';

// ! * \' ( ) ; : @ & = + $ , / ? # [ ]
const TABLEAU_SPECIAL_CHARS_REGEXP = /[\\!*'();:@&=+$,\/?#\[\]]/g;

// from axios buildURL
function encode(val) {
  return encodeURIComponent(val).
    replace(/%40/gi, '@').
    replace(/%3A/gi, ':').
    replace(/%24/g, '$').
    replace(/%2C/gi, ',').
    replace(/%20/g, '+').
    replace(/%5B/gi, '[').
    replace(/%5D/gi, ']');
}

export function shouldUpdateTableauIFrameURI(props, oldProps) {
  return (
    props.reportKey !== oldProps.reportKey ||
    !isEqual(props.currentIssuer, oldProps.currentIssuer) ||
    !isEqual(props.config, oldProps.config)
  );
}

export function escapeTableauUrlParam(param, encoded = true) {
  if (!isNotEmptyString(param)) {
    return undefined;
  }

  const result = param.replace(TABLEAU_SPECIAL_CHARS_REGEXP, '\\$&');
  return encoded ? encode(result) : result;
}

export function prepareTableauIssuerParam(issuer = {}, encoded) {
  return (issuer.id) ? escapeTableauUrlParam(`${issuer.name} - ${issuer.id}`, encoded) : undefined;
}

export function prepareTableauStatementRevisionIdParam(statementRevisionIds) {
  const ids = isArray(statementRevisionIds) ? statementRevisionIds : [statementRevisionIds];
  return ids.join(',').replace(/-/g, '').toUpperCase();
}
