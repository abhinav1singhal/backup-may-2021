import {map, get, forEach, isUndefined, isPlainObject, isFunction, isArray} from 'lodash';
import { isNotEmptyString } from 'react-techstack/utils/string';
import { isNotEmptyArray } from 'react-techstack/utils/array';

const PROCESSORS_LIST_PROPERTY = Symbol('DictionariesConfig');
const VARIABLE_REGEXP = /\${([^}]*)}/g;
const FUNCTION_REGEXP = /^(\w[\w\d]*)\(([^)]*)\)$/i;

export default class MagicStringUtils {
  constructor(processorsList) {
    this[PROCESSORS_LIST_PROPERTY] = {};

    if (isPlainObject(processorsList)) {
      forEach(processorsList, (processor, key) => {
        if (isNotEmptyString(key) && isFunction(processor)) {
          this[PROCESSORS_LIST_PROPERTY][key] = processor;
        }
      });
    }
  }

  isValidProcessor(key) {
    return isFunction(this[PROCESSORS_LIST_PROPERTY][key]);
  }

  prepareProcessorConfig(value) {
    const config = FUNCTION_REGEXP.exec(value);
    if (isNotEmptyArray(config) && this.isValidProcessor(config[1])) {
      return {
        key: config[1],
        options: isNotEmptyString(config[2]) ? map(config[2].split(','), (item) => item.trim()) : []
      };
    }

    return undefined;
  }

  executeProcessor(key, options = []) {
    if (this.isValidProcessor(key) && isArray(options)) {
      return this[PROCESSORS_LIST_PROPERTY][key](...options);
    }

    return undefined;
  }

  parse(value, data) {
    if (!isNotEmptyString(value)) {
      return undefined;
    }

    return value.replace(VARIABLE_REGEXP, (variable, key) => {
      const config = this.prepareProcessorConfig(key);
      if (!isUndefined(config)) {
        return this.executeProcessor(config.key, [data, ...config.options]);
      }

      return isNotEmptyString(key) ? get(data, key, '') : '';
    });
  }
}
