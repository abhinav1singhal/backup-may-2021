import isArray from 'lodash/isArray';

export function isEmptyArray(value) {
  return isArray(value) && value.length === 0;
}

export function isNotEmptyArray(value) {
  return isArray(value) && value.length > 0;
}

export function convertArrayToValueIfPossible(value) {
  return (isNotEmptyArray(value) && value.length <= 1) ? value[0] : value;
}
