import { Notification } from 'react-techstack';

import { getMessage } from './messagesUtils';
import { isNotEmptyString } from 'react-techstack/utils/string';

export function unexpectedErrorNotification(messageKey, titleKey) {
  return Notification.error(
    isNotEmptyString(titleKey) ? getMessage(titleKey) : getMessage('common.unexpectedErrorNotification.title'),
    isNotEmptyString(messageKey) ? getMessage(messageKey) : undefined
  );
}

export function successNotification(messageKey, titleKey) {
  return Notification.success(
    isNotEmptyString(titleKey) ? getMessage(titleKey) : undefined,
    isNotEmptyString(messageKey) ? getMessage(messageKey) : undefined
  );
}

export function warningNotification(messageKey, titleKey) {
  return Notification.warning(
    isNotEmptyString(titleKey) ? getMessage(titleKey) : undefined,
    isNotEmptyString(messageKey) ? getMessage(messageKey) : undefined
  );
}


