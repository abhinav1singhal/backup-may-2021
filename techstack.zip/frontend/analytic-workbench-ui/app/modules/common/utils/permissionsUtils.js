import {intersection, reduce, isPlainObject} from 'lodash';
import { isNotEmptyString } from 'react-techstack/utils/string';
import { isNotEmptyArray, convertArrayToValueIfPossible } from 'react-techstack/utils/array';

function preparePermissionKey(permission) {
  return permission.toUpperCase();
}

export function preparePermissionsList(permissions) {
  return reduce(permissions, (result, item) => {
    if (isNotEmptyString(item)) {
      result.push(preparePermissionKey(item));
    }

    return result;
  }, []);
}

// ToDo: check if hasAllPermissions is still needed
export function hasPermission(permissionsList, requiredPermission, hasAllPermissions = false) {
  if (!isNotEmptyArray(permissionsList)) {
    return false;
  }

  const permission = convertArrayToValueIfPossible(requiredPermission);
  if (isNotEmptyString(permission)) {
    return permissionsList.indexOf(preparePermissionKey(permission)) !== -1;
  }

  if (isNotEmptyArray(permission)) {
    const intersectionLength = intersection(permissionsList, preparePermissionsList(permission)).length;

    return hasAllPermissions ? intersectionLength === permission.length : intersectionLength > 0;
  }

  return true;
}

function isValidPermission(permission) {
  return isNotEmptyString(permission) || isNotEmptyArray(permission);
}

export function getRequiredPagePermission(page) {
  if (
    isPlainObject(page) && isPlainObject(page.props) && isPlainObject(page.props.route) &&
    isValidPermission(page.props.route.permissions)
  ) {
    return page.props.route.permissions;
  }

  return undefined;
}
