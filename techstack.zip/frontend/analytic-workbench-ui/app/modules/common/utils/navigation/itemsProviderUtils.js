import {map, findIndex, every, has, isPlainObject} from 'lodash';
import {isNotEmptyArray} from 'react-techstack/utils/array';
import {isNotEmptyString} from 'react-techstack/utils/string';

import {DATA_VIEW_TYPE_ID_URL_QUERY_PARAM_KEY} from 'modules/issuerData/utils/dataViewTypeUtils';

const STRING_CONSTANT_REGEXP = /^'.*'$/;

function itemsListMapper(configItem, list, mapper) {
  if (!isNotEmptyArray(list)) {
    return [{
      label: configItem.label,
      uri: configItem.uri,
      permissions: configItem.permissions
    }];
  }

  return map(list, (item) => mapper(item), []);
}

function ilvQuickFiltersList(configItem, data) {
  return itemsListMapper(configItem, data.ilvQuickFilters, (item) => {
    return {
      ...item,
      uri: `${configItem.uri}/${item.id}`,
      permissions: item.permission
    };
  });
}

function idvViewsList(configItem, data) {
  return itemsListMapper(configItem, data.idvViewTypes, (item) => {
    return {
      ...item,
      label: item.name,
      uri: `${configItem.uri}?${DATA_VIEW_TYPE_ID_URL_QUERY_PARAM_KEY}=${item.id}`
    };
  });
}

function showItemForLOBid(configItem, data, ...lobList) {
  if (isPlainObject(data.currentLOB) && isNotEmptyArray(lobList) && findIndex(lobList, (item) => item === `${data.currentLOB.id}`) !== -1) {
    return [configItem];
  }

  return [];
}

function isNotEmptyValues(keys, data) {
  return every(keys, (key) => {
    if (STRING_CONSTANT_REGEXP.test(key)) {
      return isNotEmptyString(key.substr(1, key.length - 2));
    }

    return has(data, key);
  });
}

function hideItemForEmpty(configItem, data, ...keyList) {
  if (isNotEmptyArray(keyList) && isNotEmptyValues(keyList, data)) {
    return [configItem];
  }

  return [];
}


export const ITEMS_PROVIDERS = {
  ilvQuickFiltersList,
  idvViewsList,
  showItemForLOBid,
  hideItemForEmpty
};
