import {isEqual, isEmpty, compact} from 'lodash';
import {asyncStatusUtils} from 'react-techstack/utils';
const {combineStatuses} = asyncStatusUtils;

const ISSUER_NAME_URL_REGEXP = /[^\w\s]/gi;

export function shouldLoadNavigationData(props, oldProps) {
  return !isEmpty(props.data.currentIssuer) && !isEqual(props.data.currentIssuer, oldProps.data.currentIssuer);
}

function getNavIssuerName(name) {
  const nameWithoutSpecialChars = name.replace(ISSUER_NAME_URL_REGEXP, '');
  const splittedNameWithoutSpaces = compact(nameWithoutSpecialChars.split(' '));

  return splittedNameWithoutSpaces.join('-');
}

function getNavIssuer(currentIssuer) {
  return currentIssuer ?
  {
    ...currentIssuer,
    nameUrl: currentIssuer.nameUrl || getNavIssuerName(currentIssuer.name) // AHS-40221
  } :
  {};
}

export function prepareNavigationData(storage) {
  const { currentIssuer } = storage.issuer;

  return {
    permissions: storage.user.permissions,
    currentIssuer: getNavIssuer(currentIssuer),
    currentLOB: storage.issuer.currentLOB,
    ilvQuickFilters: storage.issuerLibrary.quickFiltersDictionary.toJS(),
    idvViewTypes: storage.issuerDataView.viewTypesList
  };
}

export function prepareNavigationDataRequestStatus(storage) {
  return combineStatuses(
    storage.requests.issuerSelectInitialData.status,
    storage.requests.issuerSelectIssuersList.status,
    storage.requests.issuerLibraryQuickFiltersDictionary.status,
    storage.requests.issuerDataViewTypesList.status
  );
}
