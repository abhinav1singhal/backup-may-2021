import {reduce, isEqual, isUndefined} from 'lodash';
import { isNotEmptyString } from 'react-techstack/utils/string';
import { isNotEmptyArray } from 'react-techstack/utils/array';

import {prepareNavigationConfig} from './configUtils';
import {isExternalURI, prepareLink} from './linkUtils';
import {ITEMS_PROVIDERS} from './itemsProviderUtils';
import MagicStringUtilsProvider from 'modules/common/utils/MagicStringUtils';

const MagicStringUtils = new MagicStringUtilsProvider(ITEMS_PROVIDERS);

function isValidNavigationItem(item) {
  return isNotEmptyString(item.label) && (isNotEmptyString(item.link) || isNotEmptyArray(item.items));
}

function prepareNavigationItem(config, data) {
  const item = {
    label: config.label
  };

  if (isNotEmptyString(config.uri)) {
    item.link = prepareLink(config.uri, data);

    if (isNotEmptyString(config.target)) {
      item.target = config.target;
    } else if (isExternalURI(item.link)) {
      item.target = '_blank';
    }
  }

  if (isNotEmptyArray(config.items)) {
    item.items = prepareNavigationItemsList(config.items, data);  // eslint-disable-line no-use-before-define
  }

  return item;
}

function prepareItemAndAddToList(config, data, list = []) {
  const item = prepareNavigationItem(config, data);
  if (isValidNavigationItem(item)) {
    list.push(item);
  }

  return list;
}

function prepareItemsList(items, data, list = []) {
  if (isNotEmptyArray(items)) {
    list.push(...reduce(items, (result, item) => prepareItemAndAddToList(item, data, result), []));
  }

  return list;
}

export function shouldUpdateNavigationItemsList(props, oldProps) {
  return !isEqual(props.data, oldProps.data);
}

export function prepareNavigationItemsList(config, data) {
  return reduce(config, (itemsList, configItem) => {
    const providerConfig = MagicStringUtils.prepareProcessorConfig(configItem.provider);
    if (!isUndefined(providerConfig)) {
      return prepareItemsList(prepareNavigationConfig(
        MagicStringUtils.executeProcessor(providerConfig.key, [configItem, data, ...providerConfig.options]),
        data.permissions
      ), data, itemsList);
    }

    return prepareItemAndAddToList(configItem, data, itemsList);
  }, []);
}
