import { reduce, isPlainObject } from 'lodash';
import { isNotEmptyString } from 'react-techstack/utils/string';
import { isNotEmptyArray } from 'react-techstack/utils/array';
import { hasPermission } from 'modules/common/utils/permissionsUtils';

function isValidNavigationConfigItem(item) {
  return isNotEmptyString(item.provider) || isNotEmptyString(item.uri) || isNotEmptyArray(item.items);
}

export function prepareNavigationConfig(items, permissions) {
  if (!isNotEmptyArray(permissions)) {
    return [];
  }

  return reduce(items, (config, item) => {
    if (!isPlainObject(item) || !hasPermission(permissions, item.permissions)) {
      return config;
    }

    const configItem = {
      ...item,
      items: []
    };

    if (isNotEmptyArray(item.items)) {
      configItem.items = prepareNavigationConfig(item.items, permissions);
    }

    if (isValidNavigationConfigItem(configItem)) {
      config.push(configItem);
    }

    return config;
  }, []);
}
