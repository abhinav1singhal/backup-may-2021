import { isNotEmptyString } from 'react-techstack/utils/string';

import {LINK_PROCESSORS} from './linkProcessingUtils';
import MagicStringUtilsProvider from 'modules/common/utils/MagicStringUtils';
const MagicStringUtils = new MagicStringUtilsProvider(LINK_PROCESSORS);

const EXTERNAL_URI_REGEX = /^(https?:)?\/\//i;

export function isExternalURI(uri) {
  return EXTERNAL_URI_REGEX.test(uri);
}

export function prepareLink(uri, data) {
  if (!isNotEmptyString(uri)) {
    return undefined;
  }

  const link = MagicStringUtils.parse(uri, data);
  if (isNotEmptyString(link) && link.charAt(0) === '/' && !isExternalURI(link)) {
    return `.${link}`;
  }

  return link;
}
