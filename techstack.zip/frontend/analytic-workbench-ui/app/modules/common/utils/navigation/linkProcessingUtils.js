import {prepareTableauIssuerParam} from 'modules/common/utils/tableauUtils';

export const LINK_PROCESSORS = {
  tableauIssuerParam: (data) => prepareTableauIssuerParam(data.currentIssuer)
};
