import {isString, trim} from 'lodash';

export function isNotEmptyString(value) {
  return isString(value) && trim(value) !== '';
}

export function splitStringByLine(value) {
  return isNotEmptyString(value) ? value.match(/[^\r\n]+/g) : [];
}
