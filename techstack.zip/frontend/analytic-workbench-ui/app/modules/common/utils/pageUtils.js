import { documentTitleDecorator } from 'react-techstack';

import { getMessage } from './messagesUtils';

export function pageTitleDecorator(key) {
  return documentTitleDecorator({
    title: getMessage('common.pageTitle', getMessage(key), getMessage('common.basePageTitle'))
  });
}

export function basePageTitleDecorator() {
  return documentTitleDecorator({
    title: getMessage('common.basePageTitle')
  });
}
