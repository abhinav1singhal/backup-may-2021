import { isUndefined, isNumber, parseInt } from 'lodash';

export function prepareIntValue(value) {
  let result;
  if (!isUndefined(value)) {
    result = parseInt(value);
  }

  return isNumber(result) ? result : undefined;
}
