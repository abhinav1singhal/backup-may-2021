import {BASE_API_URL} from 'config/index';

import {loadCurrentUser} from './userService';
import {loadDefaultIssuer} from 'modules/issuer/services/issuerService';

import {prepareNavigationConfig} from 'modules/common/utils/navigation/configUtils';

function loadConfig(client) {
  return client.get(`${BASE_API_URL}/config`).then(({data}) => data);
}

export default (client) => {
  return {

    loadAppInitData(issuerId) {
      return Promise.all([
        loadConfig(client), loadCurrentUser(client), loadDefaultIssuer(client, issuerId)
      ]).then(([config, currentUser, defaultIssuer]) => {
        return {
          user: currentUser,
          defaultIssuer,
          navigation: prepareNavigationConfig(config.navigation, currentUser.permissions),
          externalURIs: config.externalURIs || {},
          tableauIFrameURIs: config.tableauIFrameURIs || {}
        };
      });
    }

  };
};
