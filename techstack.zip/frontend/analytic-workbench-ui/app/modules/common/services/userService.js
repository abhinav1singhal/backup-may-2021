import {BASE_API_URL} from 'config/index';
import {preparePermissionsList} from 'modules/common/utils/permissionsUtils';

export function loadCurrentUser(client) {
  return client.get(`${BASE_API_URL}/user`).then(({data}) => {
    return {
      id: data.nameId,
      firstName: data.firstName,
      lastName: data.lastName,
      fullName: `${data.firstName || ''} ${data.lastName || ''}`,
      username: data.username,
      permissions: preparePermissionsList(data.permissions)
    };
  });
}
