import {buildURL} from 'react-techstack/utils';
import { isNotEmptyString } from 'react-techstack/utils/string';
import { isPlainObject, now, get } from 'lodash';

export function downloadFile(client, url, prms, options) {
  const params = (!(options && options.noCache === false)) ? Object.assign({noCache: now()}, prms) : prms;

  if ((isPlainObject(url) && isNotEmptyString(url.post)) || (options && options.requestToken)) {
    return client.post(url.post || url, params).then(({data}) => {
      const urlGet = (isPlainObject(url) && url.get ? url.get : url);
      const tokenName = options.tokenName ? options.tokenName : 'token';
      const token = get(data, 'token') || data;
      return buildURL(`${urlGet}`, {
        [tokenName]: token,
        noCache: now()
      });
    });
  }
  return Promise.resolve(buildURL(isPlainObject(url) ? `${url.get}` : `${url}`, params));
}

export default (client) => {
  return {
    downloadFile: (url, params, options) => downloadFile(client, url, params, options)
  };
};
