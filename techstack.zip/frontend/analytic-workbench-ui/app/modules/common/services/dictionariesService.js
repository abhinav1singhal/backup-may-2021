import { BASE_API_URL } from 'config/index';
import { loadDictionaries as loadDictionariesServiceProvider } from 'react-techstack/redux/services';

export function loadDictionaries(client, list) {
  return loadDictionariesServiceProvider(client, list, BASE_API_URL);
}
