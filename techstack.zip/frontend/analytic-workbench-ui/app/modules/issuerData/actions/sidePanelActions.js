import { createAction, createAsyncAction } from 'react-techstack/redux';
import {sidePanelTypes} from '../utils/legacyDataViewUtils';

export const LOAD_ISSUER_DATA = createAsyncAction('LOAD_ISSUER_DATA');
export const SAVE_SIDEPANEL_QUERY = createAction('SAVE_SIDEPANEL_QUERY');

export function loadIssuerData(issuer = {}, {filters, sectionId, accountId, columnRevisionType, fiscalYear}) {
  return {
    type: LOAD_ISSUER_DATA,
    meta: {
      issuerId: issuer.id,
      lobId: issuer.lobId,
      accountId,
      sectionId,
      revisionType: columnRevisionType,
      fiscalYear,
      filters
    },
    promise: ({ legacyIssuerDataViewService }) => legacyIssuerDataViewService.loadIssuerData(issuer, filters)
  };
}


export function openSidePanelForSelectedCell({row, column, isRatio, adjusted, ...cell}, queryParams) {
  return () => {

    switch (queryParams.sidePanelType) {
      case sidePanelTypes.ADJUSTMENTS: {
        // dispatch(openAdjustmentsSidePanel({row, column, ...cell}, queryParams));
        break;
      }
/*      case sidePanelTypes.RATIOS_CELL: {
        dispatch(openRatiosSidePanel({row, column, ...cell}, queryParams));
        break;
      }
      case sidePanelTypes.RATIOS_ROW: {
        dispatch(openRatiosRowSidePanel({row, ...cell}, queryParams));
        break;
      }*/
      default: {
        if (adjusted) {
          // dispatch(openAdjustmentsSidePanel({row, column, ...cell}, queryParams));
        }

/*        if (isRatio) {
          dispatch(openRatiosSidePanel({row, column, ...cell}, queryParams));
        }*/
        break;
      }
    }
  };
}


export function saveSidePanelQuery(params) {
  const additionalParams = {};
  if (params && params.accountId) {
    additionalParams.accountId = /^[0-9]+$/.test(params.accountId) ? parseInt(params.accountId, 10) : params.accountId;
  }

  return {
    type: SAVE_SIDEPANEL_QUERY,
    payload: {
      ...params,
      ...additionalParams
    }
  };
}
