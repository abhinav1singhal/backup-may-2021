import {ActionsNamespaceFactory} from 'react-techstack/redux';

const actionsNamespace = ActionsNamespaceFactory('ISSUER_DATA_VIEW_DISPLAY_CONFIG');

export const LOAD_DATA_VIEW_DISPLAY_CONFIG = actionsNamespace.createAsyncAction('LOAD_CONFIG');
export const CHANGE_DATA_VIEW_DISPLAY_CONFIG = actionsNamespace.createAsyncAction('CHANGE_CONFIG');
export const CHANGE_SHOW_EMPTY_ROWS = actionsNamespace.createAction('CHANGE_SHOW_EMPTY_ROWS');
export const CHANGE_SHOW_ACCOUNT_NUMBER = actionsNamespace.createAction('CHANGE_SHOW_ACCOUNT_NUMBER');
export const CHANGE_FLIP_COA = actionsNamespace.createAction('CHANGE_FLIP_COA');
export const CHANGE_SECTIONS_FILTER = actionsNamespace.createAction('CHANGE_SECTIONS_FILTER');

export function loadDataViewDisplayConfig(issuer) {
  return {
    type: LOAD_DATA_VIEW_DISPLAY_CONFIG,
    promise: ({issuerDataViewService}) => issuerDataViewService.loadDataViewDisplayConfig(issuer)
  };
}

export function changeDataViewDisplayConfig(issuer, displayConfigValues) {
  return (dispatch, getStorage) => {
    const previousDisplayConfig = getStorage().issuerDataView.displayConfig;
    const displayConfig = previousDisplayConfig.clone().setControlsValues(displayConfigValues);
    dispatch({
      type: CHANGE_DATA_VIEW_DISPLAY_CONFIG,
      meta: {
        displayConfig
      },
      promise: ({issuerDataViewService}) => issuerDataViewService.saveDataViewDisplayConfig(issuer, displayConfig)
    });
  };
}

export function changeShowEmptyRows(showEmptyRows) {
  return {
    type: CHANGE_SHOW_EMPTY_ROWS,
    payload: showEmptyRows
  };
}

export function changeShowAccountNumber(showAccountNumber) {
  return {
    type: CHANGE_SHOW_ACCOUNT_NUMBER,
    payload: showAccountNumber
  };
}

export function changeFlipCoa(flipCoa) {
  return {
    type: CHANGE_FLIP_COA,
    payload: flipCoa
  };
}

export function changeSectionsFilter(sectionsFilters) {
  return {
    type: CHANGE_SECTIONS_FILTER,
    payload: sectionsFilters
  };
}
