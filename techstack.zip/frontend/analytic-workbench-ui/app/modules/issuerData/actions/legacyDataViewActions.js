import {ActionsNamespaceFactory} from 'react-techstack/redux';

import {sidePanelTypes, getSelectedEligibleAccounts, accountsPrivacyPanelViewTypes} from '../utils/legacyDataViewUtils';

const actionsNamespace = ActionsNamespaceFactory('LEGACY_ISSUER_DATA_VIEW');

export const OPEN_SIDEPANEL = actionsNamespace.createAction('OPEN_SIDEPANEL');
export const CLOSE_SIDEPANEL = actionsNamespace.createAction('CLOSE_SIDEPANEL');
export const RESET_SIDEPANEL_DATA = actionsNamespace.createAction('RESET_SIDEPANEL_DATA');
export const TOGGLE_SIDEPANEL = actionsNamespace.createAction('TOGGLE_SIDEPANEL');
export const RESIZE_SIDEPANEL = actionsNamespace.createAction('RESIZE_SIDEPANEL');

export const LOAD_PRIVACY_MANAGEMENT_DATA = actionsNamespace.createAsyncAction('LOAD_PRIVACY_MANAGEMENT_DATA');
export const SAVE_PRIVACY_TRANSACTION = actionsNamespace.createAsyncAction('SAVE_PRIVACY_TRANSACTION');
export const REVERT_PRIVACY_TRANSACTION = actionsNamespace.createAsyncAction('REVERT_PRIVACY_TRANSACTION');
export const LOAD_IMPACTED_ACCOUNTS = actionsNamespace.createAsyncAction('LOAD_IMPACTED_ACCOUNTS');
export const LOAD_REVERT_IMPACTED_ACCOUNTS = actionsNamespace.createAsyncAction('LOAD_REVERT_IMPACTED_ACCOUNTS');
export const CHANGE_PRIVACY_SIDEPANEL_VIEW = actionsNamespace.createAction('CHANGE_PRIVACY_SIDEPANEL_VIEW');
export const SELECT_ACCOUNT_PRIVACY_TRANSACTION = actionsNamespace.createAction('SELECT_ACCOUNT_PRIVACY_TRANSACTION');
export const SET_PRIVACY_OVERRIDE_REASON = actionsNamespace.createAction('SET_PRIVACY_OVERRIDE_REASON');
export const SELECT_ACCOUNT_FOR_PRIVACY_CHANGE = actionsNamespace.createAction('SELECT_ACCOUNT_FOR_PRIVACY_CHANGE');
export const TOGGLE_ALL_ACCOUNTS_SELECTED = actionsNamespace.createAction('TOGGLE_ALL_ACCOUNTS_SELECTED');

export const LOAD_ADJUSTMENTS_TABLE = actionsNamespace.createAsyncAction('LOAD_ADJUSTMENTS_TABLE');
export const LOAD_ADJUSTMENT_ACCOUNTS_TABLE = actionsNamespace.createAsyncAction('LOAD_ADJUSTMENT_ACCOUNTS_TABLE');
export const SELECT_ADJUSTMENTS_TABLE_ROW = actionsNamespace.createAction('SELECT_ADJUSTMENTS_TABLE_ROW');
export const SELECT_VIEWED_ISSUER_ACCOUNT = actionsNamespace.createAction('SELECT_VIEWED_ISSUER_ACCOUNT');

export function openSidePanel(panelType) { // cell
  return {
    type: OPEN_SIDEPANEL,
    payload: panelType
  };
}

export function closeSidePanel() {
  return {
    type: CLOSE_SIDEPANEL
  };
}

export function resetSidePanelData(sidePanelType) {
  return {
    type: RESET_SIDEPANEL_DATA,
    meta: {
      sidePanelType
    }
  };
}

export function toggleSidePanel(collapsed) { // ToDo: collapsed argument can be removed
  return {
    type: TOGGLE_SIDEPANEL,
    collapsed
  };
}

export function resizeSidePanel(sidepanelWidth) {
  return {
    type: RESIZE_SIDEPANEL,
    sidepanelWidth
  };
}

export function loadPrivacyManagementData(statementRevisionId) {
  return {
    type: LOAD_PRIVACY_MANAGEMENT_DATA,
    promise: ({ legacyIssuerDataViewService }) => legacyIssuerDataViewService.loadPrivacyManagementData(statementRevisionId),
    meta: {
      statementRevisionId
    }
  };
}

export function openPrivacyOverrideSidePanel(statementRevisionId) {
  return (dispatch) => {
    dispatch(openSidePanel(sidePanelTypes.ACCOUNTS_PRIVACY));
    dispatch(loadPrivacyManagementData(statementRevisionId));
  };
}

export function closeAccountsPrivacySidePanel() {
  return (dispatch) => {
    dispatch(closeSidePanel());
    dispatch(resetSidePanelData(sidePanelTypes.ACCOUNTS_PRIVACY));
  };
}

export function changePrivacySidePanelView(viewType) {
  return {
    type: CHANGE_PRIVACY_SIDEPANEL_VIEW,
    meta: {
      viewType
    }
  };
}

export function selectPreviousPrivacyTransaction(transaction) {
  return {
    type: SELECT_ACCOUNT_PRIVACY_TRANSACTION,
    meta: {
      transaction
    }
  };
}

export function setPrivacyOverrideReason(reason) {
  return {
    type: SET_PRIVACY_OVERRIDE_REASON,
    meta: {
      reason
    }
  };
}

export function selectAccountForPrivacyChange(account) {
  return {
    type: SELECT_ACCOUNT_FOR_PRIVACY_CHANGE,
    meta: {
      account
    }
  };
}

export function toggleAllAccountsSelected() {
  return {
    type: TOGGLE_ALL_ACCOUNTS_SELECTED
  };
}

export function onSuccessfulOverrideOrRevert(onSuccess) {
  return (dispatch) => {
    dispatch(closeAccountsPrivacySidePanel());

    if (onSuccess) {
      onSuccess();
    }
  };
}

export function savePrivacyTransaction(onSuccess) {
  return (dispatch, getState) => {
    const {statementRevisionId, eligibleAccounts, selectedPrivacyOverrideReason} = getState().legacyIssuerDataView.accountsPrivacyPanel;

    dispatch({
      type: SAVE_PRIVACY_TRANSACTION,
      promise: ({legacyIssuerDataViewService}) => {
        return legacyIssuerDataViewService.savePrivacyTransaction(
          statementRevisionId, getSelectedEligibleAccounts(eligibleAccounts), selectedPrivacyOverrideReason
        ).then(() => dispatch(onSuccessfulOverrideOrRevert(onSuccess)));
      }
    });
  };
}

export function revertPrivacyTransaction(onSuccess) {
  return (dispatch, getState) => {
    const {selectedTransaction} = getState().legacyIssuerDataView.accountsPrivacyPanel;

    dispatch({
      type: REVERT_PRIVACY_TRANSACTION,
      promise: ({legacyIssuerDataViewService}) => {
        return legacyIssuerDataViewService.revertPrivacyTransaction(selectedTransaction)
          .then(() => dispatch(onSuccessfulOverrideOrRevert(onSuccess)));
      }
    });
  };
}

export function loadImpactedAccounts(statementRevisionId, accountsToOverride) {
  return {
    type: LOAD_IMPACTED_ACCOUNTS,
    promise: ({ legacyIssuerDataViewService }) => legacyIssuerDataViewService.loadImpactedAccounts(statementRevisionId, accountsToOverride)
  };
}

export function loadRevertImpactedAccounts(transaction) {
  return {
    type: LOAD_REVERT_IMPACTED_ACCOUNTS,
    promise: ({ legacyIssuerDataViewService }) => legacyIssuerDataViewService.loadRevertImpactedAccounts(transaction)
  };
}

export function onShowImpactedClick() {
  return (dispatch, getState) => {
    const {statementRevisionId, eligibleAccounts} = getState().legacyIssuerDataView.accountsPrivacyPanel;

    dispatch(changePrivacySidePanelView(accountsPrivacyPanelViewTypes.SHOW_IMPACTED_ACCOUNTS));
    dispatch(loadImpactedAccounts(statementRevisionId, getSelectedEligibleAccounts(eligibleAccounts)));
  };
}

export function onShowRevertImpactedClick() {
  return (dispatch, getState) => {
    dispatch(changePrivacySidePanelView(accountsPrivacyPanelViewTypes.SHOW_IMPACTED_ACCOUNTS_FOR_REVERT));
    dispatch(loadRevertImpactedAccounts(getState().legacyIssuerDataView.accountsPrivacyPanel.selectedTransaction));
  };
}


export function selectViewedIssuerAccount(id, sectionId) {
  return {
    type: SELECT_VIEWED_ISSUER_ACCOUNT,
    meta: { id, sectionId }
  };
}

export function loadAdjustmentsTable(params, cell, column) {
  return {
    type: LOAD_ADJUSTMENTS_TABLE,
    promise: ({ legacyIssuerDataViewService }) => legacyIssuerDataViewService.loadAdjustmentsTable(params, cell, column)
  };
}

export function loadAdjustmentAccountsTable(statementRevisionId, adjustmentId) {
  return (dispatch, getStorage) => {
    const displayConfig = getStorage().issuerDataView.displayConfig;
    dispatch({
      type: LOAD_ADJUSTMENT_ACCOUNTS_TABLE,
      promise: ({ legacyIssuerDataViewService }) => legacyIssuerDataViewService.loadAdjustmentAccountsTable(statementRevisionId, adjustmentId, displayConfig)
    });
  };
}

export function selectAdjustmentsTableRow(statementRevisionId, adjustmentId) {
  return (dispatch) => {
    dispatch({
      type: SELECT_ADJUSTMENTS_TABLE_ROW,
      payload: adjustmentId
    });
    dispatch(loadAdjustmentAccountsTable(statementRevisionId, adjustmentId));
  };
}

export function openAdjustmentsDetailsSidePanel(statementRevisionId, accountId) {
  return (dispatch, getStorage) => {
    const displayConfig = getStorage().issuerDataView.displayConfig;
    dispatch(openSidePanel(sidePanelTypes.ADJUSTMENTS));
    dispatch(loadAdjustmentsTable(statementRevisionId, accountId, displayConfig));
  };
}
