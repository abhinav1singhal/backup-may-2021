import {ActionsNamespaceFactory} from 'react-techstack/redux';

const actionsNamespace = ActionsNamespaceFactory('ISSUER_DATA_VIEW');

import {isNotEmptyArray} from 'modules/common/utils/arrayUtils';
import {isNotEmptyString} from 'modules/common/utils/stringUtils';
import {isValidIssuer} from 'modules/issuer/utils/issuerUtils';
import {
  isValidDisplayConfig, shouldLoadStatementsData, shouldLoadCoAStructure
} from 'modules/issuerData/utils/dataViewUtils';

import {
  getExportDataToExcelRequiresConfig, buildLookbackURL, buildRatioDrillDownURL, buildAccountAdjustmentsDetailsURL
} from 'modules/issuerData/services/dataViewService';
import {openExternalURL} from 'modules/common/actions/commonActions';
import { downloadFile } from 'modules/common/actions/downloadFileActions';

export const LOAD_DATA = actionsNamespace.createAsyncAction('LOAD_DATA');

// This is private function please do not use it directly
function $loadData(issuer, statements, displayConfig, dataViewType, shouldLoadData = true, shouldLoadCoA = true) {
  return {
    type: LOAD_DATA,
    meta: {
      issuer,
      statements,
      displayConfig: displayConfig.clone(),
      dataViewType
    },
    promise: ({issuerDataViewService}) => {
      if (!shouldLoadData) {
        return issuerDataViewService.loadCOAStructure(issuer, dataViewType);
      } else if (!shouldLoadCoA) {
        return issuerDataViewService.loadStatementsData(issuer, statements, displayConfig);
      }

      return issuerDataViewService.loadData(issuer, statements, displayConfig, dataViewType);
    }
  };
}

export function loadData(issuer, statements, displayConfig, dataViewType) {
  return (dispatch, getStorage) => {
    const previousRequest = getStorage().requests.issuerDataViewData;
    // (isPending(previousRequest.status) && isEqual(issuer, previousRequest.meta.issuer)) ||
    if (!isValidIssuer(issuer) || !isNotEmptyArray(statements) || !isValidDisplayConfig(displayConfig)) {
      return;
    }

    const shouldLoadData = shouldLoadStatementsData({issuer, statements, displayConfig}, previousRequest.meta);
    const shouldLoadCoA = shouldLoadCoAStructure({issuer, dataViewType}, previousRequest.meta);
    if (shouldLoadData || shouldLoadCoA) {
      dispatch($loadData(issuer, statements, displayConfig, dataViewType));
    }
  };
}

export function reloadData(shouldLoadData = true, shouldLoadCoA = true) {
  return (dispatch, getStorage) => {
    const issuer = getStorage().issuer.currentIssuer;
    const {statements, displayConfig, currentViewType} = getStorage().issuerDataView;

    dispatch($loadData(issuer, statements, displayConfig, currentViewType, shouldLoadData, shouldLoadCoA));
  };
}

export function openLookBack(statement, accountId) {
  return (dispatch, getStorage) => {
    const url = getStorage().config.externalURIs.idvLookbackUrl;
    if (isNotEmptyString(url)) {
      dispatch(openExternalURL(buildLookbackURL(url, statement, accountId)));
    }
  };
}

export function openRatioDrillDown(issuer, ratioId, statementRevisionId) {
  return (dispatch, getStorage) => {
    const url = getStorage().config.externalURIs.ratioDrillDown;
    if (isNotEmptyString(url)) {
      dispatch(openExternalURL(buildRatioDrillDownURL(url, issuer, ratioId, statementRevisionId)));
    }
  };
}

export function openTabWithAccountAdjustmentsDetails(statementRevisionId, accountId) {
  return (dispatch) => {
    dispatch(openExternalURL(buildAccountAdjustmentsDetailsURL(statementRevisionId, accountId)));
  };
}

export function exportDataToExcel(staticExport) {
  return (dispatch, getStorage) => {
    const {issuer: {currentIssuer}, issuerDataView, issuerStatementsSearch: {currentFilters}} = getStorage();

    const requestConfig = getExportDataToExcelRequiresConfig(currentIssuer, issuerDataView, currentFilters, staticExport);
    dispatch(downloadFile(requestConfig.url, requestConfig.params, requestConfig.options));
  };
}
