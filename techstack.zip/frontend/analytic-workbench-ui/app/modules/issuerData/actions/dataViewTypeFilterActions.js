import {ActionsNamespaceFactory} from 'react-techstack/redux';

const actionsNamespace = ActionsNamespaceFactory('ISSUER_DATA_VIEW_TYPE_FILTER');

export const LOAD_DATA_VIEW_TYPES_LIST = actionsNamespace.createAsyncAction('LOAD_DATA_VIEW_TYPES_LIST');
export const CHANGE_CURRENT_DATA_VIEW_TYPE = actionsNamespace.createAction('CHANGE_CURRENT_DATA_VIEW_TYPE');

export function loadDataViewTypesList(issuer, defaultViewTypeId) {
  return {
    type: LOAD_DATA_VIEW_TYPES_LIST,
    promise: ({issuerDataViewService}) => issuerDataViewService.loadDataViewTypesList(issuer, defaultViewTypeId)
  };
}

export function changeCurrentDataViewType(issuer, viewType) {
  return {
    type: CHANGE_CURRENT_DATA_VIEW_TYPE,
    payload: viewType
  };
}
