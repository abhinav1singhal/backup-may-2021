import { connect } from 'react-redux';

import {isNotEmptyString} from 'modules/common/utils/stringUtils';

import {openLookBack, openRatioDrillDown, reloadData} from 'modules/issuerData/actions/dataViewActions';
import {
  openPrivacyOverrideSidePanel, openAdjustmentsDetailsSidePanel,
  closeSidePanel, resizeSidePanel, toggleSidePanel
} from 'modules/issuerData/actions/legacyDataViewActions';

import LegacyTable from './LegacyTable';

function mapStateToProps(state) {
  return {
    currentIssuer: state.issuer.currentIssuer,
    showEmptyRows: state.issuerDataView.showEmptyRows,
    showAccountNumber: state.issuerDataView.showAccountNumber,
    flipCoa: state.issuerDataView.flipCoa,
    enableLookBack: isNotEmptyString(state.config.externalURIs.idvLookbackUrl),
    enableRatioDrillDown: isNotEmptyString(state.config.externalURIs.ratioDrillDown),

    showSidepanel: state.legacyIssuerDataView.showSidepanel,
    sidePanelWidth: state.legacyIssuerDataView.sidepanelWidth,
    sidepanelType: state.legacyIssuerDataView.sidepanelType,
    isSidepanelCollapsed: state.legacyIssuerDataView.sidePanel.isSidepanelCollapsed,
    dataViewDisplayConfigRequest: state.requests.issuerDataViewDisplayConfig
  };
}

const mapDispatchToProps = {
  openLookBack,
  openRatioDrillDown,
  openPrivacyOverrideSidePanel,
  openAdjustmentsDetailsSidePanel,
  reloadData,

  resizeSidePanel,
  toggleSidePanel,
  closeSidePanel
};

export default connect(mapStateToProps, mapDispatchToProps, undefined, {forwardRef: true})(LegacyTable);
