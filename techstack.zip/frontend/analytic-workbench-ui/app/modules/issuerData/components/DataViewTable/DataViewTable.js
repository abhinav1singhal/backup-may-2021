import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import {Alert, LoadingContainer} from 'react-techstack';
import {asyncStatusTypes, asyncStatusUtils} from 'react-techstack/utils';

import DataViewDisplayConfig from '../DataViewDisplayConfig';
import ExportToExcelButton from './ExportToExcelButton';
import {DataTable} from './legacy';
import {isNotEmptyArray} from 'modules/common/utils/arrayUtils';
import {getMessage} from 'modules/common/utils/messagesUtils';

import theme from './DataViewTable.css';
const {asyncRequestType} = asyncStatusTypes;
const {isPending, isFailed} = asyncStatusUtils;

class DataViewTable extends React.Component {
  static propTypes = {
    currentIssuer: PropTypes.object,
    currentViewType: PropTypes.object,
    statements: PropTypes.array,
    displayConfig: PropTypes.object,
    columns: PropTypes.array,
    data: PropTypes.array,
    sidePanelQuery: PropTypes.shape({
      accountId: PropTypes.string,
      statementRevisionId: PropTypes.string,
      sidePanelType: PropTypes.string
    }).isRequired,

    loadData: PropTypes.func.isRequired,
    issuerDataViewDataRequest: asyncRequestType.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string,
      header: PropTypes.string
    }).isRequired
  };

  UNSAFE_componentWillReceiveProps(props) {
    props.loadData(props.currentIssuer, props.statements, props.displayConfig, props.currentViewType);
  }

  renderDisplayConfig() {
    const {statements, data, theme: customTheme} = this.props;

    if (!isNotEmptyArray(data) || !isNotEmptyArray(statements)) {
      // return null; // TODO: check why this makes sorting disappears
    }

    const DataViewDisplayConfigProps = {
      ref: (component) => {
        this.DisplayConfig = component;
      },
      scrollTableToRowById: (id) => {
        this.LegacyTable && this.LegacyTable.scrollToRowById(id);
      },
      theme: {
        root: theme.displayConfig
      }
    };

    return (
      <div className={classNames(theme.header, customTheme.header)}>
        <DataViewDisplayConfig {...DataViewDisplayConfigProps} />
        <ExportToExcelButton theme={{root: theme.exportToExcel}} />
      </div>
    );
  }

  renderTable() {
    const {statements, columns, data, sidePanelQuery} = this.props;

    if (!isNotEmptyArray(data) || !isNotEmptyArray(statements)) {
      return null;
    }

    const DataTableProps = {
      columns,
      data,
      sidePanelQuery,
      ref: (component) => {
        this.LegacyTable = component;
      },
      onChangeCurrentSection: (currentSectionId) => {
        this.DisplayConfig && this.DisplayConfig.changeCurrentSection(currentSectionId);
      }
    };

    return <DataTable {...DataTableProps}/>;
  }

  renderErrorMessage() {
    const {statements, data, issuerDataViewDataRequest} = this.props;

    if (isNotEmptyArray(data) && isNotEmptyArray(statements)) {
      return null;
    }

    let messageType = 'warning';
    let messageKey = 'noDataFoundMessage';
    if (isFailed(issuerDataViewDataRequest.status)) {
      messageType = 'danger';
      messageKey = 'unexpectedErrorMessage';
    } else if (!isNotEmptyArray(statements)) {
      messageKey = 'noStatementsSelectedMessage';
    }

    return (
      <Alert bsStyle={messageType} className={theme.errorMessage}>
        {getMessage(`issuer.dataView.table.${messageKey}`)}
      </Alert>
    );
  }

  render() {
    const {issuerDataViewDataRequest, theme: customTheme} = this.props;

    const LoadingContainerProps = {
      isLoading: isPending(issuerDataViewDataRequest.status),
      title: getMessage('issuer.dataView.table.loadingDataMessage'),
      offset: 150,
      spinner: 'primary'
    };

    return (
      <div className={classNames(theme.root, customTheme.root)}>
        <LoadingContainer {...LoadingContainerProps}>
          {this.renderErrorMessage()}
          {this.renderDisplayConfig()}
          {this.renderTable()}
        </LoadingContainer>
      </div>
    );
  }
}

DataViewTable.defaultProps = {
  theme: {}
};

export default DataViewTable;
