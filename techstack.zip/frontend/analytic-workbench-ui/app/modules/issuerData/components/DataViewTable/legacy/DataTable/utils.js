import { findIndex, isUndefined, find, uniqBy, isEmpty, some, isPlainObject } from 'lodash';

import { getMessage } from 'modules/common/utils/messagesUtils';

export const AS_PUBLISHED = 5;
function intRand(fr = 0, to = 1) {
  return Math.round(Math.random() * (to - fr) + fr);
}

export function generateIDVData(n = 1000) {
  const coa = [];
  for (let i = 0; i < n; ++i) {
    coa[i] = {
      id: i + 1,
      type: 'ACCOUNT',
      label: `Account ${i + 1}`
    };
  }
  let T = 0;
  const childCount = [5, 4, 3];

  function dfs(level, parentId) {
    const { id } = coa[T];
    coa[T++].parentId = parentId;
    for (let i = 0; i < childCount[level] && T < n; ++i) {
      dfs(level + 1, id);
    }
  }

  for (let i = 0; i < n; ++i) {
    if (!coa[i].parentId) {
      dfs(0);
    }
  }

  const data = [];
  for (let i = 0; i < 10; ++i) {
    data[i] = {
      id: i + 1,
      label: `Column ${i + 1}`,
      revisionType: 'revision-type',
      records: []
    };
    for (let j = 0; j < n; ++j) {
      data[i].records[j] = {
        id: j + 1,
        value: `${j + 1} in ${i + 1}`,
        private: true,
        adjusted: false
      };
      if (intRand(0, 100) === 0) {
        data[i].records[j].compositeRecords = [];
        const { compositeRecords } = data[i].records[j];
        const cnt = intRand(2, 4);
        for (let k = 0; k < cnt; ++k) {
          compositeRecords[k] = {
            value: `composite-${k}`,
            label: `Composite ${k + 1} for Account ${j + 1}`
          };
        }
      }
    }
  }

  return { coa, data };
}

export function isAsPublished({ typeId }) {
  return typeId === AS_PUBLISHED;
}


const SECTION_TYPE_BY_ITEM_TYPE = {
  'ACCOUNT': 'SECTION',
  'RATIO_ACCOUNT': 'RATIO_SECTION',
  'RATIO_SECTION': 'RATIO_SECTION',
  'SECTION': 'SECTION'
};

function getStatementName(statement) {
  return `${statement.fiscal_period} ${statement.revision_type.name}
  ${statement.consolidation_id ? statement.consolidation_id.name.substr(0, 1) : ''} ${statement.acc_regime_id ? statement.acc_regime_id.name : ''} ${statement.period_end_dtm}`;
}

export function prepareIDVData(idvData, selectedStatements) {
  const byId = new Map();

  function getItemKey(item) {
    return `${item.type}:${item.id}`;
  }

  function getAccountById(id) {
    return byId.get(`ACCOUNT:${id}`) || byId.get(`RATIO_ACCOUNT:${id}`);
  }

  function getParent(item) {
    if (item.parentSectionId && !item.parentId) {
      const sectionType = SECTION_TYPE_BY_ITEM_TYPE[item.type];
      return byId.get(`${sectionType}:${item.parentSectionId}`);
    }
    return byId.get(`${item.type}:${item.parentId}`);
  }


  idvData.coa.forEach((item) => {
    const key = getItemKey(item);
    if (!byId.has(key)) {
      byId.set(
        key,
        {
          id: item.id,
          name: item.label,
          type: item.type,
          childrenKeys: [],
          level: 0,
          rootSectionId: item.id,
          empty: true
        });
    }
  });

  const data = [];
  const statements = [];

  const columns = idvData.data.map((revision) => {
    const statement = find(selectedStatements, {id: revision.id});
    const plainStatement = Object.assign({}, statement);
    Object.keys(plainStatement).forEach((key) => {
      const value = plainStatement[key];
      if (isPlainObject(value) && value.id) {
        plainStatement[key] = value.id;
      }
    });
    statements.push({
      ...plainStatement,
      name: getStatementName(statement)
    });
    revision.records.forEach((record) => {
      const account = getAccountById(record.accountId);
      if (!isUndefined(account)) {
        account[revision.id] = {
          title: record.title,
          value: record.value,
          adjusted: record.adjusted,
          privacy: record.privacy
        };
        account.empty = false;

        if (!isEmpty(record.composites)) {
          account.composites = [];
          record.composites.forEach((composite, index) => {
            account.composites.push({
              [revision.id]: composite,
              children: [],
              parent: account,
              id: `${revision.id}-${index}`,
              composite: true
            });
          });
        }
      }
    });

    return {
      key: revision.id,
      label: getStatementName(statement),
      width: isAsPublished(revision) ? 400 : 200,
      minWidth: isAsPublished(revision) ? 360 : 180,
      isResizable: true,
      typeId: revision.typeId,
      statementId: revision.statementId,
      revisionDateStr: revision.dateTime
    };
  });
  columns.unshift({ key: 'name', label: getMessage('issuer.dataView.titles.accountNameColumn'), width: 450, fixed: true, isResizable: true, minWidth: 350 });
  columns.unshift({ key: 'id', label: getMessage('issuer.dataView.titles.idColumn'), width: 70, fixed: true });

  idvData.coa.forEach((item) => {
    const child = byId.get(getItemKey(item));

    const parent = getParent(item);

    if (child && parent) {
      parent.childrenKeys.push(getItemKey(item));
    }
  });

  const sections = [];
  function dfs(account) {
    data.push(account);

    if (account.parent) {
      account.level = account.parent.level + 1;
      account.rootSectionId = account.parent.rootSectionId;
      if (!account.empty) {
        account.parent.empty = false;
      }
    }

    /*
    if (account.compositeRecords) {
      account.compositeExpanded = true;
      account.compositeFrom = data.length;
      data.push(...account.compositeRecords);
      account.compositeTo = data.length - 1;
    }
    */

    account.from = data.length;
    account.childrenKeys.forEach((key) => {
      const child = {
        ...byId.get(key),
        children: [],
        parent: account
      };
      account.children.push(child);
      dfs(child);
    });
    account.to = data.length - 1;
  }

  idvData.coa.forEach((item) => {
    if (!item.parentId && !item.parentSectionId) {
      const child = { ...byId.get(getItemKey(item)), children: [] };
      if (['SECTION', 'RATIO_SECTION'].indexOf(child.type) !== -1) {
        sections.push(child);
      }
      dfs(child);
    }
  });

  return { columns, data, sections, statements };
}

export function filterSections(data, sectionIds) {
  if (sectionIds.length === 0) {
    return data;
  }

  const res = [];
  function dfs(item, parent) {
    const cur = {
      ...item,
      from: res.length + 1,
      children: [],
      parent
    };

    res.push(cur);
    parent.children.push(cur);
    item.children.forEach((child) => dfs(child, cur));
    cur.to = res.length - 1;
  }

  const sections = new Set(sectionIds);
  data.forEach((item) => {
    if (item.level === 0 && sections.has(item.id)) {
      const cur = {
        ...item,
        from: res.length + 1,
        children: []
      };
      res.push(cur);
      item.children.forEach((child) => dfs(child, cur));
      cur.to = res.length - 1;
    }
  });

  return res;
}

function copyTree(tree) {
  const res = [];
  tree.forEach((item, i) => {
    res[i] = {
      zero: item.zero,
      add: item.add
    };
  });
  return res;
}

export function hasVisibleComposites(account) {
  return some(account.children, 'composite');
}

export class VisibilityTree {
  constructor(data, saveState) {
    this._data = [];
    this._tree = [];
    const collapsedRowsIds = [];

    data.forEach((row) => {
      this._data.push(row);
      if (saveState && !row.expanded) {
        collapsedRowsIds.push(row.id);
      }
    });

    this._closeAll();
    this._tree = copyTree(this._expandedTree);
    this._data.forEach((row) => {
      row.expanded = true;
    });

    if (saveState) {
      this._data.forEach((row) => {
        if (~collapsedRowsIds.indexOf(row.id)) {
          this.toggleRow(row);
        }
      });
    }
  }

  build(v, tl, tr) {
    if (tl === tr) {
      this._tree[v] = { zero: 1, add: 0 };
      return;
    }
    const tm = Math.floor((tl + tr) / 2);
    this.build(2 * v, tl, tm);
    this.build(2 * v + 1, tm + 1, tr);
    this._tree[v] = {
      zero: this._tree[2 * v].zero + this._tree[2 * v + 1].zero,
      add: 0
    };
  }

  change(v, tl, tr, l, r, delta) {
    if (l > r) {
      return;
    }

    const { _tree: tree } = this;
    if (tl === l && tr === r) {
      tree[v].add += delta;
      if (tree[v].add === 0) {
        if (tl === tr) {
          tree[v].zero = 1;
        } else {
          tree[v].zero = tree[2 * v].zero + tree[2 * v + 1].zero;
        }
      } else {
        tree[v].zero = 0;
      }
      return;
    }

    const m = Math.floor((tl + tr) / 2);
    this.change(2 * v, tl, m, l, Math.min(m, r), delta);
    this.change(2 * v + 1, m + 1, tr, Math.max(m + 1, l), r, delta);
    tree[v].zero = tree[2 * v].zero + tree[2 * v + 1].zero;
  }

  _get(v, tl, tr, index) {
    if (tl === tr) {
      return this._data[tl];
    }

    const { _tree: tree } = this;
    const m = Math.floor((tl + tr) / 2);
    if (index >= tree[2 * v].zero) {
      return this._get(2 * v + 1, m + 1, tr, index - tree[2 * v].zero);
    }
    return this._get(2 * v, tl, m, index);
  }

  close(l, r) {
    this.change(1, 0, this._data.length - 1, l, r, 1);
  }

  open(l, r) {
    this.change(1, 0, this._data.length - 1, l, r, -1);
  }

  getRow(rowIndex) {
    return this._get(1, 0, this._data.length - 1, rowIndex);
  }

  toggleRow = (row) => {
    row.expanded = !row.expanded;
    const { children, composites } = row;
    const from = hasVisibleComposites(row) ? row.from + composites.length : row.from;
    const to = hasVisibleComposites(row) ? row.to + children.length - composites.length : row.to;

    if (row.expanded) {
      this.open(from, to);
    } else {
      this.close(from, to);
    }
    return this.getRowsCount();
  }

  getRowsCount() {
    return this._tree[1].zero;
  }

  _expandAll() {
    this._data.forEach((row) => {
      row.expanded = true;
    });

    const length = this._data.length ? this._data.length - 1 : 0;
    this.build(1, 0, length);
  }

  _closeAll() {
    this._expandAll();
    this._expandedTree = copyTree(this._tree);

    const dfs = (item) => {
      if (item.children) {
        item.children.forEach(dfs);
        this.toggleRow(item);
      }
    };
    this._data.forEach((item) => {
      if (!item.parent && item.children) {
        dfs(item);
      }
    });
    this._closedTree = copyTree(this._tree);
  }

  expandAll() {
    this._data.forEach((row) => {
      row.expanded = true;
    });

    this._tree = copyTree(this._expandedTree);
  }

  closeAll() {
    this._data.forEach((row) => {
      row.expanded = false;
    });
    this._tree = copyTree(this._closedTree);
  }

  _getTreeIndex(vv, tl, tr, index) {
    let res = 0;
    let v = vv;
    let l = tl;
    let r = tr;
    const { _tree: tree } = this;
    while (l !== r) {
      const m = Math.floor((l + r) / 2);
      if (index <= m) {
        r = m;
        v = 2 * v;
      } else {
        res += tree[2 * v].zero;
        l = m + 1;
        v = 2 * v + 1;
      }
    }
    return res;
  }

  getTreeIndex(index) {
    return this._getTreeIndex(1, 0, this._data.length - 1, index);
  }

  _findClosedParents(r) {
    let row = r;
    const res = [];
    while (row.parent) {
      row = row.parent;
      if (!row.expanded) {
        res.unshift(row);
      }
    }
    return res;
  }

  findIndex(predicate, fromIndex) {
    const rowIndex = findIndex(this._data, predicate, fromIndex);
    if (rowIndex < 0) {
      return rowIndex;
    }

    const closedParents = this._findClosedParents(this._data[rowIndex]);
    closedParents.forEach(this.toggleRow);
    return this.getTreeIndex(rowIndex);
  }
}

export function getToggleProps(treeItem, toggle) {
  const { children, composites } = treeItem;
  const expandable = !isEmpty(children) &&
    (!composites || !hasVisibleComposites(treeItem) || children.length > composites.length);

  const expanded = expandable && treeItem.expanded;
  return {
    treeItem,
    expandable,
    expanded,
    toggle
  };
}

export function heightPropTypeChecker(props, propName, componentName) {
  if (props.height === undefined && props.maxHeight === undefined) {
    return new Error(`Either height or maxHeight must be specified for ${componentName}`);
  }
  return null;
}

export function getColumnByX(columns, x, columnsWidths = {}) {
  let offset = x;
  const start = columns.findIndex(({ fixed }) => !fixed);
  for (let i = start; i < columns.length; ++i) {
    if (!columns[i]) return void 0;

    const columnWidth = columnsWidths[columns[i].key] || columns[i].width;
    if (offset >= columnWidth) {
      offset -= columnWidth;
    } else {
      return columns[i];
    }
  }
  return undefined;
}

export function getXByColumnIndex(columns, index, columnsWidths = {}) {
  let x = 0;
  const start = columns.findIndex(({ fixed }) => !fixed);
  for (let i = start; i < start + index && i < columns.length; ++i) {
    const columnWidth = columnsWidths[columns[i].key] || columns[i].width;
    x += columnWidth;
  }
  return x;
}

export function prepareSections(data) {
  return data.map((section) => ({
    sectionId: section.id,
    sectionName: section.name,
    isRatio: section.type === 'RATIO_SECTION'
  }));
}

function isAccount(item) {
  return item.type === 'ACCOUNT' || item.type === 'RATIO_ACCOUNT';
}

function prepareAccount(item) {
  return {
    accountId: item.id,
    sectionId: item.rootSectionId,
    isRatio: item.type === 'RATIO_ACCOUNT',
    accountName: item.name
  };
}

export function getUniqueAccountList(data) {
  const accounts = data.filter(isAccount);
  return uniqBy(accounts, 'id').map(prepareAccount);
}

export function preparePostOptions(filters) {
  const options = {};
  Object.keys(filters).forEach((key) => {
    const value = filters[key];
    if (isPlainObject(value) && value.key) {
      options[value.key] = value.value;
    }
  });
  return options;
}
