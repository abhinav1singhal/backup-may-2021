import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { Button, Glyphicon } from 'react-techstack';
import classNames from 'classnames';

import { getMessage } from 'modules/common/utils/messagesUtils';

import theme from './DownloadFileDropdownPanel.css';

class DownloadFileDropdownPanel extends Component {
  static propTypes = {
    onExcelButtonClick: PropTypes.func.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string,
      viewButton: PropTypes.string
    })
  };

  onExcelButtonClick = (event, staticExport) => {
    event.preventDefault();
    this.props.onExcelButtonClick(staticExport);
  };

  render() {
    const {theme: customTheme} = this.props;

    const ViewInExcelButtonProps = {
      bsStyle: 'primary',
      className: theme.viewButton,
      bsRole: 'toggle',
      onClick: (event) => this.onExcelButtonClick(event, false)
    };

    return (
      <div className={classNames(theme.dropdown, customTheme.root)}>
        <Button {...ViewInExcelButtonProps}>
          <Glyphicon glyph="new-window"/> {getMessage('issuerDataView.exportDataToExcel.dropDownButton')}
        </Button>
      </div>
    );
  }
}

DownloadFileDropdownPanel.defaultProps = {
  theme: {}
};


export default DownloadFileDropdownPanel;
