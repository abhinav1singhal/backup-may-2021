export default from './StyledCell';
