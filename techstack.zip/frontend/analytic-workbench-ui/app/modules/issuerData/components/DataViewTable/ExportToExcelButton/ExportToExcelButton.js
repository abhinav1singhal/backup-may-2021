import PropTypes from 'prop-types';
import React from 'react';
// import classNames from 'classnames';

import {hasPermission} from 'modules/common/utils/permissionsUtils';
import {DownloadFileDropdownPanel} from '../legacy';

// import theme from './ExportToExcelButton.css';
// const theme = {};

import { permissionsListType } from 'modules/common/types/permissionsTypes';

class ExportToExcelButton extends React.Component {
  static propTypes = {
    userPermissions: permissionsListType.isRequired,

    exportDataToExcel: PropTypes.func.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string
    }).isRequired
  };

  render() {
    // const {userPermissions, exportDataToExcel, theme: customTheme} = this.props;
    const {userPermissions, exportDataToExcel} = this.props;

    if (!hasPermission(userPermissions, 'export_issuer_data')) {
      return null;
    }

    const dropdownProps = {
      onExcelButtonClick: exportDataToExcel,
      theme: {
        root: this.props.theme.root
      }
    };

    return <DownloadFileDropdownPanel {...dropdownProps} />;
  }
}

ExportToExcelButton.defaultProps = {
  theme: {}
};

export default ExportToExcelButton;
