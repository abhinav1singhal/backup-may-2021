import PropTypes from 'prop-types';
import React from 'react';
import { FixedDataTable2 } from 'react-techstack';
const { Cell } = FixedDataTable2;
import ToggleButton from '../ToggleButton';

class ToggleHeaderCell extends React.Component {
  static propTypes = {
    expanded: PropTypes.bool,
    toggle: PropTypes.func.isRequired
  };

  render() {
    const { expanded, toggle, ...props } = this.props;
    const sign = expanded ? 'minus' : 'plus';

    return (
      <Cell {...props}>
        <ToggleButton type={sign} toggle={toggle} />
      </Cell>
    );
  }
}

export default ToggleHeaderCell;
