import { connect } from 'react-redux';

import IssuerDataSidepanel from './IssuerDataSidepanel';

export function mapStateToProps(state) {
  return {
    title: state.legacyIssuerDataView.sidePanel.title,
    sidePanelType: state.legacyIssuerDataView.sidepanelType,
    adjustmentsTableStatus: state.requests.adjustmentsTable.status,
    privacyManagementDataRequest: state.requests.privacyManagementData.status
  };
}

export default connect(mapStateToProps)(IssuerDataSidepanel);
