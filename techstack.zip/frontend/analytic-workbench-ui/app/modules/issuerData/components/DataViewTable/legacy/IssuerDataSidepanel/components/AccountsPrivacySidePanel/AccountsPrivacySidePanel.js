/* eslint-disable react/no-set-state */
import PropTypes from 'prop-types';

import React from 'react';
import classNames from 'classnames';
import { Glyphicon, Scrollbars, LoadingContainer, Modal, Spinner } from 'react-techstack';
import { asyncStatusUtils } from 'react-techstack/utils';
const { isFailed, isPending } = asyncStatusUtils;
import { accountsPrivacyPanelViewTypes } from 'modules/issuerData/utils/legacyDataViewUtils';
import AccountsTable from './AccountsTable';
import HorizontalSelect from './HorizontalSelect';
import WarningDialog from './WarningDialog';
import { UnexpectedError } from 'modules/base';
import { Button } from 'modules/shared/components';
import theme from './AccountsPrivacySidePanel.css';
const {
  CREATE_TRANSACTION, REVERT_TRANSACTION, SHOW_IMPACTED_ACCOUNTS, SHOW_IMPACTED_ACCOUNTS_FOR_REVERT
} = accountsPrivacyPanelViewTypes;

class AccountsPrivacySidePanel extends React.Component {

  constructor(props) {
    super(props);

    this.onTransactionsSelectChange = this.onTransactionsSelectChange.bind(this);
    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);

    this.state = {
      modalOpened: false,
      modalOnProceedClicked: null
    };
  }

  onTransactionsSelectChange(transaction) {
    const {selectedTransaction, changePrivacySidePanelView, selectPreviousPrivacyTransaction} = this.props;
    if (selectedTransaction === null) {
      changePrivacySidePanelView(REVERT_TRANSACTION);
    } else if (transaction === null) {
      changePrivacySidePanelView(CREATE_TRANSACTION);
    }
    selectPreviousPrivacyTransaction(transaction);
  }

  validateSubmitButton() {
    return this.props.selectedAccounts.length > 0 && !!this.props.selectedPrivacyOverrideReason;
  }

  openModal(onProceedClicked) {
    this.setState({
      modalOpened: true,
      modalOnProceedClicked: () => { onProceedClicked(this.props.onSuccess); }
    });
  }

  closeModal() {
    this.setState({
      modalOpened: false,
      modalOnProceedClicked: null
    });
  }

  renderTransactionsSelect() {
    const {transactions, selectedTransaction} = this.props;

    const props = {
      label: 'Previous Transactions:',
      value: selectedTransaction,
      options: transactions,
      labelKey: 'transactionName',
      valueKey: 'transactionId',
      disabled: transactions.length === 0,
      valueRenderer: ({label}) => label,
      placeholder: transactions.length === 0 ? 'No transactions found' : 'Click here to choose',
      onChange: this.onTransactionsSelectChange
    };

    return <HorizontalSelect {...props} />;
  }

  renderOverrideReasonSelect() {
    const {selectedPrivacyOverrideReason, privacyOverrideReasonList, setPrivacyOverrideReason} = this.props;

    const props = {
      label: 'Override Reason:',
      value: selectedPrivacyOverrideReason,
      options: privacyOverrideReasonList,
      disabled: privacyOverrideReasonList.length === 0,
      labelKey: 'description',
      valueKey: 'description',
      placeholder: 'Select reason',
      onChange: setPrivacyOverrideReason
    };

    return <HorizontalSelect {...props} />;
  }

  renderDetailsSection() {
    const {issuer, details} = this.props;

    return (
      <div>
        <div className={theme.title}>Details:</div>
        <div>{issuer.description}</div>
        {details.map((detail, i) => <div key={i}>{detail}</div>)}
      </div>
    );
  }

  renderSelectAccountsSection() {
    const {eligibleAccounts, selectedAccounts, onShowImpactedClick} = this.props;

    return (
      <div>
        <div className={theme.selectAccountsText}>Select Ratios to Override Privacy:</div>
        <AccountsTable accounts={eligibleAccounts} selectable/>
        <div className={theme.tableCaption}>
          <span>Total selected: {selectedAccounts.length}</span>
          <Button bsStyle="link" disabled={selectedAccounts.length === 0}
                  onClick={onShowImpactedClick}>
            Show impact
          </Button>
        </div>
      </div>
    );
  }

  renderRevertAccountsSection() {
    const {selectedTransaction, onShowRevertImpactedClick} = this.props;

    return (
      <div>
        <div className={theme.title}>Manually Overridden Ratios</div>
        <AccountsTable accounts={selectedTransaction.accounts}/>
        <div className={theme.title}>Impacted ratios made public based on this change</div>
        <AccountsTable accounts={selectedTransaction.impactedAccounts || []}/>
        <div className={theme.tableCaption}>
          <Button bsStyle="link" onClick={onShowRevertImpactedClick}>
            Show revert impact
          </Button>
        </div>
      </div>
    );
  }

  renderImpactedAccountsSection() {
    const {
      viewType, impactedAccounts, revertImpactedAccounts, changePrivacySidePanelView, impactedAccountsRequest,
      revertImpactedAccountsRequest
    } = this.props;

    const backView = viewType === SHOW_IMPACTED_ACCOUNTS ? CREATE_TRANSACTION : REVERT_TRANSACTION;
    let text = 'Impacted ratios made public based on this change';
    let isLoading = isPending(impactedAccountsRequest.status);
    if (viewType === SHOW_IMPACTED_ACCOUNTS_FOR_REVERT) {
      text = 'Impacted ratios - these ratios will be returned to private status if this transaction is reverted';
      isLoading = isPending(revertImpactedAccountsRequest.status);
    }

    return (
      <div>
        <div className={theme.section}>
          <Button onClick={() => changePrivacySidePanelView(backView)}>
            <Glyphicon glyph="arrow-left"/> Back
          </Button>
        </div>
        <div className={theme.section}>
          <div className={theme.title}>{text}</div>
          <LoadingContainer isLoading={isLoading}>
            <AccountsTable accounts={viewType === SHOW_IMPACTED_ACCOUNTS ? impactedAccounts : revertImpactedAccounts}/>
          </LoadingContainer>
        </div>
      </div>
    );
  }

  renderMainView() {
    const {
      viewType, closeAccountsPrivacySidePanel, savePrivacyTransaction, revertPrivacyTransaction,
      selectedPrivacyOverrideReason, savePrivacyTransactionRequest, revertPrivacyTransactionRequest
    } = this.props;

    return (
      <div>
        <div className={classNames('clearfix', theme.section)}>
          {this.renderTransactionsSelect()}
        </div>
        <div className={theme.section}>
          {this.renderDetailsSection()}
        </div>
        <div className={theme.section}>
          {viewType === CREATE_TRANSACTION ? this.renderSelectAccountsSection() : this.renderRevertAccountsSection()}
        </div>
        <div className={classNames('clearfix', theme.section)}>
          <div className={theme.title}>Transaction Details:</div>
          {this.renderOverrideReasonSelect()}
        </div>
        <div className={classNames('clearfix', theme.section)}>
          <div className={theme.formFooter}>
            <Button bsStyle="link" onClick={closeAccountsPrivacySidePanel}>Cancel</Button>
            {viewType === CREATE_TRANSACTION ? (
              <Button bsStyle="primary" disabled={!this.validateSubmitButton()}
                      loading={isPending(savePrivacyTransactionRequest.status)}
                      onClick={() => this.openModal(savePrivacyTransaction)}>
                Submit Selected
              </Button>
            ) : (
              <Button bsStyle="danger" disabled={!selectedPrivacyOverrideReason}
                      loading={isPending(revertPrivacyTransactionRequest.status)}
                      onClick={() => this.openModal(revertPrivacyTransaction)}>
                Revert Transaction
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  }

  renderModal() {
    const dialogProps = {
      onHide: this.closeModal,
      onProceed: () => {
        this.closeModal();
        this.state.modalOnProceedClicked();
      },
    };
    const modalProps = {
      show: this.state.modalOpened,
      backdrop: 'static',
      dialogComponentClass: () => <WarningDialog {...dialogProps} />
    };

    return <Modal {...modalProps} />;
  }

  renderOverlay() {
    const {savePrivacyTransactionRequest, revertPrivacyTransactionRequest} = this.props;

    if (isPending(savePrivacyTransactionRequest.status) || isPending(revertPrivacyTransactionRequest.status)) {
      return (
        <div className={theme.overlay}>
          <div className={theme.overlaySpinner}>
            <Spinner size={30} type="primary" />
            <div className={theme.overlaySpinnerMessage}>Saving...</div>
          </div>
        </div>
      );
    }

    return null;
  }

  render() {
    const {privacyManagementDataRequest, viewType} = this.props;

    if (isFailed(privacyManagementDataRequest.status)) {
      return <UnexpectedError />;
    }

    return (
      <div className={theme.root}>
        <h4>Data Point Privacy Override Management</h4>
        <div className={theme.content}>
          <Scrollbars>
            <div className={theme.scrollableContent}>
              {(viewType === CREATE_TRANSACTION || viewType === REVERT_TRANSACTION) && (
                this.renderMainView()
              )}
              {(viewType === SHOW_IMPACTED_ACCOUNTS || viewType === SHOW_IMPACTED_ACCOUNTS_FOR_REVERT) && (
                this.renderImpactedAccountsSection()
              )}
            </div>
          </Scrollbars>
          {this.renderOverlay()}
        </div>
        {this.renderModal()}
      </div>
    );
  }
}

AccountsPrivacySidePanel.propTypes = {
  viewType: PropTypes.string.isRequired,
  details: PropTypes.array.isRequired,
  eligibleAccounts: PropTypes.array.isRequired,
  selectedAccounts: PropTypes.array.isRequired,
  transactions: PropTypes.array.isRequired,
  selectedTransaction: PropTypes.object,
  privacyOverrideReasonList: PropTypes.array.isRequired,
  impactedAccounts: PropTypes.array,
  revertImpactedAccounts: PropTypes.array,
  changePrivacySidePanelView: PropTypes.func.isRequired,
  selectPreviousPrivacyTransaction: PropTypes.func.isRequired,
  setPrivacyOverrideReason: PropTypes.func.isRequired,
  privacyManagementDataRequest: PropTypes.object.isRequired,
  savePrivacyTransaction: PropTypes.func.isRequired,
  revertPrivacyTransaction: PropTypes.func.isRequired,
  selectedPrivacyOverrideReason: PropTypes.object,
  closeAccountsPrivacySidePanel: PropTypes.func.isRequired,
  savePrivacyTransactionRequest: PropTypes.object.isRequired,
  revertPrivacyTransactionRequest: PropTypes.object.isRequired,
  impactedAccountsRequest: PropTypes.object.isRequired,
  revertImpactedAccountsRequest: PropTypes.object.isRequired,
  issuer: PropTypes.object.isRequired,
  onShowImpactedClick: PropTypes.func.isRequired,
  onShowRevertImpactedClick: PropTypes.func.isRequired,
  onSuccess: PropTypes.func
};

export default AccountsPrivacySidePanel;
