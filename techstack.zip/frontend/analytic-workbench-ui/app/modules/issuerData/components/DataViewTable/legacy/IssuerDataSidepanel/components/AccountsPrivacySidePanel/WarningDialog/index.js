export default from './WarningDialog';
