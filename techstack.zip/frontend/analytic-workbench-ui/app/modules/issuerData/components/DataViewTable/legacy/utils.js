import { forEach, isEmpty, isUndefined, uniqBy, some, findIndex } from 'lodash';

import { getMessage } from 'modules/common/utils/messagesUtils';

const SECTION_TYPE = 'SECTION';
const RATIO_SECTION_TYPE = 'RATIO_SECTION';
const ACCOUNT_TYPE = 'ACCOUNT';
const RATIO_ACCOUNT_TYPE = 'RATIO_ACCOUNT';

const SECTION_TYPE_BY_ITEM_TYPE = {
  [SECTION_TYPE]: SECTION_TYPE,
  [RATIO_SECTION_TYPE]: RATIO_SECTION_TYPE,
  [ACCOUNT_TYPE]: SECTION_TYPE,
  [RATIO_ACCOUNT_TYPE]: RATIO_SECTION_TYPE
};

const ACCT_NM_COLUMN_LOBS = [5001, 5003, 5004, 5700]; // Banking, Finance, Securities, Asset Managers

export const AS_PUBLISHED = 5;
export function isAsPublished({typeId}) {
  return typeId === AS_PUBLISHED;
}

function isAccount(item) {
  return item.type === ACCOUNT_TYPE || item.type === RATIO_ACCOUNT_TYPE;
}

export function isSection(item) {
  return ~[SECTION_TYPE, RATIO_SECTION_TYPE].indexOf(item.type);
}

export function hasChildSectionsToDisplay(item, sections) {
  return some(item.children, (child) => sections.has(child.id));
}

export function isLobWithAccountNumber(lobId) {
  return ACCT_NM_COLUMN_LOBS.indexOf(lobId) >= 0;
}

// ToDo: prepare new utils in modules/issuerData/utils/dataViewUtils
export function prepareData(coaStructure, statementsData, lobId) {
  const byId = new Map();

  function getItemKey(item) {
    return `${item.type}:${item.id}`;
  }

  function getAccountById(id) {
    return byId.get(`${ACCOUNT_TYPE}:${id}`) || byId.get(`${RATIO_ACCOUNT_TYPE}:${id}`);
  }

  function getParent(item) {
    if (item.parentSectionId && !item.parentId) {
      const sectionType = SECTION_TYPE_BY_ITEM_TYPE[item.type];
      return byId.get(`${sectionType}:${item.parentSectionId}`);
    }
    return byId.get(`${item.type}:${item.parentId}`);
  }


  coaStructure.forEach((item) => {
    const key = getItemKey(item);
    if (!byId.has(key)) {
      byId.set(
        key,
        {
          id: item.id,
          name: item.label,
          number: item.number,
          type: item.type,
          childrenKeys: [],
          level: 0,
          rootSectionId: item.id,
          empty: true
        });
    }
  });

  const data = [];

  const columns = statementsData.map((statement) => {
    statement.records.forEach((record) => {
      const account = getAccountById(record.accountId);
      if (!isUndefined(account)) {
        account[statement.id] = {
          title: record.title,
          value: record.value,
          adjusted: record.adjusted,
          privacy: record.privacy
        };
        account.empty = false;

        if (!isEmpty(record.composites)) {
          account.composites = [];
          record.composites.forEach((composite, index) => {
            account.composites.push({
              [statement.id]: composite,
              children: [],
              parent: account,
              id: `${statement.id}-${index}`,
              composite: true
            });
          });
        }
      }
    });

    return {
      key: statement.id,
      label: statement.name,
      width: isAsPublished(statement) ? 400 : 200,
      minWidth: isAsPublished(statement) ? 360 : 180,
      isResizable: true,
      typeId: statement.typeId,
      statementId: statement.statementId,
      revisionDateStr: statement.dateTime
    };
  });
  columns.unshift({
    key: 'name',
    label: getMessage('issuer.dataView.table.columns.accountName'),
    width: 450,
    fixed: true,
    isResizable: true,
    minWidth: 350
  });
  if (isLobWithAccountNumber(lobId)) {
    columns.unshift({
      key: 'number',
      label: getMessage('issuer.dataView.table.columns.accountNumber'),
      width: 125,
      fixed: true
    });
  }
  columns.unshift({
    key: 'id',
    label: getMessage('issuer.dataView.table.columns.id'),
    width: 85,
    fixed: true
  });


  coaStructure.forEach((item) => {
    const child = byId.get(getItemKey(item));

    const parent = getParent(item);

    if (child && parent) {
      parent.childrenKeys.push(getItemKey(item));
    }
  });

  const sections = [];
  function dfs(account) {
    data.push(account);

    if (account.parent) {
      account.level = account.parent.level + 1;
      account.rootSectionId = account.parent.rootSectionId;
      account.rootSubSectionId = account.level === 1 && isSection(account) ? account.id : account.parent.rootSubSectionId;
      if (!account.empty) {
        account.parent.empty = false;
      }
    }

    /*
    if (account.compositeRecords) {
      account.compositeExpanded = true;
      account.compositeFrom = data.length;
      data.push(...account.compositeRecords);
      account.compositeTo = data.length - 1;
    }
    */

    account.from = data.length;
    account.childrenKeys.forEach((key) => {
      const child = {
        ...byId.get(key),
        children: [],
        parent: account
      };
      account.children.push(child);
      dfs(child);
    });
    account.to = data.length - 1;
  }

  coaStructure.forEach((item) => {
    if (!item.parentId && !item.parentSectionId) {
      const child = { ...byId.get(getItemKey(item)), children: [] };
      if (isSection(child)) {
        sections.push(child);
      }
      dfs(child);
    }
  });

  return { columns, data, sections };
}

export function getChildsLengthDeep(arr) {
  return arr.children.reduce((sum, child) =>
  sum + (child.children.length ? getChildsLengthDeep(child) : 1), 1);
}

export function setFromTo(item, from) {
  item.from = from;
  item.to = from + getChildsLengthDeep(item) - 2;
}

export function arrayMove(array, from, to) {
  const item = array.splice(from, 1)[0];
  if (item.children.length) {
    setFromTo(item, to);
  }

  return array.splice(to, 0, item);
}

export function flipDataOrder(data) {
  const result = data.slice();
  data.forEach((item) => {
    const from = findIndex(result, ({id}) => id === item.id);
    if (item.parent) {
      const to = findIndex(result, ({id}) => id === item.parent.id);
      arrayMove(result, from, to);
    } else {
      setFromTo(result[from], from);
    }
  });

  return result;
}

export function recalculateDataAccounts(data, showEmptyRows = true, flipCoa) {
  const res = [];

  function dfs(item, parent) {
    if (showEmptyRows || !(item.empty && isAccount(item))) {
      const cur = {
        ...item,
        from: res.length + 1,
        children: []
      };

      res.push(cur);
      if (parent) {
        cur.parent = parent;
        parent.children.push(cur);
      }
      item.children.forEach((child) => dfs(child, cur));
      cur.to = res.length - 1;
    }
  }

  data.forEach((item) => {
    if (item.level === 0) {
      dfs(item, null);
    }
  });

  return flipCoa ? flipDataOrder(res) : res;
}

export function filterSections(data, sectionsFilter) {
  if (sectionsFilter.length === 0) {
    return data;
  }

  const res = [];
  function dfs(item, parent) {
    const cur = {
      ...item,
      from: res.length + 1,
      children: [],
      parent
    };

    res.push(cur);
    parent.children.push(cur);
    item.children.forEach((child) => dfs(child, cur));
    cur.to = res.length - 1;
  }

  const sections = new Set(sectionsFilter);

  data.forEach((item) => {
    const withoutRoot = !sections.has(item.id);
    if (item.level === 0 && !withoutRoot || hasChildSectionsToDisplay(item, sections)) {
      const cur = {
        ...item,
        from: res.length + 1,
        children: []
      };
      res.push(cur);
      item.children.forEach((child) => {
        if (withoutRoot) {
          return sections.has(child.id) ? dfs(child, cur) : null;
        }
        return dfs(child, cur);
      });
      cur.to = res.length - 1;
    }
  });

  return res;
}

export function prepareTableData(data, sectionsFilter = [], showEmptyRows, flipCoa) {
  return recalculateDataAccounts(filterSections(data, sectionsFilter), showEmptyRows, flipCoa);
}

export function prepareSections(sections, withSubsections) {
  const output = [];
  forEach(sections, (section) => {
    output.push({
      sectionId: section.id,
      sectionName: section.name,
      isRatio: section.type === RATIO_SECTION_TYPE
    });
    if (withSubsections) {
      section.isSubsection = false;
      section.children.forEach((child) => {
        if (isSection(child)) {
          output.push({
            sectionId: child.id,
            sectionName: child.name,
            isRatio: child.type === RATIO_SECTION_TYPE,
            isSubsection: true
          });
        }
      });
    }
  });

  return output;
}

function prepareAccount(item) {
  return {
    accountId: item.id,
    sectionId: item.rootSectionId,
    isRatio: item.type === RATIO_ACCOUNT_TYPE,
    accountName: item.name,
    accountNumber: item.number || ''
  };
}

export function getUniqueAccountList(data) {
  const accounts = data.filter(isAccount);
  return uniqBy(accounts, 'id').map(prepareAccount);
}

export function hasVisibleComposites(account) {
  return some(account.children, 'composite');
}
