import PropTypes from 'prop-types';
import React from 'react';
import { FixedDataTable2 } from 'react-techstack';
const { Cell } = FixedDataTable2;
import { getMessage } from 'modules/common/utils/messagesUtils';

import theme from './AsPublishedHeaderCell.css';

class AsPublishedHeaderCell extends React.Component {
  static propTypes = {
    title: PropTypes.string.isRequired
  };

  render() {
    const { title } = this.props;
    return (
      <Cell>
        <div className={theme.root}>
          <div>{title}</div>
          <div className={theme.grouped}>
            <div className={theme.title}>{getMessage('issuerDataView.table.columns.asPublished.title')}</div>
            <div className={theme.value}>{getMessage('issuerDataView.table.columns.asPublished.value')}</div>
          </div>
        </div>
      </Cell>
    );
  }
}

export default AsPublishedHeaderCell;
