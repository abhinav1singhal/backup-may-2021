import { connect } from 'react-redux';

import {
  selectAccountForPrivacyChange, toggleAllAccountsSelected
} from 'modules/issuerData/actions/legacyDataViewActions';
import AccountsTable from './AccountsTable';

export function mapStateToProps({legacyIssuerDataView: {accountsPrivacyPanel}}) {
  return {
    allAccountsSelected: accountsPrivacyPanel.allAccountsSelected
  };
}

const mapDispatchToProps = {
  selectAccountForPrivacyChange,
  toggleAllAccountsSelected
};

export default connect(mapStateToProps, mapDispatchToProps)(AccountsTable);
