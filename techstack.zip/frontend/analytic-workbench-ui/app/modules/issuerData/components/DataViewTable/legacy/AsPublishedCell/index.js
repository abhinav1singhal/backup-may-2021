export default from './AsPublishedCell';
