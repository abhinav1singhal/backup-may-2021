import PropTypes from 'prop-types';
import React from 'react';
import isFunction from 'lodash/isFunction';
import { OverlayTrigger, Glyphicon } from 'react-techstack';
import classNames from 'classnames';
import {hasPermission} from 'modules/common/utils/permissionsUtils';
import MenuCellPopover from './components/MenuCellPopover';

import theme from './MenuCell.css';

// ToDo: abstract options and reuse this component in other cells with menu, i.e. RatioCell
class MenuCell extends React.Component {

  static propTypes = {
    openPrivacyOverrideSidePanel: PropTypes.func,
    userPermissions: PropTypes.arrayOf(PropTypes.string).isRequired,
    children: PropTypes.node
  };

  constructor(props) {
    super(props);

    this.state = {
      menuButtonVisible: false
    };
  }

  render() {
    const {openPrivacyOverrideSidePanel, children} = this.props;
    if (!(isFunction(openPrivacyOverrideSidePanel) && hasPermission(this.props.userPermissions, 'override_data_privacy'))) {
      return children;
    }

    const menuOptions = [{label: 'Privacy Override', onClick: () => openPrivacyOverrideSidePanel()}];
    const overlayTriggerProps = {
      overlay: <MenuCellPopover options={menuOptions} hide={() => this.refs.menuCellOverlay.hide()} />,
      trigger: 'click',
      placement: 'bottom',
      rootClose: true,
      ref: 'menuCellOverlay',
      onEnter: () => {
        this.setState({menuButtonVisible: true}); // eslint-disable-line react/no-set-state
      },
      onExit: () => {
        this.setState({menuButtonVisible: false}); // eslint-disable-line react/no-set-state
      }
    };

    return (
      <div className={classNames(theme.root, this.state.menuButtonVisible && theme.menuButtonVisible)}>
        <OverlayTrigger {...overlayTriggerProps}>
          <div className={theme.menuButton}>
            <Glyphicon glyph="option-horizontal" />
          </div>
        </OverlayTrigger>
        {children}
      </div>
    );
  }
}

export default MenuCell;
