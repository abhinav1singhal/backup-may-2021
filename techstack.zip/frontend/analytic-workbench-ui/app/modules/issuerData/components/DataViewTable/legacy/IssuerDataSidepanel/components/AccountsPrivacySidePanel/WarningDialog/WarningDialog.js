import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { Alert, ButtonToolbar } from 'react-techstack';
import { Button } from 'modules/shared/components';
import theme from './WarningDialog.css';

class WarningDialog extends React.Component {

  static propTypes = {
    onHide: PropTypes.func.isRequired,
    onProceed: PropTypes.func
  };

  render() {
    const {onHide, onProceed} = this.props;

    return (
      <div className={classNames('modal', theme.root)}>
        <div className="modal-dialog">
          <Alert bsStyle="danger" onDismiss={onHide}>
            <h4>Warning!</h4>
            <p>
              Changing ratio privacy may also impact the privacy of downstream ratios. To view impacted ratios,
              click ‘Cancel’ and then click ‘Show Impacted’. If you are aware of the impacted ratios and wish to
              continue with your change, click 'Proceed'.
            </p>
            <ButtonToolbar>
              <Button bsStyle="danger" onClick={onProceed}>Proceed</Button>
              <Button bsStyle="link" onClick={onHide}>Cancel</Button>
            </ButtonToolbar>
          </Alert>
        </div>
      </div>
    );
  }
}

export default WarningDialog;
