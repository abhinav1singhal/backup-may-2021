import PropTypes from 'prop-types';
import React from 'react';
import { LoadingContainer } from 'react-techstack';
import { asyncStatusUtils } from 'react-techstack/utils';

import AdjustmentsSidePanel from './components/AdjustmentsSidePanel';
import AccountsPrivacySidePanel from './components/AccountsPrivacySidePanel';
import {isNotEmptyString} from 'modules/common/utils/stringUtils';
import {sidePanelTypes} from 'modules/issuerData/utils/legacyDataViewUtils';

const { isPending } = asyncStatusUtils;

class IssuerDataSidepanel extends React.Component {
  static propTypes = {
    sidePanelType: PropTypes.string.isRequired,

    adjustmentsTableStatus: PropTypes.string.isRequired,
    privacyManagementDataRequest: PropTypes.string.isRequired,
    title: PropTypes.string,
    height: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
    onSuccess: PropTypes.func,

    theme: PropTypes.any.isRequired
  };

  isLoading() {
    return (
      isPending(this.props.adjustmentsTableStatus) ||
      isPending(this.props.privacyManagementDataRequest) ||
      isPending(this.props.privacyManagementDataRequest)
    );
  }

  renderHeader() {
    if (!isNotEmptyString(this.props.title)) {
      return null;
    }

    return (
      <div className={this.props.theme.header}>
        <div className={this.props.theme.title}>
          {this.props.title}
        </div>
      </div>
    );
  }

  renderContent() {
    switch (this.props.sidePanelType) { // ToDo: Remove raw strings
      case sidePanelTypes.ADJUSTMENTS:
        return <AdjustmentsSidePanel />;
      case sidePanelTypes.ACCOUNTS_PRIVACY:
        return <AccountsPrivacySidePanel onSuccess={this.props.onSuccess} />;
      default:
        return null;
    }
  }

  render() {
    const { height, theme } = this.props;

    const containerProps = {
      isLoading: this.isLoading(),
      offset: 200,
      theme: {
        spinnerContainer: theme.spinnerContainer,
        contentArea: theme.fullHeight,
        root: theme.fullHeight,
        loadingArea: '',
        title: ''
      }
    };

    return (
      <div className={theme.root} style={{height}}>
        <LoadingContainer {...containerProps}>
          {this.renderHeader()}
          {this.renderContent()}
        </LoadingContainer>
      </div>
    );
  }
}

IssuerDataSidepanel.defaultProps = {
  theme: require('./IssuerDataSidepanel.css')
};

export default IssuerDataSidepanel;
