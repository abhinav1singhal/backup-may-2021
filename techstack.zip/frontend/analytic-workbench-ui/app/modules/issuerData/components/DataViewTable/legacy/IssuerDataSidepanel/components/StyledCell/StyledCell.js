import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import theme from './StyledCell.css';

class StyledCell extends React.Component {

  static propTypes = {
    data: PropTypes.object,
    children: PropTypes.node,

    className: PropTypes.string
  };

  render() {
    const data = this.props.data || {};
    const rootClassNames = classNames({
      [theme.private]: data.private,
      [theme.adjusted]: !data.private && data.adjusted
    }, this.props.className);

    return <div className={rootClassNames}>{this.props.children}</div>;
  }
}

StyledCell.defaultProps = {};

export default StyledCell;
