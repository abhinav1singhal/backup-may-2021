import PropTypes from 'prop-types';
import React from 'react';
import isFunction from 'lodash/isFunction';
import classNames from 'classnames';
import { OverlayTrigger, Glyphicon } from 'react-techstack';

import MenuCellPopover from '../MenuCell/components/MenuCellPopover';
import { getMessage } from 'modules/common/utils/messagesUtils';

import theme from './AccountTitleWrapper.css';

class AccountTitleWrapper extends React.Component {
  static propTypes = {
    type: PropTypes.string,

    openRatioDrillDown: PropTypes.func.isRequired,

    children: PropTypes.node.isRequired,
    className: PropTypes.string
  };

  constructor(props) {
    super(props);

    this.state = {
      menuButtonVisible: false
    };
  }

  renderMenuButton(menuOptions) {
    if (menuOptions.length < 1) {
      return null;
    }

    const overlayTriggerProps = {
      overlay: <MenuCellPopover options={menuOptions} hide={() => this.refs.menuCellOverlay.hide()} />,
      trigger: 'click',
      placement: 'bottom',
      rootClose: true,
      ref: 'menuCellOverlay',
      onEnter: () => {
        this.setState({menuButtonVisible: true}); // eslint-disable-line react/no-set-state
      },
      onExit: () => {
        this.setState({menuButtonVisible: false}); // eslint-disable-line react/no-set-state
      }
    };

    return (
      <OverlayTrigger {...overlayTriggerProps}>
        <div className={theme.menuButton}>
          <Glyphicon glyph="option-horizontal" />
        </div>
      </OverlayTrigger>
    );
  }

  render() {
    const {type, openRatioDrillDown, children, className} = this.props;

    const menuOptions = [];
    if (type === 'RATIO_ACCOUNT' && isFunction(openRatioDrillDown)) {
      menuOptions.push({
        label: getMessage('issuerDataView.ratioDetailsButton'),
        onClick: openRatioDrillDown
      });
    }

    const rootClasses = classNames(theme.root, className, {
      [theme.menuEnabled]: menuOptions.length > 0,
      [theme.menuButtonVisible]: this.state.menuButtonVisible
    });

    return (
      <div className={rootClasses}>
        {this.renderMenuButton(menuOptions)}
        {className ? null : children}
      </div>
    );
  }
}

export default AccountTitleWrapper;
