import { connect } from 'react-redux';

import {selectAdjustmentsTableRow} from 'modules/issuerData/actions/legacyDataViewActions';
import {openTabWithAccountAdjustmentsDetails} from 'modules/issuerData/actions/dataViewActions';
import AdjustmentsSidePanel from './AdjustmentsSidePanel';


export function mapStateToProps(state) {
  return {
    statementRevisionId: state.legacyIssuerDataView.adjustmentsPanel.statementRevisionId,
    mappedValue: state.legacyIssuerDataView.adjustmentsPanel.mappedValue,
    adjustedValue: state.legacyIssuerDataView.adjustmentsPanel.adjustedValue,
    adjustments: state.legacyIssuerDataView.adjustmentsPanel.adjustments,
    accounts: state.legacyIssuerDataView.adjustmentsPanel.accounts,
    totalAmount: state.legacyIssuerDataView.adjustmentsPanel.totalAmount,
    selectedRow: state.legacyIssuerDataView.adjustmentsPanel.selectedRow,

    adjustmentsTableStatus: state.requests.adjustmentsTable.status
  };
}

const mapDispatchToProps = {
  selectAdjustmentsTableRow,
  openTabWithAccountAdjustmentsDetails
};

export default connect(mapStateToProps, mapDispatchToProps)(AdjustmentsSidePanel);
