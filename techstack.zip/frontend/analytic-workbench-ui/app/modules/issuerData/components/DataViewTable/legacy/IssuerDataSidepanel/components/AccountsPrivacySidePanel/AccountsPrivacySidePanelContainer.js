import { connect } from 'react-redux';

import {
  changePrivacySidePanelView, selectPreviousPrivacyTransaction, setPrivacyOverrideReason,
  savePrivacyTransaction, revertPrivacyTransaction, onShowImpactedClick,
  closeAccountsPrivacySidePanel, onShowRevertImpactedClick
} from 'modules/issuerData/actions/legacyDataViewActions';
import AccountsPrivacySidePanel from './AccountsPrivacySidePanel';
import { getSelectedEligibleAccounts } from 'modules/issuerData/utils/legacyDataViewUtils';

export function mapStateToProps({legacyIssuerDataView: {accountsPrivacyPanel}, issuer: {currentIssuer}, requests}) {
  return {
    ...accountsPrivacyPanel.toJS(),
    selectedAccounts: getSelectedEligibleAccounts(accountsPrivacyPanel.eligibleAccounts),
    issuer: currentIssuer,
    privacyManagementDataRequest: requests.privacyManagementData,
    savePrivacyTransactionRequest: requests.savePrivacyTransaction,
    revertPrivacyTransactionRequest: requests.revertPrivacyTransaction,
    impactedAccountsRequest: requests.privacyLoadImpactedAccounts,
    revertImpactedAccountsRequest: requests.privacyLoadRevertImpactedAccounts
  };
}

const mapDispatchToProps = {
  changePrivacySidePanelView,
  selectPreviousPrivacyTransaction,
  savePrivacyTransaction,
  revertPrivacyTransaction,
  setPrivacyOverrideReason,
  closeAccountsPrivacySidePanel,
  onShowImpactedClick,
  onShowRevertImpactedClick
};

export default connect(mapStateToProps, mapDispatchToProps)(AccountsPrivacySidePanel);
