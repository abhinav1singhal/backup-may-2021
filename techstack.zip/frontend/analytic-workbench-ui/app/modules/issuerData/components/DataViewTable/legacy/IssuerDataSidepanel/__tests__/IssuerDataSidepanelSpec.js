//
// /* global it xdescribe */
// /* eslint-disable no-console */
//
// import React from 'react';
// import TestUtils from 'react-addons-test-utils';
// import { findDOMNode } from 'react-dom';
// import expect from 'expect';
// import { noop } from 'lodash/util';
//
// import IssuerDataSidepanel from '../IssuerDataSidepanel';
//
//
// xdescribe('app.modules.issuerData.components.IssuerDataSidepanel.__tests__.IssuerDataSidepanelSpec', () => {
//   function renderSidepanel(customProps) {
//     const props = {
//       details: {
//         data: [{
//           id: 1,
//           name: 'Test',
//           amount: '123'
//         }],
//         totals: {
//           amount: 0
//         },
//         title: ''
//       },
//
//       selectAdjustmentsTableRow: noop,
//       loadAdjustmentsTable: noop,
//       loadAdjustmentDetailsTable: noop,
//       toggleAdjustmentsTable: noop,
//       isSidepanelCollapsed: false,
//       ...customProps
//     };
//
//     return TestUtils.renderIntoDocument(<IssuerDataSidepanel {...props} />);
//   }
//
//   it('should render', () => {
//     const sidepanelInstance = renderSidepanel();
//     const sidepanelNode = findDOMNode(sidepanelInstance);
//
//     expect(sidepanelNode).toExist();
//   });
//
//   it('should load data if sidepanel should update', () => {
//     const loadSpy = expect.createSpy();
//     renderSidepanel({
//       loadAdjustmentsTable: loadSpy,
//       shouldSidepanelUpdate: true
//     });
//
//     expect(loadSpy).toHaveBeenCalled();
//   });
//
//   it('should toggle state on collapse button click', () => {
//     const collapseSpy = expect.createSpy();
//     const sidepanelInstance = renderSidepanel({
//       toggleAdjustmentsTable: collapseSpy
//     });
//     const sidepanelNode = findDOMNode(sidepanelInstance);
//     const closeButton = sidepanelNode.querySelector('.close');
//
//     TestUtils.Simulate.click(closeButton);
//
//     expect(collapseSpy).toHaveBeenCalled();
//   });
//
//   it('should toggle state on collapse button click', () => {
//     const rowSpy = expect.createSpy();
//     const sidepanelInstance = renderSidepanel({
//       selectAdjustmentsTableRow: rowSpy
//     });
//     const sidepanelNode = findDOMNode(sidepanelInstance);
//     const rowButton = sidepanelNode.querySelector('tbody tr');
//
//     TestUtils.Simulate.click(rowButton);
//
//     expect(rowSpy).toHaveBeenCalled();
//   });
//
//   it('should call resize function if container resized', () => {
//     const resizeSpy = expect.createSpy();
//     renderSidepanel({
//       onResize: resizeSpy
//     });
//
//     expect(resizeSpy).toHaveBeenCalled();
//   });
//
//   it('should render details table if adjustments is provided', () => {
//     const sidepanelInstance = renderSidepanel({
//       adjustments: {
//         data: [{
//           id: 1,
//           name: 'Test',
//           amount: '123'
//         }],
//         totals: {
//           amount: 0
//         }
//       }
//     });
//     const sidepanelNode = findDOMNode(sidepanelInstance);
//     const tableNodes = sidepanelNode.querySelectorAll('table');
//
//     expect(tableNodes.length).toBe(2);
//   });
//
//   it('should not render if no data provided', () => {
//     const sidepanelInstance = renderSidepanel({
//       details: null
//     });
//     const sidepanelNode = findDOMNode(sidepanelInstance);
//
//     expect(sidepanelNode).toNotExist();
//   });
// });
