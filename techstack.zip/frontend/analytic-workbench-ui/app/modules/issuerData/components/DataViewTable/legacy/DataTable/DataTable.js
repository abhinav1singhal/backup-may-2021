/* eslint-disable react/no-set-state */
import PropTypes from 'prop-types';

import React from 'react';
import classNames from  'classnames';
import { noop, isEqual, findIndex } from 'lodash';
import { FixedDataTable2 } from 'react-techstack';
const { Table, Column, Cell } = FixedDataTable2;
import autoSizer from './autoSizer';
import { ToggleCell, ToggleHeaderCell } from './components';
import { VisibilityTree, getToggleProps, heightPropTypeChecker, getColumnByX, getXByColumnIndex } from './utils';

const DEFAULT_TYPE = 'root';

class DataTable extends React.Component {
  static propTypes = {
    columns: PropTypes.arrayOf(PropTypes.object).isRequired,
    data: PropTypes.arrayOf(PropTypes.object).isRequired,

    width: PropTypes.number.isRequired,
    minColumnWidth: PropTypes.number.isRequired,
    height: heightPropTypeChecker,
    maxHeight: heightPropTypeChecker,
    rowHeight: PropTypes.number.isRequired,
    headerHeight: PropTypes.number.isRequired,

    isTreeView: PropTypes.bool,
    onChangeTopRow: PropTypes.func.isRequired,
    onChangeLeftColumn: PropTypes.func.isRequired,
    toggleCell: PropTypes.func,
    cell: PropTypes.func,
    header: PropTypes.func,

    type: PropTypes.oneOf([ 'lined', 'striped', 'bordered', DEFAULT_TYPE ]).isRequired,
    className: PropTypes.string,
    theme: PropTypes.object.isRequired,
    compositesToggled: PropTypes.bool
  };

  constructor(props) {
    super(props);

    this.state = this.init(props);
    this.canScroll = true;
  }

  UNSAFE_componentWillReceiveProps(props) {
    if (props.compositesToggled) {
      this.tree = new VisibilityTree(props.data, true);
      this.setState({rowsCount: this.tree.getRowsCount()});
    } else if (props.data !== this.props.data) {
      this.setState(this.init(props));
    }
  }

  componentDidUpdate(props, state) {
    if (!isEqual(this.state, state)) {
      this.changeTopRow(this.table.state.scrollY);
      this.changeLeftColumn(this.table.state.scrollX);
    }
    if (this.state.scrollLeft !== state.scrollLeft) {
      this.setState({ scrollLeft: undefined });
    }
  }

  onVerticalScroll = (y) => {
    this.setState({ scrollTop: y });
    this.changeTopRow(y);
    return true;
  };

  onHorizontalScroll = (x) => {
    this.changeLeftColumn(x);
    return true;
  };

  onColumnResizeEnd = (newWidth, columnKey) => {
    this.setState({
      columnsWidths: {
        ...this.state.columnsWidths,
        [columnKey]: newWidth
      }
    });
  };

  getHeader(column) {
    if (column.key === 'toggle') {
      return this.renderToggleHeaderCell();
    }

    return this.props.header ? this.props.header(column) : column.label;
  }

  init(props) {
    this.tree = new VisibilityTree(props.data);
    this.topRow = this.tree.getRow(0);
    this.leftColumn = props.columns.find(({ fixed }) => !fixed);

    return {
      scrollTop: 0,
      scrollLeft: 0,
      rowsCount: this.tree.getRowsCount(),
      columnsWidths: {}
    };
  }

  scrollToRowByIndex = (index) => {
    // console.time('render');
    this.setState({ scrollTop: index * this.props.rowHeight });
  };

  scrollToColumnByIndex = (index) => {
    // console.time('render');
    this.setState({ scrollLeft: getXByColumnIndex(this.props.columns, index, this.state.columnsWidths) });
  };

  find = (rowPredicate, fromIndex, columnPredicate) => {
    // console.time('find');
    const index = this.tree.findIndex(rowPredicate, fromIndex);
    // console.timeEnd('find');
    if (index >= 0) {
      this.setState({ rowsCount: this.tree.getRowsCount() });
      this.scrollToRowByIndex(index);
    }
    if (columnPredicate) {
      const columnIndex = findIndex(this.props.columns, columnPredicate);
      if (columnIndex >= 0) {
        this.scrollToColumnByIndex(columnIndex - 2);
      }
    }

  };

  changeTopRow(y) {
    const { rowHeight } = this.props;
    const topIndex = Math.round((y + 0.1 * rowHeight) / this.props.rowHeight);
    const topRow = this.tree.getRow(topIndex);
    if (this.topRow !== topRow) {
      this.props.onChangeTopRow(topRow);
      this.topRow = topRow;
    }
  }

  changeLeftColumn(x) {
    const column = getColumnByX(this.props.columns, x, this.state.columnsWidths);
    if (this.leftColumn !== column) {
      this.props.onChangeLeftColumn(column);
      this.leftColumn = column;
    }
  }

  toggleRow = (row) => {
    // console.time('render');
    const rowsCount = this.tree.toggleRow(row);
    this.setState({ rowsCount });
  };

  toggleAll = () => {
    // console.time('render');
    const expanded = this.state.rowsCount === this.props.data.length;
    if (!expanded) {
      this.tree.expandAll();
    } else {
      this.tree.closeAll();
    }
    this.setState({ rowsCount: this.tree.getRowsCount() });
  };

  showRows = (from, to) => {
    // console.time('render');
    this.tree.open(from, to);
    this.setState({ rowsCount: this.tree.getRowsCount() });
  };

  hideRows = (from, to) => {
    // console.time('render');
    this.tree.close(from, to);
    this.setState({ rowsCount: this.tree.getRowsCount() });
  };

  renderToggleHeaderCell = () => {
    const expanded = this.state.rowsCount === this.props.data.length;
    return <ToggleHeaderCell expanded={expanded} toggle={this.toggleAll} />;
  };

  renderCell = ({ rowIndex, columnKey, ...props }) => {
    const treeItem = this.tree.getRow(rowIndex);

    if (columnKey === 'toggle') {
      const toggleProps = getToggleProps(treeItem, this.toggleRow);
      if (this.props.toggleCell) {
        return this.props.toggleCell(toggleProps, treeItem);
      }
      return <ToggleCell {...toggleProps} />;
    }
    if (this.props.cell) {
      return this.props.cell(treeItem[columnKey], columnKey, treeItem, props);
    }
    return <Cell>{treeItem[columnKey]}</Cell>;
  };

  render() {
    // console.timeEnd('render');
    const { width, height, maxHeight, rowHeight, headerHeight, minColumnWidth, isTreeView } = this.props;
    const columns = this.props.columns.slice();
    if (isTreeView) {
      columns.unshift({ key: 'toggle', width: 40, fixed: true });
    }
    const tableProps = {
      ref: (el) => { this.table = el; },
      width,
      height,
      maxHeight,
      rowsCount: this.state.rowsCount,
      rowHeight,
      headerHeight,
      className: classNames(
        this.props.className,
        this.props.theme[this.props.type]
      ),
      scrollTop: this.state.scrollTop,
      scrollLeft: this.state.scrollLeft,
      onVerticalScroll: this.onVerticalScroll,
      onHorizontalScroll: this.onHorizontalScroll,
      onColumnResizeEndCallback: this.onColumnResizeEnd,
      isColumnResizing: false
    };
    const { columnsWidths } = this.state;

    return (
      <Table {...tableProps}>
        {
          columns.filter(({hidden}) => !hidden).map((column) => {
            const header = this.getHeader(column);
            const columnProps = {
              key: column.key,
              columnKey: column.key,
              label: column.label,
              width: columnsWidths[column.key] || column.width || column.minWidth || minColumnWidth,
              minWidth: column.minWidth,
              flexGrow: column.flexGrow || (column.width === undefined ? 1 : undefined),
              cell: this.renderCell,
              header,
              fixed: column.fixed,
              isResizable: column.isResizable,
              allowCellsRecycling: true
            };

            return (
              <Column {...columnProps} />
            );
          })
        }
      </Table>
    );
  }
}

DataTable.defaultProps = {
  headerHeight: 50,
  rowHeight: 50,
  minColumnWidth: 0,
  theme: require('./DataTable.css'),
  type: DEFAULT_TYPE,
  onChangeTopRow: noop,
  onChangeLeftColumn: noop
};

export default autoSizer(DataTable);
