import PropTypes from 'prop-types';
import React from 'react';
import { Alert, Scrollbars } from 'react-techstack';
import { asyncStatusUtils } from 'react-techstack/utils';
import { displayValue } from 'modules/issuerData/utils/legacyDataViewUtils';

import StyledCell from '../StyledCell';
import AdjustmentsTable from './components/AdjustmentsTable';
const { isFailed } = asyncStatusUtils;

import { getMessage } from 'modules/common/utils/messagesUtils';

import theme from './AdjustmentsSidePanel.css';

class AdjustmentsSidePanel extends React.Component {
  static propTypes = {
    statementRevisionId: PropTypes.string,
    mappedValue: PropTypes.shape({
      amount: PropTypes.string,
      private: PropTypes.bool
    }),
    adjustedValue: PropTypes.shape({
      amount: PropTypes.string,
      private: PropTypes.bool
    }),
    adjustments: PropTypes.array,
    accounts: PropTypes.array,
    totalAmount: PropTypes.string,
    selectedRow: PropTypes.string,

    openTabWithAccountAdjustmentsDetails: PropTypes.func.isRequired,
    selectAdjustmentsTableRow: PropTypes.func.isRequired,

    adjustmentsTableStatus: PropTypes.string.isRequired
  };

  renderErrorMessage() {
    return (
      <Alert bsStyle="danger">
        Problem with loading adjustments for account.
      </Alert>
    );
  }

  renderAdjustmentsTable() {
    const { adjustments, totalAmount, statementRevisionId, selectedRow, selectAdjustmentsTableRow } = this.props;
    const tableProps = {
      data: adjustments,
      columns: [
        { key: 'name', title: 'Adjustment Title' },
        { key: 'amount', title: 'Amount', width: '30%' }
      ],
      onRowClick: (adjustmentId) => selectAdjustmentsTableRow(statementRevisionId, adjustmentId),
      totalAmount,
      selectedRow
    };

    return (
      <div className={theme.container}>
        <div className={theme.divider}>
          <span className={theme.header}>Adjustments</span>
        </div>
        <div className={theme.table}>
          <AdjustmentsTable {...tableProps} />
        </div>
      </div>
    );
  }

  renderAccountsTable() {
    if (!this.props.accounts) {
      return null;
    }

    const {accounts, statementRevisionId, openTabWithAccountAdjustmentsDetails} = this.props;

    const tableProps = {
      data: accounts,
      columns: [
        { key: 'name', title: getMessage('issuer.dataView.titles.accountNameColumn') },
        { key: 'amount', title: 'Amount', width: '30%' }
      ],
      onRowClick: (accountId) => openTabWithAccountAdjustmentsDetails(statementRevisionId, accountId)
    };

    return (
      <div className={theme.container}>
        <div className={theme.divider} />
        <div className={theme.table}>
          <AdjustmentsTable {...tableProps} />
        </div>
      </div>
    );
  }

  render() {
    if (isFailed(this.props.adjustmentsTableStatus)) {
      return this.renderErrorMessage();
    }

    if (!this.props.adjustments) {
      return null;
    }

    const {mappedValue, adjustedValue} = this.props;

    return (
      <div className={theme.root}>
        <div>
          <span>Mapped value: </span>
          <StyledCell data={{private: !!mappedValue && mappedValue.private}} className={theme.value}>
            {displayValue(mappedValue ? mappedValue.amount : null)}
          </StyledCell>
        </div>
        <div>
          <span>Adjusted value: </span>
          <StyledCell data={{private: !!adjustedValue && adjustedValue.private}} className={theme.value}>
            {displayValue(adjustedValue ? adjustedValue.amount : null)}
          </StyledCell>
        </div>
        <div className={theme.tablesWrapper}>
          <Scrollbars disableHorizontal>
            {this.renderAdjustmentsTable()}
            {this.renderAccountsTable()}
          </Scrollbars>
        </div>
      </div>
    );
  }
}

export default AdjustmentsSidePanel;
