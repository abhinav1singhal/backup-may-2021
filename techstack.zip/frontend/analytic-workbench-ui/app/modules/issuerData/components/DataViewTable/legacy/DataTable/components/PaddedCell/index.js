export default from './PaddedCell';
