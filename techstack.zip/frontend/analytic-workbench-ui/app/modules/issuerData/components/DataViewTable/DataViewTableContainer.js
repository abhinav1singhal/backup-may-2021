import { connect } from 'react-redux';

import {loadData} from 'modules/issuerData/actions/dataViewActions';

import DataViewTable from './DataViewTable';

function mapStateToProps(state) {
  return {
    currentIssuer: state.issuer.currentIssuer,
    currentViewType: state.issuerDataView.currentViewType,
    statements: state.issuerDataView.statements,
    displayConfig: state.issuerDataView.displayConfig,
    columns: state.issuerDataView.columns,
    data: state.issuerDataView.tableData,

    issuerDataViewDataRequest: state.requests.issuerDataViewData
  };
}

const mapDispatchToProps = {
  loadData
};

export default connect(mapStateToProps, mapDispatchToProps)(DataViewTable);
