import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { Select } from 'react-techstack';
import { isEqual, find } from 'lodash';
import {hasPermission} from 'modules/common/utils/permissionsUtils';
import { FilterOverlay } from 'modules/shared/components';
import SectionsFilterHeader from './components/SectionsFilterHeader';

import theme from './DataTableNavigator.css';
import { prepareSections, hasChildSectionsToDisplay } from '../utils';

const OTHER_RATIOS_SECTION_ID = '00000000-0000-0000-0000-000000000001';

class DataTableNavigator extends React.Component {
  static propTypes = {
    sections: PropTypes.arrayOf(PropTypes.object).isRequired,
    onChangeSelectedSections: PropTypes.func.isRequired,
    selectedSections: PropTypes.array.isRequired,

    currentSectionId: PropTypes.oneOfType([
      PropTypes.string, PropTypes.number
    ]),
    onChangeCurrentSection: PropTypes.func.isRequired,

    userPermissions: PropTypes.arrayOf(PropTypes.string).isRequired,
    theme: PropTypes.object.isRequired
  };

  constructor(props) {
    super(props);
    this.state = this.prepareData(props.sections, props.selectedSections, null, true);
  }

  UNSAFE_componentWillReceiveProps(props, state) {
    if (!isEqual(this.props.selectedSections, props.selectedSections) || !isEqual(this.props.sections, props.sections)) {
      this.setState(this.prepareData(props.sections, props.selectedSections, state.currentSectionId, true));
    }
  }

  onApplySectionFilter = (sectionIds) => {
    const { sections, onChangeSelectedSections, onChangeCurrentSection } = this.props;
    const newState = this.prepareData(sections, sectionIds, this.state.currentSectionId);

    this.setState(newState);

    onChangeSelectedSections(sectionIds);

    if (this.state.currentSectionId !== newState.currentSectionId) {
      onChangeCurrentSection(newState.currentSectionId);
    }
  };

  prepareData(issuerData = [], selectedSections = [], currentSectionId, initial) {
    const allSections = [];
    const options = [];
    let selectedOption;
    let separatorInserted = false;
    const sections = new Set(selectedSections);

    const data = prepareSections(issuerData, true);

    data.forEach(({sectionId, sectionName, isRatio = false, isSubsection = false}) => {
      const section = find(issuerData, ['id', sectionId]);
      const shown = sections.has(sectionId) || sections.size === 0 || (section && hasChildSectionsToDisplay(section, sections));
      if (isRatio && !separatorInserted && shown && options.length) {
        options.push({
          label: <hr className={theme.navigatorSpacer} />,
          value: '',
          disabled: true
        });
        separatorInserted = true;
      }

      const sectionNameForRatios = sectionId === OTHER_RATIOS_SECTION_ID ? sectionName : `Ratios - ${sectionName}`;
      const label = isRatio ? sectionNameForRatios : sectionName;
      const item = {
        id: sectionId,
        label,
        value: label,
        isRatio,
        isSubsection
      };

      allSections.push(item);
      if (!shown) {
        return;
      }

      options.push(item);
      if (currentSectionId === sectionId) {
        selectedOption = item;
      }
    });

    selectedOption = !selectedOption && initial ?  options[0] : selectedOption;

    return {
      allSections,
      selectedOption,
      options,
      currentSectionId: selectedOption && selectedOption.id
    };
  }

  changeCurrentSectionId = (currentSectionId) => {
    if (this.state.currentSectionId !== currentSectionId) {
      const { sections, selectedSections, onChangeCurrentSection } = this.props;
      const newState = this.prepareData(sections, selectedSections, currentSectionId);
      this.setState(newState);

      if (currentSectionId !== newState.currentSectionId && newState.currentSectionId) {
        onChangeCurrentSection(newState.currentSectionId);
      }
    }
  };

  render() {
    if (!this.props.sections || !hasPermission(this.props.userPermissions, 'search_issuer_data_sections')) {
      return null;
    }

    const { options, selectedOption, allSections} = this.state;
    const { selectedSections, onChangeCurrentSection, theme: customTheme } = this.props;

    const selectProps = {
      multi: false,
      backspaceRemoves: false,
      clearable: false,
      expandable: true,
      value: selectedOption,
      options,
      onChange: ({id}) => onChangeCurrentSection(id),
      disabled: options.length === 0,
      placeholder: '',
      wrapperClassName: theme.wrapper,
      valueClassName: theme.value,
      theme: 'noBorder',
      bsSize: 'small'
    };

    const overlayOptions = {
      disabled: allSections.length === 0,
      options: allSections,
      selected: selectedSections,
      Header: SectionsFilterHeader,
      triggerTheme: {
        button: theme.filterButton
      },
      onApply: this.onApplySectionFilter
    };

    return (
      <div className={classNames(theme.root, customTheme.root)}>
        <FilterOverlay {...overlayOptions} />
        <Select {...selectProps} />
      </div>
    );
  }
}

DataTableNavigator.defaultProps = {
  theme: {}
};

export default DataTableNavigator;
