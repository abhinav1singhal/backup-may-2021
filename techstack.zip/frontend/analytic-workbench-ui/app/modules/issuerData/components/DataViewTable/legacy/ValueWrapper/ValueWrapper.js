import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import { isUndefined, isNull, isFunction } from 'lodash';
import { OverlayTrigger, Glyphicon } from 'react-techstack';

import MenuCellPopover from '../MenuCell/components/MenuCellPopover';
import { displayValue } from 'modules/issuerData/utils/legacyDataViewUtils';
import { getMessage } from 'modules/common/utils/messagesUtils';

import theme from './ValueWrapper.css';

class ValueWrapper extends React.Component {
  static propTypes = {
    type: PropTypes.string,
    value: PropTypes.shape({
      title: PropTypes.string,
      value: PropTypes.string,
      adjusted: PropTypes.bool,
      privacy: PropTypes.bool
    }).isRequired,

    openLookBack: PropTypes.func,
    openRatioDrillDown: PropTypes.func,
    openAdjustmentsDetailsSidePanel: PropTypes.func
  };

  constructor(props) {
    super(props);

    this.state = {
      menuButtonVisible: false
    };
  }

  renderMenuButton(menuOptions) {
    if (menuOptions.length === 0) {
      return null;
    }

    const overlayTriggerProps = {
      overlay: <MenuCellPopover options={menuOptions} hide={() => this.refs.menuCellOverlay.hide()} />,
      trigger: 'click',
      placement: 'bottom',
      rootClose: true,
      ref: 'menuCellOverlay',
      onEnter: () => {
        this.setState({menuButtonVisible: true}); // eslint-disable-line react/no-set-state
      },
      onExit: () => {
        this.setState({menuButtonVisible: false}); // eslint-disable-line react/no-set-state
      }
    };

    return (
      <OverlayTrigger {...overlayTriggerProps}>
        <div className={theme.menuButton}>
          <Glyphicon glyph="option-horizontal" />
        </div>
      </OverlayTrigger>
    );
  }

  render() {
    const {type, openLookBack, openRatioDrillDown, openAdjustmentsDetailsSidePanel} = this.props;
    if (['SECTION', 'RATIO_SECTION'].indexOf(type) !== -1) {
      return null;
    }

    const {value, adjusted, privacy} = this.props.value;

    const menuOptions = [];
    if (adjusted && isFunction(openAdjustmentsDetailsSidePanel)) {
      // const params = {
      //   issuerId: issuer.id,
      //   statementId,
      //   statementRevisionId,
      //   accountId,
      //   currency,
      //   scale
      // };
      //
      // const cell = {
      //   accountId,
      //   statementRevisionId
      // };

      menuOptions.push({
        label: getMessage('issuerDataView.adjustments.detailsButton'),
        onClick: () => openAdjustmentsDetailsSidePanel()
      });
    }

    if (type === 'RATIO_ACCOUNT' && isFunction(openRatioDrillDown)) {
      menuOptions.push({
        label: getMessage('issuerDataView.ratioDetailsButton'),
        onClick: openRatioDrillDown
      });
    }

    if (type === 'ACCOUNT' && !isUndefined(value) && !isNull(value) && isFunction(openLookBack)) {
      menuOptions.push({
        label: getMessage('issuerDataView.lookBackButton'),
        onClick: openLookBack
      });
    }

    const rootClasses = classNames(theme.root, {
      [theme.menuEnabled]: menuOptions.length > 0,
      [theme.menuButtonVisible]: this.state.menuButtonVisible
    });
    const valueClasses = classNames(theme.value, {
      [theme.private]: privacy,
      [theme.adjusted]: adjusted && !privacy
    });

    return (
      <div className={rootClasses}>
        {this.renderMenuButton(menuOptions)}
        <div className={valueClasses}>{displayValue(value)}</div>
      </div>
    );
  }
}

export default ValueWrapper;
