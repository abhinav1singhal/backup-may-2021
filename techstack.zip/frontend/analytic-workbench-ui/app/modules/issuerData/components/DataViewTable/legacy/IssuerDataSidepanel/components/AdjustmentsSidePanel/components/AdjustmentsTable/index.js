export default from './AdjustmentsTable';
