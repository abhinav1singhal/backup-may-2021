// /* global beforeEach afterEach describe it xdescribe */
// /* eslint-disable no-console */
//
// import React from 'react';
// import TestUtils from 'react-addons-test-utils';
// import { findDOMNode } from 'react-dom';
// import expect from 'expect';
//
// import AdjustmentsTable from '../AdjustmentsTable';
//
// xdescribe('app.modules.issuerData.components.IssuerDataSidepanel.components.AdjustmentsSidePanel.components.AdjustmentsTable.__tests__.AdjustmentsTableSpec', () => {
//   const dataMock = [{
//     id: 1,
//     name: 'Test',
//     amount: '123'
//   }, {
//     id: 2,
//     name: 'Test2',
//     amount: '123'
//   }];
//
//   function renderAdjustmentsTable(customProps) {
//     const props = {
//       data: [],
//       columns: [
//         { key: 'name', title: 'Adjustment Title' },
//         { key: 'amount', title: 'Amount' }
//       ],
//       totals: {
//         amount: 0
//       },
//       ...customProps
//     };
//
//     return TestUtils.renderIntoDocument(<AdjustmentsTable {...props} />);
//   }
//
//   it('should render correct number of rows', () => {
//     const tableInstance = renderAdjustmentsTable({
//       data: dataMock
//     });
//     const tableNode = findDOMNode(tableInstance);
//     const rows = tableNode.querySelectorAll('tbody tr');
//
//     expect(rows.length).toEqual(2);
//   });
//
//   it('should call funciton on row click', () => {
//     const clickSpy = expect.createSpy();
//
//     const tableInstance = renderAdjustmentsTable({
//       data: dataMock,
//       onRowClick: clickSpy
//     });
//     const tableNode = findDOMNode(tableInstance);
//     const row = tableNode.querySelectorAll('tbody tr')[0];
//     TestUtils.Simulate.click(row);
//
//     expect(clickSpy).toHaveBeenCalled(2);
//   });
//
//   it('should apply selected class if row is selected', () => {
//     const tableInstance = renderAdjustmentsTable({
//       data: [{
//         selected: true,
//         ...dataMock[0]
//       }],
//       theme: {
//         selected: 'selected'
//       }
//     });
//     const tableNode = findDOMNode(tableInstance);
//     const row = tableNode.querySelector('.selected');
//
//     expect(row).toExist();
//   });
//
// });
