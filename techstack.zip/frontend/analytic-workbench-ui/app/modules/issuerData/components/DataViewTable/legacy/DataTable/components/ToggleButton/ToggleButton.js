import PropTypes from 'prop-types';
import React from 'react';
import { Icon, Button } from 'react-techstack';

import theme from './ToggleButton.css';

class ToggleButton extends React.Component {
  static propTypes = {
    type: PropTypes.oneOf(['minus', 'plus']).isRequired,
    toggle: PropTypes.func.isRequired,
    iconColor: PropTypes.string.isRequired
  };

  render() {
    const { type, toggle, iconColor } = this.props;
    return (
      <Button onClick={toggle} bsSize="xsmall" className={theme.button} >
        <Icon type={type} color={iconColor} />
      </Button>
    );
  }
}

ToggleButton.defaultProps = {
  iconColor: '#fff'
};

export default ToggleButton;
