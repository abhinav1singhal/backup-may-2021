import PropTypes from 'prop-types';
import React from 'react';
import { FixedDataTable2 } from 'react-techstack';
import classNames from 'classnames';
const { Cell } = FixedDataTable2;
import ToggleButton from '../ToggleButton';

import theme from './ToggleCell.css';
import viewTableTheme from '../../DataViewTable.css';

class ToggleCell extends React.Component {
  static propTypes = {
    treeItem: PropTypes.object.isRequired,
    expandable: PropTypes.bool,
    expanded: PropTypes.bool,
    toggle: PropTypes.func.isRequired
  };

  toggle = () => {
    this.props.toggle(this.props.treeItem);
  }

  render() {
    const { expanded, expandable, treeItem, ...props } = this.props;
    const sign = expanded ? 'minus' : 'plus';
    const compositeClass = treeItem.composite ? viewTableTheme.composite : null;

    return (
      <Cell {...props} className={classNames(theme.root, compositeClass)} >
        {expandable && <ToggleButton type={sign} toggle={this.toggle} /> }
      </Cell>
    );
  }
}

export default ToggleCell;
