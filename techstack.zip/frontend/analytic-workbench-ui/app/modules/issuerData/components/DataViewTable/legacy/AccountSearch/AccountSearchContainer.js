import { connect } from 'react-redux';

import AccountSearch from './AccountSearch';
import {selectViewedIssuerAccount} from 'modules/issuerData/actions/legacyDataViewActions';

export function mapStateToProps(state) {
  return {
    selectedActionId: state.legacyIssuerDataView.viewedIssuerAccountId
  };
}

const mapDispatchToProps = {
  selectViewedIssuerAccount
};

export default connect(mapStateToProps, mapDispatchToProps)(AccountSearch);
