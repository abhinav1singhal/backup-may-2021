import PropTypes from 'prop-types';
import React from 'react';
import {findIndex, map, reject, isEqual, filter} from 'lodash';
import classNames from 'classnames';
import {FixedDataTable2} from 'react-techstack';
const { Cell } = FixedDataTable2;
import {asyncStatusTypes, asyncStatusUtils} from 'react-techstack/utils';

import Sidepanel from 'modules/shared/components/Sidepanel';
import IssuerDataSidepanel from '../IssuerDataSidepanel';
import DataTable, {PaddedCell} from '../DataTable';
import MenuCell from '../MenuCell';
import AsPublishedHeaderCell from '../AsPublishedHeaderCell';
import AccountTitleWrapper from '../AccountTitleWrapper';
import ValueWrapper from '../ValueWrapper';
import AsPublishedCell from '../AsPublishedCell';
import {isNotEmptyString, splitStringByLine} from 'react-techstack/utils/string';
import {isAsPublished, hasVisibleComposites, recalculateDataAccounts} from '../utils';
import { sidePanelTypes } from 'modules/issuerData/utils/legacyDataViewUtils';

import theme from './LegacyTable.css';
const {asyncRequestType} = asyncStatusTypes;
const { isSuccessful } = asyncStatusUtils;

class LegacyTable extends React.Component {
  static propTypes = {
    currentIssuer: PropTypes.object,
    columns: PropTypes.arrayOf(PropTypes.object).isRequired,
    data: PropTypes.arrayOf(PropTypes.object).isRequired,

    onChangeCurrentSection: PropTypes.func.isRequired,
    enableLookBack: PropTypes.bool.isRequired,
    openLookBack: PropTypes.func.isRequired,
    enableRatioDrillDown: PropTypes.bool.isRequired,
    openRatioDrillDown: PropTypes.func.isRequired,
    openPrivacyOverrideSidePanel: PropTypes.func.isRequired,
    openAdjustmentsDetailsSidePanel: PropTypes.func.isRequired,
    reloadData: PropTypes.func.isRequired,

    sidePanelQuery: PropTypes.shape({
      accountId: PropTypes.string,
      statementRevisionId: PropTypes.string,
      sidePanelType: PropTypes.string
    }).isRequired,
    dataViewDisplayConfigRequest: asyncRequestType.isRequired,
    showSidepanel: PropTypes.bool.isRequired,
    isSidepanelCollapsed: PropTypes.bool.isRequired,
    sidePanelWidth: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
    sidepanelType: PropTypes.string.isRequired,
    resizeSidePanel: PropTypes.func.isRequired,
    toggleSidePanel: PropTypes.func.isRequired,
    closeSidePanel: PropTypes.func.isRequired,
    showEmptyRows: PropTypes.bool.isRequired,
    showAccountNumber: PropTypes.bool.isRequired,
    flipCoa: PropTypes.bool.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string
    }).isRequired
  };

  constructor(props) {
    super(props);

    this.state = {
      data: props.data,
      compositesToggled: false,
      selectedCell: null,
      columns: this.prepareColumns()
    };

    this.toggleComposites = this.toggleComposites.bind(this);
    this.header = this.header.bind(this);
    this.cell = this.cell.bind(this);
    this.onChangeTopRow = this.onChangeTopRow.bind(this);
  }

  UNSAFE_componentWillReceiveProps(props) {
    if (!isEqual(this.props.data, props.data)) {
      this.setState({
        data: props.data
      });
      this.setState({ selectedCell: null });
      props.closeSidePanel();
    }

    if (isSuccessful(props.dataViewDisplayConfigRequest.status) && !this.openedQueryPanel) {
      if (props.sidePanelQuery.sidePanelType === sidePanelTypes.ADJUSTMENTS) {
        const { statementRevisionId, accountId } = props.sidePanelQuery;
        if (props.data.find((a) => a.id === accountId) && props.columns.find((c) => c.key === statementRevisionId)) {
          this.openedQueryPanel = true;
          this.setState({ selectedCell: { accountId, statementRevisionId }});
          props.openAdjustmentsDetailsSidePanel(statementRevisionId, accountId);
        }
      }
    }

    if (!isEqual(this.props.showAccountNumber, props.showAccountNumber) || !isEqual(this.props.columns, props.columns)) {
      this.setState({
        columns: this.prepareColumns(props)
      });
    }

  }

  componentDidUpdate() {
    if (this.state.compositesToggled) {
      this.setState({compositesToggled: false});
    }

    if (!this.scrolledToSelectedCell && this.dataTable && this.dataTable.wrapped && this.props.sidePanelQuery.sidePanelType && !this.scrolledToSelectedCell) {
      const { statementRevisionId, accountId } = this.props.sidePanelQuery;
      this.dataTable.wrapped.find({ id: accountId }, 0, { key: statementRevisionId });
      this.scrolledToSelectedCell = true;
    }
  }

  onResizeSidePanel(width) {
    if (this.props.sidePanelWidth !== width) {
      this.props.resizeSidePanel(width);
    }
  }

  onChangeTopRow(row) {
    const id = row.rootSubSectionId || row.rootSectionId;
    this.props.onChangeCurrentSection(id);
  }

  prepareColumns = (props = this.props) => {
    return props.showAccountNumber
      ? props.columns
      : filter(props.columns, (item) => item.key !== 'number');
  }

  toggleSidePanel = (width) => {
    this.onResizeSidePanel(width);
    this.props.toggleSidePanel();
  };

  scrollToRowById = (id) => {
    this.dataTable.wrapped.find({id});
  };

  toggleComposites(account) {
    const { showEmptyRows, flipCoa } = this.props;
    const data = this.state.data.slice();
    const index = findIndex(data, {id: account.id});
    if (hasVisibleComposites(account)) {
      const length = account.composites.length;
      data.splice(index + 1, length);
      account.children.splice(0, length);
    } else {
      data.splice(index + 1, 0, ...account.composites);
      account.children.unshift(...account.composites);
    }

    this.setState({data: recalculateDataAccounts(data, showEmptyRows, flipCoa), compositesToggled: true});
  }

  header(column) {
    const className = classNames(theme.headerCell, { [theme.scrollableCell]: !column.fixed });
    const HeaderCellMenuProps = {
      key: `DataTable-HeaderCell-${column.key}` // ToDo: fix console warning about key property
    };

    if (!column.fixed) {
      HeaderCellMenuProps.openPrivacyOverrideSidePanel = () => this.props.openPrivacyOverrideSidePanel(column.key);
    }

    if (isAsPublished(column)) {
      return (
        <MenuCell {...HeaderCellMenuProps}>
          <AsPublishedHeaderCell title={column.label} />
        </MenuCell>
      );
    }

    const label = splitStringByLine(column.label).map((item) => {
      return isNotEmptyString(item) ? <span key={item} className={theme.headerLabelLine}>{item.trim()}</span> : null;
    });

    return (
      <MenuCell {...HeaderCellMenuProps}>
        <div className={className}>
          {label}
        </div>
      </MenuCell>
    );
  }

  cell(value, columnKey, row, cellProps) {
    const compositeClass = row.composite ? theme.composite : null;
    switch (columnKey) {
      case 'id':
        return (
          <Cell className={classNames(theme.wrapper, compositeClass)}>
            {(['ACCOUNT', 'RATIO_ACCOUNT'].indexOf(row.type) !== -1) ? value : ''}
          </Cell>
        );
      case 'number':
        return (
          <Cell className={classNames(theme.wrapper, compositeClass)}>
            {value}
          </Cell>
        );
      case 'name':
        const accountTitleProps = {
          type: row.type,
          accountId: row.id,
          className: compositeClass
        };

        if (this.props.enableRatioDrillDown) {
          accountTitleProps.openRatioDrillDown = () => {
            this.props.openRatioDrillDown(this.props.currentIssuer, row.id,
              reject(map(this.props.columns, 'key'), (item) => ['id', 'name'].indexOf(item) !== -1));
          };
        }

        const paddedCellProps = {
          value,
          level: row.level,
          className: classNames(theme.wrapper, theme.padded, {
            [theme.sectionTitle]: ['SECTION', 'RATIO_SECTION'].indexOf(row.type) !== -1
          }),
          account: row,
          toggleComposites: this.toggleComposites
        };

        return (
          <AccountTitleWrapper {...accountTitleProps}>
            <PaddedCell {...paddedCellProps} />
          </AccountTitleWrapper>
        );
      default:
        const column = this.props.columns.find(({ key }) => key === columnKey);
        const valueCellProps = {
          type: row.type,
          value: value || {},
          // statementRevisionId: column.key,
          // statementId: column.statementId,
          // accountId: row.id,
          issuer: this.props.currentIssuer,
          openAdjustmentsDetailsSidePanel: () => {
            this.setState({ selectedCell: { accountId: row.id, statementRevisionId: column.key } });
            this.props.openAdjustmentsDetailsSidePanel(column.key, row.id);
          },
          // openAdjustments: (cur, params) => {
            // this.props.openAdjustments(cur, params);
          // },
          // currency: this.props.filterValues && this.props.filterValues.local_ind.id,
          // scale: this.props.filterValues && this.props.filterValues.scale.id,
          height: cellProps.height,
          className: compositeClass
        };

        if (this.props.enableLookBack) {
          valueCellProps.openLookBack = () => {
            this.props.openLookBack({id: column.statementId, revisionDate: column.revisionDateStr}, row.id);
          };
        }

        if (this.props.enableRatioDrillDown) {
          valueCellProps.openRatioDrillDown = () => {
            this.props.openRatioDrillDown(this.props.currentIssuer, row.id, column.key);
          };
        }

        if (isAsPublished(column)) {
          return <AsPublishedCell {...valueCellProps} />;
        }

        // const { selectedCell = {} } = this.props;
        const selectedCell = this.state.selectedCell || {};
        const isSelected = selectedCell.accountId === row.id && selectedCell.statementRevisionId === column.key;
        return (
          <Cell className={classNames(theme.wrapper, compositeClass, { [theme.selectedCell]: isSelected })}>
            <ValueWrapper {...valueCellProps} />
          </Cell>
        );
    }
  }

  renderSidePanel() {
    if (!this.props.showSidepanel) {
      return null;
    }

    const {sidepanelType, isSidepanelCollapsed, closeSidePanel, reloadData} = this.props;

    const sidepanelProps = {
      heading: sidepanelType === sidePanelTypes.ACCOUNTS_PRIVACY ? 'Privacy' : undefined,
      show: !isSidepanelCollapsed,
      onHide: this.toggleSidePanel,
      onShow: this.toggleSidePanel,
      close: () => {
        this.setState({ selectedCell: null });
        closeSidePanel();
      },
      onResize: (event, width) => {
        this.onResizeSidePanel(width);
      }
    };

    const onSuccess = () => reloadData();

    return (
      <div className={theme.sidePanel}>
        <Sidepanel {...sidepanelProps}>
          <IssuerDataSidepanel height="100%" onSuccess={onSuccess} />
        </Sidepanel>
      </div>
    );
  }

  render() {
    const { theme: customTheme } = this.props;

    if (this.state.data.length === 0) {
      return null;
    }

    const DataTableProps = {
      columns: this.state.columns,
      data: this.state.data,
      header: this.header,
      cell: this.cell,
      isTreeView: true,
      type: 'bordered',
      width: 'auto',
      height: 'auto',
      headerHeight: 45,
      rowHeight: 30,
      onChangeTopRow: this.onChangeTopRow,
      compositesToggled: this.state.compositesToggled,
      ref: (component) => {
        this.dataTable = component;
      }
    };

    return (
      <div className={classNames(theme.root, customTheme.root)}>
        <div style={{marginRight: this.props.sidePanelWidth}}>
          <DataTable {...DataTableProps} />
        </div>
        {this.renderSidePanel()}
      </div>
    );
  }
}

LegacyTable.defaultProps = {
  theme: {}
};

export default LegacyTable;
