/* eslint-disable react/no-set-state */
import PropTypes from 'prop-types';

import React from 'react';
import { Input, Checkbox, DataTable, Alert } from 'react-techstack';
import theme from './AccountsTable.css';

import { getMessage } from 'modules/common/utils/messagesUtils';

class AccountsTable extends React.Component {
  static propTypes = {
    accounts: PropTypes.arrayOf(PropTypes.object).isRequired,
    allAccountsSelected: PropTypes.bool,
    selectable: PropTypes.bool,
    selectAccountForPrivacyChange: PropTypes.func,
    toggleAllAccountsSelected: PropTypes.func
  };

  constructor(props) {
    super(props);

    this.headerCell = this.headerCell.bind(this);
    this.cell = this.cell.bind(this);
    this.onFilterInputChange = this.onFilterInputChange.bind(this);
    this.state = {
      filterText: null
    };
  }

  onFilterInputChange(e) {
    this.setState({filterText: e.target.value});
  }

  headerCell({columnKey}, headerCellContent) {
    if (columnKey === 'selected') {
      const {accounts, allAccountsSelected, toggleAllAccountsSelected} = this.props;

      return (
        <Checkbox disabled={accounts.length === 0} checked={allAccountsSelected} onClick={toggleAllAccountsSelected}/>
      );
    }

    return headerCellContent;
  }

  cell(cellData, cellDataKey, row) {
    if (cellDataKey === 'selected') {
      return (
        <div className={theme.rowCheckbox}>
          <Checkbox checked={row.selected} onClick={() => this.props.selectAccountForPrivacyChange(row)}/>
        </div>
      );
    }

    return cellData;
  }

  render() {
    const {accounts, selectable} = this.props;

    if (accounts.length === 0) {
      return <Alert bsStyle="warning">No ratios found.</Alert>;
    }

    const columns = [
      {key: 'id', label: getMessage('issuer.dataView.titles.idColumn'), width: 60},
      {key: 'description', label: getMessage('issuer.dataView.titles.accountNameColumn')}
    ];
    if (selectable) {
      columns.unshift({key: 'selected', width: 45});
    }
    const props = {
      data: accounts,
      columns,
      headerCell: this.headerCell,
      cell: this.cell,
      width: 400,
      height: accounts.length === 0 ? 40 : 200,
      rowHeight: 30,
      headerHeight: 30,
      filterText: this.state.filterText
    };

    return (
      <div className={theme.root}>
        <div className={theme.filterInput}>
          <Input type="text" placeholder="Search..." onChange={this.onFilterInputChange}/>
        </div>
        <DataTable {...props} />
      </div>
    );
  }
}

export default AccountsTable;
