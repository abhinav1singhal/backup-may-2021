import PropTypes from 'prop-types';
import React from 'react';
import { throttle, isEmpty } from 'lodash';
import classNames from 'classnames';
import { FixedDataTable2, ArrowIcon } from 'react-techstack';
const { Cell } = FixedDataTable2;
import { hasVisibleComposites } from '../../utils';

import theme from './PaddedCell.css';

const PAD_PER_LEVEL = 15;

class PaddedCell extends React.Component {
  static propTypes = {
    value: PropTypes.node,
    level: PropTypes.number.isRequired,
    padPerLevel: PropTypes.number.isRequired,
    className: PropTypes.string,
    account: PropTypes.object.isRequired,
    toggleComposites: PropTypes.func
  };
  constructor(props) {
    super(props);
    this.toggleComposites = throttle(this.toggleComposites, 500, {trailing: false}).bind(this);
  }

  toggleComposites() {
    const { toggleComposites, account } = this.props;
    toggleComposites(account);
  }

  renderCompositeIcon() {
    if (!isEmpty(this.props.account.composites)) {
      return (
        <ArrowIcon
          isOpen={hasVisibleComposites(this.props.account)}
          isDisabled={false}
          onMouseDown={this.toggleComposites}
          classNames={{wrapper: theme.icon}}
        />
      );
    }
    return null;
  }

  render() {
    const { value, level, padPerLevel, className, ...props } = this.props;
    const style = {
      marginLeft: level * padPerLevel
    };
    const rootClassName = classNames(theme.root, className);
    return (
      <Cell {...props} style={style} className={rootClassName}>
        {value}
        { this.renderCompositeIcon() }
      </Cell>
    );
  }
}

PaddedCell.defaultProps = {
  level: 0,
  padPerLevel: PAD_PER_LEVEL
};

export default PaddedCell;
