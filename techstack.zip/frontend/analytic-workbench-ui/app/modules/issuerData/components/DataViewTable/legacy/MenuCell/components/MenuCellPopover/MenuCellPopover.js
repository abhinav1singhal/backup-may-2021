import PropTypes from 'prop-types';
import React from 'react';
import { Popover } from 'react-techstack';
import omit from 'lodash/omit';
import theme from './MenuCellPopover.css';

class MenuCellPopover extends React.Component {

  static propTypes = {
    options: PropTypes.arrayOf(PropTypes.object).isRequired,
    hide: PropTypes.func.isRequired
  };

  onOptionClick(callBack) {
    callBack();
    this.props.hide();
  }

  render() {
    const {options, ...restProps} = this.props;
    const linkProps = {
      className: `btn ${theme.menuBtn}`
    };

    return (
      <Popover {...omit(restProps, ['container', 'hide', 'transitionAppear'])} id="menu-cell-popover">
        <ul className={theme.btnList}>
          {options.map(({label, onClick}, i) => {
            return <li key={i}><a {...linkProps} onClick={() => this.onOptionClick(onClick)}>{label}</a></li>;
          })}
        </ul>
      </Popover>
    );
  }
}

export default MenuCellPopover;
