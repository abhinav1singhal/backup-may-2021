import PropTypes from 'prop-types';
import React from 'react';
import { Button } from 'react-techstack';

import theme from './SectionsFilterHeader.css';

const SectionsFilterHeader = ({ selectAll, deselectAll }) => {
  const btnProps = {
    bsStyle: 'link',
    className: theme.button
  };

  return (
    <div className={theme.root}>
      <div className={theme.title}>Select Section(s)</div>
      <Button {...btnProps} onClick={selectAll}>Select all</Button>
      <Button {...btnProps} onClick={deselectAll}>Deselect all</Button>
    </div>
  );
};

SectionsFilterHeader.propTypes = {
  selectAll: PropTypes.func.isRequired,
  deselectAll: PropTypes.func.isRequired
};

export default SectionsFilterHeader;
