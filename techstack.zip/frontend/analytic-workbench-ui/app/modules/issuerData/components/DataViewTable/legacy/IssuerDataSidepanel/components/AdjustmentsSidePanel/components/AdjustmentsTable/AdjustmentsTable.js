import PropTypes from 'prop-types';
import React from 'react';
import { Table } from 'react-techstack';
import classNames from 'classnames';
import StyledCell from '../../../StyledCell';

import { displayValue } from 'modules/issuerData/utils/legacyDataViewUtils';

import theme from './AdjustmentsTable.css';

export default class AdjustmentsTable extends React.Component {
  static propTypes = {
    data: PropTypes.array.isRequired,
    columns: PropTypes.arrayOf(
      PropTypes.shape({
        key: PropTypes.string.isRequired,
        title: PropTypes.string.isRequired,
        width: PropTypes.oneOfType([
          PropTypes.string, PropTypes.number
        ])
      })
    ).isRequired,
    totalAmount: PropTypes.string,
    selectedRow: PropTypes.string,

    onRowClick: PropTypes.func.isRequired
  };

  renderFooter(totalAmount) {
    if (!totalAmount) {
      return null;
    }

    return (
      <tfoot>
      <tr>
        <th>Totals</th>
        <th>{displayValue(totalAmount)}</th>
      </tr>
      </tfoot>
    );
  }

  render() {
    const {totalAmount, columns, data, selectedRow, onRowClick} = this.props;

    return (
      <div className={theme.tableContainer}>
        <Table>
          <thead>
          <tr>
            {columns.map(({key, width, title}) => {
              return <th key={key} width={width || 'auto'}>{displayValue(title)}</th>;
            })}
          </tr>
          </thead>
          {this.renderFooter(totalAmount)}
          <tbody>
          {data.map((row, index) => {
            const props = {
              key: `AdjustmentsTable-Row-${row.uuid || row.id}-${index}`,
              onClick: () => onRowClick(row.uuid || row.id),
              className: classNames({
                [theme.adjustmentsRow]: true,
                [theme.selected]: row.uuid && (row.uuid === selectedRow)
              })
            };

            return (
              <tr {...props}>
                <td>{displayValue(row.description)}</td>
                <td><StyledCell data={{private: row.private}}>{displayValue(row.amount)}</StyledCell></td>
              </tr>
            );
          })}
          </tbody>
        </Table>
      </div>
    );
  }
}
