import PropTypes from 'prop-types';
import React from 'react';
import { Select  } from 'react-techstack';
import classNames from 'classnames';

import {getUniqueAccountList} from '../utils';

import theme from './AccountSearch.css';

class AccountSearch extends React.Component {

  static propTypes = {
    data: PropTypes.array.isRequired,
    selectedActionId: PropTypes.number,
    selectViewedIssuerAccount: PropTypes.func.isRequired,

    theme: PropTypes.object.isRequired
  };

  constructor(props) {
    super(props);
    this.state = this.prepareData(props.data, props.selectedActionId);
  }

  UNSAFE_componentWillReceiveProps(props) {
    this.setState(this.prepareData(props.data, props.selectedActionId));  // eslint-disable-line react/no-set-state
  }

  onChange = (item) => {
    if (!item) {
      return;
    }
    this.props.selectViewedIssuerAccount(item.id, item.sectionId);
  };

  prepareData(issuerData = [], selectedActionId) {
    const options = [];
    const flattenData = getUniqueAccountList(issuerData);
    let selectedOption = null;

    flattenData.forEach(({accountId, accountName, accountNumber, sectionId, isRatio = false}) => {
      const label = (`${accountId} - ${isRatio ? 'Ratio - ' : ''} ${accountName} ${accountNumber}`).trim();
      const item = {
        id: accountId,
        sectionId,
        label,
        value: label
      };

      options.push(item);
      if (selectedActionId === accountId) {
        selectedOption = item;
      }
    });

    return ({options, selectedOption});
  }

  render() {
    const {options, selectedOption} = this.state;

    const selectProps = {
      multi: false,
      backspaceRemoves: false,
      clearable: true,
      options,
      onChange: this.onChange,
      disabled: options.length === 0,
      placeholder: 'Search by Account Name',
      wrapperClassName: theme.wrapper,
      theme: 'noBorder',
      value: selectedOption,
      bsSize: 'small'
    };

    return (
      <div className={classNames(theme.root, this.props.theme.root)}>
        <Select  {...selectProps}/>
      </div>
    );
  }
}

AccountSearch.defaultProps = {
  theme: {}
};

export default AccountSearch;
