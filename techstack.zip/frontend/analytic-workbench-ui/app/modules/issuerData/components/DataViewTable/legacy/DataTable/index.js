export default from './DataTable';

import { FixedDataTable2 } from 'react-techstack';
const { Cell } = FixedDataTable2;

export {
  PaddedCell,
  ToggleCell,
  ToggleHeaderCell
} from './components';
export { Cell };
