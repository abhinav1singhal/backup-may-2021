import PropTypes from 'prop-types';
import React from 'react';
import { Select } from 'react-techstack';
import theme from './HorizontalSelect.css';

class HorizontalSelect extends React.Component {

  static propTypes = {
    label: PropTypes.string
  };

  render() {
    const {label, ...props} = this.props;

    return (
      <div className={theme.horizontalSelect}>
        <div className={theme.label}>{label}</div>
        <div className={theme.select}><Select {...props} /></div>
      </div>
    );
  }
}

export default HorizontalSelect;
