import { connect } from 'react-redux';

import MenuCell from './MenuCell';

export function mapStateToProps(state) {
  return {
    userPermissions: state.user.permissions
  };
}

export default connect(mapStateToProps)(MenuCell);
