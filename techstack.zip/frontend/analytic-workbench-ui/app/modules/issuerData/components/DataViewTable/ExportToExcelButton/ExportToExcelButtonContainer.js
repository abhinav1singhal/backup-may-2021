import { connect } from 'react-redux';

import {exportDataToExcel} from 'modules/issuerData/actions/dataViewActions';

import ExportToExcelButton from './ExportToExcelButton';

function mapStateToProps(state) {
  return {
    userPermissions: state.user.permissions
  };
}

const mapDispatchToProps = {
  exportDataToExcel
};

export default connect(mapStateToProps, mapDispatchToProps)(ExportToExcelButton);
