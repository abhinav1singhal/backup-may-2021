import { connect } from 'react-redux';

import DataTableNavigator from './DataTableNavigator';

function mapStateToProps(state) {
  return {
    userPermissions: state.user.permissions
  };
}

export default connect(mapStateToProps, undefined, undefined, {forwardRef: true})(DataTableNavigator);
