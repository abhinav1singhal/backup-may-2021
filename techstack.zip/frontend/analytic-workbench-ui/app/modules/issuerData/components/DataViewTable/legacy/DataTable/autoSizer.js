/* eslint-disable react/no-set-state */
import PropTypes from 'prop-types';

import React from 'react';
import ReactDOM from 'react-dom';
import { throttle, isEqual } from 'lodash';


const decorator  = (Component) => {
  return class AutoSizer extends React.Component {
    static propTypes = {
      width: PropTypes.any.isRequired,
      height: PropTypes.any
    };

    constructor(props) {
      super(props);
      const { width, height } = props;

      this.state = {
        width: width === 'auto' ? 0 : width,
        height: height === 'auto' ? 0 : height
      };

      this.onResize = throttle(this.onResize.bind(this), 300, { leading: false, trailing: true });
    }

    shouldComponentUpdate(props, state) {
      return !isEqual(this.props, props) || !isEqual(this.state, state);
    }

    UNSAFE_componentWillReceiveProps() {
      this.onResize();
    }

    componentDidMount() {
      if (this.shouldAutoSize()) {
        this.onResize();
        window.addEventListener('resize', this.onResize);
      }
    }

    componentWillUnmount() {
      if (this.shouldAutoSize()) {
        window.removeEventListener('resize', this.onResize);
      }
    }

    onResize() {
      if (!this.root) {
        return;
      }
      const rect = ReactDOM.findDOMNode(this.root).getBoundingClientRect();
      const height = window.innerHeight - rect.top - 28;
      // TODO: Resizing table if it's inner height is lower than default height to the bottom of the page
      // if (this.wrapped) {
      //   const { _contentHeight } = this.wrapped.table;
      //   height = height > _contentHeight ? _contentHeight : height;
      // }

      const { offsetWidth } = this.root;

      this.setState({
        width: this.autoWidth() ? offsetWidth : this.state.width,
        height: this.autoHeight() ? height : this.state.height
      });
    }

    wrappedRef = (el) => {
      this.wrapped = el;
    }

    rootRef = (el) => {
      this.root = el;
    }

    autoWidth() {
      return this.props.width === 'auto';
    }

    autoHeight() {
      return this.props.height === 'auto';
    }

    shouldAutoSize() {
      return this.autoHeight() || this.autoWidth();
    }

    render() {
      const { width, height } = this.state;
      const rootStyle = {
        width: this.autoWidth() ? '100%' : width,
        height: this.autoHeight() ? '100%' : height,
        overflow: 'hidden'
      };
      const componentProps = {
        ...this.props,
        width,
        height,
        ref: this.wrappedRef
      };

      return (
        <div ref={this.rootRef} style={rootStyle}>
          {width && height ? <Component {...componentProps} /> : null}
        </div>
      );
    }
  };
};

export default decorator;
