import PropTypes from 'prop-types';
import React from 'react';
import { FixedDataTable2 } from 'react-techstack';
const { Cell } = FixedDataTable2;
import classNames from 'classnames';
import ValueWrapper from '../ValueWrapper';

import theme from './AsPublishedCell.css';

class AsPublishedCell extends React.Component {
  static propTypes = {
    type: PropTypes.string,
    className: PropTypes.string,
    value: PropTypes.shape({
      title: PropTypes.string,
      value: PropTypes.string,
      adjusted: PropTypes.bool,
      privacy: PropTypes.bool
    }).isRequired
  };

  render() {
    const { value, value: {title}, className, ...cellProps } = this.props;
    return (
      <Cell className={classNames(theme.wrapper, className)}>
        <div className={theme.asPublished}>
          <div className={theme.title}>{title}</div>
          <div className={theme.spacer} />
          <div className={theme.value}>
            <ValueWrapper {...cellProps} value={value} />
          </div>
        </div>
      </Cell>
    );
  }
}

AsPublishedCell.defaultProps = {
  value: {}
};

export default AsPublishedCell;
