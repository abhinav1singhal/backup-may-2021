import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import {Checkbox} from 'react-techstack';
import {asyncStatusTypes} from 'react-techstack/utils';

import ConfigForm from './ConfigForm';
import {DataTableNavigator, AccountSearch} from '../DataViewTable/legacy';
import { isLobWithAccountNumber } from '../DataViewTable/legacy/utils';
import {shouldLoadDataViewDisplayConfig} from 'modules/issuerData/utils/dataViewDisplayConfigUtils';
import { getMessage } from 'modules/common/utils/messagesUtils';
import { get } from 'lodash';

import theme from './DataViewDisplayConfig.css';
const {asyncRequestType} = asyncStatusTypes;

class DataViewDisplayConfig extends React.Component {
  static propTypes = {
    currentIssuer: PropTypes.object,
    config: PropTypes.object.isRequired,
    showEmptyRows: PropTypes.bool.isRequired,
    showAccountNumber: PropTypes.bool.isRequired,
    flipCoa: PropTypes.bool.isRequired,
    sections: PropTypes.arrayOf(PropTypes.object).isRequired,
    selectedSections: PropTypes.array.isRequired,
    tableData: PropTypes.arrayOf(PropTypes.object).isRequired,

    loadDataViewDisplayConfig: PropTypes.func.isRequired,
    changeDataViewDisplayConfig: PropTypes.func.isRequired,
    changeShowEmptyRows: PropTypes.func.isRequired,
    changeShowAccountNumber: PropTypes.func.isRequired,
    changeFlipCoa: PropTypes.func.isRequired,
    changeSectionsFilter: PropTypes.func.isRequired,
    scrollTableToRowById: PropTypes.func.isRequired,

    dataViewDisplayConfigRequest: asyncRequestType.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string
    }).isRequired
  };

  UNSAFE_componentWillReceiveProps(props) {
    if (shouldLoadDataViewDisplayConfig(props, this.props)) {
      props.loadDataViewDisplayConfig(props.currentIssuer);
    }
  }

  changeCurrentSection = (currentSectionId) => {
    this.sectionsFilter && this.sectionsFilter.changeCurrentSectionId(currentSectionId);
  };

  renderAccountNumberCheckbox = () => {
    const { currentIssuer, showAccountNumber, changeShowAccountNumber } = this.props;

    if (!isLobWithAccountNumber(get(currentIssuer, 'lobId'))) {
      return null;
    }

    return (<Checkbox
      label={getMessage('issuer.dataView.titles.showAccountNumber')}
      checked={showAccountNumber}
      onClick={() => changeShowAccountNumber(!showAccountNumber)}
      className={theme.configCheckbox}
    />);
  };

  render() {
    const {
      config, showEmptyRows, sections, selectedSections, tableData, currentIssuer,
      changeDataViewDisplayConfig, changeShowEmptyRows, changeSectionsFilter, scrollTableToRowById,
      theme: customTheme, changeFlipCoa, flipCoa
    } = this.props;

    const DataTableNavigatorProps = {
      sections,
      selectedSections,
      onChangeSelectedSections: changeSectionsFilter,
      onChangeCurrentSection: scrollTableToRowById,
      ref: (component) => {
        this.sectionsFilter = component;
      },
      theme: {
        root: theme.sectionsFilter
      }
    };

    const AccountSearchProps = {
      data: tableData,
      selectViewedIssuerAccount: scrollTableToRowById,
      theme: {
        root: theme.accountSearch
      }
    };

    const showEmptyRowsCheckboxProps = {
      label: getMessage('issuer.dataView.titles.showEmptyRows'),
      checked: showEmptyRows,
      onClick: () => changeShowEmptyRows(!showEmptyRows),
      className: theme.configCheckbox
    };

    const flipCoaCheckboxProps = {
      label: getMessage('issuer.dataView.titles.flipCoa'),
      checked: flipCoa,
      onClick: () => changeFlipCoa(!flipCoa),
      className: theme.configCheckbox
    };

    const ConfigFormProps = {
      controls: config.getControlsList(),
      options: config.getDictionaries(),
      data: config.getControlsValues(),
      onChange: (displayConfigValues) => changeDataViewDisplayConfig(currentIssuer, displayConfigValues),
      theme: {
        root: theme.filters,
        controlGroup: theme.controlGroup,
        controlLabel: theme.controlLabel
      }
    };

    return (
      <div className={classNames(theme.root, customTheme.root)}>
        <DataTableNavigator {...DataTableNavigatorProps} />
        <AccountSearch {...AccountSearchProps} />
        <Checkbox {...showEmptyRowsCheckboxProps} />
        {this.renderAccountNumberCheckbox()}
        <Checkbox {...flipCoaCheckboxProps} />
        <ConfigForm {...ConfigFormProps} />
      </div>
    );
  }
}

DataViewDisplayConfig.defaultProps = {
  theme: {}
};

export default DataViewDisplayConfig;
