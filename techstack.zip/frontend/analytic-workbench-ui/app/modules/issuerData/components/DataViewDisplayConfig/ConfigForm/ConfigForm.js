import PropTypes from 'prop-types';
import React from 'react';

import FormBuilder, { FormComponent } from 'react-techstack/FormBuilder';

class ConfigForm extends FormComponent {
  static propTypes = {
    ...FormComponent.propTypes,

    controls: PropTypes.arrayOf(PropTypes.object).isRequired,

    onChange: PropTypes.func.isRequired,

    theme: PropTypes.shape({
      root: PropTypes.string,
      controlGroup: PropTypes.string,
      controlLabel: PropTypes.string
    }).isRequired
  };

  render() {
    const {controls, data, onChange, theme} = this.props;

    const FormBuilderProps = {
      ...this.prepareFormConstructorProps('DataFilters'),
      controls,
      onChange: (key, value) => onChange({...data, [key]: value}),
      customFieldLabel: ({label}) => label,
      theme
    };

    return <FormBuilder {...FormBuilderProps}/>;
  }
}

ConfigForm.defaultProps = {
  ...FormComponent.defaultProps,

  theme: {}
};

export default ConfigForm;
