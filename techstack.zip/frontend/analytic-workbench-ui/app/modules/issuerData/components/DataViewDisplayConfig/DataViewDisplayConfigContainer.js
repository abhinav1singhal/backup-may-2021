import { connect } from 'react-redux';

import {
  loadDataViewDisplayConfig, changeDataViewDisplayConfig, changeShowEmptyRows,
  changeShowAccountNumber, changeSectionsFilter, changeFlipCoa
} from 'modules/issuerData/actions/dataViewDisplayConfigActions';

import DataViewDisplayConfig from './DataViewDisplayConfig';

function mapStateToProps(state) {
  return {
    currentIssuer: state.issuer.currentIssuer,
    config: state.issuerDataView.displayConfig,
    showEmptyRows: state.issuerDataView.showEmptyRows,
    showAccountNumber: state.issuerDataView.showAccountNumber,
    flipCoa: state.issuerDataView.flipCoa,
    sections: state.issuerDataView.sections,
    selectedSections: state.issuerDataView.sectionsFilter,
    tableData: state.issuerDataView.tableData,

    dataViewDisplayConfigRequest: state.requests.issuerDataViewDisplayConfig
  };
}

const mapDispatchToProps = {
  loadDataViewDisplayConfig,
  changeDataViewDisplayConfig,
  changeShowEmptyRows,
  changeShowAccountNumber,
  changeFlipCoa,
  changeSectionsFilter
};

export default connect(mapStateToProps, mapDispatchToProps, undefined, {forwardRef: true})(DataViewDisplayConfig);
