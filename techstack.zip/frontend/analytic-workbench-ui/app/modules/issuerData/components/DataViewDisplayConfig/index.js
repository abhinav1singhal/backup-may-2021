export default from './DataViewDisplayConfigContainer';
