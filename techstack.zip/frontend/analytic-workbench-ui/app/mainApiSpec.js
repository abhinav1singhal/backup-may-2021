/* global beforeEach*/
require('babel-register');

const path = require('path');
const frisby = require('frisby');
const joi = require('joi');
const glob = require('glob');
const config = require('../tools/config').default;

function addJoiMatcher() {
  this.addMatchers({
    toHaveJoiSchema: function toHaveJoiSchema(schema, options) {
      const defaultOptions = {
        convert: false,
        allowUnknown: false
      };
      const validationResult = joi.validate(this.actual, schema, Object.assign({}, defaultOptions, options));
      this.message = () => {
        const details = validationResult.error.details[0];
        return `${details.message} at ${details.path}`;
      };
      return validationResult.error === null;
    }
  });
}

beforeEach(addJoiMatcher);

frisby.globalSetup({
  timeout: 100000000,
  request: {
    headers: {
      'Cache-Control': 'no-cache',
      'Content-Type': 'application/json;charset=UTF-8',
      cookie: `JSESSIONID=${config.JSESSIONID}`
    },
    json: true
  }
});

const BASE_URL = `${config.PROXY_URL}/${config.PROXY_URL_APP}`;

const dir = path.join(__dirname, 'modules');

glob.sync(`${dir}/**/*ApiSpec.js`).forEach((file) => {
  require(file).default(BASE_URL);
});
